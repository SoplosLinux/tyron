function fish_prompt
    set_color ff7d2e
    echo -n (whoami)@(hostname)
    set_color normal
    echo -n ':'
    set_color fec431
    echo -n (string replace $HOME '~' $PWD)
    set_color normal
    echo -n '$ '
end
