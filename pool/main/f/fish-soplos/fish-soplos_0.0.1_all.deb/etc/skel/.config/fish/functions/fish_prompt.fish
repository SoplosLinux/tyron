function fish_prompt
    set_color ff7d2e
    echo -n (whoami)@(hostname)
    set_color normal
    echo -n ':'
    set_color fec431
    echo -n (prompt_pwd)
    set_color normal
    echo -n '$ '
end
