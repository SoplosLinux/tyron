# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2026-04-24

### 🎉 Added
- **Complete modular rewrite**: core/, services/, ui/tabs/, config/, utils/ architecture.
- **Tabbed interface**: Themes, Wallpapers, Avatar, Panel & Dock — all in one window.
- **Wallpaper browser**: Scans system wallpaper directories, deduplicates symlinks, lazy-loads on tab activation.
- **Avatar manager**: Replaces Mugshot. Crop dialog for non-square images, writes to `~/.face` and AccountsService. Editable user data fields (Full Name, Email, Phone, Location).
- **Panel & Dock tab**: Integrated Docklike configuration (pinned apps, available apps, drag reorder).
- **Theme bundles (.sth)**: Export and import themes as tar.gz archives with manifest.json.
- **Screenshot previews**: `scrot` + `imagemagick` capture with `notify-send` notification, `wmctrl` desktop minimize/restore, and window iconify/deiconify.
- **Footer progress bar**: Soplos-standard `Gtk.Revealer` + `Gtk.ProgressBar` revealed for all operations.
- **Theme apply**: Correct XFCE restart sequence — `xfce4-panel --quit` + `pkill xfconfd` + apply + `xfdesktop --reload` + `Popen(xfce4-panel)`.
- **xfconf parsing**: Fixed parser to read `xfconf-query -lv` format (space-separated) instead of `key=value`.
- **Panel subdirectory support**: `launcher-N/` plugin directories handled with `copytree` on apply, backup and save.
- **Symlink deduplication**: Wallpaper scanner resolves symlinks via `Path.resolve()` to avoid duplicate entries.
- **App ID**: Migrated from `com.soplos.thememanager` to `org.soplos.thememanager`.
- **i18n**: gettext-based internationalization replacing legacy dict strings, 8 languages.
- **CSS**: Updated to Soplos welcome standard (entry, filechooser, treeview, notebook borders, etc.).

### 🔄 Changed
- Theme directory: `~/.themes-backup` (backwards compatible with v1 legacy).
- Default theme CSS: always dark for Soplos Linux Tyron, configurable via `settings.json`.
- Window decorations: SSD (no CSD), `GTK_CSD=0`.

### 🐛 Fixed
- Startup freeze: wallpapers now lazy-load via GTK `map` signal.
- Wrong startup tab: `set_current_page(0)` called after `show_all()`.
- Theme detection: reads `~/.themes-backup` (same as v1) instead of new separate directory.
- Avatar detection: checks `~/.face` → AccountsService icons → `Icon=` field in user file.
- Panel apply error: `[Errno 21] Is a directory` on `launcher-N/` subdirectories.
- Progress bar not visible: moved revealer before `ScrolledWindow` (footer pattern).
- pkexec password prompts on avatar: removed all `pkexec` — `~/.face` is sufficient on XFCE.

---

## [1.0.3] - 2025-07-27

### 🎨 Changed
- Program icon changed.
- Developer updated to Sergi Perich.

## [1.0.2] - 2025-07-18

### 🛠️ Improved
- Metainfo update for AppStream/DEP-11 compliance.
- Renamed screenshots to screenshot1.png, screenshot2.png, etc.
- Minor documentation and metadata improvements.
- No functional changes.

## [1.0.0] - 2025-05-08

### 🎉 Initial Release
- Graphical interface for managing XFCE desktop themes.
- Create, save and apply desktop themes.
- Compatible with Soplos Linux Tyron.
- Translations for 8 languages.

---

## Types of Changes

- **Added** for new features
- **Changed** for changes in existing functionality
- **Deprecated** for features to be removed soon
- **Removed** for now removed features
- **Fixed** for any bug fixes
- **Security** in case of vulnerabilities

## Contribute

To report bugs or request features:
- **Issues**: https://github.com/SoplosLinux/soplos-theme-manager/issues
- **Email**: info@soploslinux.com

## Support

- **Documentation**: https://soplos.org/wiki
- **Community**: https://soplos.org/
- **Support**: info@soploslinux.com
