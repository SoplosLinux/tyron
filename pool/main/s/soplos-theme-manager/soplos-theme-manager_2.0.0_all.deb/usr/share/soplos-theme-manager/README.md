# Soplos Theme Manager

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-2.0.0-green.svg)]()

Desktop theme manager for Soplos Linux Tyron (XFCE). Apply, create, export and import complete desktop themes with a single click.

## 📝 Description

Soplos Theme Manager is the official theme management tool for Soplos Linux Tyron. It provides a complete graphical interface to manage XFCE desktop themes, wallpapers, user avatar and panel dock configuration — all in one application.

## ✨ Features

- 🎨 **Theme Gallery**: Apply, create, export and import full XFCE desktop themes.
- 🖼️ **Wallpaper Browser**: Browse and apply wallpapers from system directories.
- 👤 **Avatar Manager**: Replace Mugshot — set user avatar with crop dialog and edit user data.
- 🔧 **Panel & Dock**: Integrated Docklike configuration panel.
- 📦 **Theme Bundles**: Export and import themes as `.sth` files (tar.gz + manifest).
- 📸 **Screenshot Previews**: Automatic screenshot capture with desktop minimize for theme cards.
- 📊 **Footer Progress Bar**: Soplos-standard progress indicator for all operations.
- 🌍 **Multi-language**: 8 languages (es, en, fr, pt, de, it, ru, ro).
- 🖥️ **Exclusive for XFCE**: Optimized for Soplos Linux Tyron — no multi-DE overhead.

## 🛠️ Requirements

- Python 3.6+
- GTK 3.0 / python3-gi
- XFCE4 (xfce4-panel, xfconf, xfwm4, xfdesktop4)
- scrot + imagemagick (for screenshot previews)
- wmctrl + libnotify-bin (for desktop minimize on screenshot)

## 📥 Installation

Available in the official Soplos Linux repositories:

```bash
sudo apt update
sudo apt install soplos-theme-manager
```

## 🚀 Usage

```bash
soplos-theme-manager
```

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Q` | Quit |
| `F1` | About dialog |

## 📸 Screenshots

### Theme Gallery
![Theme Gallery](https://raw.githubusercontent.com/SoplosLinux/soplos-theme-manager/main/assets/screenshots/screenshot1.png)

### Wallpaper Browser
![Wallpaper Browser](https://raw.githubusercontent.com/SoplosLinux/soplos-theme-manager/main/assets/screenshots/screenshot2.png)

### Avatar Manager
![Avatar Manager](https://raw.githubusercontent.com/SoplosLinux/soplos-theme-manager/main/assets/screenshots/screenshot3.png)

## 🌐 Supported Languages

| Language | Code |
|----------|------|
| Spanish  | es   |
| English  | en   |
| French   | fr   |
| Portuguese | pt |
| German   | de   |
| Italian  | it   |
| Russian  | ru   |
| Romanian | ro   |

## 📄 License

This project is licensed under [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Developer

Developed by Sergi Perich (<info@soploslinux.com>)

## 🔗 Links

- [Website](https://soplos.org/)
- [Report Issues](https://github.com/SoplosLinux/soplos-theme-manager/issues)
- [Help](https://soplos.org/wiki)
- [Donate](https://www.paypal.com/paypalme/isubdes)
