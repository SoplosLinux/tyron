"""
Traduções em português para Soplos GRUB Editor
"""

STRINGS = {
    # Títulos e cabeçalhos
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'Configurações Gerais',
    'entries_tab': 'Entradas de Inicialização',
    'appearance_tab': 'Aparência',
    
    # Botões comuns
    'save_button': 'Salvar',
    'apply_button': 'Aplicar',
    'close_button': 'Fechar',
    'cancel_button': 'Cancelar',
    'ok_button': 'OK',
    
    # Títulos de diálogos
    'error_title': 'Erro',
    'info_title': 'Informação',
    'warning_title': 'Aviso',
    'confirm_title': 'Confirmar',
    'question_title': 'Pergunta',
    
    # Mensagens gerais
    'changes_saved': 'Alterações salvas com sucesso',
    'changes_error': 'Erro ao salvar as alterações',
    'need_root': 'Privilégios de administrador necessários',
    'confirm_exit': 'Tem certeza de que deseja sair?',
    'unsaved_changes': 'As alterações não salvas serão perdidas.',
    
    # Aba Geral
    'timeout_label': 'Tempo limite (segundos):',
    'default_entry_label': 'Entrada padrão:',
    'resolution_label': 'Resolução da tela:',
    'kernel_params_label': 'Parâmetros do kernel:',
    'os_prober_label': 'Detectar outros sistemas operacionais',
    'show_menu_label': 'Mostrar menu de inicialização',
    'recovery_label': 'Incluir opções de recuperação',
    'advanced_options': 'Opções avançadas',
    'kernel_params_section': 'Parâmetros do kernel',
    
    # Aba Aparência
    'theme_section': 'Tema',
    'font_section': 'Fontes',
    'colors_section': 'Cores',
    'background_section': 'Fundo',
    'preview_label': 'Pré-visualização',
    'install_theme': 'Instalar tema...',
    'remove_theme': 'Remover tema',
    'disable_theme': 'Desativar tema',
    'select_font': 'Selecionar fonte...',
    'remove_font': 'Remover fonte',
    'font_size': 'Tamanho da fonte:',
    'text_color': 'Cor do texto:',
    'background_color': 'Cor do fundo:',
    'select_background': 'Selecionar fundo...',
    'remove_background': 'Remover fundo',
    'highlight_text_color': 'Cor do texto em destaque:',
    'highlight_background_color': 'Cor do fundo em destaque:',
    'apply_theme_button': 'Aplicar tema',
    
    # Aba Entradas
    'add_entry': 'Adicionar entrada',
    'edit_entry': 'Editar entrada',
    'remove_entry': 'Remover entrada',
    'entry_name': 'Nome:',
    'entry_type': 'Tipo:',
    'entry_kernel': 'Kernel:',
    'entry_initrd': 'Initrd:',
    'entry_params': 'Parâmetros:',
    'entry_path': 'Caminho',
    'entry_enabled': 'Habilitado',
    
    # Mensagens de status
    'ready': 'Pronto',
    'saving': 'Salvando...',
    'applying': 'Aplicando alterações...',
    'loading': 'Carregando...',
    'updating': 'Atualizando GRUB...',
    'grub_updated': 'GRUB atualizado com sucesso',
    
    # Diálogos específicos
    'select_font_dialog': 'Selecionar fonte',
    'select_theme_dialog': 'Selecionar tema',
    'select_background_dialog': 'Selecionar imagem de fundo',
    'font_filter': 'Fontes',
    'theme_filter': 'Arquivos de tema',
    'image_filter': 'Imagens',
    'all_files': 'Todos os arquivos',
    'open_button': 'Abrir',
    
    # Textos de resolução
    'resolution_disabled': 'Desativado',
    'resolution_auto': 'Automático',
    
    # Textos de entradas
    'last_selection': 'Última seleção',
    'default_entry_saved': 'Última seleção',
    
    # Ajuda e controles de fonte
    'font_help': 'Este método evita problemas com update-grub, modificando diretamente a configuração.',
    'font_select_help': 'Selecione um arquivo de fonte TTF ou OTF',
    'browse_button': 'Procurar...',
    'install_font_button': 'Instalar fonte',
    'apply_font_button': 'Aplicar fonte selecionada',
    'remove_font_button': 'Remover fonte selecionada',
    'delete_font_file_button': 'Excluir arquivo',
    
    # Avisos e confirmações
    'delete_font_confirm': 'Tem certeza de que deseja excluir esta fonte?',
    'delete_font_warning': 'O arquivo será excluído: {}\nEsta ação não pode ser desfeita.',
    'apply_font_confirm': 'Deseja aplicar esta fonte?',
    'apply_font_message': 'A fonte será aplicada: {}',
    'remove_theme_confirm': 'Remover o tema \'{}\'?',
    'disable_theme_confirm': 'Deseja remover o tema atual?',
    'disable_theme_message': 'O tema será desativado, mas não será removido do sistema',
    'update_grub_title': 'Atualizar GRUB',
    'update_grub_message': 'update-grub será executado para aplicar as alterações.',
    'apply_changes_title': 'Aplicar alterações?',
    'apply_changes_message': 'update-grub será executado para aplicar as alterações.',
    
    # Mensagens de sucesso
    'font_installed': 'Fonte instalada com sucesso em: {}',
    'font_removed': 'Fonte removida com sucesso',
    'font_removed_successfully': 'Fonte removida com sucesso',
    'font_deleted_successfully': 'Fonte excluída com sucesso',
    'font_applied_successfully': 'Fonte aplicada com sucesso',
    'theme_installed': 'Tema instalado com sucesso',
    'theme_applied': 'Tema aplicado com sucesso',
    'grub_theme_applied': 'Tema do GRUB aplicado com sucesso',
    'background_applied': 'Fundo configurado com sucesso',
    'background_removed': 'Fundo removido com sucesso',
    'entry_added': 'Entrada adicionada com sucesso',
    'entry_removed': 'Entrada removida com sucesso',
    'changes_applied': 'Alterações aplicadas com sucesso',
    'config_saved_successfully': 'Configuração salva com sucesso em custom.cfg',
    
    # Mensagens de erro
    'error_save': 'Erro ao salvar a configuração',
    'error_load': 'Erro ao carregar a configuração',
    'error_apply': 'Erro ao aplicar as alterações',
    'error_update': 'Erro ao atualizar o GRUB',
    'error_permission': 'Erro de permissão',
    'error_missing_deps': 'Dependências necessárias ausentes',
    'invalid_font': 'Por favor, selecione um arquivo de fonte válido',
    'font_error': 'Erro ao instalar a fonte: {}',
    'theme_error': 'Erro ao instalar o tema: {}',
    'background_error': 'Erro ao carregar a imagem: {}',
    'entry_error': 'Erro ao adicionar a entrada: {}',
    'entry_add_error': 'Erro ao adicionar entrada',
    'entry_name_kernel_required': 'Nome e kernel são obrigatórios',
    'entry_remove_error': 'Erro ao remover entrada',
    'no_entry_selected': 'Nenhuma entrada selecionada',
    'no_font_installed': 'Nenhuma fonte instalada no GRUB',
    'no_background_configured': 'Nenhum fundo está configurado',
    'config_save_error': 'Erro ao salvar a configuração',
    'config_save_error_path': 'Erro ao salvar a configuração em {}: {}',
    'colors_cannot_be_same': 'A cor do texto e a cor do fundo não podem ser iguais.',
    'highlight_colors_cannot_be_same': 'A cor do texto em destaque e a cor do fundo em destaque não podem ser iguais.',
    
    # Erros específicos do sistema
    'pkexec_error': 'Erro: Não foi possível obter privilégios de administrador.',
    'relaunch_error': 'Erro ao reiniciar como root: {}',
    'grub_config_not_found': 'Arquivo de configuração do GRUB não encontrado',
    'insufficient_permissions': 'Permissões insuficientes para acessar a configuração do GRUB',
    'initialization_error': 'Erro durante a inicialização: {}',
    'update_grub_error': 'Erro ao executar update-grub: {}',
    'cache_cleanup_error': 'Erro ao limpar o cache: {}',
    'background_remove_error': 'Erro ao remover o fundo: {}',
    'font_load_error': 'Erro ao carregar as fontes instaladas: {}',
    
    # Confirmações de saída
    'confirm_exit_title': 'Tem certeza de que deseja sair?',
    'confirm_exit_message': 'As alterações não salvas serão perdidas.',
    
    # Erros de fonte
    'invalid_font_file': 'O arquivo não é uma fonte válida',
    'font_not_exists': 'A fonte {} não existe',
    'font_convert_error': 'Erro ao converter fonte: {}',
    'font_install_error': 'Erro ao instalar fonte: {}',
    'font_convert_exception': 'Erro ao converter fonte: {}',
    'font_set_error': 'Erro ao configurar fonte: {}',
    'font_remove_error': 'Erro ao remover fonte: {}',
    'font_file_not_exists': 'Arquivo de fonte não existe',
    'font_not_in_grub_dir': 'Fonte não está no diretório de fontes do GRUB',
    'only_pf2_files_allowed': 'Apenas arquivos de fonte .pf2 podem ser excluídos',
    'font_deleted': 'Fonte excluída: {}',
    'font_delete_error': 'Erro ao excluir fonte: {}',
    'font_delete_exception': 'Erro ao excluir fonte: {}',
    
    # Atalhos de teclado
    'shortcut_save': 'Ctrl+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Atalhos de teclado',
    'shortcut_titles': {
        'save': 'Salvar (Ctrl+S)',
        'apply': 'Aplicar (Alt+A)',
        'close': 'Fechar (Alt+C)',
        'browse': 'Procurar (Alt+B)',
        'install': 'Instalar (Alt+I)',
        'remove': 'Remover (Alt+R)',
        'delete': 'Excluir (Del)',
        'add': 'Adicionar (Alt+N)',
        'edit': 'Editar (Alt+E)'
    },
    
    # Estados do sistema
    'no_theme_selected': 'Nenhum tema selecionado',
    'theme_preview_error': 'Erro ao gerar prévia do tema',
    'grub_theme_disabled': 'Tema do GRUB desativado',
    'custom_entry_saved': 'Entrada personalizada salva',
    'system_entry': 'Entrada do sistema',
    'custom_entry': 'Entrada personalizada',
    'entries_loaded': 'Entradas carregadas: {}',
    'grub_config_loaded': 'Configuração do GRUB carregada',
    'backup_created': 'Backup criado',
    'backup_restored': 'Backup restaurado',
    'permission_denied': 'Permissão negada',
    'file_not_found': 'Arquivo não encontrado',
    'invalid_configuration': 'Configuração inválida',
    'theme_installation_success': 'Tema instalado com sucesso em: {}',
    'theme_removal_success': 'Tema removido com sucesso',
    'operation_completed': 'Operação concluída',
    'operation_failed': 'Operação falhou',
    
    # Mensagens técnicas e de log (NOVO)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Erro ao definir ícone por nome: {}',
    'program_class_error': 'Erro ao definir program_class: {}',
    'directory_cleaned': 'Diretório limpo: {}',
    'directory_clean_error': 'Erro ao limpar {}: {}',
    
    # Mensagens de utils/theme_utils.py (NOVO)
    'file_format_not_supported': 'Formato de arquivo não suportado. Use .tar.gz, .tgz, .tar.xz ou .zip',
    'theme_directory_invalid': 'O diretório do tema não contém theme.txt',
    'invalid_path': 'O caminho especificado não é válido',
    'theme_disabled_successfully': 'Tema desativado com sucesso',
    'theme_preview_generation_error': 'Não foi possível gerar prévia: {}',
    'theme_txt_not_found': 'theme.txt não encontrado',
    'theme_decompress_error': 'Erro ao descomprimir o tema: {}',
    'theme_preview_generation_failed': 'Não foi possível gerar a prévia',
    
    # Mensagens de utils/system_utils.py (NOVO)
    'font_path_not_exists': 'A fonte {} não existe',
    'font_convert_stderr': 'Erro ao converter fonte: {}',
    'grub_config_updated': 'Configuração do GRUB atualizada com sucesso',
    
    # Mensagens de utils/font_utils.py (NOVO)
    'config_module_deprecated': 'O módulo \'config\' está obsoleto. Use \'app_paths\' em seu lugar.',
    'no_backup_to_restore': 'Não existe backup para restaurar',
    'config_restored_successfully': 'Configuração restaurada com sucesso',
    
    # Comentários de código gerado (NOVO)
    'disabled_by_soplos_grub_editor': '# Desativado pelo Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# Este arquivo fornece entradas personalizadas para GRUB\n\n',
}
