"""
Módulo de soporte para localización de la aplicación.
Reemplazo seguro para el directorio 'locale' anterior que causaba conflictos.
"""

from translations.strings import TRANSLATIONS

# Reexportar las traducciones para mantener compatibilidad
__all__ = ['TRANSLATIONS']
