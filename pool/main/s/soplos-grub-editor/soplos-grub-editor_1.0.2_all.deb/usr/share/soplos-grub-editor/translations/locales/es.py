"""
Traducciones en español para Soplos GRUB Editor
"""

STRINGS = {
    # Títulos y encabezados
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'Configuración general',
    'entries_tab': 'Entradas de arranque',
    'appearance_tab': 'Apariencia',
    
    # Botones comunes
    'save_button': 'Guardar',
    'apply_button': 'Aplicar',
    'close_button': 'Cerrar',
    'cancel_button': 'Cancelar',
    'ok_button': 'Aceptar',
    
    # Títulos de diálogos
    'error_title': 'Error',
    'info_title': 'Información',
    'warning_title': 'Advertencia',
    'confirm_title': 'Confirmar',
    'question_title': 'Pregunta',
    
    # Mensajes generales
    'changes_saved': 'Cambios guardados correctamente',
    'changes_error': 'Error al guardar los cambios',
    'need_root': 'Se requieren privilegios de administrador',
    'confirm_exit': '¿Está seguro de que desea salir?',
    'unsaved_changes': 'Los cambios no guardados se perderán.',
    
    # Pestaña General
    'timeout_label': 'Tiempo de espera (segundos):',
    'default_entry_label': 'Entrada predeterminada:',
    'resolution_label': 'Resolución de pantalla:',
    'kernel_params_label': 'Parámetros del kernel:',
    'os_prober_label': 'Detectar otros sistemas operativos',
    'show_menu_label': 'Mostrar menú de arranque',
    'recovery_label': 'Incluir opciones de recuperación',
    'advanced_options': 'Opciones avanzadas',
    'kernel_params_section': 'Parámetros del kernel',
    
    # Pestaña Apariencia
    'theme_section': 'Tema',
    'font_section': 'Fuentes',
    'colors_section': 'Colores',
    'background_section': 'Fondo',
    'preview_label': 'Vista previa',
    'install_theme': 'Instalar tema...',
    'remove_theme': 'Eliminar tema',
    'disable_theme': 'Desactivar tema',
    'select_font': 'Seleccionar fuente...',
    'remove_font': 'Eliminar fuente',
    'font_size': 'Tamaño de fuente:',
    'text_color': 'Color del texto:',
    'background_color': 'Color del fondo:',
    'select_background': 'Seleccionar fondo...',
    'remove_background': 'Quitar fondo',
    'highlight_text_color': 'Color del texto resaltado:',
    'highlight_background_color': 'Color del fondo resaltado:',
    'apply_theme_button': 'Aplicar tema',
    
    # Pestaña Entradas
    'add_entry': 'Añadir entrada',
    'edit_entry': 'Editar entrada',
    'remove_entry': 'Eliminar entrada',
    'entry_name': 'Nombre:',
    'entry_type': 'Tipo:',
    'entry_kernel': 'Kernel:',
    'entry_initrd': 'Initrd:',
    'entry_params': 'Parámetros:',
    'entry_path': 'Ruta',
    'entry_enabled': 'Habilitado',
    
    # Mensajes de estado
    'ready': 'Listo',
    'saving': 'Guardando...',
    'applying': 'Aplicando cambios...',
    'loading': 'Cargando...',
    'updating': 'Actualizando GRUB...',
    'grub_updated': 'GRUB actualizado correctamente',
    
    # Diálogos específicos
    'select_font_dialog': 'Seleccionar fuente',
    'select_theme_dialog': 'Seleccionar tema',
    'select_background_dialog': 'Seleccionar imagen de fondo',
    'font_filter': 'Fuentes',
    'theme_filter': 'Archivos de tema',
    'image_filter': 'Imágenes',
    'all_files': 'Todos los archivos',
    'open_button': 'Abrir',
    
    # Textos de resolución
    'resolution_disabled': 'Desactivado',
    'resolution_auto': 'Automático',
    
    # Textos de entradas
    'last_selection': 'Última selección',
    'default_entry_saved': 'Última selección',
    
    # Fuentes
    'font_help': 'Este método evita los problemas con update-grub modificando directamente la configuración.',
    'font_select_help': 'Seleccione un archivo de fuente TTF o OTF',
    'browse_button': 'Examinar...',
    'install_font_button': 'Instalar Fuente',
    'apply_font_button': 'Aplicar Fuente Seleccionada',
    'remove_font_button': 'Eliminar Fuente Seleccionada',
    'delete_font_file_button': 'Eliminar Archivo',
    
    # Confirmaciones y advertencias
    'delete_font_confirm': '¿Está seguro de que desea eliminar esta fuente?',
    'delete_font_warning': 'Se eliminará el archivo: {}\nEsta acción no se puede deshacer.',
    'apply_font_confirm': '¿Desea aplicar esta fuente?',
    'apply_font_message': 'Se aplicará la fuente: {}',
    'remove_theme_confirm': '¿Eliminar el tema \'{}\'?',
    'disable_theme_confirm': '¿Desea quitar el tema actual?',
    'disable_theme_message': 'El tema se deshabilitará pero no se eliminará del sistema',
    'update_grub_title': 'Actualizar GRUB',
    'update_grub_message': 'Se ejecutará update-grub para aplicar los cambios.',
    'apply_changes_title': '¿Aplicar cambios?',
    'apply_changes_message': 'Se ejecutará update-grub para aplicar los cambios.',
    
    # Mensajes de éxito
    'font_installed': 'Fuente instalada correctamente en: {}',
    'font_removed': 'Fuente eliminada correctamente',
    'font_removed_successfully': 'Fuente eliminada correctamente',
    'font_deleted_successfully': 'Fuente eliminada correctamente',
    'font_applied_successfully': 'Fuente aplicada correctamente',
    'theme_installed': 'Tema instalado correctamente',
    'theme_applied': 'Tema aplicado correctamente',
    'grub_theme_applied': 'Tema de GRUB aplicado correctamente',
    'background_applied': 'Fondo de pantalla configurado correctamente',
    'background_removed': 'Fondo de pantalla eliminado correctamente',
    'entry_added': 'Entrada añadida correctamente',
    'entry_removed': 'Entrada eliminada correctamente',
    'changes_applied': 'Cambios aplicados correctamente',
    'config_saved_successfully': 'Configuración guardada correctamente en custom.cfg',
    
    # Mensajes de error
    'error_save': 'Error al guardar la configuración',
    'error_load': 'Error al cargar la configuración',
    'error_apply': 'Error al aplicar los cambios',
    'error_update': 'Error al actualizar GRUB',
    'error_permission': 'Error de permisos',
    'error_missing_deps': 'Faltan dependencias requeridas',
    'invalid_font': 'Por favor seleccione un archivo de fuente válido',
    'font_error': 'Error al instalar la fuente: {}',
    'theme_error': 'Error al instalar el tema: {}',
    'background_error': 'Error al cargar la imagen: {}',
    'entry_error': 'Error al añadir la entrada: {}',
    'entry_add_error': 'Error al añadir la entrada',
    'entry_name_kernel_required': 'El nombre y el kernel son obligatorios',
    'entry_remove_error': 'Error al eliminar la entrada',
    'no_entry_selected': 'No se ha seleccionado ninguna entrada',
    'no_font_installed': 'No hay fuentes instaladas en GRUB',
    'no_background_configured': 'No hay fondo de pantalla configurado',
    'config_save_error': 'Error al guardar la configuración',
    'config_save_error_path': 'Error al guardar la configuración en {}: {}',
    'colors_cannot_be_same': 'El color del texto y el fondo no pueden ser iguales.',
    'highlight_colors_cannot_be_same': 'El color del texto marcado y su fondo no pueden ser iguales.',
    
    # Errores específicos del sistema
    'pkexec_error': 'Error: No se pudieron obtener privilegios de administrador.',
    'relaunch_error': 'Error al relanzar como root: {}',
    'grub_config_not_found': 'No se encontró el archivo de configuración de GRUB',
    'insufficient_permissions': 'No hay permisos suficientes para acceder a la configuración de GRUB',
    'initialization_error': 'Error al inicializar: {}',
    'update_grub_error': 'Error al ejecutar update-grub: {}',
    'cache_cleanup_error': 'Error al limpiar caché: {}',
    'background_remove_error': 'Error al eliminar el fondo de pantalla: {}',
    'font_load_error': 'Error al cargar las fuentes instaladas: {}',
    
    # Confirmaciones de salida
    'confirm_exit_title': '¿Está seguro de que desea salir?',
    'confirm_exit_message': 'Los cambios no guardados se perderán.',
    
    # Errores de fuentes
    'invalid_font_file': 'El archivo no es una fuente válida',
    'font_not_exists': 'La fuente {} no existe',
    'font_convert_error': 'Error al convertir la fuente: {}',
    'font_install_error': 'Error al instalar la fuente: {}',
    'font_convert_exception': 'Error al convertir la fuente: {}',
    'font_set_error': 'Error al configurar la fuente: {}',
    'font_remove_error': 'Error al eliminar la fuente: {}',
    'font_file_not_exists': 'El archivo de fuente no existe',
    'font_not_in_grub_dir': 'La fuente no está en el directorio de fuentes de GRUB',
    'only_pf2_files_allowed': 'Solo se pueden eliminar archivos de fuente .pf2',
    'font_deleted': 'Fuente eliminada: {}',
    'font_delete_error': 'Error al eliminar la fuente: {}',
    'font_delete_exception': 'Error al eliminar la fuente: {}',
    
    # Atajos de teclado
    'shortcut_save': 'Ctrl+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Atajos de teclado',
    'shortcut_titles': {
        'save': 'Guardar (Ctrl+S)',
        'apply': 'Aplicar (Alt+A)', 
        'close': 'Cerrar (Alt+C)',
        'browse': 'Examinar (Alt+B)',
        'install': 'Instalar (Alt+I)',
        'remove': 'Eliminar (Alt+R)',
        'delete': 'Eliminar (Supr)',
        'add': 'Añadir (Alt+N)',
        'edit': 'Editar (Alt+E)'
    },
    
    # Estados del sistema
    'no_theme_selected': 'No hay tema seleccionado',
    'theme_preview_error': 'Error al generar vista previa del tema',
    'grub_theme_disabled': 'Tema de GRUB deshabilitado',
    'custom_entry_saved': 'Entrada personalizada guardada',
    'system_entry': 'Entrada del sistema',
    'custom_entry': 'Entrada personalizada',
    'entries_loaded': 'Entradas cargadas: {}',
    'grub_config_loaded': 'Configuración de GRUB cargada',
    'backup_created': 'Copia de seguridad creada',
    'backup_restored': 'Copia de seguridad restaurada',
    'permission_denied': 'Permisos denegados',
    'file_not_found': 'Archivo no encontrado',
    'invalid_configuration': 'Configuración no válida',
    'theme_installation_success': 'Tema instalado correctamente en: {}',
    'theme_removal_success': 'Tema eliminado correctamente',
    'operation_completed': 'Operación completada',
    'operation_failed': 'Operación fallida',
    
    # Mensajes de log y técnicos (NUEVO)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Error estableciendo icono por nombre: {}',
    'program_class_error': 'Error estableciendo program_class: {}',
    'directory_cleaned': 'Directorio limpiado: {}',
    'directory_clean_error': 'Error al limpiar {}: {}',
    
    # Mensajes de utils/theme_utils.py (NUEVO)
    'file_format_not_supported': 'Formato de archivo no soportado. Use .tar.gz, .tgz, .tar.xz o .zip',
    'theme_directory_invalid': 'El directorio del tema no contiene theme.txt',
    'invalid_path': 'La ruta especificada no es válida',
    'theme_disabled_successfully': 'Tema deshabilitado correctamente',
    'theme_preview_generation_error': 'No se pudo generar vista previa: {}',
    'theme_txt_not_found': 'No se encontró theme.txt',
    'theme_decompress_error': 'Error al descomprimir el tema: {}',
    'theme_preview_generation_failed': 'No se pudo generar la vista previa',
    
    # Mensajes de utils/system_utils.py (NUEVO)
    'font_path_not_exists': 'La fuente {} no existe',
    'font_convert_stderr': 'Error al convertir la fuente: {}',
    'grub_config_updated': 'Configuración de GRUB actualizada correctamente',
    
    # Mensajes de utils/font_utils.py (NUEVO)
    'config_module_deprecated': 'El módulo \'config\' está obsoleto. Use \'app_paths\' en su lugar.',
    'no_backup_to_restore': 'No existe copia de seguridad para restaurar',
    'config_restored_successfully': 'Configuración restaurada correctamente',
    
    # Comentarios de código generado (NUEVO)
    'disabled_by_soplos_grub_editor': '# Deshabilitado por Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# Este archivo proporciona entradas personalizadas para GRUB\n\n',
}
