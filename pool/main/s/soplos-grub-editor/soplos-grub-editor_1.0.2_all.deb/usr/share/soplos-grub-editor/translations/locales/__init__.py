"""
Archivos de localización por idioma
"""

# Asegurar que el directorio de locales esté en el path de Python
import sys
import os

current_dir = os.path.dirname(__file__)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)
