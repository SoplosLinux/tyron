"""
Русские переводы для Soplos GRUB Editor
"""

STRINGS = {
    # Заголовки и заголовки
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'Общие настройки',
    'entries_tab': 'Записи загрузки',
    'appearance_tab': 'Внешний вид',
    
    # Общие кнопки
    'save_button': 'Сохранить',
    'apply_button': 'Применить',
    'close_button': 'Закрыть',
    'cancel_button': 'Отмена',
    'ok_button': 'ОК',
    
    # Заголовки диалогов
    'error_title': 'Ошибка',
    'info_title': 'Информация',
    'warning_title': 'Предупреждение',
    'confirm_title': 'Подтвердить',
    'question_title': 'Вопрос',
    
    # Общие сообщения
    'changes_saved': 'Изменения успешно сохранены',
    'changes_error': 'Ошибка при сохранении изменений',
    'need_root': 'Требуются права администратора',
    'confirm_exit': 'Вы уверены, что хотите выйти?',
    'unsaved_changes': 'Несохраненные изменения будут потеряны.',
    
    # Вкладка Общие
    'timeout_label': 'Тайм-аут (секунды):',
    'default_entry_label': 'Запись по умолчанию:',
    'resolution_label': 'Разрешение экрана:',
    'kernel_params_label': 'Параметры ядра:',
    'os_prober_label': 'Обнаружить другие операционные системы',
    'show_menu_label': 'Показать меню загрузки',
    'recovery_label': 'Включить параметры восстановления',
    'advanced_options': 'Расширенные параметры',
    'kernel_params_section': 'Параметры ядра',
    
    # Вкладка Внешний вид
    'theme_section': 'Тема',
    'font_section': 'Шрифты',
    'colors_section': 'Цвета',
    'background_section': 'Фон',
    'preview_label': 'Предварительный просмотр',
    'install_theme': 'Установить тему...',
    'remove_theme': 'Удалить тему',
    'disable_theme': 'Отключить тему',
    'select_font': 'Выбрать шрифт...',
    'remove_font': 'Удалить шрифт',
    'font_size': 'Размер шрифта:',
    'text_color': 'Цвет текста:',
    'background_color': 'Цвет фона:',
    'select_background': 'Выбрать фон...',
    'remove_background': 'Удалить фон',
    'highlight_text_color': 'Цвет выделенного текста:',
    'highlight_background_color': 'Цвет выделенного фона:',
    'apply_theme_button': 'Применить тему',
    
    # Вкладка Записи
    'add_entry': 'Добавить запись',
    'edit_entry': 'Редактировать запись',
    'remove_entry': 'Удалить запись',
    'entry_name': 'Имя:',
    'entry_type': 'Тип:',
    'entry_kernel': 'Ядро:',
    'entry_initrd': 'Initrd:',
    'entry_params': 'Параметры:',
    'entry_path': 'Путь',
    'entry_enabled': 'Включено',
    
    # Сообщения о состоянии
    'ready': 'Готово',
    'saving': 'Сохранение...',
    'applying': 'Применение изменений...',
    'loading': 'Загрузка...',
    'updating': 'Обновление GRUB...',
    'grub_updated': 'GRUB успешно обновлен',
    
    # Специфические диалоги
    'select_font_dialog': 'Выбрать шрифт',
    'select_theme_dialog': 'Выбрать тему',
    'select_background_dialog': 'Выбрать фоновое изображение',
    'font_filter': 'Шрифты',
    'theme_filter': 'Файлы тем',
    'image_filter': 'Изображения',
    'all_files': 'Все файлы',
    'open_button': 'Открыть',
    
    # Тексты разрешения
    'resolution_disabled': 'Отключено',
    'resolution_auto': 'Автоматически',
    
    # Тексты записей
    'last_selection': 'Последний выбор',
    'default_entry_saved': 'Последний выбор',
    
    # Помощь и элементы управления шрифтами
    'font_help': 'Этот метод избегает проблем с update-grub, напрямую изменяя конфигурацию.',
    'font_select_help': 'Выберите файл шрифта TTF или OTF',
    'browse_button': 'Обзор...',
    'install_font_button': 'Установить шрифт',
    'apply_font_button': 'Применить выбранный шрифт',
    'remove_font_button': 'Удалить выбранный шрифт',
    'delete_font_file_button': 'Удалить файл',
    
    # Предупреждения и подтверждения
    'delete_font_confirm': 'Вы уверены, что хотите удалить этот шрифт?',
    'delete_font_warning': 'Файл будет удален: {}\nЭто действие нельзя отменить.',
    'apply_font_confirm': 'Вы хотите применить этот шрифт?',
    'apply_font_message': 'Шрифт будет применен: {}',
    'remove_theme_confirm': 'Удалить тему \'{}\'?',
    'disable_theme_confirm': 'Вы хотите удалить текущую тему?',
    'disable_theme_message': 'Тема будет отключена, но не удалена из системы',
    'update_grub_title': 'Обновить GRUB',
    'update_grub_message': 'update-grub будет выполнен для применения изменений.',
    'apply_changes_title': 'Применить изменения?',
    'apply_changes_message': 'update-grub будет выполнен для применения изменений.',
    
    # Сообщения об успехе
    'font_installed': 'Шрифт успешно установлен в: {}',
    'font_removed': 'Шрифт успешно удален',
    'font_removed_successfully': 'Шрифт успешно удален',
    'font_deleted_successfully': 'Шрифт успешно удален',
    'font_applied_successfully': 'Шрифт успешно применен',
    'theme_installed': 'Тема успешно установлена',
    'theme_applied': 'Тема успешно применена',
    'grub_theme_applied': 'Тема GRUB успешно применена',
    'background_applied': 'Фон успешно установлен',
    'background_removed': 'Фон успешно удален',
    'entry_added': 'Запись успешно добавлена',
    'entry_removed': 'Запись успешно удалена',
    'changes_applied': 'Изменения успешно применены',
    'config_saved_successfully': 'Конфигурация успешно сохранена в custom.cfg',
    
    # Сообщения об ошибках
    'error_save': 'Ошибка при сохранении конфигурации',
    'error_load': 'Ошибка при загрузке конфигурации',
    'error_apply': 'Ошибка при применении изменений',
    'error_update': 'Ошибка при обновлении GRUB',
    'error_permission': 'Ошибка разрешения',
    'error_missing_deps': 'Отсутствуют необходимые зависимости',
    'invalid_font': 'Пожалуйста, выберите допустимый файл шрифта',
    'font_error': 'Ошибка при установке шрифта: {}',
    'theme_error': 'Ошибка при установке темы: {}',
    'background_error': 'Ошибка при загрузке изображения: {}',
    'entry_error': 'Ошибка при добавлении записи: {}',
    'entry_add_error': 'Ошибка при добавлении записи',
    'entry_name_kernel_required': 'Имя и ядро обязательны',
    'entry_remove_error': 'Ошибка при удалении записи',
    'no_entry_selected': 'Запись не выбрана',
    'no_font_installed': 'В GRUB не установлено шрифтов',
    'no_background_configured': 'Фон не настроен',
    'config_save_error': 'Ошибка при сохранении конфигурации',
    'config_save_error_path': 'Ошибка при сохранении конфигурации в {}: {}',
    'colors_cannot_be_same': 'Цвет текста и цвет фона не могут быть одинаковыми.',
    'highlight_colors_cannot_be_same': 'Цвет выделенного текста и цвет выделенного фона не могут быть одинаковыми.',
    
    # Системные ошибки
    'pkexec_error': 'Ошибка: Не удалось получить права администратора.',
    'relaunch_error': 'Ошибка при перезапуске от имени root: {}',
    'grub_config_not_found': 'Файл конфигурации GRUB не найден',
    'insufficient_permissions': 'Недостаточно прав для доступа к конфигурации GRUB',
    'initialization_error': 'Ошибка при инициализации: {}',
    'update_grub_error': 'Ошибка при выполнении update-grub: {}',
    'cache_cleanup_error': 'Ошибка при очистке кеша: {}',
    'background_remove_error': 'Ошибка при удалении фона: {}',
    'font_load_error': 'Ошибка при загрузке установленных шрифтов: {}',
    
    # Подтверждения выхода
    'confirm_exit_title': 'Вы уверены, что хотите выйти?',
    'confirm_exit_message': 'Несохраненные изменения будут потеряны.',
    
    # Ошибки шрифтов
    'invalid_font_file': 'Файл не является действительным шрифтом',
    'font_not_exists': 'Шрифт {} не существует',
    'font_convert_error': 'Ошибка при конвертации шрифта: {}',
    'font_install_error': 'Ошибка при установке шрифта: {}',
    'font_convert_exception': 'Ошибка при конвертации шрифта: {}',
    'font_set_error': 'Ошибка при установке шрифта: {}',
    'font_remove_error': 'Ошибка при удалении шрифта: {}',
    'font_file_not_exists': 'Файл шрифта не существует',
    'font_not_in_grub_dir': 'Шрифт не находится в каталоге шрифтов GRUB',
    'only_pf2_files_allowed': 'Можно удалять только файлы шрифтов .pf2',
    'font_deleted': 'Шрифт удален: {}',
    'font_delete_error': 'Ошибка при удалении шрифта: {}',
    'font_delete_exception': 'Ошибка при удалении шрифта: {}',
    
    # Горячие клавиши
    'shortcut_save': 'Ctrl+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Горячие клавиши',
    'shortcut_titles': {
        'save': 'Сохранить (Ctrl+S)',
        'apply': 'Применить (Alt+A)',
        'close': 'Закрыть (Alt+C)',
        'browse': 'Обзор (Alt+B)',
        'install': 'Установить (Alt+I)',
        'remove': 'Удалить (Alt+R)',
        'delete': 'Удалить (Del)',
        'add': 'Добавить (Alt+N)',
        'edit': 'Редактировать (Alt+E)'
    },
    
    # Состояния системы
    'no_theme_selected': 'Тема не выбрана',
    'theme_preview_error': 'Ошибка при генерации предварительного просмотра темы',
    'grub_theme_disabled': 'Тема GRUB отключена',
    'custom_entry_saved': 'Пользовательская запись сохранена',
    'system_entry': 'Системная запись',
    'custom_entry': 'Пользовательская запись',
    'entries_loaded': 'Записей загружено: {}',
    'grub_config_loaded': 'Конфигурация GRUB загружена',
    'backup_created': 'Резервная копия создана',
    'backup_restored': 'Резервная копия восстановлена',
    'permission_denied': 'Доступ запрещен',
    'file_not_found': 'Файл не найден',
    'invalid_configuration': 'Недопустимая конфигурация',
    'theme_installation_success': 'Тема успешно установлена в: {}',
    'theme_removal_success': 'Тема успешно удалена',
    'operation_completed': 'Операция завершена',
    'operation_failed': 'Операция не удалась',
    
    # Технические и лог сообщения (НОВОЕ)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Ошибка установки иконки по имени: {}',
    'program_class_error': 'Ошибка установки program_class: {}',
    'directory_cleaned': 'Каталог очищен: {}',
    'directory_clean_error': 'Ошибка очистки {}: {}',
    
    # Сообщения от utils/theme_utils.py (НОВОЕ)
    'file_format_not_supported': 'Формат файла не поддерживается. Используйте .tar.gz, .tgz, .tar.xz или .zip',
    'theme_directory_invalid': 'Каталог темы не содержит theme.txt',
    'invalid_path': 'Указанный путь недействителен',
    'theme_disabled_successfully': 'Тема успешно отключена',
    'theme_preview_generation_error': 'Не удалось создать предварительный просмотр: {}',
    'theme_txt_not_found': 'theme.txt не найден',
    'theme_decompress_error': 'Ошибка распаковки темы: {}',
    'theme_preview_generation_failed': 'Не удалось создать предварительный просмотр',
    
    # Сообщения от utils/system_utils.py (НОВОЕ)
    'font_path_not_exists': 'Шрифт {} не существует',
    'font_convert_stderr': 'Ошибка конвертации шрифта: {}',
    'grub_config_updated': 'Конфигурация GRUB успешно обновлена',
    
    # Сообщения от utils/font_utils.py (НОВОЕ)
    'config_module_deprecated': 'Модуль \'config\' устарел. Используйте \'app_paths\' вместо него.',
    'no_backup_to_restore': 'Нет резервной копии для восстановления',
    'config_restored_successfully': 'Конфигурация успешно восстановлена',
    
    # Комментарии сгенерированного кода (НОВОЕ)
    'disabled_by_soplos_grub_editor': '# Отключено Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# Этот файл предоставляет пользовательские записи для GRUB\n\n',
}
