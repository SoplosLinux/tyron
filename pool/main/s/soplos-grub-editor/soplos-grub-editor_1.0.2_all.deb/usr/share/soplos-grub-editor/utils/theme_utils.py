import os
import shutil
import logging
import subprocess
import tempfile
from pathlib import Path
from .system_utils import update_grub_config

# Importar sistema de traducciones
from translations.strings import TRANSLATIONS

# Obtener el idioma del sistema
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

logger = logging.getLogger(__name__)

GRUB_THEMES_DIR = "/boot/grub/themes"
GRUB_THEME_KEY = "GRUB_THEME"

def check_themes_dir():
    """Crear directorio de temas si no existe"""
    if not os.path.exists(GRUB_THEMES_DIR):
        os.makedirs(GRUB_THEMES_DIR, exist_ok=True)

def generate_theme_preview(theme_path):
    """
    Genera una vista previa del tema usando Plymouth
    """
    try:
        preview_path = os.path.join(theme_path, "preview.png")
        
        # Si ya existe una vista previa, usarla
        if os.path.exists(preview_path):
            return True, preview_path
            
        # Buscar la imagen de fondo del tema
        theme_file = os.path.join(theme_path, "theme.txt")
        if not os.path.exists(theme_file):
            return False, "No se encontró theme.txt"
            
        # Leer el archivo theme.txt para encontrar la imagen de fondo
        with open(theme_file, 'r') as f:
            theme_content = f.read()
            
        # Buscar la línea que define el fondo
        for line in theme_content.splitlines():
            if "desktop-image:" in line or "background-image:" in line:
                image_path = line.split('"')[1] if '"' in line else line.split()[1]
                bg_path = os.path.join(theme_path, image_path)
                if os.path.exists(bg_path):
                    # Copiar y redimensionar la imagen de fondo como vista previa
                    try:
                        subprocess.run([
                            "convert",
                            bg_path,
                            "-resize", "320x240",
                            preview_path
                        ], check=True)
                        return True, preview_path
                    except subprocess.CalledProcessError:
                        # Si no se puede usar convert, intentar copiar la imagen directamente
                        shutil.copy2(bg_path, preview_path)
                        return True, preview_path
                
        # Si no se encuentra una imagen, usar una vista previa genérica
        try:
            subprocess.run([
                "convert",
                "-size", "320x240",
                "xc:black",
                "-gravity", "center",
                "-pointsize", "20",
                "-fill", "white",
                "-draw", f'text 0,0 "Theme: {os.path.basename(theme_path)}"',
                preview_path
            ], check=True)
            return True, preview_path
        except subprocess.CalledProcessError:
            return False, "No se pudo generar la vista previa"
            
    except Exception as e:
        logger.error(_('theme_preview_error') + f": {str(e)}")  # Usar traducción
        return False, str(e)

def install_theme(theme_path):
    """
    Instala un tema de GRUB desde un archivo comprimido o un directorio.
    """
    try:
        check_themes_dir()
        
        # Si es un archivo comprimido
        if os.path.isfile(theme_path):
            # Obtener el nombre base sin extensiones
            base_name = os.path.basename(theme_path)
            for ext in ['.tar.gz', '.tgz', '.tar.xz', '.zip']:
                if base_name.endswith(ext):
                    theme_name = base_name[:-len(ext)]
                    break
            else:
                return False, _('file_format_not_supported')
            
            theme_dir = os.path.join(GRUB_THEMES_DIR, theme_name)
            
            # Eliminar instalación anterior si existe
            if os.path.exists(theme_dir):
                shutil.rmtree(theme_dir)
            
            # Crear directorio temporal para descomprimir
            with tempfile.TemporaryDirectory() as temp_dir:
                try:
                    # Descomprimir según el formato
                    if theme_path.endswith(('.tar.gz', '.tgz')):
                        import tarfile
                        with tarfile.open(theme_path, 'r:gz') as tar:
                            tar.extractall(temp_dir)
                    
                    elif theme_path.endswith('.tar.xz'):
                        import tarfile
                        with tarfile.open(theme_path, 'r:xz') as tar:
                            tar.extractall(temp_dir)
                    
                    elif theme_path.endswith('.zip'):
                        import zipfile
                        with zipfile.ZipFile(theme_path, 'r') as zip_ref:
                            zip_ref.extractall(temp_dir)
                    
                    # Buscar el archivo theme.txt en el directorio temporal
                    theme_txt = None
                    for root, dirs, files in os.walk(temp_dir):
                        if 'theme.txt' in files:
                            theme_txt = os.path.join(root, 'theme.txt')
                            # El directorio que contiene theme.txt es el directorio del tema
                            actual_theme_dir = os.path.dirname(theme_txt)
                            break
                    
                    if not theme_txt:
                        return False, _('theme_directory_invalid')
                    
                    # Mover el directorio del tema a su ubicación final
                    shutil.copytree(actual_theme_dir, theme_dir)
                    return True, theme_dir
                
                except Exception as e:
                    return False, _('theme_decompress_error').format(str(e))
        
        # Si es un directorio
        elif os.path.isdir(theme_path):
            theme_name = os.path.basename(theme_path)
            theme_dir = os.path.join(GRUB_THEMES_DIR, theme_name)
            
            # Verificar que existe theme.txt
            if not os.path.exists(os.path.join(theme_path, "theme.txt")):
                return False, _('theme_directory_invalid')
            
            # Eliminar instalación anterior si existe
            if os.path.exists(theme_dir):
                shutil.rmtree(theme_dir)
            
            # Copiar el directorio del tema
            shutil.copytree(theme_path, theme_dir)
            return True, theme_dir
        
        return False, _('invalid_path')
        
    except Exception as e:
        logger.error(_('operation_failed') + f": {str(e)}")
        return False, str(e)
    
    # Si la instalación fue exitosa, generar vista previa
    if os.path.exists(theme_dir):
        success, preview = generate_theme_preview(theme_dir)
        if not success:
            logger.warning(f"No se pudo generar vista previa: {preview}")
    
    return True, theme_dir

def set_grub_theme(theme_path, grub_config):
    """Configura un tema como el tema activo de GRUB"""
    try:
        if not os.path.exists(theme_path):
            return False, _('file_not_found')  # Usar traducción
        
        if not os.path.exists(os.path.join(theme_path, "theme.txt")):
            return False, _('invalid_configuration')  # Usar traducción
        
        theme_value = f"{theme_path}/theme.txt"
        
        # Procesar líneas existentes
        new_lines = []
        for line in grub_config.config_lines:
            stripped_line = line.strip()
            if 'GRUB_BACKGROUND=' in line and not stripped_line.startswith('#'):
                # Comentar línea de fondo activa
                new_lines.append(f"# {stripped_line} # Deshabilitado por tema activo\n")
                if 'GRUB_BACKGROUND' in grub_config.config:
                    del grub_config.config['GRUB_BACKGROUND']
            elif GRUB_THEME_KEY in line:
                # Omitir líneas antiguas de tema
                continue
            else:
                new_lines.append(line)
        
        # Añadir la nueva configuración del tema
        if new_lines and new_lines[-1].strip():
            new_lines.append('\n')
        new_lines.append(f'{GRUB_THEME_KEY}="{theme_value}"\n')
        
        # Actualizar configuración
        grub_config.config_lines = new_lines
        grub_config.config[GRUB_THEME_KEY] = theme_value
        
        # Intentar generar una vista previa si no existe
        preview_path = os.path.join(theme_path, "preview.png")
        if not os.path.exists(preview_path):
            success, _ = generate_theme_preview(theme_path)
            if not success:
                logger.warning("No se pudo generar vista previa del tema")
        
        if not grub_config.save_config():
            return False, "Error al guardar la configuración"
        
        success, message = update_grub_config()
        if not success:
            return False, message
        
        return True, _('grub_theme_applied')  # Usar traducción
        
    except Exception as e:
        logger.error(_('operation_failed') + f": {str(e)}")  # Usar traducción
        return False, str(e)

def disable_theme(grub_config):
    """Deshabilita el tema activo sin eliminarlo"""
    try:
        # Buscar líneas existentes de tema
        found_lines = []
        for i, line in enumerate(grub_config.config_lines):
            stripped_line = line.strip()
            if GRUB_THEME_KEY in line and not stripped_line.startswith('#'):
                found_lines.append(i)
        
        # Eliminar todas las líneas excepto la primera
        for i in reversed(found_lines[1:]):
            del grub_config.config_lines[i]
        
        # Comentar la línea restante
        if found_lines:
            line = grub_config.config_lines[found_lines[0]].strip()
            if not line.startswith('#'):
                grub_config.config_lines[found_lines[0]] = f"# {line} {_('disabled_by_soplos_grub_editor')}\n"
        
        # Eliminar la configuración del tema del diccionario
        if GRUB_THEME_KEY in grub_config.config:
            del grub_config.config[GRUB_THEME_KEY]
        
        if not grub_config.save_config():
            return False, "Error al guardar la configuración"
        
        success, message = update_grub_config()
        if not success:
            return False, message
        
        return True, _('theme_disabled_successfully')
        
    except Exception as e:
        logger.error(f"Error al deshabilitar tema: {str(e)}")
        return False, str(e)

def list_installed_themes():
    """
    Lista los temas instalados en /boot/grub/themes
    """
    themes = []
    try:
        if os.path.exists(GRUB_THEMES_DIR):
            for item in os.listdir(GRUB_THEMES_DIR):
                theme_dir = os.path.join(GRUB_THEMES_DIR, item)
                if os.path.isdir(theme_dir) and os.path.exists(os.path.join(theme_dir, "theme.txt")):
                    themes.append(theme_dir)
        return themes
    except Exception as e:
        logger.error(f"Error al listar temas: {str(e)}")
        return []

def remove_theme(theme_path):
    """
    Elimina un tema instalado
    """
    try:
        if not theme_path.startswith(GRUB_THEMES_DIR):
            return False, "El tema no está en el directorio de temas de GRUB"
        
        if os.path.exists(theme_path):
            shutil.rmtree(theme_path)
            return True, "Tema eliminado correctamente"
        
        return False, "El tema no existe"
        
    except Exception as e:
        logger.error(f"Error al eliminar tema: {str(e)}")
        return False, str(e)
