import os
import subprocess
import logging
import tempfile
import shutil
from pathlib import Path

# Importar sistema de traducciones
from translations.strings import TRANSLATIONS

# Obtener el idioma del sistema
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

# Configurar el sistema de logging
logging.basicConfig(level=logging.ERROR)
logger = logging.getLogger(__name__)

# ... (las funciones existentes se mantienen igual)

def convert_font_for_grub(font_path, size=16):
    """
    Convierte una fuente TTF/OTF al formato de GRUB usando grub-mkfont.

    Args:
        font_path (str): Ruta a la fuente a convertir.
        size (int): Tamaño de la fuente en puntos.

    Returns:
        tuple: (True/False, ruta_a_la_fuente_generada o mensaje_de_error)
    """
    try:
        # Verificar si la fuente existe
        if not os.path.exists(font_path):
            return False, _('font_path_not_exists').format(font_path)

        # Crear nombre para la fuente convertida
        font_name = os.path.basename(font_path).rsplit('.', 1)[0]
        output_path = f"/boot/grub/fonts/{font_name}_{size}.pf2"

        # Asegurarse de que el directorio de destino existe
        os.makedirs("/boot/grub/fonts", exist_ok=True)

        # Crear un archivo temporal para almacenar la salida
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pf2') as temp_file:
            temp_path = temp_file.name

        # Ejecutar grub-mkfont
        cmd = f"grub-mkfont --output={temp_path} --size={size} {font_path}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

        if result.returncode != 0:
            os.unlink(temp_path)
            return False, _('font_convert_stderr').format(result.stderr)

        # Mover el archivo a la ubicación final (necesita privilegios)
        move_cmd = f"sudo mv {temp_path} {output_path}"
        move_result = subprocess.run(move_cmd, shell=True, capture_output=True, text=True)

        if move_result.returncode != 0:
            os.unlink(temp_path)
            return False, f"Error al instalar la fuente: {move_result.stderr}"

        # Establecer permisos correctos
        chmod_cmd = f"sudo chmod 644 {output_path}"
        subprocess.run(chmod_cmd, shell=True)

        return True, output_path
    except Exception as e:
        logger.error(f"Error al convertir la fuente: {str(e)}")
        return False, str(e)

def list_installed_grub_fonts():
    """
    Lista las fuentes instaladas para GRUB.

    Returns:
        list: Lista de rutas a las fuentes instaladas.
    """
    try:
        font_path = Path("/boot/grub/fonts")
        if not font_path.exists():
            return []

        return [str(f) for f in font_path.glob("*.pf2")]
    except Exception as e:
        logger.error(f"Error al listar fuentes: {str(e)}")
        return []

def set_grub_font(font_path, use_custom_method=True):
    """
    Configura una fuente para GRUB usando un método alternativo al estándar.

    Args:
        font_path (str): Ruta a la fuente convertida (.pf2).
        use_custom_method (bool): Si es True, usa un método alternativo que no requiere GRUB_FONT.

    Returns:
        bool: True si tuvo éxito, False en caso contrario.
    """
    try:
        if not os.path.exists(font_path):
            return False

        if use_custom_method:
            # Método alternativo: modificar directamente el archivo de configuración GRUB
            grub_cfg_path = "/boot/grub/grub.cfg"

            # Leer el archivo actual
            with open(grub_cfg_path, 'r') as f:
                content = f.read()

            # Buscar si ya existe una línea de font
            font_line = f"loadfont {font_path}"
            if font_line in content:
                return True  # La fuente ya está configurada

            # Modificar el archivo para cargar la fuente al inicio
            content_lines = content.split('\n')

            # Buscar la posición adecuada para insertar la carga de la fuente
            insert_pos = None
            for i, line in enumerate(content_lines):
                if line.strip().startswith('terminal_'):
                    insert_pos = i
                    break

            if insert_pos is not None:
                content_lines.insert(insert_pos, font_line)

                # Crear copia de seguridad
                backup_cmd = f"sudo cp {grub_cfg_path} {grub_cfg_path}.bak"
                subprocess.run(backup_cmd, shell=True)

                # Escribir el archivo modificado
                with tempfile.NamedTemporaryFile(mode='w', delete=False) as temp_file:
                    temp_path = temp_file.name
                    temp_file.write('\n'.join(content_lines))

                copy_cmd = f"sudo cp {temp_path} {grub_cfg_path}"
                result = subprocess.run(copy_cmd, shell=True, capture_output=True, text=True)
                os.unlink(temp_path)

                if result.returncode != 0:
                    return False

                return True

            return False
        else:
            # Método estándar (problemático): usar variables de GRUB
            return False
    except Exception as e:
        logger.error(f"Error al configurar la fuente: {str(e)}")
        return False

def detect_grub_update_method():
    """
    Detecta el método correcto para actualizar GRUB según el sistema.
    Returns:
        tuple: (comando, ruta_destino) donde comando es el ejecutable y ruta_destino es opcional
    """
    try:
        # Verificar si existe update-grub (Debian/Ubuntu y derivados)
        update_grub = shutil.which('update-grub')
        if update_grub:
            return ('update-grub', None)

        # Verificar si existe grub2-mkconfig (Red Hat/Fedora)
        grub2_mkconfig = shutil.which('grub2-mkconfig')
        if grub2_mkconfig:
            return ('grub2-mkconfig', '/boot/grub2/grub.cfg')

        # Verificar si existe grub-mkconfig (Arch/Gentoo)
        grub_mkconfig = shutil.which('grub-mkconfig')
        if grub_mkconfig:
            return ('grub-mkconfig', '/boot/grub/grub.cfg')

        # Si no se encuentra ninguno, intentar con el más común
        return ('grub-mkconfig', '/boot/grub/grub.cfg')
    except Exception as e:
        logger.error(f"Error al detectar método de actualización de GRUB: {str(e)}")
        return ('update-grub', None)  # Valor por defecto

def update_grub_config():
    """
    Actualiza la configuración de GRUB usando el método apropiado para el sistema.
    """
    try:
        cmd, output_path = detect_grub_update_method()
        command = []

        if cmd == 'update-grub':
            command = [cmd]
        else:
            command = [cmd]
            if output_path:
                command.extend(['-o', output_path])

        result = subprocess.run(command, capture_output=True, text=True)
        
        if result.returncode != 0:
            logger.error(f"Error al actualizar GRUB: {result.stderr}")
            return False, f"Error al actualizar GRUB: {result.stderr}"
        
        return True, _('grub_config_updated')
    except Exception as e:
        logger.error(f"Error al actualizar GRUB: {str(e)}")
        return False, str(e)