# Soplos GRUB Editor

## 📝 Descripción
Herramienta gráfica avanzada para gestionar y personalizar la configuración de GRUB2 en sistemas Linux.

## ✨ Características Principales
- 🖥️ Interfaz gráfica intuitiva para editar GRUB
- 📋 Gestión completa de entradas de arranque
- ⚡ Actualización automática de configuración
- 🔄 Backup automático de configuraciones
- 🎨 Personalización visual completa
- 🔒 Validación de cambios en tiempo real

## 🛠️ Requisitos
- Sistema Linux con GRUB 2.x
- Python 3.6+
- GTK 3.0
- Permisos de administrador

## 📋 Funcionalidades

### Gestión de Entradas
- Modificar orden de arranque
- Ocultar/mostrar entradas
- Editar parámetros del kernel
- Gestionar timeouts

### Personalización
- Temas de GRUB
- Resolución de pantalla
- Fuentes y colores
- Fondos personalizados

### Seguridad
- Backups automáticos
- Restauración de configuración
- Validación de cambios
- Protección contra errores

## ⌨️ Atajos de Teclado
- **Ctrl+S**: Guardar cambios
- **Alt+A**: Aplicar cambios
- **Alt+C**: Cerrar
- **Alt+R**: Restaurar backup

## 🌍 Idiomas Soportados
- 🇪🇸 Español
- 🇬🇧 Inglés
- 🇫🇷 Francés
- 🇩🇪 Alemán
- 🇮🇹 Italiano
- 🇵🇹 Portugués
- 🇷🇴 Rumano
- 🇷🇺 Ruso

## 📞 Contacto
- **Web**: https://soploslinux.com/
- **GitHub**: https://github.com/SoplosLinux
- **Email**: info@soploslinux.com

## 📄 Licencia
GPL-3.0 © 2024 Soplos Team