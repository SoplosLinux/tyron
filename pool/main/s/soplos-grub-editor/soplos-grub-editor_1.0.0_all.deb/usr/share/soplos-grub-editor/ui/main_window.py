import gi
import os
import subprocess
import logging
# Cambiado: importar desde el directorio translations
from translations.strings import TRANSLATIONS
from app_paths import ICON_PATH, LOGO_PATH  # Importar desde app_paths en lugar de config

# Configurar el logger
logger = logging.getLogger(__name__)

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GdkPixbuf, Gdk

# Importar nuestros módulos
from config.grub_config import GrubConfig
from ui.general_tab import GeneralTab
from ui.entries_tab import EntriesTab
from ui.appearance_tab import AppearanceTab

# Obtener el idioma del sistema
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

class GrubEditorWindow(Gtk.ApplicationWindow):  # Cambiar a ApplicationWindow
    def __init__(self):
        super().__init__(title=_('app_name'))
        self.set_default_size(800, 600)
        
        # Cargar el logo de Soplos para la interfaz
        logo_path = LOGO_PATH  # Usar el logo de Soplos
        if os.path.exists(logo_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    filename=logo_path,
                    width=150,  # Ancho máximo del logo
                    height=150,  # Alto máximo del logo
                    preserve_aspect_ratio=True
                )
                logo_image = Gtk.Image.new_from_pixbuf(pixbuf)
                logo_image.set_margin_bottom(15)
                self.box.pack_start(logo_image, False, False, 0)
            except Exception as e:
                logger.warning(f"No se pudo cargar el logo: {e}")

        self.grub_config = GrubConfig()
        
        # Inicializar ventana y accel_group primero
        self.set_default_size(800, 600)
        
        # Crear e inicializar el grupo de accels antes de crear otros widgets
        self.accel_group = Gtk.AccelGroup()
        self.add_accel_group(self.accel_group)
        
        self.connect("delete-event", self.on_delete_event)  # Añadir esta línea
        
        # Usar el icono de la aplicación
        icon_path = ICON_PATH  # Usar el icono de la aplicación
        if os.path.exists(icon_path):
            self.set_icon_from_file(icon_path)
        
        self.notebook = Gtk.Notebook()
        self.general_tab = GeneralTab(self)
        self.entries_tab = EntriesTab(self)
        self.appearance_tab = AppearanceTab(self)
        
        self.notebook.append_page(self.general_tab.get_content(), 
                                Gtk.Label(label=_('general_tab')))
        self.notebook.append_page(self.entries_tab.get_content(), 
                                Gtk.Label(label=_('entries_tab')))
        self.notebook.append_page(self.appearance_tab.get_content(), 
                                Gtk.Label(label=_('appearance_tab')))
        
        # Logo en la cabecera
        self.logo = Gtk.Image()
        if os.path.exists(logo_path):  # Usar el logo de Soplos
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(logo_path, 128, 128, True)
                self.logo.set_from_pixbuf(pixbuf)
            except GLib.Error as e:
                logging.warning(f"No se pudo cargar el logo: {str(e)}")
        
        self.statusbar = Gtk.Statusbar()
        self.statusbar.push(0, _('ready'))  # Cambiar "Listo" por la traducción
        
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.main_box.pack_start(self.logo, False, False, 0)
        self.main_box.pack_start(self.notebook, True, True, 0)
        
        # Barra de botones inferior con atajos de teclado
        self.button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.button_box.set_halign(Gtk.Align.END)
        self.button_box.set_margin_bottom(10)
        
        # Botón Guardar con atajo Ctrl+S
        self.save_button = Gtk.Button(label="_" + _('save_button'))
        self.save_button.set_use_underline(True)
        self.save_button.add_accelerator("clicked", self.accel_group,
                                   ord('S'), Gdk.ModifierType.CONTROL_MASK, 
                                   Gtk.AccelFlags.VISIBLE)
        self.save_button.set_image(Gtk.Image.new_from_icon_name("document-save", 
                             Gtk.IconSize.BUTTON))
        self.save_button.connect("clicked", self.on_save_clicked)
        
        # Botón Aplicar con atajo Alt+A
        self.apply_button = Gtk.Button(label="_" + _('apply_button'))
        self.apply_button.set_use_underline(True)
        self.apply_button.add_accelerator("clicked", self.accel_group,
                                    ord('A'), Gdk.ModifierType.MOD1_MASK, 
                                    Gtk.AccelFlags.VISIBLE)
        self.apply_button.set_image(Gtk.Image.new_from_icon_name("system-run", 
                              Gtk.IconSize.BUTTON))
        self.apply_button.connect("clicked", self.on_apply_clicked)
        
        # Botón Cerrar con atajo Alt+C
        self.close_button = Gtk.Button(label="_" + _('close_button'))
        self.close_button.set_use_underline(True)
        self.close_button.add_accelerator("clicked", self.accel_group,
                                    ord('C'), Gdk.ModifierType.MOD1_MASK, 
                                    Gtk.AccelFlags.VISIBLE)
        self.close_button.set_image(Gtk.Image.new_from_icon_name("window-close", 
                              Gtk.IconSize.BUTTON))
        self.close_button.set_margin_end(10)
        self.close_button.connect("clicked", self.on_close_clicked)
        
        self.button_box.pack_start(self.save_button, False, False, 0)
        self.button_box.pack_start(self.apply_button, False, False, 0)
        self.button_box.pack_start(self.close_button, False, False, 0)
        
        self.main_box.pack_end(self.button_box, False, False, 0)
        self.main_box.pack_end(self.statusbar, False, False, 0)
        
        self.add(self.main_box)
        
        # Verificar permisos antes de cargar configuración
        if os.geteuid() != 0:
            self.show_error("Se requieren privilegios de administrador")
            return

        try:
            # Cargar configuración con manejo de errores
            if not os.path.exists('/etc/default/grub'):
                self.show_error("No se encontró el archivo de configuración de GRUB")
                return
                
            if not os.access('/etc/default/grub', os.R_OK | os.W_OK):
                self.show_error("No hay permisos suficientes para acceder a la configuración de GRUB")
                return

            # ... resto del código ...

        except Exception as e:
            self.show_error(f"Error al inicializar: {str(e)}")
    
    def on_save_clicked(self, widget):
        self.general_tab.update_config()
        self.appearance_tab.update_config()
        
        if self.grub_config.save_config():
            # Ejecutar update-grub inmediatamente después de guardar
            if self._run_update_grub():
                # Usar la clave de traducción, no el texto traducido
                self.set_status("changes_saved")  # CAMBIAR ESTO
            else:
                self.set_status("error_update")
        else:
            self.set_status("error_save")

    def _run_update_grub(self):
        """Ejecutar update-grub con manejo de errores mejorado"""
        try:
            result = subprocess.run(
                ['update-grub'],
                check=True,
                capture_output=True,
                text=True
            )
            return True
        except subprocess.CalledProcessError as e:
            logging.error(f"Error al ejecutar update-grub: {e.stderr}")
            self.show_error(f"Error al ejecutar update-grub:\n{e.stderr}")
            return False
        except Exception as e:
            logging.error(f"Error al ejecutar update-grub: {str(e)}")
            self.show_error(f"Error al ejecutar update-grub:\n{str(e)}")
            return False
    
    def on_apply_clicked(self, widget):
        self.on_save_clicked(widget)
        
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=_('update_grub_title'),
            secondary_text=_('update_grub_message')
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.OK:
            if self._run_update_grub():
                self.set_status("grub_updated")  # Usar la clave de traducción
            else:
                self.set_status("error_update")

    def set_status(self, message):
        """Actualizar mensaje de estado"""
        self.statusbar.pop(0)
        # El mensaje ya es una clave de traducción, no un texto traducido
        self.statusbar.push(0, _(message))

    def show_error(self, message):
        """Mostrar diálogo de error traducido"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=_('error_title')  # Usar traducción
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def show_info(self, message):
        """Mostrar diálogo de información traducido"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=_('info_title')  # Usar traducción
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def on_close_clicked(self, widget):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_('confirm_exit'),
            secondary_text=_('unsaved_changes')
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            try:
                from main import limpiar_pycache
                limpiar_pycache()
            except Exception as e:
                logging.error(f"Error al limpiar caché: {str(e)}")
                
            # Usar quit() de la aplicación en lugar de Gtk.main_quit()
            self.get_application().quit()

    def on_delete_event(self, widget, event):
        """Maneja el evento de cierre de ventana."""
        self.on_close_clicked(None)
        return True  # Previene que la ventana se cierre automáticamente

if __name__ == "__main__":
    app = GrubEditorWindow()
    app.show_all()
    Gtk.main()