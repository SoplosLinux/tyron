"""Traducciones de filtros de archivos en español"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Scripts de Shell (*.sh)',
        }
    }
}
