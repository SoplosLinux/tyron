"""Script translations in English"""

FRAGMENT = {
    'downloading_gpg': 'Downloading GPG key...',
    'error_downloading_gpg': 'Error downloading GPG key',
    'verify_root': 'Check if running as root',
    'must_be_root': 'This script must be run as root',
    'create_keyring': 'Create GPG keyring directory',
    'download_gpg': 'Download and import GPG key',
    'verify_gpg': 'Verify key was downloaded correctly',
    'error_gpg_empty': 'Error: GPG key is empty or was not installed',
    'config_repo': 'Configure repository',
    'configuring_repo': 'Configuring repository...',
    'force_update': 'Force secure update',
    'updating_indices': 'Updating indices...',
    'verify_repo': 'Verify repository is configured',
    'error_repo_not_configured': 'Error: Repository was not configured correctly',
    'repo_installed': 'Repository installed successfully!',
    'colors': 'Colors for messages',
    'install_repo': 'Installation script for repository {}'
}
