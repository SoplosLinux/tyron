"""Estados de pacotes em português"""

FRAGMENT = {
    'new': 'Novo',
    'processing': 'Processando',
    'uploading': 'A enviar',
    'uploaded': 'Enviado',
    'error': 'Erro',
    'in_pool': 'Em Pool',
    'in_github': 'No GitHub',
    'in_incoming': 'Em Incoming',
    'unknown': 'Desconhecido',
    'installed': 'Instalado',
    'not_installed': 'Não instalado',
    'partially_installed': 'Parcialmente instalado',
    'to_install': 'Para instalar',
    'to_remove': 'Para remover',
    'to_upgrade': 'Para atualizar',
    'broken': 'Quebrado',
    'configured': 'Configurado',
    'not_configured': 'Não configurado',
    'processed': 'Processado'  # Añadir traducción en portugués
}
