"""Fortschrittsmeldungen auf Deutsch"""

FRAGMENT = {
    'estimated_time': 'Geschätzte verbleibende Zeit: {0}',
    'total_progress': 'Gesamtfortschritt: {0}%',
    'remaining_items': '{0} Elemente verbleibend',
    'task_status': '{0} von {1}',
    'current_operation': 'Aktuelle Operation: {0}',
    'processing_item': 'Verarbeite {0}...',
    'start_task': 'Starte {0}...',
    'finish_task': 'Abgeschlossen {0}',
    'abort_task': 'Breche {0} ab...',
    'error_task': 'Fehler in {0}: {1}',
    'percent': '{0}% abgeschlossen'
}
