"""Tooltip-Übersetzungen auf Deutsch"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Neues .deb-Paket zum Repository hinzufügen',
        'upload_changes': 'Ausstehende Änderungen auf GitHub hochladen',
        'manage_keys': 'GPG-Schlüssel verwalten',
        'configure_repo': 'Repository-Details konfigurieren',
        'generate_script': 'Installationsskript generieren',
        'refresh_list': 'Paketliste aktualisieren',
        'remove_package': 'Ausgewähltes Paket entfernen',
        'sign_package': 'Paketdetails anzeigen'
    },
    'tips': {
        'exit_app': 'Anwendung beenden'
    }
}
