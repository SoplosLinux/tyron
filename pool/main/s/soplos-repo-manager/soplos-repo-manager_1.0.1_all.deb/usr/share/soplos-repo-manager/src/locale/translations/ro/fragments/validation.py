"""Mesaje de validare în română"""

FRAGMENT = {
    'url_invalid': 'URL invalid',
    'token_invalid': 'Token invalid',
    'branch_empty': 'Ramura nu poate fi goală',
    'name_invalid': 'Nume invalid',
    'email_invalid': 'Email invalid',
    'duplicate': '{0} există deja',
    'required_field': 'Câmp obligatoriu: {0}',
    'invalid_input': 'Intrare invalidă: {0}',
    'config_error': 'Eroare de configurare: {0}',
    'profile_exists': 'Există deja un profil cu acest nume',
    'missing_fields': 'Toate câmpurile sunt obligatorii',
    'gpg_key_required': 'Este necesară o cheie GPG',
    'invalid_version': 'Versiune invalidă'
}
