"""Mesaje de dialog în română"""

FRAGMENT = {
    'select_gpg': 'Selectare Cheie GPG',
    'wait': 'Vă rugăm așteptați...',
    'config_repo': 'Configurare Depozit',
    'new_profile': 'Profil Nou',
    'package_list': 'Listă Pachete',
    'version_select': 'Selectare versiune',
    'existing_file': 'Fișier Existent',
    'file_details': 'Detalii fișier',
    'package_details': 'Detalii pachet',
    'create_gpg': 'Creare Cheie GPG Nouă',
    'select_gpg': 'Selectare Cheie GPG',
    'save_script': 'Salvare Script de Instalare',
    'install_script': 'Script de Instalare',
    'gpg_verification': 'Verificare GPG',
    'gpg_key_info': 'Informații Cheie GPG',
    'repo_instructions': 'Instrucțiuni Depozit',
    'confirm_clean_repo': 'Confirmare Curățare Depozit',
    'colors': {
        'green': 'Verde',
        'red': 'Roșu',
        'nc': 'Fără Culoare'
    }
}
