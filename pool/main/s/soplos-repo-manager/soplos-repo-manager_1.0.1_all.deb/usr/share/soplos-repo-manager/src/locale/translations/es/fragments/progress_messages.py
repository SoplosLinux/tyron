"""Mensajes de progreso en español"""

FRAGMENT = {
    'estimated_time': 'Tiempo restante estimado: {0}',
    'total_progress': 'Progreso total: {0}%',
    'remaining_items': '{0} elementos restantes',
    'task_status': '{0} de {1}',
    'current_operation': 'Operación actual: {0}',
    'processing_item': 'Procesando {0}...',
    'start_task': 'Iniciando {0}...',
    'finish_task': 'Completado {0}',
    'abort_task': 'Abortando {0}...',
    'error_task': 'Error en {0}: {1}',
    'percent': '{0}% completado'
}
