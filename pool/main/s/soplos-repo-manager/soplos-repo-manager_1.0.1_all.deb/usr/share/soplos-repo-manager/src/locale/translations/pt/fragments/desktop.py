"""Traduções para o arquivo .desktop em português"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Usar o mesmo nome que em ui_elements
    'generic_name': 'Gestor de Repositórios',
    'keywords': 'pacotes;apt;repo;deb;gpg;repositório;',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
