"""Статусы и сообщения о состоянии на русском"""

FRAGMENT = {
    'ready': 'Готово',
    'processing': 'Обработка...',
    'waiting': 'Ожидание...',
    'completed': 'Завершено',
    'failed': 'Ошибка',
    'uploading': 'Загрузка...',
    'downloading': 'Скачивание...',
    'installing': 'Установка...',
    'updating': 'Обновление...',
    'error': 'Ошибка',
    'success': 'Успешно',
    'cancelled': 'Отменено',
    'paused': 'Приостановлено',
    'offline': 'Не в сети',
    'online': 'В сети',
    'syncing': 'Синхронизация...',
    'initializing': 'Инициализация...',
    'cleaning': 'Очистка...'
}
