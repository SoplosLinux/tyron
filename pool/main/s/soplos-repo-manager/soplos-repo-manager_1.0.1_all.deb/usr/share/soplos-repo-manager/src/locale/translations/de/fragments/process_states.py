"""Prozessstatus auf Deutsch"""

FRAGMENT = {
    'startup': {
        'loading': 'Anwendung wird gestartet...',
        'checking_deps': 'Abhängigkeiten werden überprüft...',
        'init_repo': 'Repository wird initialisiert...',
        'loading_profiles': 'Profile werden geladen...',
        'ready': 'System bereit'
    },
    'shutdown': {
        'saving': 'Änderungen werden gespeichert...',
        'cleaning': 'Temporäre Dateien werden bereinigt...',
        'closing': 'Anwendung wird beendet...'
    },
    'states': {
        'validating': 'Validierung...',
        'processing': 'Verarbeitung...',
        'signing': 'Signierung...',
        'verifying': 'Überprüfung...',
        'uploading': 'Hochladen...',
        'downloading': 'Herunterladen...',
        'installing': 'Installation...',
        'removing': 'Entfernen...',
        'cleaning': 'Bereinigung...',
        'backing_up': 'Sicherung...',
        'restoring': 'Wiederherstellung...',
        'calculating': 'Berechnung...',
        'updating': 'Aktualisierung...',
        'indexing': 'Indizierung...'
    }
}
