"""Traduzioni per il file .desktop in italiano"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Usare lo stesso nome di ui_elements
    'generic_name': 'Gestore dei Repository',
    'keywords': 'pacchetti;apt;repo;deb;gpg;repository;',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
