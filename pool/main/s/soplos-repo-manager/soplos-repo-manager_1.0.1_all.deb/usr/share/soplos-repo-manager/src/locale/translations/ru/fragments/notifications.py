"""Уведомления на русском"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Информация',
        'warning': 'Предупреждение',
        'error': 'Ошибка',
        'success': 'Успех'
    },
    'messages': {
        'package_added': 'Пакет {0} успешно добавлен',
        'package_removed': 'Пакет {0} удален',
        'upload_started': 'Начало загрузки {0}...',
        'upload_complete': 'Загрузка завершена: {0}',
        'update_available': 'Доступна новая версия: {0}',
        'repo_synced': 'Репозиторий синхронизирован',
        'backup_created': 'Резервная копия создана в {0}'
    }
}
