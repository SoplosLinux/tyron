"""Chaînes de texte manquantes en français"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Signaler des bugs',
        'license': 'Licence',
        'support': 'Support',
        'translate': 'Traduire',
        'version': 'Version',
        'website': 'Site web'
    },
    'buttons': {
        'accept': 'Accepter',
        'cancel': 'Annuler',
        'clean': 'Nettoyer',
        'close': 'Fermer',
        'create': 'Créer',
        'create_gpg_key': 'Créer une clé GPG',
        'delete': 'Supprimer',
        'delete_gpg_key': 'Supprimer la clé GPG',
        'no': 'Non',
        'overwrite': 'Écraser',
        'overwrite_all': 'Tout écraser',
        'save': 'Enregistrer',
        'select': 'Sélectionner',
        'skip': 'Ignorer',
        'skip_all': 'Tout ignorer',
        'update_list': 'Actualiser la liste',
        'yes': 'Oui'
    },
    'dialogs': {
        'colors': {
            'green': '\\033[0;32m',
            'red': '\\033[0;31m',
            'nc': '\\033[0m'
        },
        'confirm_clean_repo': 'Êtes-vous sûr de vouloir nettoyer le dépôt ?',
        'config_repo': 'Configurer le dépôt',
        'create_gpg': 'Créer une nouvelle clé GPG',
        'existing_file': 'Fichier existant',
        'file_details': 'Détails du fichier',
        'gpg_key_info': 'La clé GPG sera créée avec les données suivantes :',
        'gpg_verification': 'Vérification GPG',
        'install_script': 'Script d\'installation',
        'new_profile': 'Nouveau profil',
        'package_details': 'Détails du paquet {0}',
        'package_list': 'Liste des paquets',
        'profile_setup': 'Configuration initiale',
        'repo_instructions': 'Configurez les détails du dépôt Git.\nVous aurez besoin d\'un compte GitHub et d\'un token avec les permissions "repo".',
        'save_script': 'Enregistrer le script',
        'select_gpg': 'Sélectionner une clé GPG',
        'version_select': 'Sélectionner la version',
        'wait': 'Veuillez patienter'
    },
    'labels': {
        'arch': 'Architecture',
        'branch': 'Branche',
        'date': 'Date',
        'description': 'Description',
        'email': 'Email',
        'id': 'ID',
        'language': 'Langue',
        'list_filename': 'Nom du fichier .list',
        'name': 'Nom',
        'profile': 'Profil',
        'repo_title': 'Titre du dépôt',
        'repo_url': 'URL du dépôt',
        'section': 'Section',
        'size': 'Taille',
        'status': 'État',
        'token': 'Token',
        'tree_columns': {
            'file_date': 'Date',
            'file_name': 'Nom',
            'file_size': 'Taille',
            'file_status': 'État',
            'pkg_arch': 'Architecture',
            'pkg_description': 'Description',
            'pkg_name': 'Nom',
            'pkg_section': 'Section',
            'pkg_version': 'Version'
        }
    },
    'package_states': {
        'error': 'Erreur',
        'in_github': 'Sur GitHub',
        'in_incoming': 'En attente',
        'in_pool': 'Dans le pool',
        'new': 'Nouveau',
        'processing': 'En cours',
        'unknown': 'Inconnu',
        'uploaded': 'Envoyé',
        'uploading': 'Envoi en cours'
    },
    'placeholders': {
        'branch': 'main',
        'repo_url': 'https://github.com/utilisateur/depot',
        'token': 'Entrez votre token personnel GitHub'
    },
    'progress_messages': {
        'abort_task': 'Annulation de {0}...',
        'current_operation': 'Opération en cours : {0}',
        'error_task': 'Erreur dans {0} : {1}',
        'estimated_time': 'Temps estimé : {0}',
        'finish_task': 'Terminé {0}',
        'percent': '{0}% terminé',
        'processing_item': 'Traitement de {0}...',
        'remaining_items': 'Éléments restants : {0}',
        'start_task': 'Démarrage de {0}...',
        'task_status': '{0} sur {1}',
        'total_progress': 'Progression totale : {0}%'
    },
    'notes': {
        'branch': '<small>Il est recommandé d\'utiliser "main" par défaut</small>'
    },
    'defaults': {
        'install_script_name': 'installer-{}.sh',
        'list_filename': 'soplos.list',
        'repo_title': 'Dépôt Soplos'
    }
}
