"""Application information in English"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Keep the same name across all translations
    'display_name': 'Soplos Repo Manager',  # UI display name
    'version': 'Version {0}',
    'description': 'APT Repository Manager for Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'GPL-3.0 License',
    'website': 'https://soplos.org',
    'bugs': 'Report bugs',
    'support': 'Support',
    'translate': 'Help translate',
    'contributors': 'Contributors',
    'dependencies': 'Dependencies',
    'system_info': 'System information'
}
