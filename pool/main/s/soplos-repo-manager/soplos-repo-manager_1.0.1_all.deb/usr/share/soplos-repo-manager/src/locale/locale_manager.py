"""Gestor de idiomas"""
import gi
import locale
import logging
from typing import List

gi.require_version('GObject', '2.0')
from gi.repository import GObject

from .translations import TRANSLATIONS, LANGUAGE_NAMES

logger = logging.getLogger(__name__)

def get_system_language() -> str:
    """Detecta el idioma del sistema"""
    try:
        system_lang = locale.getdefaultlocale()[0]
        if system_lang:
            lang_code = system_lang.split('_')[0]
            if lang_code in TRANSLATIONS:
                return lang_code
    except Exception as e:
        logger.error(f"Error detectando idioma: {e}")
    return 'es'

class LocaleManager(GObject.Object):
    """Gestor de configuración de idioma"""
    __gsignals__ = {
        'language-changed': (GObject.SIGNAL_RUN_FIRST, None, ())
    }

    def __init__(self):
        super().__init__()
        self._current_lang = get_system_language()
        logger.debug(f"LocaleManager inicializado con idioma: {self._current_lang}")

    @property
    def current_lang(self) -> str:
        return self._current_lang

    def get_available_languages(self) -> List[str]:
        return sorted(TRANSLATIONS.keys())

    def get_language_name(self, lang_code: str) -> str:
        return LANGUAGE_NAMES.get(lang_code, lang_code)

    def set_language(self, lang_code: str) -> bool:
        if lang_code in TRANSLATIONS:
            self._current_lang = lang_code
            self.emit('language-changed')
            return True
        return False

# Instancia global
locale_manager = LocaleManager()
