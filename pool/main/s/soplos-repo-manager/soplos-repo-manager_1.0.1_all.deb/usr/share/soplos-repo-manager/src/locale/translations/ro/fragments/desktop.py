"""Traduceri pentru fișierul .desktop în română"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Folosiți același nume ca în ui_elements
    'generic_name': 'Manager de Depozite',
    'keywords': 'pachete;apt;repo;deb;gpg;depozit;',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
