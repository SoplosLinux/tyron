"""Package states in English"""

FRAGMENT = {
    'error': 'Error',
    'in_github': 'In GitHub',
    'in_incoming': 'In incoming',
    'in_pool': 'In pool',
    'new': 'New',
    'processing': 'Processing',
    'processed': 'Processed',  # Añadir traducción en inglés
    'unknown': 'Unknown',
    'uploaded': 'Uploaded',
    'uploading': 'Uploading'
}
