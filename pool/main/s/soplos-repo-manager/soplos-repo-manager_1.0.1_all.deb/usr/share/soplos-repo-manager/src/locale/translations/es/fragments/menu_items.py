"""Traducciones de elementos de menú en español"""

FRAGMENT = {
    'menu': {
        'file': '_Archivo',
        'edit': '_Editar',
        'view': '_Ver',
        'tools': '_Herramientas',
        'help': '_Ayuda'
    },
    'file_menu': {
        'save': '_Guardar',
        'save_as': 'Guardar _como',
        'preferences': '_Preferencias',
        'quit': '_Salir'
    },
    'edit_menu': {
        'undo': '_Deshacer',
        'redo': '_Rehacer',
        'cut': 'Cor_tar',
        'copy': '_Copiar',
        'paste': '_Pegar',
        'delete': '_Eliminar',
        'select_all': 'Seleccionar _todo'
    },
    'view_menu': {
        'refresh': '_Actualizar',
        'fullscreen': '_Pantalla completa',
        'zoom_in': 'Aumentar zoom',
        'zoom_out': 'Reducir zoom',
        'reset_zoom': 'Zoom normal'
    },
    'help_menu': {
        'about': '_Acerca de',
        'documentation': '_Documentación',
        'keyboard_shortcuts': 'Atajos de _teclado',
        'report_bug': 'Informar de un _error',
        'check_updates': 'Buscar _actualizaciones'
    }
}
