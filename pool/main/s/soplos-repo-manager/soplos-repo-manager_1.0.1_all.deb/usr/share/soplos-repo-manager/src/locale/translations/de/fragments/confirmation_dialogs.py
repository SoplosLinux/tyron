"""Bestätigungsdialoge auf Deutsch"""

FRAGMENT = {
    'delete_package': {
        'title': 'Paket löschen',
        'message': 'Sind Sie sicher, dass Sie das Paket {0} löschen möchten?',
        'details': 'Diese Aktion wird das Paket aus dem Repository und alle zugehörigen Dateien entfernen.'
    },
    'clean_repo': {
        'title': 'Repository bereinigen',
        'message': 'Sind Sie sicher, dass Sie das Repository bereinigen möchten?',
        'details': 'Diese Aktion wird alle temporären Dateien entfernen und die Indizes neu aufbauen.'
    },
    'delete_profile': {
        'title': 'Profil löschen',
        'message': 'Sind Sie sicher, dass Sie das Profil {0} löschen möchten?',
        'details': 'Diese Aktion wird alle Konfigurationen und Dateien des Profils löschen.'
    },
    'exit_app': {
        'title': 'Beenden',
        'message': 'Sind Sie sicher, dass Sie beenden möchten?',
        'details': 'Nicht gespeicherte Änderungen gehen verloren.'
    }
}
