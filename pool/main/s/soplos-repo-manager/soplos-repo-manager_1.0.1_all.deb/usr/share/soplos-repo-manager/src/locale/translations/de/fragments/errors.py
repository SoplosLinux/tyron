"""Fehlermeldungen auf Deutsch"""

FRAGMENT = {
    'git_not_installed': 'GitPython wird benötigt (python3-git)',
    'load_profiles': 'Fehler beim Laden der Profile: {0}',
    'save_profile': 'Fehler beim Speichern des Profils: {0}',
    'delete_profile': 'Fehler beim Löschen des Profils: {0}',
    'loading_config': 'Fehler beim Laden der Konfiguration: {0}',
    'saving_config': 'Fehler beim Speichern der Konfiguration: {0}',
    'repo_init': 'Fehler bei der Git-Repository-Initialisierung: {0}',
    'get_repo_name': 'Fehler beim Abrufen des Repository-Namens: {0}',
    'readme_dialog': 'Fehler im README-Dialog: {0}',
    'list_packages': 'Fehler beim Auflisten der Pakete: {0}',
    'reading_package': 'Fehler beim Lesen von {0}: {1}',
    'create_structure': 'Fehler beim Erstellen der Struktur: {0}',
    'configure_reprepro': 'Fehler bei der Reprepro-Konfiguration: {0}',
    'init_indices': 'Fehler bei der Indizes-Initialisierung: {0}',
    'verify_structure': 'Fehler bei der Strukturüberprüfung: {0}',
    'integrity_check': 'Fehler bei der Integritätsprüfung: {0}',
    'reprepro_stderr': 'Reprepro-Fehler: {0}'
}
