"""Platzhaltertexte auf Deutsch"""

FRAGMENT = {
    'repo_url': 'https://github.com/benutzer/repository',
    'token': 'Geben Sie Ihren persönlichen GitHub-Token ein',
    'branch': 'main',
    'search': 'Suchen...',
    'filter': 'Filtern...',
    'comments': 'Kommentar schreiben...',
    'name': 'Vollständiger Name',
    'email': 'email@beispiel.de',
    'profile_name': 'Profilname',
    'password': 'Passwort',
    'confirm_password': 'Passwort bestätigen'
}
