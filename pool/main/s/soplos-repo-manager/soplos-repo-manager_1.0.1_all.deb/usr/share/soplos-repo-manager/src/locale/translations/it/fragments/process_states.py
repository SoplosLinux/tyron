"""Stati dei processi in italiano"""

FRAGMENT = {
    'startup': {
        'loading': 'Avvio applicazione...',
        'checking_deps': 'Verifica dipendenze...',
        'init_repo': 'Inizializzazione repository...',
        'loading_profiles': 'Caricamento profili...',
        'ready': 'Sistema pronto'
    },
    'shutdown': {
        'saving': 'Salvataggio modifiche...',
        'cleaning': 'Pulizia file temporanei...',
        'closing': 'Chiusura applicazione...'
    },
    'states': {
        'validating': 'Convalida...',
        'processing': 'Elaborazione...',
        'signing': 'Firma...',
        'verifying': 'Verifica...',
        'uploading': 'Caricamento...',
        'downloading': 'Scaricamento...',
        'installing': 'Installazione...',
        'removing': 'Rimozione...',
        'cleaning': 'Pulizia...',
        'backing_up': 'Backup...',
        'restoring': 'Ripristino...',
        'calculating': 'Calcolo...',
        'updating': 'Aggiornamento...',
        'indexing': 'Indicizzazione...'
    }
}
