"""Traducciones de operaciones de archivo en español"""

FRAGMENT = {
    'operations': {
        'copying': 'Copiando {0}...',
        'moving': 'Moviendo {0}...',
        'removing': 'Eliminando {0}...',
        'creating_dir': 'Creando directorio {0}...',
        'reading': 'Leyendo {0}...',
        'writing': 'Escribiendo {0}...'
    },
    'errors': {
        'error_copy': 'Error copiando archivo: {0}',
        'error_move': 'Error moviendo archivo: {0}',
        'error_remove': 'Error eliminando archivo: {0}',
        'error_create': 'Error creando directorio: {0}',
        'error_read': 'Error leyendo archivo: {0}',
        'error_write': 'Error escribiendo archivo: {0}'
    }
}
