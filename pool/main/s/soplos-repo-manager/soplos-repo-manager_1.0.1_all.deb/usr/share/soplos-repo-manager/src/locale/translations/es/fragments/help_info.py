"""Traducciones de ayuda en español"""

FRAGMENT = {
    'help_info': {
        'gpg_setup': 'Cómo configurar GPG',
        'repo_setup': 'Cómo configurar el repositorio',
        'profiles': 'Uso de perfiles',
        'packages': 'Gestión de paquetes',
        'scripts': 'Scripts de instalación',
        'updates': 'Actualizaciones',
        'support': 'Obtener soporte',
        'sections': {
            'quick_start': 'Inicio rápido',
            'configuration': 'Configuración',
            'usage': 'Uso básico',
            'advanced': 'Opciones avanzadas',
            'troubleshooting': 'Solución de problemas',
            'faq': 'Preguntas frecuentes'
        }
    }
}
