"""Dialogmeldungen auf Deutsch"""

FRAGMENT = {
    'select_gpg': 'GPG-Schlüssel auswählen',
    'wait': 'Bitte warten...',
    'config_repo': 'Repository konfigurieren',
    'new_profile': 'Neues Profil',
    'package_list': 'Paketliste',
    'version_select': 'Version auswählen',
    'existing_file': 'Vorhandene Datei',
    'file_details': 'Dateidetails',
    'package_details': 'Paketdetails',
    'create_gpg': 'Neuen GPG-Schlüssel erstellen',
    'select_gpg': 'GPG-Schlüssel auswählen',
    'save_script': 'Installationsskript speichern',
    'install_script': 'Installationsskript',
    'gpg_verification': 'GPG-Verifizierung',
    'gpg_key_info': 'GPG-Schlüsselinformationen',
    'repo_instructions': 'Repository-Anweisungen',
    'confirm_clean_repo': 'Repository-Bereinigung bestätigen',
    'colors': {
        'green': 'Grün',
        'red': 'Rot',
        'nc': 'Keine Farbe'
    }
}
