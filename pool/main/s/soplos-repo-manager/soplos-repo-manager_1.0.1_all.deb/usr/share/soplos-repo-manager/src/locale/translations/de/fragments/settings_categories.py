"""Einstellungskategorien auf Deutsch"""

FRAGMENT = {
    'general': {
        'title': 'Allgemein',
        'language': 'Sprache',
        'updates': 'Aktualisierungen',
        'notifications': 'Benachrichtigungen'
    },
    'appearance': {
        'title': 'Erscheinungsbild',
        'theme': 'Design',
        'icons': 'Symbole',
        'fonts': 'Schriftarten'
    },
    'network': {
        'title': 'Netzwerk',
        'proxy': 'Proxy',
        'timeout': 'Zeitüberschreitung',
        'retries': 'Wiederholungen'
    },
    'advanced': {
        'title': 'Erweitert',
        'logging': 'Protokollierung',
        'debug': 'Fehlersuche',
        'cache': 'Zwischenspeicher'
    },
    'profiles': {
        'title': 'Profile',
        'default': 'Standardprofil',
        'auto_load': 'Letztes Profil laden',
        'backup': 'Automatische Sicherung'
    }
}
