"""Logging messages in English"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'Starting repository package cleanup...',
        'cleaning_complete': 'Repository cleaned successfully',
        'generating_key': 'Generating GPG key...',
        'key_generated': 'GPG key generated with ID: {0}',
        'cloning_repo': 'Cloning repository from {0}',
        'updating_readme': 'Updating README...'
    },
    'info': {
        'profile_loaded': 'Profile {0} loaded',
        'deleting_package': 'Deleting {0} from reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'Could not delete {0}: {1}',
        'key_not_found': 'Could not find generated key'
    }
}
