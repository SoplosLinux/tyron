"""Messages système en français"""

FRAGMENT = {
    'system': {
        'startup': {
            'loading': 'Démarrage de l\'application...',
            'checking_deps': 'Vérification des dépendances...',
            'init_repo': 'Initialisation du dépôt...',
            'loading_profiles': 'Chargement des profils...',
            'ready': 'Système prêt'
        },
        'shutdown': {
            'saving': 'Enregistrement des modifications...',
            'cleaning': 'Nettoyage des fichiers temporaires...',
            'closing': 'Fermeture de l\'application...'
        },
        'errors': {
            'critical': 'Erreur critique : {0}',
            'dependency': 'Dépendance manquante : {0}',
            'permission': 'Erreur de permissions : {0}',
            'connection': 'Erreur de connexion : {0}',
            'config': 'Erreur de configuration : {0}'
        },
        'warnings': {
            'disk_space': 'Espace disque faible',
            'memory': 'Mémoire système faible',
            'connection': 'Connexion instable',
            'outdated': 'Version obsolète'
        }
    }
}
