"""Cadenas de texto faltantes en español"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Reportar errores',
        'license': 'Licencia',
        'support': 'Soporte',
        'translate': 'Traducir',
        'version': 'Versión',
        'website': 'Sitio web'
    },
    'buttons': {
        'accept': 'Aceptar',
        'cancel': 'Cancelar',
        'clean': 'Limpiar',
        'close': 'Cerrar',
        'create': 'Crear',
        'create_gpg_key': 'Crear clave GPG',
        'delete': 'Eliminar',
        'delete_gpg_key': 'Eliminar clave GPG',
        'no': 'No',
        'overwrite': 'Sobrescribir',
        'overwrite_all': 'Sobrescribir todo',
        'save': 'Guardar',
        'select': 'Seleccionar',
        'skip': 'Omitir',
        'skip_all': 'Omitir todo',
        'update_list': 'Actualizar lista',
        'yes': 'Sí'
    },
    'dialogs': {
        'colors': {
            'green': '\\033[0;32m',
            'red': '\\033[0;31m',
            'nc': '\\033[0m'
        },
        'confirm_clean_repo': '¿Está seguro de que desea limpiar el repositorio?',
        'config_repo': 'Configurar repositorio',
        'create_gpg': 'Crear nueva clave GPG',
        'existing_file': 'Archivo existente',
        'file_details': 'Detalles del archivo',
        'gpg_key_info': 'La clave GPG se creará con los siguientes datos:',
        'gpg_verification': 'Verificación GPG',
        'install_script': 'Script de instalación',
        'new_profile': 'Nuevo perfil',
        'package_details': 'Detalles del paquete {0}',
        'package_list': 'Lista de paquetes',
        'profile_setup': 'Configuración inicial',
        'repo_instructions': 'Configure los detalles del repositorio Git.\nNecesitará una cuenta de GitHub y un token con permisos "repo".',
        'save_script': 'Guardar script',
        'select_gpg': 'Seleccionar clave GPG',
        'version_select': 'Seleccionar versión',
        'wait': 'Por favor espere'
    },
    'labels': {
        'arch': 'Arquitectura',
        'branch': 'Rama',
        'date': 'Fecha',
        'description': 'Descripción',
        'email': 'Email',
        'id': 'ID',
        'language': 'Idioma',
        'list_filename': 'Nombre del archivo .list',
        'name': 'Nombre',
        'profile': 'Perfil',
        'repo_title': 'Título del repositorio',
        'repo_url': 'URL del repositorio',
        'section': 'Sección',
        'size': 'Tamaño',
        'status': 'Estado',
        'token': 'Token',
        'tree_columns': {
            'file_date': 'Fecha',
            'file_name': 'Nombre',
            'file_size': 'Tamaño', 
            'file_status': 'Estado',
            'pkg_arch': 'Arquitectura',
            'pkg_description': 'Descripción',
            'pkg_name': 'Nombre',
            'pkg_section': 'Sección',
            'pkg_version': 'Versión'
        }
    },
    'package_states': {
        'error': 'Error',
        'in_github': 'En GitHub',
        'in_incoming': 'En entrada',
        'in_pool': 'En pool',
        'new': 'Nuevo',
        'processing': 'Procesando',
        'processed': 'Procesado',  # Añadir esta traducción
        'unknown': 'Desconocido',
        'uploaded': 'Subido',
        'uploading': 'Subiendo'
    },
    'placeholders': {
        'branch': 'main',
        'repo_url': 'https://github.com/usuario/repositorio',
        'token': 'Ingrese su token personal de GitHub'
    },
    'progress_messages': {
        'abort_task': 'Abortando {0}...',
        'current_operation': 'Operación actual: {0}',
        'error_task': 'Error en {0}: {1}',
        'estimated_time': 'Tiempo estimado: {0}',
        'finish_task': 'Finalizado {0}',
        'percent': '{0}% completado',
        'processing_item': 'Procesando {0}...',
        'remaining_items': 'Elementos restantes: {0}',
        'start_task': 'Iniciando {0}...',
        'task_status': '{0} de {1}',
        'total_progress': 'Progreso total: {0}%'
    },
    'notes': {
        'branch': '<small>Se recomienda usar "main" por defecto</small>'
    },
    'defaults': {
        'install_script_name': 'instalar-{}.sh',
        'list_filename': 'soplos.list',
        'repo_title': 'Repositorio Soplos'
    }
}
