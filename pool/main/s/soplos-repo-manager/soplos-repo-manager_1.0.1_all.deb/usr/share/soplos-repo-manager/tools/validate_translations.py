#!/usr/bin/env python3
"""
Herramienta para validar y verificar traducciones
"""
import os
import sys
import json
from pathlib import Path
from typing import Dict, List, Set

from src.locale.translations import TRANSLATIONS, BASE_TRANSLATIONS

def _get_all_keys(d: Dict, prefix: str = '') -> Set[str]:
    """Obtiene todas las claves de un diccionario anidado"""
    keys = set()
    for k, v in d.items():
        full_key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            keys.update(_get_all_keys(v, full_key))
        else:
            keys.add(full_key)
    return keys

def validate_translation_format(base: Dict, translation: Dict, path: str="") -> List[str]:
    """Valida el formato y estructura de una traducción"""
    errors = []
    
    for key, value in base.items():
        current_path = f"{path}.{key}" if path else key
        
        if key not in translation:
            errors.append(f"Falta la clave '{current_path}'")
            continue
            
        if isinstance(value, dict):
            if not isinstance(translation[key], dict):
                errors.append(f"'{current_path}' debe ser un diccionario")
            else:
                errors.extend(validate_translation_format(value, translation[key], current_path))
                
        elif not isinstance(translation[key], str):
            errors.append(f"'{current_path}' debe ser una cadena")
            
    return errors

def get_untranslated(translation: Dict, path: str="") -> Set[str]:
    """Encuentra claves sin traducir (vacías)"""
    empty = set()
    
    for key, value in translation.items():
        current_path = f"{path}.{key}" if path else key
        
        if isinstance(value, dict):
            empty.update(get_untranslated(value, current_path))
        elif not value:
            empty.add(current_path)
            
    return empty

def main():
    """Función principal"""
    for lang_code, translation in TRANSLATIONS.items():
        if lang_code == 'es':  # Saltar español (base)
            continue
            
        print(f"\nValidando {lang_code}...")
        
        # Usar la función _get_all_keys local
        base_keys = _get_all_keys(BASE_TRANSLATIONS)
        trans_keys = _get_all_keys(translation)
        
        # Validar formato
        errors = validate_translation_format(BASE_TRANSLATIONS, translation)
        if errors:
            print("\nErrores de formato:")
            for error in errors:
                print(f"- {error}")
                
        # Buscar no traducidas
        empty = get_untranslated(translation)
        if empty:
            print("\nClaves sin traducir:")
            for key in sorted(empty):
                print(f"- {key}")
                
        # Buscar claves extra
        extra = trans_keys - base_keys
        if extra:
            print("\nClaves extra:")
            for key in sorted(extra):
                print(f"- {key}")

if __name__ == "__main__":
    main()
