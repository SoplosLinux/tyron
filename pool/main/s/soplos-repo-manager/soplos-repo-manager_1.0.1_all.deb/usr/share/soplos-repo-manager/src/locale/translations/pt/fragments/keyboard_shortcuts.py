"""Traduções de atalhos de teclado em português"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Atalhos de teclado',
        'categories': {
            'general': 'Geral',
            'navigation': 'Navegação',
            'editing': 'Edição',
            'view': 'Visualização'
        },
        'actions': {
            'save': 'Guardar (Ctrl+S)',
            'quit': 'Sair (Ctrl+Q)',
            'refresh': 'Atualizar (Ctrl+R)',
            'search': 'Procurar (Ctrl+F)',
            'preferences': 'Preferências (Ctrl+P)',
            'help': 'Ajuda (F1)',
            'switch_tab': 'Mudar separador (Ctrl+Tab)',
            'new_item': 'Novo elemento (Ctrl+N)',
            'delete_item': 'Eliminar elemento (Del)',
            'fullscreen': 'Ecrã inteiro (F11)',
            'zoom_in': 'Aumentar zoom (Ctrl++)',
            'zoom_out': 'Diminuir zoom (Ctrl+-)',
            'reset_zoom': 'Repor zoom (Ctrl+0)'
        }
    }
}
