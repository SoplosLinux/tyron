"""Traduzioni in italiano"""

from .fragments.app_info import FRAGMENT as APP_INFO
from .fragments.buttons import FRAGMENT as BUTTONS
from .fragments.notes import FRAGMENT as NOTES
from .fragments.confirmation_dialogs import FRAGMENT as CONFIRMATIONS
from .fragments.defaults import FRAGMENT as DEFAULTS
from .fragments.dialog_messages import FRAGMENT as DIALOG_MSGS
from .fragments.dialogs import FRAGMENT as DIALOGS  # Aggiungere questa importazione
from .fragments.errors import FRAGMENT as ERRORS
from .fragments.file_filters import FRAGMENT as FILE_FILTERS
from .fragments.file_operations import FRAGMENT as FILE_OPS
from .fragments.help_info import FRAGMENT as HELP
from .fragments.keyboard_shortcuts import FRAGMENT as KEYBOARD
from .fragments.labels import FRAGMENT as LABELS
from .fragments.logging import FRAGMENT as LOGGING
from .fragments.menu_items import FRAGMENT as MENUS
from .fragments.messages import FRAGMENT as MESSAGES
from .fragments.missing import FRAGMENT as MISSING
from .fragments.notifications import FRAGMENT as NOTIFICATIONS
from .fragments.package_states import FRAGMENT as PKG_STATES
from .fragments.placeholders import FRAGMENT as PLACEHOLDERS
from .fragments.process_states import FRAGMENT as PROCESS_STATES
from .fragments.progress_messages import FRAGMENT as PROGRESS
from .fragments.scripts import FRAGMENT as SCRIPTS
from .fragments.script_texts import FRAGMENT as SCRIPT_TEXTS
from .fragments.settings_categories import FRAGMENT as SETTINGS
from .fragments.status import FRAGMENT as STATUS
from .fragments.system_messages import FRAGMENT as SYSTEM
from .fragments.time_formats import FRAGMENT as TIME
from .fragments.tooltips import FRAGMENT as TOOLTIPS
from .fragments.ui_elements import FRAGMENT as UI
from .fragments.validation import FRAGMENT as VALIDATION

# Assicurarsi che UI sia prima nella combinazione per avere la priorità
ITALIAN = {
    'ui_elements': UI,
    'buttons': BUTTONS,
    'labels': LABELS,
    'messages': MESSAGES,
    'dialogs': DIALOGS,
    'errors': ERRORS,
    'file_filters': FILE_FILTERS,
    'file_operations': FILE_OPS,
    'help_info': HELP,
    'keyboard_shortcuts': KEYBOARD,
    'logging': LOGGING,
    'menu_items': MENUS,
    'missing': MISSING,
    'notes': NOTES,
    'notifications': NOTIFICATIONS,
    'package_states': PKG_STATES,
    'placeholders': PLACEHOLDERS,
    'process_states': PROCESS_STATES,
    'progress_messages': PROGRESS,
    'scripts': SCRIPTS,
    'script_texts': SCRIPT_TEXTS,
    'settings_categories': SETTINGS,
    'status': STATUS,
    'system_messages': SYSTEM,
    'time_formats': TIME,
    'tooltips': TOOLTIPS,
    'validation': VALIDATION,
    'defaults': DEFAULTS,
    **LOGGING
}
