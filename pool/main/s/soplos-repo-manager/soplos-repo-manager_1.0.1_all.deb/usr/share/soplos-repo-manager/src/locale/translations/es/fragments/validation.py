"""Mensajes de validación en español"""

FRAGMENT = {
    'url_invalid': 'URL inválida',
    'token_invalid': 'Token inválido',
    'branch_empty': 'La rama no puede estar vacía',
    'name_invalid': 'Nombre inválido',
    'email_invalid': 'Email inválido',
    'duplicate': '{0} ya existe',
    'required_field': 'Campo requerido: {0}',
    'invalid_input': 'Entrada inválida: {0}',
    'config_error': 'Error de configuración: {0}',
    'profile_exists': 'Ya existe un perfil con ese nombre',
    'missing_fields': 'Todos los campos son obligatorios',
    'gpg_key_required': 'Se requiere una clave GPG',
    'invalid_version': 'Versión inválida'
}
