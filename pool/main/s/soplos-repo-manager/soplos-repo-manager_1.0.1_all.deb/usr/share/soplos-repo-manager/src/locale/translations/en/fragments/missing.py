"""Missing strings in English"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Report bugs',
        'license': 'License',
        'support': 'Support',
        'translate': 'Translate',
        'version': 'Version',
        'website': 'Website'
    },
    'buttons': {
        'accept': 'Accept',
        'cancel': 'Cancel',
        'clean': 'Clean',
        'close': 'Close',
        'create': 'Create',
        'create_gpg_key': 'Create GPG key',
        'delete': 'Delete',
        'delete_gpg_key': 'Delete GPG key',
        'no': 'No',
        'overwrite': 'Overwrite',
        'overwrite_all': 'Overwrite all',
        'save': 'Save',
        'select': 'Select',
        'skip': 'Skip',
        'skip_all': 'Skip all',
        'update_list': 'Update list',
        'yes': 'Yes'
    },
    'dialogs': {
        'colors': {
            'green': '\\033[0;32m',
            'red': '\\033[0;31m',
            'nc': '\\033[0m'
        },
        'confirm_clean_repo': 'Are you sure you want to clean the repository?',
        'config_repo': 'Configure repository',
        'create_gpg': 'Create new GPG key',
        'existing_file': 'Existing file',
        'file_details': 'File details',
        'gpg_key_info': 'The GPG key will be created with the following data:',
        'gpg_verification': 'GPG verification',
        'install_script': 'Installation script',
        'new_profile': 'New profile',
        'package_details': 'Package details {0}',
        'package_list': 'Package list',
        'profile_setup': 'Initial setup',
        'repo_instructions': 'Configure the Git repository details.\nYou will need a GitHub account and a token with "repo" permissions.',
        'save_script': 'Save script',
        'select_gpg': 'Select GPG key',
        'version_select': 'Select version',
        'wait': 'Please wait'
    },
    'labels': {
        'arch': 'Architecture',
        'branch': 'Branch',
        'date': 'Date',
        'description': 'Description',
        'email': 'Email',
        'id': 'ID',
        'language': 'Language',
        'list_filename': 'List filename',
        'name': 'Name',
        'profile': 'Profile',
        'repo_title': 'Repository title',
        'repo_url': 'Repository URL',
        'section': 'Section',
        'size': 'Size',
        'status': 'Status',
        'token': 'Token',
        'tree_columns': {
            'file_date': 'Date',
            'file_name': 'Name',
            'file_size': 'Size',
            'file_status': 'Status',
            'pkg_arch': 'Architecture',
            'pkg_description': 'Description',
            'pkg_name': 'Name',
            'pkg_section': 'Section',
            'pkg_version': 'Version'
        }
    },
    'package_states': {
        'error': 'Error',
        'in_github': 'In GitHub',
        'in_incoming': 'In incoming',
        'in_pool': 'In pool',
        'new': 'New',
        'processing': 'Processing',
        'unknown': 'Unknown',
        'uploaded': 'Uploaded',
        'uploading': 'Uploading'
    },
    'placeholders': {
        'branch': 'main',
        'repo_url': 'https://github.com/user/repository',
        'token': 'Enter your personal GitHub token'
    },
    'progress_messages': {
        'abort_task': 'Aborting {0}...',
        'current_operation': 'Current operation: {0}',
        'error_task': 'Error in {0}: {1}',
        'estimated_time': 'Estimated time: {0}',
        'finish_task': 'Finished {0}',
        'percent': '{0}% completed',
        'processing_item': 'Processing {0}...',
        'remaining_items': 'Remaining items: {0}',
        'start_task': 'Starting {0}...',
        'task_status': '{0} of {1}',
        'total_progress': 'Total progress: {0}%'
    },
    'notes': {
        'branch': '<small>Using "main" is recommended by default</small>'
    },
    'defaults': {
        'install_script_name': 'install-{}.sh',
        'list_filename': 'soplos.list',
        'repo_title': 'Soplos Repository'
    }
}
