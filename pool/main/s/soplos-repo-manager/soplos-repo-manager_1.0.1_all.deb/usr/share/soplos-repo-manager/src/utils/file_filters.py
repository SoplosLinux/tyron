from gi.repository import Gtk

def create_deb_filter():
    """Crear filtro para archivos .deb"""
    deb_filter = Gtk.FileFilter()
    deb_filter.set_name("Paquetes Debian (*.deb)")
    deb_filter.add_pattern("*.deb")
    return deb_filter

def create_all_filter():
    """Crear filtro para todos los archivos"""
    all_filter = Gtk.FileFilter()
    all_filter.set_name("Todos los archivos")
    all_filter.add_pattern("*")
    return all_filter
