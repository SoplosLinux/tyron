"""Anwendungsinformationen"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Namen in allen Übersetzungen gleich lassen
    'display_name': 'Soplos Repo Manager',  # UI-Anzeigename
    'version': 'Version {0}',
    'description': 'APT-Repository-Manager für Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'GPL-3.0-Lizenz',
    'website': 'https://soplos.org',
    'bugs': 'Fehler melden',
    'support': 'Support',
    'translate': 'Bei der Übersetzung helfen',
    'contributors': 'Mitwirkende',
    'dependencies': 'Abhängigkeiten',
    'system_info': 'Systeminformationen'
}
