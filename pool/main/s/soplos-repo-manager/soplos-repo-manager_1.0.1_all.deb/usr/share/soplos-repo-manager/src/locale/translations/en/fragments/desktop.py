"""Desktop file translations in English"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Keep the same name
    'generic_name': 'Repository Manager',
    'keywords': 'packages;apt;repo;deb;gpg;repository;management;linux;soplos',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
