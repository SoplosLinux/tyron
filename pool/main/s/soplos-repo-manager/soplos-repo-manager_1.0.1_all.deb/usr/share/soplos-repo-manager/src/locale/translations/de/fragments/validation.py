"""Validierungsmeldungen auf Deutsch"""

FRAGMENT = {
    'url_invalid': 'Ungültige URL',
    'token_invalid': 'Ungültiger Token',
    'branch_empty': 'Der Branch darf nicht leer sein',
    'name_invalid': 'Ungültiger Name',
    'email_invalid': 'Ungültige E-Mail',
    'duplicate': '{0} existiert bereits',
    'required_field': 'Pflichtfeld: {0}',
    'invalid_input': 'Ungültige Eingabe: {0}',
    'config_error': 'Konfigurationsfehler: {0}',
    'profile_exists': 'Ein Profil mit diesem Namen existiert bereits',
    'missing_fields': 'Alle Felder sind erforderlich',
    'gpg_key_required': 'Ein GPG-Schlüssel ist erforderlich',
    'invalid_version': 'Ungültige Version'
}
