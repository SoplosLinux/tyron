"""Testi degli script in italiano"""

FRAGMENT = {
    'script_header': '#!/bin/bash\n# Script di installazione per repository {0}\n',
    'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo "Questo script deve essere eseguito come root"\n    exit 1\nfi\n',
    'add_key': 'Aggiunta chiave GPG...',
    'add_repo': 'Aggiunta repository...',
    'updating': 'Aggiornamento indici...',
    'installing': 'Installazione pacchetti...',
    'complete': 'Installazione completata',
    'error': 'Errore: {0}',
    'warning': 'Avviso: {0}',
    'info': 'Info: {0}',
    'debug': 'Debug: {0}',
    'script_footer': 'echo "Processo completato"\nexit 0'
}
