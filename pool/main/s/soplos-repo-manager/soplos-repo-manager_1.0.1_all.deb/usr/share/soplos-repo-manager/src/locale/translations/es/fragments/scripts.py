"""Traducciones de scripts en español"""

FRAGMENT = {
    'downloading_gpg': 'Descargando clave GPG...',
    'error_downloading_gpg': 'Error al descargar la clave GPG',
    'verify_root': 'Verificar si se ejecuta como root',
    'must_be_root': 'Este script debe ejecutarse como root',
    'create_keyring': 'Crear directorio de llavero GPG',
    'download_gpg': 'Descargar e importar clave GPG',
    'verify_gpg': 'Verificar que la clave se descargó correctamente',
    'error_gpg_empty': 'Error: La clave GPG está vacía o no se instaló',
    'config_repo': 'Configurar repositorio',
    'configuring_repo': 'Configurando repositorio...',
    'force_update': 'Forzar actualización segura',
    'updating_indices': 'Actualizando índices...',
    'verify_repo': 'Verificar que el repositorio está configurado',
    'error_repo_not_configured': 'Error: El repositorio no se configuró correctamente',
    'repo_installed': '¡Repositorio instalado correctamente!',
    'colors': 'Colores para mensajes',
    'install_repo': 'Script de instalación para repositorio {}'
}
