"""Traduzioni delle operazioni sui file in italiano"""

FRAGMENT = {
    'operations': {
        'copying': 'Copia di {0}...',
        'moving': 'Spostamento di {0}...',
        'removing': 'Rimozione di {0}...',
        'creating_dir': 'Creazione directory {0}...',
        'reading': 'Lettura di {0}...',
        'writing': 'Scrittura di {0}...'
    },
    'errors': {
        'error_copy': 'Errore durante la copia del file: {0}',
        'error_move': 'Errore durante lo spostamento del file: {0}',
        'error_remove': 'Errore durante la rimozione del file: {0}',
        'error_create': 'Errore durante la creazione della directory: {0}',
        'error_read': 'Errore durante la lettura del file: {0}',
        'error_write': 'Errore durante la scrittura del file: {0}'
    }
}
