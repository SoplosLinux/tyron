"""Time format translations in English"""

FRAGMENT = {
    'short_date': '%m/%d/%Y',
    'long_date': '%B %d, %Y',
    'time': '%H:%M:%S',
    'datetime': '%m/%d/%Y %H:%M:%S',
    'month_names': [
        'January', 'February', 'March', 'April',
        'May', 'June', 'July', 'August',
        'September', 'October', 'November', 'December'
    ],
    'day_names': [
        'Monday', 'Tuesday', 'Wednesday', 'Thursday',
        'Friday', 'Saturday', 'Sunday'
    ],
    'relative': {
        'today': 'Today',
        'yesterday': 'Yesterday',
        'tomorrow': 'Tomorrow',
        'past': '{0} ago',
        'future': 'In {0}'
    }
}
