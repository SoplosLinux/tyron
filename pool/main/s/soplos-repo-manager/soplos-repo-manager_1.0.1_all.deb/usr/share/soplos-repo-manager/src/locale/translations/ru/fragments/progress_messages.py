"""Сообщения о прогрессе на русском"""

FRAGMENT = {
    'estimated_time': 'Расчетное оставшееся время: {0}',
    'total_progress': 'Общий прогресс: {0}%',
    'remaining_items': 'Осталось элементов: {0}',
    'task_status': '{0} из {1}',
    'current_operation': 'Текущая операция: {0}',
    'processing_item': 'Обработка {0}...',
    'start_task': 'Запуск {0}...',
    'finish_task': 'Завершено {0}',
    'abort_task': 'Прерывание {0}...',
    'error_task': 'Ошибка в {0}: {1}',
    'percent': '{0}% выполнено'
}
