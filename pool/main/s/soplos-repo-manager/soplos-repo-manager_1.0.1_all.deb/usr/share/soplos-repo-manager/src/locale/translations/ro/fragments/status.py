"""Stări și mesaje de stare în română"""

FRAGMENT = {
    'ready': 'Gata',
    'processing': 'Se procesează...',
    'waiting': 'Se așteaptă...',
    'completed': 'Finalizat',
    'failed': 'Eșuat',
    'uploading': 'Se încarcă...',
    'downloading': 'Se descarcă...',
    'installing': 'Se instalează...',
    'updating': 'Se actualizează...',
    'error': 'Eroare',
    'success': 'Succes',
    'cancelled': 'Anulat',
    'paused': 'Întrerupt',
    'offline': 'Deconectat',
    'online': 'Conectat',
    'syncing': 'Se sincronizează...',
    'initializing': 'Se inițializează...',
    'cleaning': 'Se curăță...'
}
