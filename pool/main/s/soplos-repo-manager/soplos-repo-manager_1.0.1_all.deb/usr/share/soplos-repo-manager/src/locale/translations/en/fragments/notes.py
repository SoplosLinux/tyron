"""Notes and help texts in English"""

FRAGMENT = {
    'branch': '<small>Using "main" is recommended by default</small>',
    'gpg_key': '<small>Using a GPG key is recommended to sign packages</small>',
    'repo': '<small>The repository will be configured with the provided details</small>',
    'profile': '<small>A new profile will be created with the provided details</small>',
    'backup': '<small>A backup of the current configuration will be created</small>',
    'restore': '<small>Configuration will be restored from backup</small>',
    'import': '<small>Configuration will be imported from selected file</small>',
    'export': '<small>Configuration will be exported to selected file</small>',
    'update': '<small>Package indices will be updated</small>',
    'preferences': '<small>User preferences will be saved</small>'
}
