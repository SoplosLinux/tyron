"""Estados y mensajes de estado en español"""

FRAGMENT = {
    'ready': 'Listo',
    'processing': 'Procesando...',
    'waiting': 'Esperando...',
    'completed': 'Completado',
    'failed': 'Fallido',
    'uploading': 'Subiendo...',
    'downloading': 'Descargando...',
    'installing': 'Instalando...',
    'updating': 'Actualizando...',
    'error': 'Error',
    'success': 'Éxito',
    'cancelled': 'Cancelado',
    'paused': 'Pausado',
    'offline': 'Desconectado',
    'online': 'Conectado',
    'syncing': 'Sincronizando...',
    'initializing': 'Inicializando...',
    'cleaning': 'Limpiando...'
}
