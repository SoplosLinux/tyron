"""Skript-Übersetzungen auf Deutsch"""

FRAGMENT = {
    'downloading_gpg': 'GPG-Schlüssel wird heruntergeladen...',
    'error_downloading_gpg': 'Fehler beim Herunterladen des GPG-Schlüssels',
    'verify_root': 'Überprüfen ob als Root ausgeführt',
    'must_be_root': 'Dieses Skript muss als Root ausgeführt werden',
    'create_keyring': 'GPG-Schlüsselbund-Verzeichnis erstellen',
    'download_gpg': 'GPG-Schlüssel herunterladen und importieren',
    'verify_gpg': 'Überprüfen ob der Schlüssel korrekt heruntergeladen wurde',
    'error_gpg_empty': 'Fehler: GPG-Schlüssel ist leer oder wurde nicht installiert',
    'config_repo': 'Repository konfigurieren',
    'configuring_repo': 'Repository wird konfiguriert...',
    'force_update': 'Sichere Aktualisierung erzwingen',
    'updating_indices': 'Indizes werden aktualisiert...',
    'verify_repo': 'Überprüfen ob Repository konfiguriert ist',
    'error_repo_not_configured': 'Fehler: Repository wurde nicht korrekt konfiguriert',
    'repo_installed': 'Repository erfolgreich installiert!',
    'colors': 'Farben für Meldungen',
    'install_repo': 'Installationsskript für Repository {}'
}
