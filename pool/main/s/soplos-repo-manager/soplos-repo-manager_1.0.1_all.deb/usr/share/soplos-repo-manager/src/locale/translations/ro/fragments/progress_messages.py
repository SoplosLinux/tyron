"""Mesaje de progres în română"""

FRAGMENT = {
    'estimated_time': 'Timp rămas estimat: {0}',
    'total_progress': 'Progres total: {0}%',
    'remaining_items': '{0} elemente rămase',
    'task_status': '{0} din {1}',
    'current_operation': 'Operația curentă: {0}',
    'processing_item': 'Se procesează {0}...',
    'start_task': 'Se începe {0}...',
    'finish_task': 'Finalizat {0}',
    'abort_task': 'Se anulează {0}...',
    'error_task': 'Eroare în {0}: {1}',
    'percent': '{0}% completat'
}
