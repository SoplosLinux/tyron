"""Traducciones de errores en español"""

FRAGMENT = {
    'git_not_installed': 'Se requiere GitPython (python3-git)',
    'load_profiles': 'Error cargando perfiles: {0}',
    'save_profile': 'Error guardando perfil: {0}',
    'delete_profile': 'Error eliminando perfil: {0}',
    'loading_config': 'Error cargando configuración: {0}',
    'saving_config': 'Error guardando configuración: {0}',
    'repo_init': 'Error inicializando repositorio Git: {0}',
    'get_repo_name': 'Error obteniendo nombre del repo: {0}',
    'readme_dialog': 'Error en diálogo del README: {0}',
    'list_packages': 'Error listando paquetes: {0}',
    'reading_package': 'Error leyendo {0}: {1}',
    'create_structure': 'Error creando estructura: {0}',
    'configure_reprepro': 'Error configurando reprepro: {0}',
    'init_indices': 'Error inicializando índices: {0}',
    'verify_structure': 'Error verificando estructura: {0}',
    'integrity_check': 'Error verificando integridad: {0}',
    'reprepro_stderr': 'Error de reprepro: {0}'
}
