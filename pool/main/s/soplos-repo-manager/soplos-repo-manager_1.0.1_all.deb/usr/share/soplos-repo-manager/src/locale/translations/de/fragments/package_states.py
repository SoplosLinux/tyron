"""Paketstatus auf Deutsch"""

FRAGMENT = {
    'new': 'Neu',
    'processing': 'Wird verarbeitet',
    'uploading': 'Wird hochgeladen',
    'uploaded': 'Hochgeladen',
    'error': 'Fehler',
    'in_pool': 'Im Pool',
    'in_github': 'In GitHub',
    'in_incoming': 'In Eingang',
    'unknown': 'Unbekannt',
    'installed': 'Installiert',
    'not_installed': 'Nicht installiert',
    'partially_installed': 'Teilweise installiert',
    'to_install': 'Zu installieren',
    'to_remove': 'Zu entfernen',
    'to_upgrade': 'Zu aktualisieren',
    'broken': 'Defekt',
    'configured': 'Konfiguriert',
    'not_configured': 'Nicht konfiguriert',
    'processed': 'Verarbeitet'
}
