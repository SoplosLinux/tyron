"""Messages de validation en français"""

FRAGMENT = {
    'url_invalid': 'URL invalide',
    'token_invalid': 'Token invalide',
    'branch_empty': 'La branche ne peut pas être vide',
    'name_invalid': 'Nom invalide',
    'email_invalid': 'Email invalide',
    'duplicate': '{0} existe déjà',
    'required_field': 'Champ requis : {0}',
    'invalid_input': 'Entrée invalide : {0}',
    'config_error': 'Erreur de configuration : {0}',
    'profile_exists': 'Un profil avec ce nom existe déjà',
    'missing_fields': 'Tous les champs sont obligatoires',
    'gpg_key_required': 'Une clé GPG est requise',
    'invalid_version': 'Version invalide'
}
