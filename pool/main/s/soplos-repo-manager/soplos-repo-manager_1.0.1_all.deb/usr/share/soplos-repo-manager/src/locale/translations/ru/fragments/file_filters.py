"""Переводы фильтров файлов на русский"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Скрипты оболочки (*.sh)',
        }
    }
}
