"""Texte substituente în română"""

FRAGMENT = {
    'repo_url': 'https://github.com/utilizator/depozit',
    'token': 'Introduceți token-ul personal GitHub',
    'branch': 'main',
    'search': 'Căutare...',
    'filter': 'Filtrare...',
    'comments': 'Scrieți un comentariu...',
    'name': 'Nume complet',
    'email': 'email@exemplu.com',
    'profile_name': 'Nume profil',
    'password': 'Parolă',
    'confirm_password': 'Confirmă parola'
}
