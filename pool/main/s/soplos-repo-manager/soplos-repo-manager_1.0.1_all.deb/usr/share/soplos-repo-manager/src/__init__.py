"""
Módulo principal de Soplos Repo Manager
"""
