"""Traduções de ajuda em português"""

FRAGMENT = {
    'help_info': {
        'gpg_setup': 'Como configurar GPG',
        'repo_setup': 'Como configurar o repositório',
        'profiles': 'Utilização de perfis',
        'packages': 'Gestão de pacotes',
        'scripts': 'Scripts de instalação',
        'updates': 'Atualizações',
        'support': 'Obter suporte',
        'sections': {
            'quick_start': 'Início rápido',
            'configuration': 'Configuração',
            'usage': 'Utilização básica',
            'advanced': 'Opções avançadas',
            'troubleshooting': 'Resolução de problemas',
            'faq': 'Perguntas frequentes'
        }
    }
}
