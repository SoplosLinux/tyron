"""Dialogues de confirmation en français"""

FRAGMENT = {
    'delete_package': {
        'title': 'Supprimer le paquet',
        'message': 'Êtes-vous sûr de vouloir supprimer le paquet {0} ?',
        'details': 'Cette action supprimera le paquet du dépôt et tous les fichiers associés.'
    },
    'clean_repo': {
        'title': 'Nettoyer le dépôt',
        'message': 'Êtes-vous sûr de vouloir nettoyer le dépôt ?',
        'details': 'Cette action supprimera tous les fichiers temporaires et reconstruira les index.'
    },
    'delete_profile': {
        'title': 'Supprimer le profil',
        'message': 'Êtes-vous sûr de vouloir supprimer le profil {0} ?',
        'details': 'Cette action supprimera toutes les configurations et fichiers associés au profil.'
    },
    'exit_app': {
        'title': 'Quitter',
        'message': 'Êtes-vous sûr de vouloir quitter ?',
        'details': 'Les modifications non enregistrées seront perdues.'
    }
}
