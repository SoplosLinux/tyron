"""Systemmeldungen auf Deutsch"""

FRAGMENT = {
    'system': {
        'startup': {
            'loading': 'Anwendung wird gestartet...',
            'checking_deps': 'Abhängigkeiten werden überprüft...',
            'init_repo': 'Repository wird initialisiert...',
            'loading_profiles': 'Profile werden geladen...',
            'ready': 'System bereit'
        },
        'shutdown': {
            'saving': 'Änderungen werden gespeichert...',
            'cleaning': 'Temporäre Dateien werden bereinigt...',
            'closing': 'Anwendung wird beendet...'
        },
        'errors': {
            'critical': 'Kritischer Fehler: {0}',
            'dependency': 'Fehlende Abhängigkeit: {0}',
            'permission': 'Berechtigungsfehler: {0}',
            'connection': 'Verbindungsfehler: {0}',
            'config': 'Konfigurationsfehler: {0}'
        },
        'warnings': {
            'disk_space': 'Wenig Festplattenspeicher',
            'memory': 'Wenig Systemspeicher',
            'connection': 'Instabile Verbindung',
            'outdated': 'Veraltete Version'
        }
    }
}
