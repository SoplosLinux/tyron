"""Категории настроек на русском"""

FRAGMENT = {
    'general': {
        'title': 'Общие',
        'language': 'Язык',
        'updates': 'Обновления',
        'notifications': 'Уведомления'
    },
    'appearance': {
        'title': 'Внешний вид',
        'theme': 'Тема',
        'icons': 'Значки',
        'fonts': 'Шрифты'
    },
    'network': {
        'title': 'Сеть',
        'proxy': 'Прокси',
        'timeout': 'Таймаут',
        'retries': 'Повторные попытки'
    },
    'advanced': {
        'title': 'Расширенные',
        'logging': 'Журналирование',
        'debug': 'Отладка',
        'cache': 'Кэш'
    },
    'profiles': {
        'title': 'Профили',
        'default': 'Профиль по умолчанию',
        'auto_load': 'Загружать последний профиль',
        'backup': 'Автоматическое резервирование'
    }
}
