"""Notes et aides en français"""

FRAGMENT = {
    'branch': '<small>Il est recommandé d\'utiliser "main" par défaut</small>',
    'gpg_key': '<small>Il est recommandé d\'utiliser une clé GPG pour signer les paquets</small>',
    'repo': '<small>Le dépôt sera configuré avec les détails fournis</small>',
    'profile': '<small>Un nouveau profil sera créé avec les détails fournis</small>',
    'backup': '<small>Une sauvegarde de la configuration actuelle sera créée</small>',
    'restore': '<small>La configuration sera restaurée depuis la sauvegarde</small>',
    'import': '<small>La configuration sera importée depuis le fichier sélectionné</small>',
    'export': '<small>La configuration sera exportée vers le fichier sélectionné</small>',
    'update': '<small>Les index des paquets seront mis à jour</small>',
    'preferences': '<small>Les préférences de l\'utilisateur seront enregistrées</small>'
}
