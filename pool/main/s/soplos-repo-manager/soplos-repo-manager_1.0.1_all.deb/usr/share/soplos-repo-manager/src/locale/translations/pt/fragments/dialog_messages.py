"""Mensagens de diálogo em português"""

FRAGMENT = {
    'select_gpg': 'Selecionar Chave GPG',
    'wait': 'Por favor aguarde...',
    'config_repo': 'Configurar Repositório',
    'new_profile': 'Novo Perfil',
    'package_list': 'Lista de Pacotes',
    'version_select': 'Selecionar versão',
    'existing_file': 'Arquivo Existente',
    'file_details': 'Detalhes do arquivo',
    'package_details': 'Detalhes do pacote',
    'create_gpg': 'Criar Nova Chave GPG',
    'select_gpg': 'Selecionar Chave GPG',
    'save_script': 'Guardar Script de Instalação',
    'install_script': 'Script de Instalação',
    'gpg_verification': 'Verificação GPG',
    'gpg_key_info': 'Informação da Chave GPG',
    'repo_instructions': 'Instruções do Repositório',
    'confirm_clean_repo': 'Confirmar Limpeza do Repositório',
    'colors': {
        'green': 'Verde',
        'red': 'Vermelho',
        'nc': 'Sem Cor'
    }
}
