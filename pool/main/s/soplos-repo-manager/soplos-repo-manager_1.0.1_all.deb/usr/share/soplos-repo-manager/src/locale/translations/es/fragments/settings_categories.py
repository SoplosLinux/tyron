"""Categorías de configuración en español"""

FRAGMENT = {
    'general': {
        'title': 'General',
        'language': 'Idioma',
        'updates': 'Actualizaciones',
        'notifications': 'Notificaciones'
    },
    'appearance': {
        'title': 'Apariencia',
        'theme': 'Tema',
        'icons': 'Iconos',
        'fonts': 'Fuentes'
    },
    'network': {
        'title': 'Red',
        'proxy': 'Proxy',
        'timeout': 'Tiempo de espera',
        'retries': 'Reintentos'
    },
    'advanced': {
        'title': 'Avanzado',
        'logging': 'Registro',
        'debug': 'Depuración',
        'cache': 'Caché'
    },
    'profiles': {
        'title': 'Perfiles',
        'default': 'Perfil predeterminado',
        'auto_load': 'Cargar último perfil',
        'backup': 'Respaldo automático'
    }
}
