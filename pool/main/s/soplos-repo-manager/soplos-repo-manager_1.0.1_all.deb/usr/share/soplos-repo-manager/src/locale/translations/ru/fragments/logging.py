"""Сообщения журнала на русском"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'Начало очистки пакетов репозитория...',
        'cleaning_complete': 'Репозиторий успешно очищен',
        'generating_key': 'Генерация ключа GPG...',
        'key_generated': 'Ключ GPG сгенерирован с ID: {0}',
        'cloning_repo': 'Клонирование репозитория из {0}',
        'updating_readme': 'Обновление README...'
    },
    'info': {
        'profile_loaded': 'Профиль {0} загружен',
        'deleting_package': 'Удаление {0} из reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'Не удалось удалить {0}: {1}',
        'key_not_found': 'Не удалось найти сгенерированный ключ'
    }
}
