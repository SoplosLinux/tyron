# Soplos Repository Manager

Gestor gráfico de repositorios APT para Soplos Linux. Permite gestionar paquetes .deb, firmarlos con GPG y sincronizarlos con GitHub.

## Características

- Interfaz gráfica intuitiva con GTK3
- Gestión de paquetes .deb
- Firma GPG automática
- Sincronización con GitHub
- Generación de scripts de instalación
- Soporte multilingüe (8 idiomas)
- Sistema de perfiles

## Requisitos

- Python 3.8 o superior
- GTK 3
- Git
- GPG
- Reprepro
- Dependencias de Python (ver requirements.txt)

## Instalación

```bash
sudo apt install ./soplos-repo-manager_1.0.0_all.deb
```

## Uso

1. Ejecute la aplicación desde el menú o con:
```bash
soplos-repo-manager
```

2. Configure el repositorio con su token de GitHub y clave GPG
3. Añada paquetes .deb y súbalos al repositorio
4. Genere el script de instalación para distribuir

## Desarrollo

Para configurar el entorno de desarrollo:

```bash
git clone https://github.com/soplos/soplos-repo-manager
cd soplos-repo-manager
pip install -r requirements.txt
```

## Licencia

Este proyecto está bajo la Licencia GNU GPL v3 - ver el archivo LICENSE para más detalles.

## Autores

- Soplos Linux Team (info@soplos.org)
