"""Desktop-Datei Übersetzungen"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Name in allen Übersetzungen gleich lassen
    'generic_name': 'Repository-Manager',
    'keywords': 'pakete;apt;repo;deb;gpg;repository;',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
