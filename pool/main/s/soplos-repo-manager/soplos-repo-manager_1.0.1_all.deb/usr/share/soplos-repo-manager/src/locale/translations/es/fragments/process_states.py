"""Estados de proceso en español"""

FRAGMENT = {
    'startup': {
        'loading': 'Iniciando aplicación...',
        'checking_deps': 'Verificando dependencias...',
        'init_repo': 'Inicializando repositorio...',
        'loading_profiles': 'Cargando perfiles...',
        'ready': 'Sistema listo'
    },
    'shutdown': {
        'saving': 'Guardando cambios...',
        'cleaning': 'Limpiando archivos temporales...',
        'closing': 'Cerrando aplicación...'
    },
    'states': {
        'validating': 'Validando...',
        'processing': 'Procesando...',
        'signing': 'Firmando...',
        'verifying': 'Verificando...',
        'uploading': 'Subiendo...',
        'downloading': 'Descargando...',
        'installing': 'Instalando...',
        'removing': 'Eliminando...',
        'cleaning': 'Limpiando...',
        'backing_up': 'Respaldando...',
        'restoring': 'Restaurando...',
        'calculating': 'Calculando...',
        'updating': 'Actualizando...',
        'indexing': 'Indexando...'
    }
}
