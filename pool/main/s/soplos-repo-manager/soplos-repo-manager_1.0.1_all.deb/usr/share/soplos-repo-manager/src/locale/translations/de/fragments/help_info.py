"""Hilfetexte auf Deutsch"""

FRAGMENT = {
    'help_info': {
        'gpg_setup': 'GPG konfigurieren',
        'repo_setup': 'Repository konfigurieren',
        'profiles': 'Profile verwenden',
        'packages': 'Paketverwaltung',
        'scripts': 'Installationsskripte',
        'updates': 'Aktualisierungen',
        'support': 'Support erhalten',
        'sections': {
            'quick_start': 'Schnellstart',
            'configuration': 'Konfiguration',
            'usage': 'Grundlegende Verwendung',
            'advanced': 'Erweiterte Optionen',
            'troubleshooting': 'Fehlerbehebung',
            'faq': 'Häufig gestellte Fragen'
        }
    }
}
