"""Сообщения валидации на русском"""

FRAGMENT = {
    'url_invalid': 'Недействительный URL',
    'token_invalid': 'Недействительный токен',
    'branch_empty': 'Ветка не может быть пустой',
    'name_invalid': 'Недействительное имя',
    'email_invalid': 'Недействительный email',
    'duplicate': '{0} уже существует',
    'required_field': 'Обязательное поле: {0}',
    'invalid_input': 'Неверный ввод: {0}',
    'config_error': 'Ошибка конфигурации: {0}',
    'profile_exists': 'Профиль с таким именем уже существует',
    'missing_fields': 'Все поля обязательны',
    'gpg_key_required': 'Требуется ключ GPG',
    'invalid_version': 'Недействительная версия'
}
