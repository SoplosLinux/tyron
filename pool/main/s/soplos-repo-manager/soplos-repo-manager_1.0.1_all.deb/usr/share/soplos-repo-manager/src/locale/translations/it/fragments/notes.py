"""Note e suggerimenti in italiano"""

FRAGMENT = {
    'branch': '<small>Si consiglia di utilizzare "main" come predefinito</small>',
    'gpg_key': '<small>Si consiglia di utilizzare una chiave GPG per firmare i pacchetti</small>',
    'repo': '<small>Il repository verrà configurato con i dettagli forniti</small>',
    'profile': '<small>Verrà creato un nuovo profilo con i dettagli forniti</small>',
    'backup': '<small>Verrà creata una copia di backup della configurazione attuale</small>',
    'restore': '<small>La configurazione verrà ripristinata dal backup</small>',
    'import': '<small>La configurazione verrà importata dal file selezionato</small>',
    'export': '<small>La configurazione verrà esportata nel file selezionato</small>',
    'update': '<small>Gli indici dei pacchetti verranno aggiornati</small>',
    'preferences': '<small>Le preferenze dell\'utente verranno salvate</small>'
}
