"""Traduzioni dei formati temporali in italiano"""

FRAGMENT = {
    'short_date': '%d/%m/%Y',
    'long_date': '%d %B %Y',
    'time': '%H:%M:%S',
    'datetime': '%d/%m/%Y %H:%M:%S',
    'month_names': [
        'Gennaio', 'Febbraio', 'Marzo', 'Aprile',
        'Maggio', 'Giugno', 'Luglio', 'Agosto',
        'Settembre', 'Ottobre', 'Novembre', 'Dicembre'
    ],
    'day_names': [
        'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì',
        'Venerdì', 'Sabato', 'Domenica'
    ],
    'relative': {
        'today': 'Oggi',
        'yesterday': 'Ieri',
        'tomorrow': 'Domani',
        'past': '{0} fa',
        'future': 'Fra {0}'
    }
}
