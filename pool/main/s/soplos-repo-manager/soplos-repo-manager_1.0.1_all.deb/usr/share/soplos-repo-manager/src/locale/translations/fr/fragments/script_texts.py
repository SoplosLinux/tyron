"""Textes des scripts en français"""

FRAGMENT = {
    'script_header': '#!/bin/bash\n# Script d\'installation pour le dépôt {0}\n',
    'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo "Ce script doit être exécuté en tant que root"\n    exit 1\nfi\n',
    'add_key': 'Ajout de la clé GPG...',
    'add_repo': 'Ajout du dépôt...',
    'updating': 'Mise à jour des index...',
    'installing': 'Installation des paquets...',
    'complete': 'Installation terminée',
    'error': 'Erreur : {0}',
    'warning': 'Avertissement : {0}',
    'info': 'Info : {0}',
    'debug': 'Debug : {0}',
    'script_footer': 'echo "Processus terminé"\nexit 0'
}
