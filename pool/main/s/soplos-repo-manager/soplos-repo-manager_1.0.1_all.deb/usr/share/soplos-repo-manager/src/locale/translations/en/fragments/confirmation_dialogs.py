"""Confirmation dialog translations in English"""

FRAGMENT = {
    'delete_package': {
        'title': 'Delete package',
        'message': 'Are you sure you want to delete package {0}?',
        'details': 'This action will remove the package from the repository and all associated files.'
    },
    'clean_repo': {
        'title': 'Clean repository',
        'message': 'Are you sure you want to clean the repository?',
        'details': 'This action will remove all temporary files and rebuild the indices.'
    },
    'delete_profile': {
        'title': 'Delete profile',
        'message': 'Are you sure you want to delete profile {0}?',
        'details': 'This action will delete all configurations and files associated with the profile.'
    },
    'exit_app': {
        'title': 'Exit',
        'message': 'Are you sure you want to exit?',
        'details': 'Any unsaved changes will be lost.'
    }
}
