"""Traduzioni degli errori in italiano"""

FRAGMENT = {
    'git_not_installed': 'GitPython (python3-git) è richiesto',
    'load_profiles': 'Errore nel caricamento dei profili: {0}',
    'save_profile': 'Errore nel salvataggio del profilo: {0}',
    'delete_profile': 'Errore nell\'eliminazione del profilo: {0}',
    'loading_config': 'Errore nel caricamento della configurazione: {0}',
    'saving_config': 'Errore nel salvataggio della configurazione: {0}',
    'repo_init': 'Errore nell\'inizializzazione del repository Git: {0}',
    'get_repo_name': 'Errore nell\'ottenere il nome del repository: {0}',
    'readme_dialog': 'Errore nel dialogo README: {0}',
    'list_packages': 'Errore nell\'elenco dei pacchetti: {0}',
    'reading_package': 'Errore nella lettura di {0}: {1}',
    'create_structure': 'Errore nella creazione della struttura: {0}',
    'configure_reprepro': 'Errore nella configurazione di reprepro: {0}',
    'init_indices': 'Errore nell\'inizializzazione degli indici: {0}',
    'verify_structure': 'Errore nella verifica della struttura: {0}',
    'integrity_check': 'Errore nella verifica dell\'integrità: {0}',
    'reprepro_stderr': 'Errore di reprepro: {0}'
}
