"""Mensagens de registo em português"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'A iniciar limpeza de pacotes do repositório...',
        'cleaning_complete': 'Repositório limpo com sucesso',
        'generating_key': 'A gerar chave GPG...',
        'key_generated': 'Chave GPG gerada com ID: {0}',
        'cloning_repo': 'A clonar repositório de {0}',
        'updating_readme': 'A atualizar README...'
    },
    'info': {
        'profile_loaded': 'Perfil {0} carregado',
        'deleting_package': 'A eliminar {0} do reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'Não foi possível eliminar {0}: {1}',
        'key_not_found': 'Não foi possível encontrar a chave gerada'
    }
}
