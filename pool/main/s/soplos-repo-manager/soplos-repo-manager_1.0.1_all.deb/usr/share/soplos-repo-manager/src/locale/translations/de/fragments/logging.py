"""Logging-Nachrichten auf Deutsch"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'Starte Bereinigung der Repository-Pakete...',
        'cleaning_complete': 'Repository erfolgreich bereinigt',
        'generating_key': 'Generiere GPG-Schlüssel...',
        'key_generated': 'GPG-Schlüssel generiert mit ID: {0}',
        'cloning_repo': 'Klone Repository von {0}',
        'updating_readme': 'Aktualisiere README...'
    },
    'info': {
        'profile_loaded': 'Profil {0} geladen',
        'deleting_package': 'Entferne {0} aus reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'Konnte {0} nicht löschen: {1}',
        'key_not_found': 'Generierter Schlüssel konnte nicht gefunden werden'
    }
}
