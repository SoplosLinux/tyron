"""Состояния пакетов на русском"""

FRAGMENT = {
    'new': 'Новый',
    'processing': 'Обработка',
    'uploading': 'Загрузка',
    'uploaded': 'Загружен',
    'error': 'Ошибка',
    'in_pool': 'В пуле',
    'in_github': 'На GitHub',
    'in_incoming': 'Во входящих',
    'unknown': 'Неизвестно',
    'installed': 'Установлен',
    'not_installed': 'Не установлен',
    'partially_installed': 'Частично установлен',
    'to_install': 'К установке',
    'to_remove': 'К удалению',
    'to_upgrade': 'К обновлению',
    'broken': 'Сломан',
    'configured': 'Настроен',
    'not_configured': 'Не настроен',
    'processed': 'Обработано'
}
