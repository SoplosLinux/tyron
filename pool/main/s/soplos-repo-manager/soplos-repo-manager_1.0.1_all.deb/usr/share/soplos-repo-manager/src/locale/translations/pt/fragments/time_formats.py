"""Traduções de formatos de tempo em português"""

FRAGMENT = {
    'short_date': '%d/%m/%Y',
    'long_date': '%d de %B de %Y',
    'time': '%H:%M:%S',
    'datetime': '%d/%m/%Y %H:%M:%S',
    'month_names': [
        'Janeiro', 'Fevereiro', 'Março', 'Abril',
        'Maio', 'Junho', 'Julho', 'Agosto',
        'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ],
    'day_names': [
        'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira',
        'Sexta-feira', 'Sábado', 'Domingo'
    ],
    'relative': {
        'today': 'Hoje',
        'yesterday': 'Ontem',
        'tomorrow': 'Amanhã',
        'past': 'Há {0}',
        'future': 'Em {0}'
    }
}
