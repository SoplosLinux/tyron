"""UI-Elemente auf Deutsch"""

FRAGMENT = {
    'app_name': 'Soplos Repo Manager',  # Hauptschlüssel für den Anwendungsnamen
    'main_window': {
        'title': 'Soplos Repository-Manager',  # Hauptfenstertitel
        'title_with_profile': 'Soplos Repository-Manager - {0}'  # Titel mit aktivem Profil
    },
    'window_title': 'Soplos Repository-Manager',  # Diese Zeile hinzufügen
    'menu_items': {
        'file': '_Datei',
        'edit': '_Bearbeiten',
        'view': '_Ansicht',
        'tools': '_Werkzeuge',
        'help': '_Hilfe'
    },
    'tabs': {
        'upload': 'Hochladen',
        'manage': 'Verwalten',
        'settings': 'Einstellungen',
        'logs': 'Protokolle'
    },
    'sections': {
        'general': 'Allgemein',
        'appearance': 'Erscheinungsbild',
        'network': 'Netzwerk',
        'advanced': 'Erweitert',
        'profiles': 'Profile',
        'backup': 'Sicherung'
    },
    'context_menu': {
        'cut': 'Ausschneiden',
        'copy': 'Kopieren',
        'paste': 'Einfügen',
        'delete': 'Löschen',
        'select_all': 'Alles auswählen'
    },
    'placeholders': {
        'search': 'Suchen...',
        'filter': 'Filtern...',
        'comments': 'Kommentar schreiben...'
    },
    'file_filters': {
        'deb_packages': 'Debian-Pakete (*.deb)',
        'shell_scripts': 'Shell-Skripte (*.sh)',
        'all_files': 'Alle Dateien (*.*)',
        'config_files': 'Konfigurationsdateien (*.conf)',
        'text_files': 'Textdateien (*.txt)',
        'backup_files': 'Sicherungsdateien (*.bak)'
    }
}
