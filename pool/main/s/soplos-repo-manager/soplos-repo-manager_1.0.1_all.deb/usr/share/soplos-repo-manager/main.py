#!/usr/bin/env python3
"""
Soplos Repo Manager
------------------
Aplicación GTK para gestionar repositorios de paquetes.
Proporciona una interfaz gráfica para:
- Configurar repositorios
- Gestionar claves GPG
- Administrar perfiles
- Subir y gestionar paquetes
"""

import gi
import os
import sys
import shutil
import logging

# Added by Soplos Packager - Setup Application ID
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk

GLib.set_prgname('com.soplos.repomanager')
GLib.set_application_name('soplos-repo-manager')
try:
    Gtk.Window.set_default_icon_name('com.soplos.repomanager')
except:
    pass
try:
    if hasattr(Gdk, 'set_program_class'):
        Gdk.set_program_class('com.soplos.repomanager')
except:
    pass
# End of Soplos Packager addition

# Configurar logging primero
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'  # Formato correcto
)
logger = logging.getLogger(__name__)

# Asegurar que podemos importar desde src
base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, base_dir)

# Limpiar __pycache__ al inicio
for root, dirs, files in os.walk(base_dir):
    if '__pycache__' in dirs:
        cache_dir = os.path.join(root, '__pycache__')
        try:
            shutil.rmtree(cache_dir)
        except Exception as e:
            logger.warning(f"No se pudo limpiar cache: {e}")

# Configuración básica de GTK
os.environ['NO_AT_BRIDGE'] = '1'
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio

# Importar componentes en orden correcto
try:
    # Primero cargar el sistema de traducciones
    from src.locale.locale_manager import locale_manager, get_system_language
    from src.locale.translations import TRANSLATIONS
    from src.locale.strings import get_string
    
    # Luego los componentes que dependen de las traducciones
    from src.gui.window import MainWindow
    from src.utils.repo_manager import RepoManager
except Exception as e:
    logger.error(f"Error importando módulos: {e}")
    sys.exit(1)

class SoplosRepoApp(Gtk.Application):
    def __init__(self):
        super().__init__(
            application_id='com.soplos.repomanager',
            flags=Gio.ApplicationFlags.FLAGS_NONE
        )

    def do_startup(self):
        Gtk.Application.do_startup(self)

    def do_activate(self):
        windows = self.get_windows()
        if windows:
            window = windows[0]
            if isinstance(window, Gtk.Widget):
                window.present()
        else:
            try:
                window = MainWindow(application=self)
                if isinstance(window, Gtk.Widget):
                    window.show_all()
            except Exception as e:
                logger.error(f"Error creando ventana: {e}")
                dialog = Gtk.MessageDialog(
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.CLOSE,
                    text="Error Iniciando Aplicación"
                )
                dialog.format_secondary_text(str(e))
                dialog.run()
                dialog.destroy()
                sys.exit(1)

def main():
    try:
        app = SoplosRepoApp()
        return app.run()
    except Exception as e:
        logger.error(f"Error fatal: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
