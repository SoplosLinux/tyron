"""Messages de journalisation en français"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'Démarrage du nettoyage des paquets du dépôt...',
        'cleaning_complete': 'Dépôt nettoyé avec succès',
        'generating_key': 'Génération de la clé GPG...',
        'key_generated': 'Clé GPG générée avec ID : {0}',
        'cloning_repo': 'Clonage du dépôt depuis {0}',
        'updating_readme': 'Mise à jour du README...'
    },
    'info': {
        'profile_loaded': 'Profil {0} chargé',
        'deleting_package': 'Suppression de {0} de reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'Impossible de supprimer {0} : {1}',
        'key_not_found': 'Impossible de trouver la clé générée'
    }
}
