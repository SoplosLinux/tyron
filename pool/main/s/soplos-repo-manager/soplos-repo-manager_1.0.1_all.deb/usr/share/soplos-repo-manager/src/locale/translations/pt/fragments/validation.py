"""Mensagens de validação em português"""

FRAGMENT = {
    'url_invalid': 'URL inválido',
    'token_invalid': 'Token inválido',
    'branch_empty': 'O ramo não pode estar vazio',
    'name_invalid': 'Nome inválido',
    'email_invalid': 'Email inválido',
    'duplicate': '{0} já existe',
    'required_field': 'Campo obrigatório: {0}',
    'invalid_input': 'Entrada inválida: {0}',
    'config_error': 'Erro de configuração: {0}',
    'profile_exists': 'Já existe um perfil com esse nome',
    'missing_fields': 'Todos os campos são obrigatórios',
    'gpg_key_required': 'É necessária uma chave GPG',
    'invalid_version': 'Versão inválida'
}
