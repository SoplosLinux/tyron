"""Testi segnaposto in italiano"""

FRAGMENT = {
    'repo_url': 'https://github.com/utente/repository',
    'token': 'Inserisci il tuo token personale GitHub',
    'branch': 'main',
    'search': 'Cerca...',
    'filter': 'Filtra...',
    'comments': 'Scrivi un commento...',
    'name': 'Nome completo',
    'email': 'email@esempio.com',
    'profile_name': 'Nome del profilo',
    'password': 'Password',
    'confirm_password': 'Conferma password'
}
