"""Gestión de cadenas traducidas"""
from typing import Optional
import locale
import logging
from .locale_manager import locale_manager
from .translations.es import SPANISH   # Añadir esta importación
from .translations import TRANSLATIONS

# Configurar logger
logger = logging.getLogger(__name__)

def get_string(key: str, lang: Optional[str] = None) -> str:
    """
    Obtiene una cadena traducida.
    Si no se especifica idioma, usa el idioma actual del LocaleManager.
    """
    # Si no se especifica idioma, usar el actual
    if lang is None:
        lang = locale_manager.current_lang

    # Obtener traducción para el idioma
    translation = TRANSLATIONS.get(lang, TRANSLATIONS['es'])
    
    # Separar la clave en sus partes
    parts = key.split('.')
    
    try:
        # Navegar la estructura
        value = translation
        for part in parts:
            if part not in value:
                # Si no encuentra la clave, intentar en español
                value = TRANSLATIONS['es']
                for p in parts:
                    value = value[p]
                break
            value = value[part]
            
        if value is None or value == '':
            raise KeyError(f"Empty value for key: {key}")
            
        return str(value)
        
    except Exception as e:
        logger.error(f"Missing translation key: {key} for language {lang}. Available keys in {lang}: {list(translation.keys())}")
        # Intentar obtener de español como fallback
        try:
            value = TRANSLATIONS['es']
            for part in parts:
                value = value[part]
            return str(value)
        except:
            return f"[Missing: {key}]"

def get_string(key):
    """Obtiene una cadena traducida por su clave"""
    try:
        # Obtener idioma actual y traducciones
        current_lang = locale_manager.current_lang
        translations = TRANSLATIONS.get(current_lang, SPANISH)  # Ahora SPANISH está definido
        
        # Separar la clave en partes (por ejemplo: 'buttons.ok' -> ['buttons', 'ok'])
        parts = key.split('.')
        
        # Navegar por el diccionario
        value = translations
        for part in parts:
            value = value[part]
            
        return value
    except KeyError:
        logger.error(f"Missing translation key: {key} for language {current_lang}")
        return f"[Missing: {key}]"
    except Exception as e:
        logger.error(f"Error getting string: {e}")
        return f"[Error: {key}]"

# Exportar referencia a las traducciones 
STRINGS = TRANSLATIONS

# Exports
__all__ = ['get_string', 'locale_manager', 'STRINGS']