"""Переводы элементов меню на русский"""

FRAGMENT = {
    'menu': {
        'file': '_Файл',
        'edit': '_Правка',
        'view': '_Вид',
        'tools': '_Инструменты',
        'help': '_Справка'
    },
    'file_menu': {
        'save': '_Сохранить',
        'save_as': 'Сохранить _как',
        'preferences': '_Настройки',
        'quit': '_Выход'
    },
    'edit_menu': {
        'undo': '_Отменить',
        'redo': '_Повторить',
        'cut': '_Вырезать',
        'copy': '_Копировать',
        'paste': '_Вставить',
        'delete': '_Удалить',
        'select_all': 'Выделить _всё'
    },
    'view_menu': {
        'refresh': '_Обновить',
        'fullscreen': '_Полный экран',
        'zoom_in': 'Увеличить',
        'zoom_out': 'Уменьшить',
        'reset_zoom': 'Сбросить масштаб'
    },
    'help_menu': {
        'about': '_О программе',
        'documentation': '_Документация',
        'keyboard_shortcuts': '_Комбинации клавиш',
        'report_bug': 'Сообщить об _ошибке',
        'check_updates': 'Проверить _обновления'
    }
}
