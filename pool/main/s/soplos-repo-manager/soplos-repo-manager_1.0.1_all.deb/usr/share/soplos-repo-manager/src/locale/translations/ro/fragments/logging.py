"""Mesaje de jurnal în română"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'Se începe curățarea pachetelor din depozit...',
        'cleaning_complete': 'Depozit curățat cu succes',
        'generating_key': 'Se generează cheia GPG...',
        'key_generated': 'Cheie GPG generată cu ID: {0}',
        'cloning_repo': 'Se clonează depozitul din {0}',
        'updating_readme': 'Se actualizează README...'
    },
    'info': {
        'profile_loaded': 'Profil {0} încărcat',
        'deleting_package': 'Se șterge {0} din reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'Nu s-a putut șterge {0}: {1}',
        'key_not_found': 'Nu s-a putut găsi cheia generată'
    }
}
