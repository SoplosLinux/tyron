"""Informazioni dell'applicazione in italiano"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Usare lo stesso nome in tutta l'applicazione
    'display_name': 'Soplos Repo Manager',  # Nome per l'interfaccia utente
    'version': 'Versione {0}',
    'description': 'Gestore dei repository APT per Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'Licenza GPL-3.0',
    'website': 'https://soplos.org',
    'bugs': 'Segnala bug',
    'support': 'Supporto',
    'translate': 'Aiuta a tradurre',
    'contributors': 'Collaboratori',
    'dependencies': 'Dipendenze',
    'system_info': 'Informazioni di sistema'
}
