"""Mensagens do sistema em português"""

FRAGMENT = {
    'system': {
        'startup': {
            'loading': 'A iniciar aplicação...',
            'checking_deps': 'A verificar dependências...',
            'init_repo': 'A inicializar repositório...',
            'loading_profiles': 'A carregar perfis...',
            'ready': 'Sistema pronto'
        },
        'shutdown': {
            'saving': 'A guardar alterações...',
            'cleaning': 'A limpar ficheiros temporários...',
            'closing': 'A fechar aplicação...'
        },
        'errors': {
            'critical': 'Erro crítico: {0}',
            'dependency': 'Dependência em falta: {0}',
            'permission': 'Erro de permissões: {0}',
            'connection': 'Erro de ligação: {0}',
            'config': 'Erro de configuração: {0}'
        },
        'warnings': {
            'disk_space': 'Espaço em disco baixo',
            'memory': 'Memória do sistema baixa',
            'connection': 'Ligação instável',
            'outdated': 'Versão desatualizada'
        }
    }
}
