"""Note și ajutoare în română"""

FRAGMENT = {
    'branch': '<small>Se recomandă utilizarea "main" implicit</small>',
    'gpg_key': '<small>Se recomandă utilizarea unei chei GPG pentru semnarea pachetelor</small>',
    'repo': '<small>Depozitul va fi configurat cu detaliile furnizate</small>',
    'profile': '<small>Se va crea un profil nou cu detaliile furnizate</small>',
    'backup': '<small>Se va crea o copie de siguranță a configurației actuale</small>',
    'restore': '<small>Configurația va fi restaurată din copia de siguranță</small>',
    'import': '<small>Configurația va fi importată din fișierul selectat</small>',
    'export': '<small>Configurația va fi exportată în fișierul selectat</small>',
    'update': '<small>Indicii pachetelor vor fi actualizați</small>',
    'preferences': '<small>Preferințele utilizatorului vor fi salvate</small>'
}
