"""Dateifilter-Übersetzungen"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Shell-Skripte (*.sh)',
        }
    }
}
