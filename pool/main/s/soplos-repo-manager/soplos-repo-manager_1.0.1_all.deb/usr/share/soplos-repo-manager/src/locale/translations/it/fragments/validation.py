"""Messaggi di validazione in italiano"""

FRAGMENT = {
    'url_invalid': 'URL non valido',
    'token_invalid': 'Token non valido',
    'branch_empty': 'Il ramo non può essere vuoto',
    'name_invalid': 'Nome non valido',
    'email_invalid': 'Email non valida',
    'duplicate': '{0} esiste già',
    'required_field': 'Campo obbligatorio: {0}',
    'invalid_input': 'Input non valido: {0}',
    'config_error': 'Errore di configurazione: {0}',
    'profile_exists': 'Esiste già un profilo con questo nome',
    'missing_fields': 'Tutti i campi sono obbligatori',
    'gpg_key_required': 'È richiesta una chiave GPG',
    'invalid_version': 'Versione non valida'
}
