"""Process states translations in English"""

FRAGMENT = {
    'startup': {
        'loading': 'Starting application...',
        'checking_deps': 'Checking dependencies...',
        'init_repo': 'Initializing repository...',
        'loading_profiles': 'Loading profiles...',
        'ready': 'System ready'
    },
    'shutdown': {
        'saving': 'Saving changes...',
        'cleaning': 'Cleaning temporary files...',
        'closing': 'Closing application...'
    },
    'states': {
        'validating': 'Validating...',
        'processing': 'Processing...',
        'signing': 'Signing...',
        'verifying': 'Verifying...',
        'uploading': 'Uploading...',
        'downloading': 'Downloading...',
        'installing': 'Installing...',
        'removing': 'Removing...',
        'cleaning': 'Cleaning...',
        'backing_up': 'Backing up...',
        'restoring': 'Restoring...',
        'calculating': 'Calculating...',
        'updating': 'Updating...',
        'indexing': 'Indexing...'
    }
}
