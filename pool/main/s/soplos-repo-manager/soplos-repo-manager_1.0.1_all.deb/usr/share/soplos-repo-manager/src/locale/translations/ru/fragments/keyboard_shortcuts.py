"""Переводы сочетаний клавиш на русский"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Сочетания клавиш',
        'categories': {
            'general': 'Общие',
            'navigation': 'Навигация',
            'editing': 'Редактирование',
            'view': 'Вид'
        },
        'actions': {
            'save': 'Сохранить (Ctrl+S)',
            'quit': 'Выход (Ctrl+Q)',
            'refresh': 'Обновить (Ctrl+R)',
            'search': 'Поиск (Ctrl+F)',
            'preferences': 'Настройки (Ctrl+P)',
            'help': 'Помощь (F1)',
            'switch_tab': 'Переключить вкладку (Ctrl+Tab)',
            'new_item': 'Новый элемент (Ctrl+N)',
            'delete_item': 'Удалить элемент (Del)',
            'fullscreen': 'Полный экран (F11)',
            'zoom_in': 'Увеличить (Ctrl++)',
            'zoom_out': 'Уменьшить (Ctrl+-)',
            'reset_zoom': 'Сбросить масштаб (Ctrl+0)'
        }
    }
}
