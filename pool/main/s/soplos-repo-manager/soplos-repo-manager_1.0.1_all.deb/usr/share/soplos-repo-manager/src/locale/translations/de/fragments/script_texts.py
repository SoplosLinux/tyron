"""Skript-Texte auf Deutsch"""

FRAGMENT = {
    'script_header': '#!/bin/bash\n# Installationsskript für Repository {0}\n',
    'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo "Dieses Skript muss als Root ausgeführt werden"\n    exit 1\nfi\n',
    'add_key': 'GPG-Schlüssel wird hinzugefügt...',
    'add_repo': 'Repository wird hinzugefügt...',
    'updating': 'Indizes werden aktualisiert...',
    'installing': 'Pakete werden installiert...',
    'complete': 'Installation abgeschlossen',
    'error': 'Fehler: {0}',
    'warning': 'Warnung: {0}',
    'info': 'Info: {0}',
    'debug': 'Debug: {0}',
    'script_footer': 'echo "Vorgang abgeschlossen"\nexit 0'
}
