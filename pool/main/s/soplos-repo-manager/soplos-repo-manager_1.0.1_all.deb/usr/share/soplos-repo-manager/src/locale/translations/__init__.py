"""Módulo de traducciones"""
from .es import SPANISH
from .en import ENGLISH
from .de import GERMAN
from .fr import FRENCH
from .it import ITALIAN
from .pt import PORTUGUESE
from .ro import ROMANIAN
from .ru import RUSSIAN

# Agregar todos los idiomas disponibles
TRANSLATIONS = {
    'es': SPANISH,     # Español (por defecto)
    'en': ENGLISH,     # Inglés
    'de': GERMAN,      # Alemán
    'fr': FRENCH,      # Francés 
    'it': ITALIAN,     # Italiano
    'pt': PORTUGUESE,  # Portugués
    'ro': ROMANIAN,    # Rumano
    'ru': RUSSIAN      # Ruso
}

# Nombres descriptivos de los idiomas
LANGUAGE_NAMES = {
    'es': 'Español',
    'en': 'English',
    'de': 'Deutsch',
    'fr': 'Français',
    'it': 'Italiano', 
    'pt': 'Português',
    'ro': 'Română',
    'ru': 'Русский'
}