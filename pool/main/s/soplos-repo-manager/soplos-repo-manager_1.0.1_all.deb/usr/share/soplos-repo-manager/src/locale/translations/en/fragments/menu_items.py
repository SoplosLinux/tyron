"""Menu items translations in English"""

FRAGMENT = {
    'menu': {
        'file': '_File',
        'edit': '_Edit',
        'view': '_View',
        'tools': '_Tools',
        'help': '_Help'
    },
    'file_menu': {
        'save': '_Save',
        'save_as': 'Save _as',
        'preferences': '_Preferences',
        'quit': '_Quit'
    },
    'edit_menu': {
        'undo': '_Undo',
        'redo': '_Redo',
        'cut': 'Cu_t',
        'copy': '_Copy',
        'paste': '_Paste',
        'delete': '_Delete',
        'select_all': 'Select _all'
    },
    'view_menu': {
        'refresh': '_Refresh',
        'fullscreen': '_Fullscreen',
        'zoom_in': 'Zoom in',
        'zoom_out': 'Zoom out',
        'reset_zoom': 'Reset zoom'
    },
    'help_menu': {
        'about': '_About',
        'documentation': '_Documentation',
        'keyboard_shortcuts': '_Keyboard shortcuts',
        'report_bug': 'Report _bug',
        'check_updates': 'Check for _updates'
    }
}
