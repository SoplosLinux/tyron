"""Messaggi di log in italiano"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'Avvio pulizia pacchetti dal repository...',
        'cleaning_complete': 'Repository pulito con successo',
        'generating_key': 'Generazione chiave GPG...',
        'key_generated': 'Chiave GPG generata con ID: {0}',
        'cloning_repo': 'Clonazione repository da {0}',
        'updating_readme': 'Aggiornamento README...'
    },
    'info': {
        'profile_loaded': 'Profilo {0} caricato',
        'deleting_package': 'Rimozione {0} da reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'Impossibile eliminare {0}: {1}',
        'key_not_found': 'Impossibile trovare la chiave generata'
    }
}
