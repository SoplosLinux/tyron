"""États des processus en français"""

FRAGMENT = {
    'startup': {
        'loading': 'Démarrage de l\'application...',
        'checking_deps': 'Vérification des dépendances...',
        'init_repo': 'Initialisation du dépôt...',
        'loading_profiles': 'Chargement des profils...',
        'ready': 'Système prêt'
    },
    'shutdown': {
        'saving': 'Enregistrement des modifications...',
        'cleaning': 'Nettoyage des fichiers temporaires...',
        'closing': 'Fermeture de l\'application...'
    },
    'states': {
        'validating': 'Validation...',
        'processing': 'Traitement...',
        'signing': 'Signature...',
        'verifying': 'Vérification...',
        'uploading': 'Envoi...',
        'downloading': 'Téléchargement...',
        'installing': 'Installation...',
        'removing': 'Suppression...',
        'cleaning': 'Nettoyage...',
        'backing_up': 'Sauvegarde...',
        'restoring': 'Restauration...',
        'calculating': 'Calcul...',
        'updating': 'Mise à jour...',
        'indexing': 'Indexation...'
    }
}
