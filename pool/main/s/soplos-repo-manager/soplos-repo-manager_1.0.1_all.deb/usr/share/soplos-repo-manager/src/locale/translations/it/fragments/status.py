"""Stati e messaggi di stato in italiano"""

FRAGMENT = {
    'ready': 'Pronto',
    'processing': 'Elaborazione...',
    'waiting': 'In attesa...',
    'completed': 'Completato',
    'failed': 'Fallito',
    'uploading': 'Caricamento...',
    'downloading': 'Scaricamento...',
    'installing': 'Installazione...',
    'updating': 'Aggiornamento...',
    'error': 'Errore',
    'success': 'Successo',
    'cancelled': 'Annullato',
    'paused': 'In pausa',
    'offline': 'Non in linea',
    'online': 'In linea',
    'syncing': 'Sincronizzazione...',
    'initializing': 'Inizializzazione...',
    'cleaning': 'Pulizia...'
}
