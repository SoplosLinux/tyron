"""Переводы подсказок на русский"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Добавить новый пакет .deb в репозиторий',
        'upload_changes': 'Загрузить ожидающие изменения на GitHub',
        'manage_keys': 'Управление ключами GPG',
        'configure_repo': 'Настроить параметры репозитория',
        'generate_script': 'Создать установочный скрипт',
        'refresh_list': 'Обновить список пакетов',
        'remove_package': 'Удалить выбранный пакет',
        'sign_package': 'Просмотр информации о пакете'
    },
    'tips': {
        'exit_app': 'Выйти из приложения'
    }
}
