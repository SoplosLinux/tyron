"""
Definición de la estructura base de traducciones
"""
from typing import Dict

TRANSLATION_STRUCTURE: Dict[str, Dict] = {
    'app_info': {
        'bugs': '',
        'license': '',
        'support': '',
        'translate': '',
        'version': '',
        'website': ''
    },
    'buttons': {
        'accept': '',
        'cancel': '',
        'clean': '',
        'close': '',
        'create': '',
        'create_gpg_key': '',
        'delete': '',
        'delete_gpg_key': '',
        'no': '',
        'overwrite': '',
        'overwrite_all': '',
        'save': '',
        'select': '',
        'skip': '',
        'skip_all': '',
        'update_list': '',
        'yes': ''
    },
    'defaults': {
        'install_script_name': '',
        'list_filename': '',
        'repo_title': ''
    },
    'dialogs': {
        'colors': {
            'green': '',
            'nc': '',
            'red': ''
        },
        'confirm_clean_repo': '',
        'config_repo': '',
        'create_gpg': '',
        'existing_file': '',
        'file_details': '',
        'gpg_key_info': '',
        'gpg_verification': '',
        'install_script': '',
        'new_profile': '',
        'package_details': '',
        'package_list': '',
        'profile_setup': '',
        'repo_instructions': '',
        'save_script': '',
        'select_gpg': '',
        'version_select': '',
        'wait': ''
    },
    'keyboard': {
        'preferences': '',
        'quit': '',
        'refresh': '',
        'save': '',
        'search': '',
        'shortcuts': ''
    },
    'labels': {
        'tree_columns': {
            'file_date': '',
            'file_name': '',
            'file_size': '',
            'file_status': '',
            'pkg_arch': '',
            'pkg_description': '',
            'pkg_name': '',
            'pkg_section': '',
            'pkg_version': ''
        },
        'arch': '',
        'branch': '',
        'date': '',
        'description': '',
        'email': '',
        'id': '',
        'language': '',
        'list_name': '',
        'name': '',
        'profile': '',
        'repo_title': '',
        'repo_url': '',
        'section': '',
        'size': '',
        'status': '',
        'token': ''
    },
    'messages': {
        'apply_all': '',
        'cleaning_repo': '',
        'config_required': '',
        'config_repo_first': '',
        'confirm_exit': '',
        'deleting_packages': '',
        'file_exists': '',
        'gpg_config_success': '',
        'gpg_required': '',
        'name_email_required': '',
        'no_packages': '',
        'no_profiles': '',
        'operation_error': '',
        'operation_success': '',
        'overwrite_prompt': '',
        'package_status': '',
        'packages_found': '',
        'profile_created': '',
        'profile_deleted': '',
        'profile_error': '',
        'profile_not_found': '',
        'repo_config_success': '',
        'script_error': '',
        'script_generated': '',
        'select_files': '',
        'token_required': '',
        'uploading': ''
    },
    'notes': {
        'branch': ''
    },
    'package_states': {
        'error': '',
        'in_github': '',
        'in_incoming': '',
        'in_pool': '',
        'new': '',
        'processing': '',
        'processed': '',  # Añadido el estado 'processed'
        'unknown': '',
        'uploaded': '',
        'uploading': ''
    },
    'placeholders': {
        'branch': '',
        'repo_url': '',
        'token': ''
    },
    'progress_messages': {
        'abort_task': '',
        'error_task': '',
        'finish_task': '',
        'percent': '',
        'start_task': ''
    },
    'scripts': {
        'colors': '',
        'config_repo': '',
        'configuring_repo': '',
        'create_keyring': '',
        'download_gpg': '',
        'downloading_gpg': '',
        'error_downloading_gpg': '',
        'error_gpg_empty': '',
        'error_repo_not_configured': '',
        'force_update': '',
        'install_repo': '',
        'must_be_root': '',
        'repo_installed': '',
        'updating_indices': '',
        'verify_gpg': '',
        'verify_repo': '',
        'verify_root': ''
    },
    'validation': {
        'branch_empty': '',
        'duplicate': '',
        'email_invalid': '',
        'name_invalid': '',
        'token_invalid': '',
        'url_invalid': ''
    },
    'initialization': {
        'starting': '',
        'loading_config': '',
        'creating_dirs': '',
        'checking_deps': '',
        'loading_profiles': '',
        'error_start': '',
        'cache_clean_error': '',
        'init_complete': ''
    },
    
    'profile_operations': {
        'loading': '',
        'saving': '',
        'deleting': '',
        'switching': '',
        'backup_create': '',
        'backup_restore': '',
        'profile_loaded': '',
        'profile_saved': '',
        'profile_deleted': '',
        'profile_load_error': '',
        'profile_save_error': '',
        'confirm_delete_profile': '',
        'profile_delete_error': ''
    },

    'file_operations': {
        # ...añadir operaciones de archivos...
    },

    'package_operations': {
        # ...añadir operaciones de paquetes...
    },

    'git_operations': {
        # ...añadir operaciones de git...
    },

    'gpg_operations': {
        # ...añadir operaciones de gpg...
    },

    'settings_categories': {
        'general': '',
        'appearance': '', 
        'network': '',
        'advanced': '',
        'backup': '',
        'updates': ''
    },

    'file_dialogs': {
        'open_deb': 'Seleccionar archivos .deb',
        'save_script': 'Guardar script de instalación',
        'filters': {
            'deb_packages': 'Paquetes Debian (*.deb)',
            'shell_scripts': 'Scripts de Shell (*.sh)'
        }
    },
    'desktop': {
        'name': 'Soplos Repo Manager',
        'comment': 'Gestor de Repositorios APT para Soplos Linux',
        'generic_name': 'Gestor de Repositorios',
        'keywords': 'repo;apt;deb;repository;packages;'
    },
    'package_info': {
        'title': 'Información del paquete {0}',
        'name': 'Nombre',
        'version': 'Versión',
        'arch': 'Arquitectura',
        'section': 'Sección',
        'priority': 'Prioridad',
        'size': 'Tamaño',
        'installed_size': 'Tamaño instalado',
        'maintainer': 'Mantenedor',
        'description': 'Descripción',
        'homepage': 'Página web',
        'dependencies': 'Dependencias'
    },
    'script_templates': {
        'install_header': '#!/bin/bash\n# Script de instalación para el repositorio {0}\n',
        'colors_def': '# Definición de colores\nGREEN="\\033[0;32m"\nRED="\\033[0;31m"\nNC="\\033[0m"\n',
        'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo -e "${RED}Debe ejecutar este script como root${NC}"\n    exit 1\nfi\n'
        # ...añadir más templates según necesidad
    }
}
