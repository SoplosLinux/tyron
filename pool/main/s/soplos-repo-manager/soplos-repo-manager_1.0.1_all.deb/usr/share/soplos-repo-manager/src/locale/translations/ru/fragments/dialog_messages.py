"""Сообщения диалогов на русском"""

FRAGMENT = {
    'select_gpg': 'Выбрать Ключ GPG',
    'wait': 'Пожалуйста, подождите...',
    'config_repo': 'Настройка Репозитория',
    'new_profile': 'Новый Профиль',
    'package_list': 'Список Пакетов',
    'version_select': 'Выбрать версию',
    'existing_file': 'Существующий Файл',
    'file_details': 'Детали файла',
    'package_details': 'Детали пакета',
    'create_gpg': 'Создать Новый Ключ GPG',
    'select_gpg': 'Выбрать Ключ GPG',
    'save_script': 'Сохранить Скрипт Установки',
    'install_script': 'Скрипт Установки',
    'gpg_verification': 'Проверка GPG',
    'gpg_key_info': 'Информация о Ключе GPG',
    'repo_instructions': 'Инструкции Репозитория',
    'confirm_clean_repo': 'Подтвердить Очистку Репозитория',
    'colors': {
        'green': 'Зелёный',
        'red': 'Красный',
        'nc': 'Без Цвета'
    }
}
