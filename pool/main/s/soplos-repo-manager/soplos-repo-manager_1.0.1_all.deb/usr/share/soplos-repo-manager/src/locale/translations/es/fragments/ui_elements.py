"""Traducciones de elementos de UI en español"""

FRAGMENT = {
    'app_name': 'Soplos Repo Manager',  # Clave principal para el nombre de la aplicación
    'main_window': {
        'title': 'Gestor de Repositorios Soplos',  # Título de la ventana principal
        'title_with_profile': 'Gestor de Repositorios Soplos - {0}'  # Título con perfil activo
    },
    'menu_items': {
        'file': '_Archivo',
        'edit': '_Editar',
        'view': '_Ver',
        'tools': '_Herramientas',
        'help': '_Ayuda'
    },
    'tabs': {
        'upload': 'Subir Paquetes',
        'manage': 'Gestionar Repositorio',
        'settings': 'Configuración',
        'logs': 'Registros'
    },
    'sections': {
        'general': 'General',
        'appearance': 'Apariencia',
        'network': 'Red',
        'advanced': 'Avanzado',
        'profiles': 'Perfiles',
        'backup': 'Respaldo'
    },
    'context_menu': {
        'cut': 'Cortar',
        'copy': 'Copiar',
        'paste': 'Pegar',
        'delete': 'Eliminar',
        'select_all': 'Seleccionar todo'
    },
    'placeholders': {
        'search': 'Buscar...',
        'filter': 'Filtrar...',
        'comments': 'Escribir comentario...'
    },
    'file_filters': {
        'deb_packages': 'Paquetes Debian (*.deb)',
        'shell_scripts': 'Scripts de Shell (*.sh)',
        'all_files': 'Todos los archivos (*.*)',
        'config_files': 'Archivos de configuración (*.conf)',
        'text_files': 'Archivos de texto (*.txt)',
        'backup_files': 'Archivos de respaldo (*.bak)'
    },
    'window_title': 'Gestor de Repositorios Soplos'  # Añadir esta línea
}
