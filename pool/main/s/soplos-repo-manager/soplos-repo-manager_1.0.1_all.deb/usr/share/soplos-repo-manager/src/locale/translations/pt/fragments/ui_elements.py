"""UI elements in Portuguese"""

FRAGMENT = {
    'app_name': 'Soplos Repo Manager',  # Nome principal da aplicação
    'main_window': {
        'title': 'Gerenciador de Repositórios Soplos',  # Título da janela principal
        'title_with_profile': 'Gerenciador de Repositórios Soplos - {0}'  # Título com perfil ativo
    },
    'window_title': 'Gerenciador de Repositórios Soplos',
    'menu_items': {
        'file': '_Ficheiro',
        'edit': '_Editar',
        'view': '_Ver',
        'tools': '_Ferramentas',
        'help': '_Ajuda'
    },
    'tabs': {
        'upload': 'Enviar',
        'manage': 'Gerenciar',
        'settings': 'Configurações',
        'logs': 'Registos'
    },
    'sections': {
        'general': 'Geral',
        'appearance': 'Aparência',
        'network': 'Rede',
        'advanced': 'Avançado',
        'profiles': 'Perfis',
        'backup': 'Cópia de Segurança'
    },
    'context_menu': {
        'cut': 'Cortar',
        'copy': 'Copiar',
        'paste': 'Colar',
        'delete': 'Eliminar',
        'select_all': 'Selecionar tudo'
    },
    'placeholders': {
        'search': 'Pesquisar...',
        'filter': 'Filtrar...',
        'comments': 'Escrever comentário...'
    },
    'file_filters': {
        'deb_packages': 'Pacotes Debian (*.deb)',
        'shell_scripts': 'Scripts Shell (*.sh)',
        'all_files': 'Todos os ficheiros (*.*)',
        'config_files': 'Ficheiros de configuração (*.conf)',
        'text_files': 'Ficheiros de texto (*.txt)',
        'backup_files': 'Ficheiros de backup (*.bak)'
    },
}
