"""Textos de scripts em português"""

FRAGMENT = {
    'script_header': '#!/bin/bash\n# Script de instalação para repositório {0}\n',
    'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo "Este script deve ser executado como root"\n    exit 1\nfi\n',
    'add_key': 'A adicionar chave GPG...',
    'add_repo': 'A adicionar repositório...',
    'updating': 'A atualizar índices...',
    'installing': 'A instalar pacotes...',
    'complete': 'Instalação concluída',
    'error': 'Erro: {0}',
    'warning': 'Aviso: {0}',
    'info': 'Info: {0}',
    'debug': 'Debug: {0}',
    'script_footer': 'echo "Processo concluído"\nexit 0'
}
