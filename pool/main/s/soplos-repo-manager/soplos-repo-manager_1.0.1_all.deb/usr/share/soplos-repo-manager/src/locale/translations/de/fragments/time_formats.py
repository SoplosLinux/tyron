"""Zeitformate auf Deutsch"""

FRAGMENT = {
    'short_date': '%d.%m.%Y',
    'long_date': '%d. %B %Y',
    'time': '%H:%M:%S',
    'datetime': '%d.%m.%Y %H:%M:%S',
    'month_names': [
        'Januar', 'Februar', 'März', 'April',
        'Mai', 'Juni', 'Juli', 'August',
        'September', 'Oktober', 'November', 'Dezember'
    ],
    'day_names': [
        'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag',
        'Freitag', 'Samstag', 'Sonntag'
    ],
    'relative': {
        'today': 'Heute',
        'yesterday': 'Gestern',
        'tomorrow': 'Morgen',
        'past': 'Vor {0}',
        'future': 'In {0}'
    }
}
