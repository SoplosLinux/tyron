"""Traductions pour le fichier .desktop en français"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Garder le même nom que ui_elements
    'generic_name': 'Gestionnaire de Dépôts',
    'keywords': 'paquets;apt;repo;deb;gpg;dépôt;',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
