"""
Módulo de internacionalización
"""
import os
import json
import logging
from typing import Dict, List, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Importar traducciones primero
from .translations import TRANSLATIONS, LANGUAGE_NAMES

def _get_all_keys(d: Dict, prefix: str = '') -> set:
    """Obtiene todas las claves de un diccionario anidado"""
    keys = set()
    for k, v in d.items():
        full_key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            keys.update(_get_all_keys(v, full_key))
        else:
            keys.add(full_key)
    return keys

def _validate_translation_format(base: Dict, to_check: Dict, path: str="") -> List[str]:
    """Valida el formato de las traducciones"""
    errors = []
    for key, value in base.items():
        current_path = f"{path}.{key}" if path else key
        
        if key not in to_check:
            errors.append(f"Falta la clave '{current_path}'")
            continue
            
        if isinstance(value, dict):
            if not isinstance(to_check[key], dict):
                errors.append(f"La clave '{current_path}' debe ser un diccionario")
            else:
                errors.extend(_validate_translation_format(value, to_check[key], current_path))
    return errors

# No importar strings.py aquí para evitar referencias circulares

def get_system_language() -> str:
    """Detecta el idioma del sistema"""
    try:
        import locale
        lang = locale.getdefaultlocale()[0]
        if lang:
            return lang.split('_')[0]
    except:
        pass
    return 'es'

def get_available_languages() -> List[str]:
    """Retorna la lista de idiomas disponibles"""
    return list(TRANSLATIONS.keys())

def get_language_name(lang_code: str) -> str:
    """Obtiene el nombre descriptivo de un idioma"""
    return LANGUAGE_NAMES.get(lang_code, lang_code)

def load_custom_translations(custom_path: str) -> Dict:
    """Carga traducciones personalizadas desde un directorio"""
    custom_translations = {}
    if os.path.exists(custom_path):
        for file in os.listdir(custom_path):
            if file.endswith('.json'):
                lang_code = file[:-5]
                try:
                    with open(os.path.join(custom_path, file), 'r', encoding='utf-8') as f:
                        custom_translations[lang_code] = json.load(f)
                except Exception as e:
                    logger.error(f"Error loading custom translation {file}: {e}")
    return custom_translations

def merge_translations(base: Dict, custom: Dict) -> Dict:
    """Combina traducciones base con personalizadas"""
    result = base.copy()
    for lang, trans in custom.items():
        if lang in result:
            result[lang].update(trans)
        else:
            result[lang] = trans
    return result

def get_language_completion() -> Dict[str, float]:
    """Obtiene el porcentaje de completitud de cada idioma"""
    base_keys = _get_all_keys(TRANSLATIONS['es'])
    completion = {}
    
    for lang in TRANSLATIONS:
        if lang == 'es':
            completion[lang] = 100.0
            continue
            
        lang_keys = _get_all_keys(TRANSLATIONS[lang])
        total = len(base_keys)
        translated = len(base_keys.intersection(lang_keys))
        completion[lang] = (translated / total) * 100
        
    return completion

def _validate_translation_format(lang: str) -> List[str]:
    """Valida el formato de las traducciones de un idioma"""
    errors = []
    base = TRANSLATIONS['es']
    
    if lang not in TRANSLATIONS:
        return [f"Idioma {lang} no encontrado"]
        
    to_check = TRANSLATIONS[lang]
    
    def check_dict(base_dict: Dict, check_dict: Dict, path: str=""):
        for key, value in base_dict.items():
            current_path = f"{path}.{key}" if path else key
            
            if key not in check_dict:
                errors.append(f"Falta la clave '{current_path}' en {lang}")
                continue
                
            if isinstance(value, dict):
                if not isinstance(check_dict[key], dict):
                    errors.append(f"La clave '{current_path}' debe ser un diccionario en {lang}")
                else:
                    check_dict(value, check_dict[key], current_path)
                    
    check_dict(base, to_check)
    return errors

# Cargar traducciones personalizadas si existen
custom_path = os.path.expanduser('~/.config/soplos-repo-manager/translations')
custom_translations = load_custom_translations(custom_path)
if custom_translations:
    TRANSLATIONS = merge_translations(TRANSLATIONS, custom_translations)
