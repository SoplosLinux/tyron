"""Valores por defecto en español"""

FRAGMENT = {
    'install_script_name': 'instalar-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Repositorio Soplos'
}
