"""Notas e ajudas em português"""

FRAGMENT = {
    'branch': '<small>Recomenda-se usar "main" por defeito</small>',
    'gpg_key': '<small>Recomenda-se usar uma chave GPG para assinar os pacotes</small>',
    'repo': '<small>O repositório será configurado com os detalhes fornecidos</small>',
    'profile': '<small>Será criado um novo perfil com os detalhes fornecidos</small>',
    'backup': '<small>Será criada uma cópia de segurança da configuração atual</small>',
    'restore': '<small>A configuração será restaurada a partir da cópia de segurança</small>',
    'import': '<small>A configuração será importada do arquivo selecionado</small>',
    'export': '<small>A configuração será exportada para o arquivo selecionado</small>',
    'update': '<small>Os índices dos pacotes serão atualizados</small>',
    'preferences': '<small>As preferências do utilizador serão guardadas</small>'
}
