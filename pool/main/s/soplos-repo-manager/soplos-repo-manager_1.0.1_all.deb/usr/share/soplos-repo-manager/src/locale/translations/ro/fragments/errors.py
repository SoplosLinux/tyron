"""Traduceri pentru erori în română"""

FRAGMENT = {
    'git_not_installed': 'Este necesar GitPython (python3-git)',
    'load_profiles': 'Eroare la încărcarea profilurilor: {0}',
    'save_profile': 'Eroare la salvarea profilului: {0}',
    'delete_profile': 'Eroare la ștergerea profilului: {0}',
    'loading_config': 'Eroare la încărcarea configurației: {0}',
    'saving_config': 'Eroare la salvarea configurației: {0}',
    'repo_init': 'Eroare la inițializarea depozitului Git: {0}',
    'get_repo_name': 'Eroare la obținerea numelui depozitului: {0}',
    'readme_dialog': 'Eroare în dialogul README: {0}',
    'list_packages': 'Eroare la listarea pachetelor: {0}',
    'reading_package': 'Eroare la citirea {0}: {1}',
    'create_structure': 'Eroare la crearea structurii: {0}',
    'configure_reprepro': 'Eroare la configurarea reprepro: {0}',
    'init_indices': 'Eroare la inițializarea indicilor: {0}',
    'verify_structure': 'Eroare la verificarea structurii: {0}',
    'integrity_check': 'Eroare la verificarea integrității: {0}',
    'reprepro_stderr': 'Eroare reprepro: {0}'
}
