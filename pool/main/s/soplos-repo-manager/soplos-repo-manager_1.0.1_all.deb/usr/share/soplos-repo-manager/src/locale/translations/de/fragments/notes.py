"""Hinweise und Hilfetexte auf Deutsch"""

FRAGMENT = {
    'branch': '<small>Es wird empfohlen, standardmäßig "main" zu verwenden</small>',
    'gpg_key': '<small>Es wird empfohlen, einen GPG-Schlüssel zum Signieren der Pakete zu verwenden</small>',
    'repo': '<small>Das Repository wird mit den angegebenen Details konfiguriert</small>',
    'profile': '<small>Ein neues Profil wird mit den angegebenen Details erstellt</small>',
    'backup': '<small>Es wird eine Sicherungskopie der aktuellen Konfiguration erstellt</small>',
    'restore': '<small>Die Konfiguration wird aus der Sicherung wiederhergestellt</small>',
    'import': '<small>Die Konfiguration wird aus der ausgewählten Datei importiert</small>',
    'export': '<small>Die Konfiguration wird in die ausgewählte Datei exportiert</small>',
    'update': '<small>Die Paketindizes werden aktualisiert</small>',
    'preferences': '<small>Die Benutzereinstellungen werden gespeichert</small>'
}
