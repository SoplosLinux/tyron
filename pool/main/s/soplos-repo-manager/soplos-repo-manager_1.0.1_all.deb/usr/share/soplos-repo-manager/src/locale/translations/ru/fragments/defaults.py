"""Значения по умолчанию на русском"""

FRAGMENT = {
    'install_script_name': 'ustanovit-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Репозиторий Soplos'
}
