"""Traduções de tooltips em português"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Adicionar novo pacote .deb ao repositório',
        'upload_changes': 'Enviar alterações pendentes para o GitHub',
        'manage_keys': 'Gerir chaves GPG',
        'configure_repo': 'Configurar detalhes do repositório',
        'generate_script': 'Gerar script de instalação',
        'refresh_list': 'Atualizar lista de pacotes',
        'remove_package': 'Remover pacote selecionado',
        'sign_package': 'Ver detalhes do pacote'
    },
    'tips': {
        'exit_app': 'Sair da aplicação'
    }
}
