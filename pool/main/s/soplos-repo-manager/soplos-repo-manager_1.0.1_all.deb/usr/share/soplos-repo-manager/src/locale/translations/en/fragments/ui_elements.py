"""UI elements in English"""

FRAGMENT = {
    'main_window': {
        'title': 'Soplos Repository Manager'
    },
    'window_title': 'Soplos Repository Manager',
    'app_name': 'Soplos Repo Manager',  # Keep the same as Spanish
    'menu_items': {
        'file': '_File',
        'edit': '_Edit',
        'view': '_View',
        'tools': '_Tools',
        'help': '_Help'
    },
    'tabs': {
        'upload': 'Upload',
        'manage': 'Manage'
    },
    'sections': {
        'general': 'General',
        'appearance': 'Appearance',
        'network': 'Network',
        'advanced': 'Advanced',
        'profiles': 'Profiles',
        'backup': 'Backup'
    },
    'context_menu': {
        'cut': 'Cut',
        'copy': 'Copy',
        'paste': 'Paste',
        'delete': 'Delete',
        'select_all': 'Select All'
    },
    'placeholders': {
        'search': 'Search...',
        'filter': 'Filter...',
        'comments': 'Write comment...'
    },
    'file_filters': {
        'deb_packages': 'Debian Packages (*.deb)',
        'shell_scripts': 'Shell Scripts (*.sh)'
    }
}
