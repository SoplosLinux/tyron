from .translations.es.fragments.defaults import FRAGMENT as ES_DEFAULTS
from .translations.es.fragments.dialogs import FRAGMENT as ES_DIALOGS
# ...existing imports...

# Definir traducciones base
BASE_TRANSLATIONS = {
    'defaults': {
        'install_script_name': 'instalar-{}.sh',
        'list_filename': 'apt-repo.list',  # Cambiado a un nombre más neutro
        'repo_title': 'Repositorio APT'    # Cambiado a un texto más neutro
    },
    'ui_elements': {
        # ...existing code...
        'file_filters': {
            'deb_packages': 'Paquetes Debian (*.deb)',
            'shell_scripts': 'Scripts de shell (*.sh)',
            'all_files': 'Todos los archivos'
        },
    },
    'dialogs': {
        'error': 'Error',
        'success': 'Éxito',
        'info': 'Información',
        'confirm': 'Confirmar',
        'select_files': 'Seleccionar archivos',  # Añadido campo faltante
        'select_gpg': 'Seleccionar clave GPG',
        'create_gpg': 'Crear clave GPG',
        'config_repo': 'Configurar repositorio',
        'package_details': 'Detalles de {0}',
        'new_profile': 'Nuevo perfil',
        'select_version': 'Seleccionar versión para {0}',
        'save_install_script': 'Guardar script de instalación',
        'file_exists': 'El archivo ya existe',
        'apply_to_all': 'Aplicar a todos'
    },
    'buttons': {
        # ...existing code...
    },
    # ...existing code...
}

# Asegurar que las traducciones heredan correctamente de BASE_TRANSLATIONS
TRANSLATIONS = {
    "es": BASE_TRANSLATIONS,  # Español usa BASE_TRANSLATIONS directamente
    "en": {
        'defaults': {
            'install_script_name': 'install-{}.sh',
            'list_filename': 'apt-repo.list',  # Cambiado a un nombre más neutro
            'repo_title': 'APT Repository'     # Cambiado a un texto más neutro
        },
        # ...existing code...
    },
    'de': {
        'defaults': {
            'install_script_name': 'installieren-{}.sh',
            'list_filename': 'soplos.list',
            'repo_title': 'Soplos Repository'
        }
    },
    'fr': {
        'defaults': {
            'install_script_name': 'installer-{}.sh',
            'list_filename': 'soplos.list',
            'repo_title': 'Dépôt Soplos'
        }
    },
    'it': {
        'defaults': {
            'install_script_name': 'installare-{}.sh',
            'list_filename': 'soplos.list',
            'repo_title': 'Repository Soplos'
        }
    },
    'pt': {
        'defaults': {
            'install_script_name': 'instalar-{}.sh',
            'list_filename': 'soplos.list',
            'repo_title': 'Repositório Soplos'
        }
    },
    'ro': {
        'defaults': {
            'install_script_name': 'instaleaza-{}.sh',
            'list_filename': 'soplos.list',
            'repo_title': 'Depozit Soplos'
        }
    },
    'ru': {
        'defaults': {
            'install_script_name': 'ustanovit-{}.sh',
            'list_filename': 'soplos.list',
            'repo_title': 'Репозиторий Soplos'
        }
    }
}