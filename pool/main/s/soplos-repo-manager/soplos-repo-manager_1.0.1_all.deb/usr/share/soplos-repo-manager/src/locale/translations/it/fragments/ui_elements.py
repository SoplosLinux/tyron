"""UI elements in Italian"""

FRAGMENT = {
    'app_name': 'Soplos Repo Manager',  # Nome principale dell'applicazione
    'main_window': {
        'title': 'Gestore Repository Soplos'  # Titolo della finestra principale
    },
    'window_title': 'Gestore Repository Soplos',
    'menu_items': {
        'file': '_File',
        'edit': '_Modifica',
        'view': '_Visualizza',
        'tools': '_Strumenti',
        'help': '_Aiuto'
    },
    'tabs': {
        'upload': 'Carica',
        'manage': 'Gestisci',
        'settings': 'Impostazioni',
        'logs': 'Registri'
    },
    'sections': {
        'general': 'Generale',
        'appearance': 'Aspetto',
        'network': 'Rete',
        'advanced': 'Avanzate',
        'profiles': 'Profili',
        'backup': 'Backup'
    },
    'context_menu': {
        'cut': 'Taglia',
        'copy': 'Copia',
        'paste': 'Incolla',
        'delete': 'Elimina',
        'select_all': 'Seleziona tutto'
    },
    'placeholders': {
        'search': 'Cerca...',
        'filter': 'Filtra...',
        'comments': 'Scrivi commento...'
    },
    'file_filters': {
        'deb_packages': 'Pacchetti Debian (*.deb)',
        'shell_scripts': 'Script Shell (*.sh)',
        'all_files': 'Tutti i file (*.*)',
        'config_files': 'File di configurazione (*.conf)',
        'text_files': 'File di testo (*.txt)',
        'backup_files': 'File di backup (*.bak)'
    },
}
