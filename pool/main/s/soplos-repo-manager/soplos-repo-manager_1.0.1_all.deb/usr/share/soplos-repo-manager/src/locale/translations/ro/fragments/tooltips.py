"""Traduceri pentru tooltips în română"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Adaugă pachet nou .deb în depozit',
        'upload_changes': 'Încarcă modificările în așteptare pe GitHub',
        'manage_keys': 'Gestionează cheile GPG',
        'configure_repo': 'Configurează detaliile depozitului',
        'generate_script': 'Generează script de instalare',
        'refresh_list': 'Actualizează lista de pachete',
        'remove_package': 'Șterge pachetul selectat',
        'sign_package': 'Vezi detaliile pachetului'
    },
    'tips': {
        'exit_app': 'Ieșire din aplicație'
    }
}
