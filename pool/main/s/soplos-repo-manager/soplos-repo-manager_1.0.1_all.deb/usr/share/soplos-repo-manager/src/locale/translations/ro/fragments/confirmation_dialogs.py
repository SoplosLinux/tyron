"""Dialoguri de confirmare în română"""

FRAGMENT = {
    'delete_package': {
        'title': 'Șterge pachet',
        'message': 'Sunteți sigur că doriți să ștergeți pachetul {0}?',
        'details': 'Această acțiune va șterge pachetul din depozit și toate fișierele asociate.'
    },
    'clean_repo': {
        'title': 'Curăță depozitul',
        'message': 'Sunteți sigur că doriți să curățați depozitul?',
        'details': 'Această acțiune va șterge toate fișierele temporare și va reconstrui indicii.'
    },
    'delete_profile': {
        'title': 'Șterge profil',
        'message': 'Sunteți sigur că doriți să ștergeți profilul {0}?',
        'details': 'Această acțiune va șterge toate configurările și fișierele asociate profilului.'
    },
    'exit_app': {
        'title': 'Ieșire',
        'message': 'Sunteți sigur că doriți să ieșiți?',
        'details': 'Modificările nesalvate vor fi pierdute.'
    }
}
