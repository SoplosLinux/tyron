"""Отсутствующие строки на русском"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Сообщить об ошибке',
        'license': 'Лицензия',
        'support': 'Поддержка',
        'translate': 'Перевести',
        'version': 'Версия',
        'website': 'Веб-сайт'
    },
    'buttons': {
        'accept': 'Принять',
        'cancel': 'Отмена',
        'clean': 'Очистить',
        'close': 'Закрыть',
        'create': 'Создать',
        'create_gpg_key': 'Создать ключ GPG',
        'delete': 'Удалить',
        'delete_gpg_key': 'Удалить ключ GPG',
        'no': 'Нет',
        'overwrite': 'Перезаписать',
        'overwrite_all': 'Перезаписать всё',
        'save': 'Сохранить',
        'select': 'Выбрать',
        'skip': 'Пропустить',
        'skip_all': 'Пропустить всё',
        'update_list': 'Обновить список',
        'yes': 'Да'
    },
    # ...resto del código con las traducciones al ruso...
}
