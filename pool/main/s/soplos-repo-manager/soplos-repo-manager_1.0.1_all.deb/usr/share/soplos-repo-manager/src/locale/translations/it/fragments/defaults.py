"""Valori predefiniti in italiano"""

FRAGMENT = {
    'install_script_name': 'installare-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Repository Soplos'
}
