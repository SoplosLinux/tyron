"""UI elements in Romanian"""

FRAGMENT = {
    'main_window': {
        'title': 'Manager Depozit Soplos'
    },
    'window_title': 'Manager Depozit Soplos',
    'menu_items': {
        'file': '_Fișier',
        'edit': '_Editare',
        'view': '_Vizualizare',
        'tools': '_Unelte',
        'help': '_Ajutor'
    },
    'tabs': {
        'upload': 'Încărcare',
        'manage': 'Gestionare',
        'settings': 'Setări',
        'logs': 'Jurnale'
    },
    'sections': {
        'general': 'General',
        'appearance': 'Aspect',
        'network': 'Rețea',
        'advanced': 'Avansat',
        'profiles': 'Profiluri',
        'backup': 'Copie de rezervă'
    },
    'context_menu': {
        'cut': 'Taie',
        'copy': 'Copiază',
        'paste': 'Lipește',
        'delete': 'Șterge',
        'select_all': 'Selectează tot'
    },
    'placeholders': {
        'search': 'Caută...',
        'filter': 'Filtrează...',
        'comments': 'Scrie comentariu...'
    },
    'file_filters': {
        'deb_packages': 'Pachete Debian (*.deb)',
        'shell_scripts': 'Scripturi Shell (*.sh)',
        'all_files': 'Toate fișierele (*.*)',
        'config_files': 'Fișiere de configurare (*.conf)',
        'text_files': 'Fișiere text (*.txt)',
        'backup_files': 'Fișiere backup (*.bak)'
    },
}
