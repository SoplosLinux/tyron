"""Textos em falta em português"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Reportar erros',
        'license': 'Licença',
        'support': 'Suporte',
        'translate': 'Traduzir',
        'version': 'Versão',
        'website': 'Site web'
    },
    'buttons': {
        'accept': 'Aceitar',
        'cancel': 'Cancelar',
        'clean': 'Limpar',
        'close': 'Fechar',
        'create': 'Criar',
        'create_gpg_key': 'Criar chave GPG',
        'delete': 'Eliminar',
        'delete_gpg_key': 'Eliminar chave GPG',
        'no': 'Não',
        'overwrite': 'Substituir',
        'overwrite_all': 'Substituir tudo',
        'save': 'Guardar',
        'select': 'Selecionar',
        'skip': 'Ignorar',
        'skip_all': 'Ignorar tudo',
        'update_list': 'Atualizar lista',
        'yes': 'Sim'
    },
    # ...resto del código con las traducciones al portugués...
}
