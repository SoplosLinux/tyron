"""Default values in English"""

FRAGMENT = {
    'install_script_name': 'install-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Soplos Repository'
}
