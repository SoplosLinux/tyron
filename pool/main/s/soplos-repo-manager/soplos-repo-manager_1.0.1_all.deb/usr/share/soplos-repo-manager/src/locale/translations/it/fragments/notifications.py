"""Notifiche in italiano"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Informazione',
        'warning': 'Avviso',
        'error': 'Errore',
        'success': 'Successo'
    },
    'messages': {
        'package_added': 'Pacchetto {0} aggiunto con successo',
        'package_removed': 'Pacchetto {0} rimosso',
        'upload_started': 'Avvio caricamento di {0}...',
        'upload_complete': 'Caricamento completato: {0}',
        'update_available': 'Nuova versione disponibile: {0}',
        'repo_synced': 'Repository sincronizzato',
        'backup_created': 'Backup creato in {0}'
    }
}
