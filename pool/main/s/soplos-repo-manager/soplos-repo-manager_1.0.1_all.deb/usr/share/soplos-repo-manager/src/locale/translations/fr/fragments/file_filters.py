"""Traductions des filtres de fichiers en français"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Scripts Shell (*.sh)',
        }
    }
}
