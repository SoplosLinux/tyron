"""Traduzioni degli elementi del menu in italiano"""

FRAGMENT = {
    'menu': {
        'file': '_File',
        'edit': '_Modifica',
        'view': '_Visualizza',
        'tools': '_Strumenti',
        'help': '_Aiuto'
    },
    'file_menu': {
        'save': '_Salva',
        'save_as': 'Salva _come',
        'preferences': '_Preferenze',
        'quit': '_Esci'
    },
    'edit_menu': {
        'undo': '_Annulla',
        'redo': '_Ripeti',
        'cut': '_Taglia',
        'copy': '_Copia',
        'paste': '_Incolla',
        'delete': '_Elimina',
        'select_all': 'Seleziona _tutto'
    },
    'view_menu': {
        'refresh': '_Aggiorna',
        'fullscreen': 'Schermo _intero',
        'zoom_in': 'Aumenta zoom',
        'zoom_out': 'Diminuisci zoom',
        'reset_zoom': 'Zoom normale'
    },
    'help_menu': {
        'about': '_Informazioni',
        'documentation': '_Documentazione',
        'keyboard_shortcuts': 'Scorciatoie da _tastiera',
        'report_bug': 'Segnala un _errore',
        'check_updates': 'Cerca _aggiornamenti'
    }
}
