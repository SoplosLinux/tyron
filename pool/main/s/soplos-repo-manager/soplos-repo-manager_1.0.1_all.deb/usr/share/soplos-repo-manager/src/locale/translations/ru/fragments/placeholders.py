"""Тексты-заполнители на русском"""

FRAGMENT = {
    'repo_url': 'https://github.com/пользователь/репозиторий',
    'token': 'Введите ваш личный токен GitHub',
    'branch': 'main',
    'search': 'Поиск...',
    'filter': 'Фильтр...',
    'comments': 'Написать комментарий...',
    'name': 'Полное имя',
    'email': 'почта@пример.com',
    'profile_name': 'Имя профиля',
    'password': 'Пароль',
    'confirm_password': 'Подтвердите пароль'
}
