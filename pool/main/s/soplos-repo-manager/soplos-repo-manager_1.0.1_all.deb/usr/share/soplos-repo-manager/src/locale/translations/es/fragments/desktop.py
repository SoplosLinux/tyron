"""Traducciones para el archivo .desktop en español"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Usar el mismo nombre que en ui_elements
    'generic_name': 'Gestor de Repositorios',
    'keywords': 'paquetes;apt;repo;deb;gpg;repositorio;',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
