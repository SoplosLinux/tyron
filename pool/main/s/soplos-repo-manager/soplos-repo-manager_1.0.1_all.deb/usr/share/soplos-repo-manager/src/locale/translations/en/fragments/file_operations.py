"""File operations translations in English"""

FRAGMENT = {
    'operations': {
        'copying': 'Copying {0}...',
        'moving': 'Moving {0}...',
        'removing': 'Removing {0}...',
        'creating_dir': 'Creating directory {0}...',
        'reading': 'Reading {0}...',
        'writing': 'Writing {0}...'
    },
    'errors': {
        'error_copy': 'Error copying file: {0}',
        'error_move': 'Error moving file: {0}',
        'error_remove': 'Error removing file: {0}',
        'error_create': 'Error creating directory: {0}',
        'error_read': 'Error reading file: {0}',
        'error_write': 'Error writing file: {0}'
    }
}
