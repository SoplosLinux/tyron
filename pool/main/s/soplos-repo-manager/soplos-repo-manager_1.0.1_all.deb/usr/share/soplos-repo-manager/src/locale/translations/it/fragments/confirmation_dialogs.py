"""Dialoghi di conferma in italiano"""

FRAGMENT = {
    'delete_package': {
        'title': 'Eliminare pacchetto',
        'message': 'Sei sicuro di voler eliminare il pacchetto {0}?',
        'details': 'Questa azione rimuoverà il pacchetto dal repository e tutti i file associati.'
    },
    'clean_repo': {
        'title': 'Pulire repository',
        'message': 'Sei sicuro di voler pulire il repository?',
        'details': 'Questa azione rimuoverà tutti i file temporanei e ricostruirà gli indici.'
    },
    'delete_profile': {
        'title': 'Eliminare profilo',
        'message': 'Sei sicuro di voler eliminare il profilo {0}?',
        'details': 'Questa azione rimuoverà tutte le configurazioni e i file associati al profilo.'
    },
    'exit_app': {
        'title': 'Uscire',
        'message': 'Sei sicuro di voler uscire?',
        'details': 'Le modifiche non salvate andranno perse.'
    }
}
