"""Traduções de elementos de menu em português"""

FRAGMENT = {
    'menu': {
        'file': '_Ficheiro',
        'edit': '_Editar',
        'view': '_Ver',
        'tools': '_Ferramentas',
        'help': 'A_juda'
    },
    'file_menu': {
        'save': '_Guardar',
        'save_as': 'Guardar _como',
        'preferences': '_Preferências',
        'quit': '_Sair'
    },
    'edit_menu': {
        'undo': '_Desfazer',
        'redo': '_Refazer',
        'cut': 'Cor_tar',
        'copy': '_Copiar',
        'paste': 'Co_lar',
        'delete': '_Eliminar',
        'select_all': 'Selecionar _tudo'
    },
    'view_menu': {
        'refresh': '_Atualizar',
        'fullscreen': '_Ecrã inteiro',
        'zoom_in': 'Aumentar zoom',
        'zoom_out': 'Diminuir zoom',
        'reset_zoom': 'Zoom normal'
    },
    'help_menu': {
        'about': '_Sobre',
        'documentation': '_Documentação',
        'keyboard_shortcuts': 'Atalhos de _teclado',
        'report_bug': 'Reportar _erro',
        'check_updates': 'Procurar _atualizações'
    }
}
