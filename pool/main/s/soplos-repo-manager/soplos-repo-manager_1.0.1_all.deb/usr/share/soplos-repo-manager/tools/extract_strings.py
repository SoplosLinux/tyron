#!/usr/bin/env python3
"""
Herramienta para extraer cadenas de texto de los archivos fuente
"""
import os
import re
import ast
import json
from pathlib import Path
from typing import Dict, Set, List

EXCLUDE_DIRS = {'__pycache__', 'build', 'dist', '.git', '.vscode', 'tools'}
PYTHON_CATEGORIES = {
    'dialogs': r'dialog|message|alert',
    'buttons': r'button|btn',  
    'labels': r'label|title|text',
    'errors': r'error|exception|failed',
    'messages': r'msg|message',
    'status': r'status|state',
    'tooltips': r'tooltip|hint',
    'placeholders': r'placeholder|hint',
    'validations': r'valid|check|verify'
}

def extract_strings_from_file(filepath: str) -> Dict[str, Set[str]]:
    """Extrae cadenas de texto de un archivo clasificándolas por categoría"""
    strings = {cat: set() for cat in PYTHON_CATEGORIES}
    strings['uncategorized'] = set()
    
    with open(filepath, 'r', encoding='utf-8') as f:
        try:
            tree = ast.parse(f.read())
            
            class StringVisitor(ast.NodeVisitor):
                def visit_Str(self, node):
                    if len(node.s.strip()) > 2:  # Ignorar cadenas muy cortas
                        # Intentar categorizar la cadena
                        categorized = False
                        for cat, pattern in PYTHON_CATEGORIES.items():
                            if re.search(pattern, str(node), re.I):
                                strings[cat].add(node.s)
                                categorized = True
                                break
                        if not categorized:
                            strings['uncategorized'].add(node.s)
                            
            StringVisitor().visit(tree)
            
        except Exception as e:
            print(f"Error parsing {filepath}: {e}")
            
    return strings

def scan_directory(base_dir: str) -> Dict[str, Dict[str, Set[str]]]:
    """Escanea un directorio recursivamente buscando cadenas"""
    all_strings = {}
    
    for root, dirs, files in os.walk(base_dir):
        # Excluir directorios no deseados
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        
        for file in files:
            if file.endswith('.py'):
                filepath = os.path.join(root, file)
                rel_path = os.path.relpath(filepath, base_dir)
                strings = extract_strings_from_file(filepath)
                if any(s for s in strings.values()):
                    all_strings[rel_path] = strings
                    
    return all_strings

def generate_translation_keys(strings_dict: Dict) -> Dict:
    """Genera un diccionario de claves de traducción organizadas"""
    translation_keys = {}
    
    for file_path, categories in strings_dict.items():
        for category, strings in categories.items():
            if category == 'uncategorized':
                continue
                
            if category not in translation_keys:
                translation_keys[category] = {}
                
            for s in strings:
                # Generar una clave válida
                key = re.sub(r'[^a-z0-9_]', '_', s.lower())
                key = re.sub(r'_+', '_', key).strip('_')
                
                if key in translation_keys[category]:
                    # Si la clave existe, agregar un número
                    i = 1
                    while f"{key}_{i}" in translation_keys[category]:
                        i += 1
                    key = f"{key}_{i}"
                    
                translation_keys[category][key] = ''
                
    return translation_keys

def main():
    base_dir = "/usr/local/bin/soplos-repo-manager"
    
    print("Escaneando archivos...")
    strings_dict = scan_directory(base_dir)
    
    print("\nGenerando claves de traducción...")
    translation_keys = generate_translation_keys(strings_dict)
    
    # Guardar resultados
    output_dir = os.path.join(base_dir, 'tools', 'output')
    os.makedirs(output_dir, exist_ok=True)
    
    # Guardar cadenas extraídas
    with open(os.path.join(output_dir, 'extracted_strings.json'), 'w', encoding='utf-8') as f:
        json.dump(strings_dict, f, indent=2, ensure_ascii=False)
        
    # Guardar claves generadas
    with open(os.path.join(output_dir, 'translation_keys.json'), 'w', encoding='utf-8') as f:
        json.dump(translation_keys, f, indent=2, ensure_ascii=False)
        
    print(f"\nResultados guardados en {output_dir}")
    print("\nResumen de cadenas encontradas:")
    for cat in PYTHON_CATEGORIES:
        count = sum(len(f[cat]) for f in strings_dict.values())
        print(f"  {cat}: {count}")
    
    uncategorized = sum(len(f['uncategorized']) for f in strings_dict.values())
    print(f"  uncategorized: {uncategorized}")

if __name__ == "__main__":
    main()
