"""Diálogos de confirmación en español"""

FRAGMENT = {
    'delete_package': {
        'title': 'Eliminar paquete',
        'message': '¿Está seguro de que desea eliminar el paquete {0}?',
        'details': 'Esta acción eliminará el paquete del repositorio y todos los archivos asociados.'
    },
    'clean_repo': {
        'title': 'Limpiar repositorio',
        'message': '¿Está seguro de que desea limpiar el repositorio?',
        'details': 'Esta acción eliminará todos los archivos temporales y reconstruirá los índices.'
    },
    'delete_profile': {
        'title': 'Eliminar perfil',
        'message': '¿Está seguro de que desea eliminar el perfil {0}?',
        'details': 'Esta acción eliminará todas las configuraciones y archivos asociados al perfil.'
    },
    'exit_app': {
        'title': 'Salir',
        'message': '¿Está seguro de que desea salir?',
        'details': 'Se perderán los cambios no guardados.'
    }
}
