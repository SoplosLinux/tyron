"""Valori implicite în română"""

FRAGMENT = {
    'install_script_name': 'instaleaza-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Depozit Soplos'
}
