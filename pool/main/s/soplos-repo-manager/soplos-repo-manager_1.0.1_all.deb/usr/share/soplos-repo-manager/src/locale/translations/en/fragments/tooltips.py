"""Tooltip translations in English"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Add new .deb package to repository',
        'upload_changes': 'Upload pending changes to GitHub',
        'manage_keys': 'Manage GPG keys',
        'configure_repo': 'Configure repository details',
        'generate_script': 'Generate installation script',
        'refresh_list': 'Update package list',
        'remove_package': 'Remove selected package',
        'sign_package': 'View package details'
    },
    'tips': {
        'exit_app': 'Exit application'
    }
}
