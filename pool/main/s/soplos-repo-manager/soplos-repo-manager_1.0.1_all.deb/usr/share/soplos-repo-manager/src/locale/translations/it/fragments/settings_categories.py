"""Categorie di configurazione in italiano"""

FRAGMENT = {
    'general': {
        'title': 'Generale',
        'language': 'Lingua',
        'updates': 'Aggiornamenti',
        'notifications': 'Notifiche'
    },
    'appearance': {
        'title': 'Aspetto',
        'theme': 'Tema',
        'icons': 'Icone',
        'fonts': 'Caratteri'
    },
    'network': {
        'title': 'Rete',
        'proxy': 'Proxy',
        'timeout': 'Timeout',
        'retries': 'Tentativi'
    },
    'advanced': {
        'title': 'Avanzate',
        'logging': 'Registro',
        'debug': 'Debug',
        'cache': 'Cache'
    },
    'profiles': {
        'title': 'Profili',
        'default': 'Profilo predefinito',
        'auto_load': 'Carica ultimo profilo',
        'backup': 'Backup automatico'
    }
}
