"""Traduceri pentru scurtături de tastatură în română"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Scurtături de tastatură',
        'categories': {
            'general': 'General',
            'navigation': 'Navigare',
            'editing': 'Editare',
            'view': 'Vizualizare'
        },
        'actions': {
            'save': 'Salvare (Ctrl+S)',
            'quit': 'Ieșire (Ctrl+Q)',
            'refresh': 'Actualizare (Ctrl+R)',
            'search': 'Căutare (Ctrl+F)',
            'preferences': 'Preferințe (Ctrl+P)',
            'help': 'Ajutor (F1)',
            'switch_tab': 'Schimbare filă (Ctrl+Tab)',
            'new_item': 'Element nou (Ctrl+N)',
            'delete_item': 'Ștergere element (Del)',
            'fullscreen': 'Ecran complet (F11)',
            'zoom_in': 'Mărire (Ctrl++)',
            'zoom_out': 'Micșorare (Ctrl+-)',
            'reset_zoom': 'Resetare zoom (Ctrl+0)'
        }
    }
}
