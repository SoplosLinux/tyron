"""Estados e mensagens de estado em português"""

FRAGMENT = {
    'ready': 'Pronto',
    'processing': 'A processar...',
    'waiting': 'A aguardar...',
    'completed': 'Concluído',
    'failed': 'Falhou',
    'uploading': 'A enviar...',
    'downloading': 'A descarregar...',
    'installing': 'A instalar...',
    'updating': 'A atualizar...',
    'error': 'Erro',
    'success': 'Sucesso',
    'cancelled': 'Cancelado',
    'paused': 'Pausado',
    'offline': 'Desligado',
    'online': 'Ligado',
    'syncing': 'A sincronizar...',
    'initializing': 'A inicializar...',
    'cleaning': 'A limpar...'
}
