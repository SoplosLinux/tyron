"""Traduceri pentru operații cu fișiere în română"""

FRAGMENT = {
    'operations': {
        'copying': 'Se copiază {0}...',
        'moving': 'Se mută {0}...',
        'removing': 'Se șterge {0}...',
        'creating_dir': 'Se creează directorul {0}...',
        'reading': 'Se citește {0}...',
        'writing': 'Se scrie {0}...'
    },
    'errors': {
        'error_copy': 'Eroare la copierea fișierului: {0}',
        'error_move': 'Eroare la mutarea fișierului: {0}',
        'error_remove': 'Eroare la ștergerea fișierului: {0}',
        'error_create': 'Eroare la crearea directorului: {0}',
        'error_read': 'Eroare la citirea fișierului: {0}',
        'error_write': 'Eroare la scrierea fișierului: {0}'
    }
}
