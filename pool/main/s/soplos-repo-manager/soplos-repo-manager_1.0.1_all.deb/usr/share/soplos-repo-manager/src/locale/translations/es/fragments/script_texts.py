"""Textos de scripts en español"""

FRAGMENT = {
    'script_header': '#!/bin/bash\n# Script de instalación para repositorio {0}\n',
    'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo "Este script debe ejecutarse como root"\n    exit 1\nfi\n',
    'add_key': 'Añadiendo clave GPG...',
    'add_repo': 'Añadiendo repositorio...',
    'updating': 'Actualizando índices...',
    'installing': 'Instalando paquetes...',
    'complete': 'Instalación completada',
    'error': 'Error: {0}',
    'warning': 'Advertencia: {0}',
    'info': 'Info: {0}',
    'debug': 'Debug: {0}',
    'script_footer': 'echo "Proceso completado"\nexit 0'
}
