"""Mensajes de logging en español"""

FRAGMENT = {
    'debug': {
        'cleaning_start': 'Iniciando limpieza de paquetes del repositorio...',
        'cleaning_complete': 'Repositorio limpiado correctamente',
        'generating_key': 'Generando clave GPG...',
        'key_generated': 'Clave GPG generada con ID: {0}',
        'cloning_repo': 'Clonando repositorio desde {0}',
        'updating_readme': 'Actualizando README...'
    },
    'info': {
        'profile_loaded': 'Perfil {0} cargado',
        'deleting_package': 'Eliminando {0} de reprepro...'
    },
    'warning': {
        'cannot_delete_dir': 'No se pudo eliminar {0}: {1}',
        'key_not_found': 'No se pudo encontrar la clave generada'
    }
}
