"""Information de l'application en français"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Garder le même nom dans toute l'application
    'display_name': 'Soplos Repo Manager',  # Pour le titre dans l'interface
    'version': 'Version {0}',
    'description': 'Gestionnaire de dépôts APT pour Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'Licence GPL-3.0',
    'website': 'https://soplos.org',
    'bugs': 'Signaler un bug',
    'support': 'Support',
    'translate': 'Aider à traduire',
    'contributors': 'Contributeurs',
    'dependencies': 'Dépendances',
    'system_info': 'Informations système'
}
