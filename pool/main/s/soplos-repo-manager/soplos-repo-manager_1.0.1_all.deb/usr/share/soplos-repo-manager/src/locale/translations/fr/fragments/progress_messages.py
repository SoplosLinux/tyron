"""Messages de progression en français"""

FRAGMENT = {
    'estimated_time': 'Temps restant estimé : {0}',
    'total_progress': 'Progression totale : {0}%',
    'remaining_items': '{0} éléments restants',
    'task_status': '{0} sur {1}',
    'current_operation': 'Opération en cours : {0}',
    'processing_item': 'Traitement de {0}...',
    'start_task': 'Démarrage de {0}...',
    'finish_task': 'Terminé {0}',
    'abort_task': 'Annulation de {0}...',
    'error_task': 'Erreur dans {0} : {1}',
    'percent': '{0}% terminé'
}
