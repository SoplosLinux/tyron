"""Mensagens de progresso em português"""

FRAGMENT = {
    'estimated_time': 'Tempo restante estimado: {0}',
    'total_progress': 'Progresso total: {0}%',
    'remaining_items': '{0} elementos restantes',
    'task_status': '{0} de {1}',
    'current_operation': 'Operação atual: {0}',
    'processing_item': 'A processar {0}...',
    'start_task': 'A iniciar {0}...',
    'finish_task': 'Concluído {0}',
    'abort_task': 'A abortar {0}...',
    'error_task': 'Erro em {0}: {1}',
    'percent': '{0}% concluído'
}
