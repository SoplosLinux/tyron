"""Traduções de erros em português"""

FRAGMENT = {
    'git_not_installed': 'É necessário GitPython (python3-git)',
    'load_profiles': 'Erro ao carregar perfis: {0}',
    'save_profile': 'Erro ao guardar perfil: {0}',
    'delete_profile': 'Erro ao eliminar perfil: {0}',
    'loading_config': 'Erro ao carregar configuração: {0}',
    'saving_config': 'Erro ao guardar configuração: {0}',
    'repo_init': 'Erro ao inicializar repositório Git: {0}',
    'get_repo_name': 'Erro ao obter nome do repositório: {0}',
    'readme_dialog': 'Erro no diálogo do README: {0}',
    'list_packages': 'Erro ao listar pacotes: {0}',
    'reading_package': 'Erro ao ler {0}: {1}',
    'create_structure': 'Erro ao criar estrutura: {0}',
    'configure_reprepro': 'Erro ao configurar reprepro: {0}',
    'init_indices': 'Erro ao inicializar índices: {0}',
    'verify_structure': 'Erro ao verificar estrutura: {0}',
    'integrity_check': 'Erro ao verificar integridade: {0}',
    'reprepro_stderr': 'Erro do reprepro: {0}'
}
