"""États des paquets en français"""

FRAGMENT = {
    'new': 'Nouveau',
    'processing': 'En cours',
    'uploading': 'Envoi en cours',
    'uploaded': 'Envoyé',
    'error': 'Erreur',
    'in_pool': 'Dans le Pool',
    'in_github': 'Sur GitHub',
    'in_incoming': 'En attente',
    'unknown': 'Inconnu',
    'installed': 'Installé',
    'not_installed': 'Non installé',
    'partially_installed': 'Partiellement installé',
    'to_install': 'À installer',
    'to_remove': 'À supprimer',
    'to_upgrade': 'À mettre à jour',
    'broken': 'Cassé',
    'configured': 'Configuré',
    'not_configured': 'Non configuré',
    'processed': 'Traité'
}
