"""Traducciones de mensajes del sistema en español"""

FRAGMENT = {
    'system': {
        'startup': {
            'loading': 'Iniciando aplicación...',
            'checking_deps': 'Verificando dependencias...',
            'init_repo': 'Inicializando repositorio...',
            'loading_profiles': 'Cargando perfiles...',
            'ready': 'Sistema listo'
        },
        'shutdown': {
            'saving': 'Guardando cambios...',
            'cleaning': 'Limpiando archivos temporales...',
            'closing': 'Cerrando aplicación...'
        },
        'errors': {
            'critical': 'Error crítico: {0}',
            'dependency': 'Dependencia faltante: {0}',
            'permission': 'Error de permisos: {0}',
            'connection': 'Error de conexión: {0}',
            'config': 'Error de configuración: {0}'
        },
        'warnings': {
            'disk_space': 'Espacio en disco bajo',
            'memory': 'Memoria del sistema baja',
            'connection': 'Conexión inestable',
            'outdated': 'Versión desactualizada'
        }
    }
}
