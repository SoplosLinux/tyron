"""Notas y ayudas en español"""

FRAGMENT = {
    'branch': '<small>Se recomienda usar "main" por defecto</small>',
    'gpg_key': '<small>Se recomienda usar una clave GPG para firmar los paquetes</small>',
    'repo': '<small>El repositorio se configurará con los detalles proporcionados</small>',
    'profile': '<small>Se creará un nuevo perfil con los detalles proporcionados</small>',
    'backup': '<small>Se creará una copia de seguridad de la configuración actual</small>',
    'restore': '<small>Se restaurará la configuración desde la copia de seguridad</small>',
    'import': '<small>Se importará la configuración desde el archivo seleccionado</small>',
    'export': '<small>Se exportará la configuración al archivo seleccionado</small>',
    'update': '<small>Se actualizarán los índices de los paquetes</small>',
    'preferences': '<small>Se guardarán las preferencias del usuario</small>'
}
