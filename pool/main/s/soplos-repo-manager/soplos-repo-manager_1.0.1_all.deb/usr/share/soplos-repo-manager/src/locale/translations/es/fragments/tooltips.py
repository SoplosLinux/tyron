"""Traducciones de tooltips en español"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Añadir nuevo paquete .deb al repositorio',
        'upload_changes': 'Subir cambios pendientes a GitHub',
        'manage_keys': 'Gestionar claves GPG',
        'configure_repo': 'Configurar detalles del repositorio',
        'generate_script': 'Generar script de instalación',
        'refresh_list': 'Actualizar lista de paquetes',
        'remove_package': 'Eliminar paquete seleccionado',
        'sign_package': 'Ver detalles del paquete'
    },
    'tips': {
        'exit_app': 'Salir de la aplicación'
    }
}
