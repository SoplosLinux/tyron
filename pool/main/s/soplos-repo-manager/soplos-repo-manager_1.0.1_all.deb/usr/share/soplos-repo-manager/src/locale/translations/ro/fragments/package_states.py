"""Stări pachete în română"""

FRAGMENT = {
    'new': 'Nou',
    'processing': 'În procesare',
    'uploading': 'Se încarcă',
    'uploaded': 'Încărcat',
    'error': 'Eroare',
    'in_pool': 'În Pool',
    'in_github': 'Pe GitHub',
    'in_incoming': 'În Intrări',
    'unknown': 'Necunoscut',
    'installed': 'Instalat',
    'not_installed': 'Neinstalat',
    'partially_installed': 'Parțial instalat',
    'to_install': 'De instalat',
    'to_remove': 'De șters',
    'to_upgrade': 'De actualizat',
    'broken': 'Deteriorat',
    'configured': 'Configurat',
    'not_configured': 'Neconfigurat',
    'processed': 'Procesat'
}
