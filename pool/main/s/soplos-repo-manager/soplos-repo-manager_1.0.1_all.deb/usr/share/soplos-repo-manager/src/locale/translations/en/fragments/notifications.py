"""Notifications in English"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Information',
        'warning': 'Warning',
        'error': 'Error',
        'success': 'Success'
    },
    'messages': {
        'package_added': 'Package {0} successfully added',
        'package_removed': 'Package {0} removed',
        'upload_started': 'Starting upload of {0}...',
        'upload_complete': 'Upload completed: {0}',
        'update_available': 'New version available: {0}',
        'repo_synced': 'Repository synchronized',
        'backup_created': 'Backup created at {0}'
    }
}
