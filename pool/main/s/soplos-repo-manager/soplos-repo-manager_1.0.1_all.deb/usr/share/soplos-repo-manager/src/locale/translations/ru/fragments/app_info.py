"""Информация о приложении на русском"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Использовать то же имя во всем приложении
    'display_name': 'Soplos Repo Manager',  # Имя для отображения в интерфейсе
    'version': 'Версия {0}',
    'description': 'Менеджер репозиториев APT для Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'Лицензия GPL-3.0',
    'website': 'https://soplos.org',
    'bugs': 'Сообщить об ошибке',
    'support': 'Поддержка',
    'translate': 'Помочь с переводом',
    'contributors': 'Участники',
    'dependencies': 'Зависимости',
    'system_info': 'Информация о системе'
}
