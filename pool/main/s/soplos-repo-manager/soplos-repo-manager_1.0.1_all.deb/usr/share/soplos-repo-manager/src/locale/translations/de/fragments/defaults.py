"""Standardwerte auf Deutsch"""

FRAGMENT = {
    'install_script_name': 'installieren-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Soplos Repository'
}
