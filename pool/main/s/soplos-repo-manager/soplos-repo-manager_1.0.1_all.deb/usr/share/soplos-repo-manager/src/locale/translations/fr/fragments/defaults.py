"""Valeurs par défaut en français"""

FRAGMENT = {
    'install_script_name': 'installer-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Dépôt Soplos'
}
