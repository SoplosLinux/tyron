"""Traductions des éléments de menu en français"""

FRAGMENT = {
    'menu': {
        'file': '_Fichier',
        'edit': '_Édition',
        'view': '_Affichage',
        'tools': '_Outils',
        'help': '_Aide'
    },
    'file_menu': {
        'save': '_Enregistrer',
        'save_as': 'Enregistrer _sous',
        'preferences': '_Préférences',
        'quit': '_Quitter'
    },
    'edit_menu': {
        'undo': '_Annuler',
        'redo': '_Rétablir',
        'cut': '_Couper',
        'copy': 'Co_pier',
        'paste': 'Co_ller',
        'delete': '_Supprimer',
        'select_all': 'Tout _sélectionner'
    },
    'view_menu': {
        'refresh': '_Actualiser',
        'fullscreen': 'Plein _écran',
        'zoom_in': 'Zoom avant',
        'zoom_out': 'Zoom arrière',
        'reset_zoom': 'Zoom normal'
    },
    'help_menu': {
        'about': 'À _propos',
        'documentation': '_Documentation',
        'keyboard_shortcuts': 'Raccourcis _clavier',
        'report_bug': 'Signaler un _bug',
        'check_updates': 'Rechercher des _mises à jour'
    }
}
