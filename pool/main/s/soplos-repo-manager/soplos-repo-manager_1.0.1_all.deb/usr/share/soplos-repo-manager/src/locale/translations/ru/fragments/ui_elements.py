"""UI elements in Russian"""

FRAGMENT = {
    'app_name': 'Soplos Repo Manager',  # Основное название приложения
    'main_window': {
        'title': 'Менеджер репозиториев Soplos',  # Заголовок главного окна
        'title_with_profile': 'Менеджер Репозиториев Soplos - {0}'  # Заголовок с активным профилем
    },
    'window_title': 'Менеджер репозиториев Soplos',
    'menu_items': {
        'file': '_Файл',
        'edit': '_Правка',
        'view': '_Вид',
        'tools': '_Инструменты',
        'help': '_Помощь'
    },
    'tabs': {
        'upload': 'Загрузить',
        'manage': 'Управление',
        'settings': 'Настройки',
        'logs': 'Журналы'
    },
    'sections': {
        'general': 'Общие',
        'appearance': 'Внешний вид',
        'network': 'Сеть',
        'advanced': 'Расширенные',
        'profiles': 'Профили',
        'backup': 'Резервное копирование'
    },
    'context_menu': {
        'cut': 'Вырезать',
        'copy': 'Копировать',
        'paste': 'Вставить',
        'delete': 'Удалить',
        'select_all': 'Выделить всё'
    },
    'placeholders': {
        'search': 'Поиск...',
        'filter': 'Фильтр...',
        'comments': 'Написать комментарий...'
    },
    'file_filters': {
        'deb_packages': 'Пакеты Debian (*.deb)',
        'shell_scripts': 'Скрипты Shell (*.sh)',
        'all_files': 'Все файлы (*.*)',
        'config_files': 'Файлы конфигурации (*.conf)',
        'text_files': 'Текстовые файлы (*.txt)',
        'backup_files': 'Файлы резервных копий (*.bak)'
    }
}
