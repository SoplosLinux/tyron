"""Status und Statusmeldungen auf Deutsch"""

FRAGMENT = {
    'ready': 'Bereit',
    'processing': 'Wird verarbeitet...',
    'waiting': 'Warten...',
    'completed': 'Abgeschlossen',
    'failed': 'Fehlgeschlagen',
    'uploading': 'Wird hochgeladen...',
    'downloading': 'Wird heruntergeladen...',
    'installing': 'Wird installiert...',
    'updating': 'Wird aktualisiert...',
    'error': 'Fehler',
    'success': 'Erfolgreich',
    'cancelled': 'Abgebrochen',
    'paused': 'Pausiert',
    'offline': 'Offline',
    'online': 'Online',
    'syncing': 'Wird synchronisiert...',
    'initializing': 'Wird initialisiert...',
    'cleaning': 'Wird bereinigt...'
}
