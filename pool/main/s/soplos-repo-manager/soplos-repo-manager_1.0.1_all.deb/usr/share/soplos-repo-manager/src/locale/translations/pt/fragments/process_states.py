"""Estados de processo em português"""

FRAGMENT = {
    'startup': {
        'loading': 'A iniciar aplicação...',
        'checking_deps': 'A verificar dependências...',
        'init_repo': 'A inicializar repositório...',
        'loading_profiles': 'A carregar perfis...',
        'ready': 'Sistema pronto'
    },
    'shutdown': {
        'saving': 'A guardar alterações...',
        'cleaning': 'A limpar ficheiros temporários...',
        'closing': 'A fechar aplicação...'
    },
    'states': {
        'validating': 'A validar...',
        'processing': 'A processar...',
        'signing': 'A assinar...',
        'verifying': 'A verificar...',
        'uploading': 'A enviar...',
        'downloading': 'A descarregar...',
        'installing': 'A instalar...',
        'removing': 'A remover...',
        'cleaning': 'A limpar...',
        'backing_up': 'A fazer cópia...',
        'restoring': 'A restaurar...',
        'calculating': 'A calcular...',
        'updating': 'A atualizar...',
        'indexing': 'A indexar...'
    }
}
