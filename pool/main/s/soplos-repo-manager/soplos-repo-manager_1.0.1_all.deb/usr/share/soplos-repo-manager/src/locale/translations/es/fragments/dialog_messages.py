"""Mensajes de diálogo en español"""

FRAGMENT = {
    'select_gpg': 'Seleccionar Clave GPG',
    'wait': 'Por favor espere...',
    'config_repo': 'Configurar Repositorio',
    'new_profile': 'Nuevo Perfil',
    'package_list': 'Lista de Paquetes',
    'version_select': 'Seleccionar versión',
    'existing_file': 'Archivo Existente',
    'file_details': 'Detalles del archivo',
    'package_details': 'Detalles del paquete',
    'create_gpg': 'Crear Nueva Clave GPG',
    'select_gpg': 'Seleccionar Clave GPG',
    'save_script': 'Guardar Script de Instalación',
    'install_script': 'Script de Instalación',
    'gpg_verification': 'Verificación GPG',
    'gpg_key_info': 'Información de la Clave GPG',
    'repo_instructions': 'Instrucciones del Repositorio',
    'confirm_clean_repo': 'Confirmar Limpieza del Repositorio',
    'colors': {
        'green': 'Verde',
        'red': 'Rojo',
        'nc': 'Sin Color'
    }
}
