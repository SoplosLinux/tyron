"""Notifications en français"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Information',
        'warning': 'Avertissement',
        'error': 'Erreur',
        'success': 'Succès'
    },
    'messages': {
        'package_added': 'Paquet {0} ajouté avec succès',
        'package_removed': 'Paquet {0} supprimé',
        'upload_started': 'Démarrage de l\'envoi de {0}...',
        'upload_complete': 'Envoi terminé : {0}',
        'update_available': 'Nouvelle version disponible : {0}',
        'repo_synced': 'Dépôt synchronisé',
        'backup_created': 'Sauvegarde créée dans {0}'
    }
}
