"""Placeholder texts in English"""

FRAGMENT = {
    'repo_url': 'https://github.com/user/repository',
    'token': 'Enter your personal GitHub token',
    'branch': 'main',
    'search': 'Search...',
    'filter': 'Filter...',
    'comments': 'Write comment...',
    'name': 'Full name',
    'email': 'email@example.com',
    'profile_name': 'Profile name',
    'password': 'Password',
    'confirm_password': 'Confirm password'
}
