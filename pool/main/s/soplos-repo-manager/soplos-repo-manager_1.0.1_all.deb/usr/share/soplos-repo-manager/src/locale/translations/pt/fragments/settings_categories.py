"""Categorias de configuração em português"""

FRAGMENT = {
    'general': {
        'title': 'Geral',
        'language': 'Idioma',
        'updates': 'Atualizações',
        'notifications': 'Notificações'
    },
    'appearance': {
        'title': 'Aparência',
        'theme': 'Tema',
        'icons': 'Ícones',
        'fonts': 'Tipos de letra'
    },
    'network': {
        'title': 'Rede',
        'proxy': 'Proxy',
        'timeout': 'Tempo limite',
        'retries': 'Tentativas'
    },
    'advanced': {
        'title': 'Avançado',
        'logging': 'Registo',
        'debug': 'Depuração',
        'cache': 'Cache'
    },
    'profiles': {
        'title': 'Perfis',
        'default': 'Perfil predefinido',
        'auto_load': 'Carregar último perfil',
        'backup': 'Backup automático'
    }
}
