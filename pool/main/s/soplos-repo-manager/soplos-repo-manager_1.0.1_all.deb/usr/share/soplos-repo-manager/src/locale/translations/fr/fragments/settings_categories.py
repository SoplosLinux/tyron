"""Catégories de configuration en français"""

FRAGMENT = {
    'general': {
        'title': 'Général',
        'language': 'Langue',
        'updates': 'Mises à jour',
        'notifications': 'Notifications'
    },
    'appearance': {
        'title': 'Apparence',
        'theme': 'Thème',
        'icons': 'Icônes',
        'fonts': 'Polices'
    },
    'network': {
        'title': 'Réseau',
        'proxy': 'Proxy',
        'timeout': 'Délai d\'attente',
        'retries': 'Tentatives'
    },
    'advanced': {
        'title': 'Avancé',
        'logging': 'Journalisation',
        'debug': 'Débogage',
        'cache': 'Cache'
    },
    'profiles': {
        'title': 'Profils',
        'default': 'Profil par défaut',
        'auto_load': 'Charger le dernier profil',
        'backup': 'Sauvegarde automatique'
    }
}
