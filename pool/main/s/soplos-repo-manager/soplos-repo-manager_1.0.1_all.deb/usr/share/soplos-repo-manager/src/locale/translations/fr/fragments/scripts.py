"""Traductions des scripts en français"""

FRAGMENT = {
    'downloading_gpg': 'Téléchargement de la clé GPG...',
    'error_downloading_gpg': 'Erreur lors du téléchargement de la clé GPG',
    'verify_root': 'Vérifier l\'exécution en tant que root',
    'must_be_root': 'Ce script doit être exécuté en tant que root',
    'create_keyring': 'Créer le répertoire du trousseau GPG',
    'download_gpg': 'Télécharger et importer la clé GPG',
    'verify_gpg': 'Vérifier que la clé a été correctement téléchargée',
    'error_gpg_empty': 'Erreur : La clé GPG est vide ou n\'a pas été installée',
    'config_repo': 'Configurer le dépôt',
    'configuring_repo': 'Configuration du dépôt...',
    'force_update': 'Forcer la mise à jour sécurisée',
    'updating_indices': 'Mise à jour des index...',
    'verify_repo': 'Vérifier que le dépôt est configuré',
    'error_repo_not_configured': 'Erreur : Le dépôt n\'a pas été configuré correctement',
    'repo_installed': 'Dépôt installé avec succès !',
    'colors': 'Couleurs pour les messages',
    'install_repo': 'Script d\'installation pour le dépôt {}'
}
