"""Notificações em português"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Informação',
        'warning': 'Aviso',
        'error': 'Erro',
        'success': 'Sucesso'
    },
    'messages': {
        'package_added': 'Pacote {0} adicionado com sucesso',
        'package_removed': 'Pacote {0} removido',
        'upload_started': 'A iniciar envio de {0}...',
        'upload_complete': 'Envio concluído: {0}',
        'update_available': 'Nova versão disponível: {0}',
        'repo_synced': 'Repositório sincronizado',
        'backup_created': 'Cópia de segurança criada em {0}'
    }
}
