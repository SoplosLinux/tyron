"""Traduceri pentru elementele de meniu în română"""

FRAGMENT = {
    'menu': {
        'file': '_Fișier',
        'edit': '_Editare',
        'view': '_Vizualizare',
        'tools': '_Unelte',
        'help': '_Ajutor'
    },
    'file_menu': {
        'save': '_Salvare',
        'save_as': 'Salvare _ca',
        'preferences': '_Preferințe',
        'quit': '_Ieșire'
    },
    'edit_menu': {
        'undo': '_Anulare',
        'redo': '_Refacere',
        'cut': '_Tăiere',
        'copy': '_Copiere',
        'paste': '_Lipire',
        'delete': '_Ștergere',
        'select_all': 'Selectare _tot'
    },
    'view_menu': {
        'refresh': '_Reîmprospătare',
        'fullscreen': 'Ecran _complet',
        'zoom_in': 'Mărire',
        'zoom_out': 'Micșorare',
        'reset_zoom': 'Zoom normal'
    },
    'help_menu': {
        'about': '_Despre',
        'documentation': '_Documentație',
        'keyboard_shortcuts': '_Comenzi rapide',
        'report_bug': 'Raportare _eroare',
        'check_updates': 'Căutare _actualizări'
    }
}
