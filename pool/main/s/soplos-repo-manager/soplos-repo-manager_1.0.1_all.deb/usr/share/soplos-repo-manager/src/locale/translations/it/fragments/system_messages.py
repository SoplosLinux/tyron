"""Messaggi di sistema in italiano"""

FRAGMENT = {
    'system': {
        'startup': {
            'loading': 'Avvio applicazione...',
            'checking_deps': 'Verifica dipendenze...',
            'init_repo': 'Inizializzazione repository...',
            'loading_profiles': 'Caricamento profili...',
            'ready': 'Sistema pronto'
        },
        'shutdown': {
            'saving': 'Salvataggio modifiche...',
            'cleaning': 'Pulizia file temporanei...',
            'closing': 'Chiusura applicazione...'
        },
        'errors': {
            'critical': 'Errore critico: {0}',
            'dependency': 'Dipendenza mancante: {0}',
            'permission': 'Errore di permessi: {0}',
            'connection': 'Errore di connessione: {0}',
            'config': 'Errore di configurazione: {0}'
        },
        'warnings': {
            'disk_space': 'Spazio su disco insufficiente',
            'memory': 'Memoria di sistema insufficiente',
            'connection': 'Connessione instabile',
            'outdated': 'Versione non aggiornata'
        }
    }
}
