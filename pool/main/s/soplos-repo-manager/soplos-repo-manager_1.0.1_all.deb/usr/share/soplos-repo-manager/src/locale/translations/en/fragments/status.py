"""Status translations in English"""

FRAGMENT = {
    'ready': 'Ready',
    'processing': 'Processing...',
    'waiting': 'Waiting...',
    'completed': 'Completed',
    'failed': 'Failed',
    'uploading': 'Uploading...',
    'downloading': 'Downloading...',
    'installing': 'Installing...',
    'updating': 'Updating...',
    'error': 'Error',
    'success': 'Success',
    'cancelled': 'Cancelled',
    'paused': 'Paused',
    'offline': 'Offline',
    'online': 'Online',
    'syncing': 'Syncing...',
    'initializing': 'Initializing...',
    'cleaning': 'Cleaning...'
}
