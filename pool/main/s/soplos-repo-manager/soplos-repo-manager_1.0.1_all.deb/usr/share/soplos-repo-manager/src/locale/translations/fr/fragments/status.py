"""États et messages d'état en français"""

FRAGMENT = {
    'ready': 'Prêt',
    'processing': 'Traitement...',
    'waiting': 'En attente...',
    'completed': 'Terminé',
    'failed': 'Échoué',
    'uploading': 'Envoi...',
    'downloading': 'Téléchargement...',
    'installing': 'Installation...',
    'updating': 'Mise à jour...',
    'error': 'Erreur',
    'success': 'Succès',
    'cancelled': 'Annulé',
    'paused': 'En pause',
    'offline': 'Hors ligne',
    'online': 'En ligne',
    'syncing': 'Synchronisation...',
    'initializing': 'Initialisation...',
    'cleaning': 'Nettoyage...'
}
