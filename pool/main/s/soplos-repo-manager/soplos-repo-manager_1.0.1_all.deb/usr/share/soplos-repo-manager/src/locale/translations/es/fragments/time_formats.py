"""Traducciones de formatos de tiempo en español"""

FRAGMENT = {
    'short_date': '%d/%m/%Y',
    'long_date': '%d de %B de %Y',
    'time': '%H:%M:%S',
    'datetime': '%d/%m/%Y %H:%M:%S',
    'month_names': [
        'Enero', 'Febrero', 'Marzo', 'Abril',
        'Mayo', 'Junio', 'Julio', 'Agosto',
        'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ],
    'day_names': [
        'Lunes', 'Martes', 'Miércoles', 'Jueves',
        'Viernes', 'Sábado', 'Domingo'
    ],
    'relative': {
        'today': 'Hoy',
        'yesterday': 'Ayer',
        'tomorrow': 'Mañana',
        'past': 'Hace {0}',
        'future': 'En {0}'
    }
}
