"""File filter translations in English"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Shell Scripts (*.sh)',
        }
    }
}
