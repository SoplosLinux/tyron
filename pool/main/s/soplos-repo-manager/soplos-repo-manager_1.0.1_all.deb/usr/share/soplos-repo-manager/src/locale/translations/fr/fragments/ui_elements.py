"""UI elements in French"""

FRAGMENT = {
    'app_name': 'Soplos Repo Manager',
    'main_window': {
        'title': 'Gestionnaire de dépôts Soplos'
    },
    'window_title': 'Gestionnaire de dépôts Soplos',
    'menu_items': {
        'file': '_Fichier',
        'edit': '_Édition',
        'view': '_Affichage',
        'tools': '_Outils',
        'help': '_Aide'
    },
    'tabs': {
        'upload': 'Téléverser',
        'manage': 'Gérer',
        'settings': 'Configuration',
        'logs': 'Journaux'
    },
    'sections': {
        'general': 'Général',
        'appearance': 'Apparence',
        'network': 'Réseau',
        'advanced': 'Avancé',
        'profiles': 'Profils',
        'backup': 'Sauvegarde'
    },
    'context_menu': {
        'cut': 'Couper',
        'copy': 'Copier',
        'paste': 'Coller',
        'delete': 'Supprimer',
        'select_all': 'Tout sélectionner'
    },
    'placeholders': {
        'search': 'Rechercher...',
        'filter': 'Filtrer...',
        'comments': 'Écrire un commentaire...'
    },
    'file_filters': {
        'deb_packages': 'Paquets Debian (*.deb)',
        'shell_scripts': 'Scripts Shell (*.sh)',
        'all_files': 'Tous les fichiers (*.*)',
        'config_files': 'Fichiers de configuration (*.conf)',
        'text_files': 'Fichiers texte (*.txt)',
        'backup_files': 'Fichiers de sauvegarde (*.bak)'
    }
}
