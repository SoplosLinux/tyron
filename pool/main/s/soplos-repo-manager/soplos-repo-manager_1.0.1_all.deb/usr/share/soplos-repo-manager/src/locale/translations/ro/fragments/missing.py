"""Texte lipsă în română"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Raportează erori',
        'license': 'Licență',
        'support': 'Suport',
        'translate': 'Traducere',
        'version': 'Versiune',
        'website': 'Site web'
    },
    'buttons': {
        'accept': 'Acceptă',
        'cancel': 'Anulează',
        'clean': 'Curăță',
        'close': 'Închide',
        'create': 'Creează',
        'create_gpg_key': 'Creează cheie GPG',
        'delete': 'Șterge',
        'delete_gpg_key': 'Șterge cheie GPG',
        'no': 'Nu',
        'overwrite': 'Suprascrie',
        'overwrite_all': 'Suprascrie tot',
        'save': 'Salvează',
        'select': 'Selectează',
        'skip': 'Omite',
        'skip_all': 'Omite tot',
        'update_list': 'Actualizează lista',
        'yes': 'Da'
    },
    # ...resto del código con las traducciones al rumano...
}
