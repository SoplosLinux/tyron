"""Переводы ошибок на русский"""

FRAGMENT = {
    'git_not_installed': 'Требуется GitPython (python3-git)',
    'load_profiles': 'Ошибка загрузки профилей: {0}',
    'save_profile': 'Ошибка сохранения профиля: {0}',
    'delete_profile': 'Ошибка удаления профиля: {0}',
    'loading_config': 'Ошибка загрузки конфигурации: {0}',
    'saving_config': 'Ошибка сохранения конфигурации: {0}',
    'repo_init': 'Ошибка инициализации репозитория Git: {0}',
    'get_repo_name': 'Ошибка получения имени репозитория: {0}',
    'readme_dialog': 'Ошибка в диалоге README: {0}',
    'list_packages': 'Ошибка получения списка пакетов: {0}',
    'reading_package': 'Ошибка чтения {0}: {1}',
    'create_structure': 'Ошибка создания структуры: {0}',
    'configure_reprepro': 'Ошибка настройки reprepro: {0}',
    'init_indices': 'Ошибка инициализации индексов: {0}',
    'verify_structure': 'Ошибка проверки структуры: {0}',
    'integrity_check': 'Ошибка проверки целостности: {0}',
    'reprepro_stderr': 'Ошибка reprepro: {0}'
}
