"""Traduceri pentru filtre de fișiere în română"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Scripturi Shell (*.sh)',
        }
    }
}
