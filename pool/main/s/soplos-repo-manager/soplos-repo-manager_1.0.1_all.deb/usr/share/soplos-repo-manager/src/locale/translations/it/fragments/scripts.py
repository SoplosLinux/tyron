"""Traduzioni degli script in italiano"""

FRAGMENT = {
    'downloading_gpg': 'Download della chiave GPG in corso...',
    'error_downloading_gpg': 'Errore durante il download della chiave GPG',
    'verify_root': 'Verifica esecuzione come root',
    'must_be_root': 'Questo script deve essere eseguito come root',
    'create_keyring': 'Creazione directory del portachiavi GPG',
    'download_gpg': 'Download e importazione chiave GPG',
    'verify_gpg': 'Verifica corretto download della chiave',
    'error_gpg_empty': 'Errore: La chiave GPG è vuota o non installata',
    'config_repo': 'Configura repository',
    'configuring_repo': 'Configurazione repository in corso...',
    'force_update': 'Forza aggiornamento sicuro',
    'updating_indices': 'Aggiornamento indici in corso...',
    'verify_repo': 'Verifica configurazione repository',
    'error_repo_not_configured': 'Errore: Il repository non è stato configurato correttamente',
    'repo_installed': 'Repository installato con successo!',
    'colors': 'Colori per i messaggi',
    'install_repo': 'Script di installazione per repository {}'
}
