import os
import json
import logging

class ProfileManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.config_dir = os.path.expanduser("~/.config/soplos-repo-manager")
        self.profiles_file = os.path.join(self.config_dir, "profiles.json")
        self.current_profile = None
        self.profiles = self._load_profiles()

    def _load_profiles(self):
        """Carga los perfiles guardados"""
        try:
            os.makedirs(self.config_dir, exist_ok=True)
            if os.path.exists(self.profiles_file):
                with open(self.profiles_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            self.logger.error(f"Error cargando perfiles: {e}")
            return {}

    def save_profile(self, name, data):
        """Guarda un nuevo perfil o actualiza uno existente"""
        try:
            self.profiles[name] = data
            with open(self.profiles_file, 'w') as f:
                json.dump(self.profiles, f, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error guardando perfil: {e}")
            return False

    def delete_profile(self, name):
        """Elimina un perfil existente"""
        try:
            if name in self.profiles:
                del self.profiles[name]
                with open(self.profiles_file, 'w') as f:
                    json.dump(self.profiles, f, indent=2)
                return True
            return False
        except Exception as e:
            self.logger.error(f"Error eliminando perfil: {e}")
            return False

    def get_profile(self, name):
        """Obtiene un perfil por nombre"""
        return self.profiles.get(name)

    def list_profiles(self):
        """Lista todos los perfiles disponibles"""
        return list(self.profiles.keys())

    def set_current_profile(self, name):
        """Establece el perfil activo"""
        if name in self.profiles:
            self.current_profile = name
            return True
        return False
