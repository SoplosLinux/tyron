"""Traductions des opérations sur les fichiers en français"""

FRAGMENT = {
    'operations': {
        'copying': 'Copie de {0}...',
        'moving': 'Déplacement de {0}...',
        'removing': 'Suppression de {0}...',
        'creating_dir': 'Création du répertoire {0}...',
        'reading': 'Lecture de {0}...',
        'writing': 'Écriture de {0}...'
    },
    'errors': {
        'error_copy': 'Erreur lors de la copie du fichier : {0}',
        'error_move': 'Erreur lors du déplacement du fichier : {0}',
        'error_remove': 'Erreur lors de la suppression du fichier : {0}',
        'error_create': 'Erreur lors de la création du répertoire : {0}',
        'error_read': 'Erreur lors de la lecture du fichier : {0}',
        'error_write': 'Erreur lors de l\'écriture du fichier : {0}'
    }
}
