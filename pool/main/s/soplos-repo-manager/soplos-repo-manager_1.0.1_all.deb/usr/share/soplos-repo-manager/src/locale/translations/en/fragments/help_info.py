"""Help information translations in English"""

FRAGMENT = {
    'help_info': {
        'gpg_setup': 'How to configure GPG',
        'repo_setup': 'How to configure the repository',
        'profiles': 'Using profiles',
        'packages': 'Package management',
        'scripts': 'Installation scripts',
        'updates': 'Updates',
        'support': 'Get support',
        'sections': {
            'quick_start': 'Quick start',
            'configuration': 'Configuration',
            'usage': 'Basic usage',
            'advanced': 'Advanced options',
            'troubleshooting': 'Troubleshooting',
            'faq': 'Frequently asked questions'
        }
    }
}
