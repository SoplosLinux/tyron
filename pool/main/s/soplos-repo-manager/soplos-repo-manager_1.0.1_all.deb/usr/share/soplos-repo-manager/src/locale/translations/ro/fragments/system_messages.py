"""Mesaje de sistem în română"""

FRAGMENT = {
    'system': {
        'startup': {
            'loading': 'Se pornește aplicația...',
            'checking_deps': 'Se verifică dependențele...',
            'init_repo': 'Se inițializează depozitul...',
            'loading_profiles': 'Se încarcă profilurile...',
            'ready': 'Sistem pregătit'
        },
        'shutdown': {
            'saving': 'Se salvează modificările...',
            'cleaning': 'Se curăță fișierele temporare...',
            'closing': 'Se închide aplicația...'
        },
        'errors': {
            'critical': 'Eroare critică: {0}',
            'dependency': 'Dependență lipsă: {0}',
            'permission': 'Eroare de permisiuni: {0}',
            'connection': 'Eroare de conexiune: {0}',
            'config': 'Eroare de configurare: {0}'
        },
        'warnings': {
            'disk_space': 'Spațiu pe disc redus',
            'memory': 'Memorie sistem redusă',
            'connection': 'Conexiune instabilă',
            'outdated': 'Versiune învechită'
        }
    }
}
