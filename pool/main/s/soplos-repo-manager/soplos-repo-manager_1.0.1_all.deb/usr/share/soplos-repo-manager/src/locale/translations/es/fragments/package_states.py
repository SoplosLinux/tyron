"""Estados de paquetes en español"""

FRAGMENT = {
    'error': 'Error',
    'in_github': 'En GitHub',
    'in_incoming': 'En incoming',
    'in_pool': 'En pool',
    'new': 'Nuevo',
    'processing': 'Procesando',
    'processed': 'Procesado',  # Añadir traducción en español
    'unknown': 'Desconocido',
    'uploaded': 'Subido',
    'uploading': 'Subiendo'
}
