"""Textes d'espace réservé en français"""

FRAGMENT = {
    'repo_url': 'https://github.com/utilisateur/depot',
    'token': 'Entrez votre token personnel GitHub',
    'branch': 'main',
    'search': 'Rechercher...',
    'filter': 'Filtrer...',
    'comments': 'Écrire un commentaire...',
    'name': 'Nom complet',
    'email': 'email@exemple.com',
    'profile_name': 'Nom du profil',
    'password': 'Mot de passe',
    'confirm_password': 'Confirmer le mot de passe'
}
