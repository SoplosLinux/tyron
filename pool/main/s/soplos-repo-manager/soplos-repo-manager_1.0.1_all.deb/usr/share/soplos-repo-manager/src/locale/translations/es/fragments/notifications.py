"""Notificaciones en español"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Información',
        'warning': 'Advertencia',
        'error': 'Error',
        'success': 'Éxito'
    },
    'messages': {
        'package_added': 'Paquete {0} añadido exitosamente',
        'package_removed': 'Paquete {0} eliminado',
        'upload_started': 'Iniciando subida de {0}...',
        'upload_complete': 'Subida completada: {0}',
        'update_available': 'Nueva versión disponible: {0}',
        'repo_synced': 'Repositorio sincronizado',
        'backup_created': 'Respaldo creado en {0}'
    }
}
