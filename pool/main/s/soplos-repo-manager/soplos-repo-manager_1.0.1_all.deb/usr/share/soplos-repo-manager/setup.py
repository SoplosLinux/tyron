from setuptools import setup, find_packages

setup(
    name="soplos-repo-manager",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "pygit2>=1.12.0",
        "PyGObject>=3.42.0",
        "python-apt>=2.0.0",
        "setuptools>=42.0.0",
        "wheel>=0.37.0",
    ],
    entry_points={
        'gui_scripts': [
            'soplos-repo-manager=main:main',
        ],
    },
    package_data={
        'assets': ['icons/*.png', '*.desktop'],
    },
    data_files=[
        ('share/applications', ['assets/com.soplos.repomanager.desktop']),
        ('share/icons/hicolor/128x128/apps', ['assets/icons/com.soplos.repomanager.png']),
        ('share/metainfo', ['debian/com.soplos.repomanager.metainfo.xml']),
    ],
    author="Soplos Linux Team",
    author_email="info@soplos.org",
    description="Gestor de repositorios APT para Soplos Linux",
    keywords="apt, repository, package, manager, gtk",
    project_urls={
        "Homepage": "https://soploslinux.com",
        "Bug Tracker": "https://github.com/SoplosLinux/tyron/issues",
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: X11 Applications :: GTK",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Programming Language :: Python :: 3",
        "Topic :: System :: Software Distribution",
    ],
)
