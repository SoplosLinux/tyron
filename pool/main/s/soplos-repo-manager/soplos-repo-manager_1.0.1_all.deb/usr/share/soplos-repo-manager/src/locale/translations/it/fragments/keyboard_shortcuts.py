"""Traduzioni delle scorciatoie da tastiera in italiano"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Scorciatoie da tastiera',
        'categories': {
            'general': 'Generale',
            'navigation': 'Navigazione',
            'editing': 'Modifica',
            'view': 'Visualizzazione'
        },
        'actions': {
            'save': 'Salva (Ctrl+S)',
            'quit': 'Esci (Ctrl+Q)',
            'refresh': 'Aggiorna (Ctrl+R)',
            'search': 'Cerca (Ctrl+F)',
            'preferences': 'Preferenze (Ctrl+P)',
            'help': 'Aiuto (F1)',
            'switch_tab': 'Cambia scheda (Ctrl+Tab)',
            'new_item': 'Nuovo elemento (Ctrl+N)',
            'delete_item': 'Elimina elemento (Canc)',
            'fullscreen': 'Schermo intero (F11)',
            'zoom_in': 'Aumenta zoom (Ctrl++)',
            'zoom_out': 'Diminuisci zoom (Ctrl+-)',
            'reset_zoom': 'Reimposta zoom (Ctrl+0)'
        }
    }
}
