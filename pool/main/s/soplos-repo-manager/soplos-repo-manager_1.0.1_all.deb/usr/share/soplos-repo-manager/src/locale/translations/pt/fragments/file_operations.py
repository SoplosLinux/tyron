"""Traduções de operações de ficheiros em português"""

FRAGMENT = {
    'operations': {
        'copying': 'A copiar {0}...',
        'moving': 'A mover {0}...',
        'removing': 'A eliminar {0}...',
        'creating_dir': 'A criar diretório {0}...',
        'reading': 'A ler {0}...',
        'writing': 'A escrever {0}...'
    },
    'errors': {
        'error_copy': 'Erro ao copiar ficheiro: {0}',
        'error_move': 'Erro ao mover ficheiro: {0}',
        'error_remove': 'Erro ao eliminar ficheiro: {0}',
        'error_create': 'Erro ao criar diretório: {0}',
        'error_read': 'Erro ao ler ficheiro: {0}',
        'error_write': 'Erro ao escrever ficheiro: {0}'
    }
}
