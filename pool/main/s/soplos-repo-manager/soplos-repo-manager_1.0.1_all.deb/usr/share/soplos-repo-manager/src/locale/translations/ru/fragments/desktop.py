"""Переводы для файла .desktop на русском"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Использовать то же имя, что и в ui_elements
    'generic_name': 'Менеджер Репозиториев',
    'keywords': 'пакеты;apt;repo;deb;gpg;репозиторий;',
    'categories': 'System;PackageManager;GTK;',
    'startup_notify': 'true'
}
