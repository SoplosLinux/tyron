"""Informações da aplicação em português"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Usar o mesmo nome em toda a aplicação
    'display_name': 'Soplos Repo Manager',  # Nome para exibição na interface
    'version': 'Versão {0}',
    'description': 'Gestor de repositórios APT para Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'Licença GPL-3.0',
    'website': 'https://soplos.org',
    'bugs': 'Reportar erros',
    'support': 'Suporte',
    'translate': 'Ajudar a traduzir',
    'contributors': 'Colaboradores',
    'dependencies': 'Dependências',
    'system_info': 'Informações do sistema'
}
