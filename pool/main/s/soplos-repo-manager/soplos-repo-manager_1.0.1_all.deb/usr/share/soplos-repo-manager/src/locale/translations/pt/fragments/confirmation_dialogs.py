"""Diálogos de confirmação em português"""

FRAGMENT = {
    'delete_package': {
        'title': 'Eliminar pacote',
        'message': 'Tem certeza que deseja eliminar o pacote {0}?',
        'details': 'Esta ação eliminará o pacote do repositório e todos os ficheiros associados.'
    },
    'clean_repo': {
        'title': 'Limpar repositório',
        'message': 'Tem certeza que deseja limpar o repositório?',
        'details': 'Esta ação eliminará todos os ficheiros temporários e reconstruirá os índices.'
    },
    'delete_profile': {
        'title': 'Eliminar perfil',
        'message': 'Tem certeza que deseja eliminar o perfil {0}?',
        'details': 'Esta ação eliminará todas as configurações e ficheiros associados ao perfil.'
    },
    'exit_app': {
        'title': 'Sair',
        'message': 'Tem certeza que deseja sair?',
        'details': 'As alterações não guardadas serão perdidas.'
    }
}
