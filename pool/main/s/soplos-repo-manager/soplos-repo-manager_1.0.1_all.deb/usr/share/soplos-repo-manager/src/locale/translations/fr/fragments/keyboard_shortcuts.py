"""Traductions des raccourcis clavier en français"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Raccourcis clavier',
        'categories': {
            'general': 'Général',
            'navigation': 'Navigation',
            'editing': 'Édition',
            'view': 'Affichage'
        },
        'actions': {
            'save': 'Enregistrer (Ctrl+S)',
            'quit': 'Quitter (Ctrl+Q)',
            'refresh': 'Actualiser (Ctrl+R)',
            'search': 'Rechercher (Ctrl+F)',
            'preferences': 'Préférences (Ctrl+P)',
            'help': 'Aide (F1)',
            'switch_tab': 'Changer d\'onglet (Ctrl+Tab)',
            'new_item': 'Nouvel élément (Ctrl+N)',
            'delete_item': 'Supprimer l\'élément (Suppr)',
            'fullscreen': 'Plein écran (F11)',
            'zoom_in': 'Zoom avant (Ctrl++)',
            'zoom_out': 'Zoom arrière (Ctrl+-)',
            'reset_zoom': 'Réinitialiser le zoom (Ctrl+0)'
        }
    }
}
