"""Keyboard shortcuts translations in English"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Keyboard shortcuts',
        'categories': {
            'general': 'General',
            'navigation': 'Navigation',
            'editing': 'Editing',
            'view': 'View'
        },
        'actions': {
            'save': 'Save (Ctrl+S)',
            'quit': 'Quit (Ctrl+Q)',
            'refresh': 'Refresh (Ctrl+R)',
            'search': 'Search (Ctrl+F)',
            'preferences': 'Preferences (Ctrl+P)',
            'help': 'Help (F1)',
            'switch_tab': 'Switch tab (Ctrl+Tab)',
            'new_item': 'New item (Ctrl+N)',
            'delete_item': 'Delete item (Del)',
            'fullscreen': 'Fullscreen (F11)',
            'zoom_in': 'Zoom in (Ctrl++)',
            'zoom_out': 'Zoom out (Ctrl+-)',
            'reset_zoom': 'Reset zoom (Ctrl+0)'
        }
    }
}
