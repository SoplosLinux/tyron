"""Progress messages in English"""

FRAGMENT = {
    'estimated_time': 'Estimated time remaining: {0}',
    'total_progress': 'Total progress: {0}%',
    'remaining_items': '{0} items remaining',
    'task_status': '{0} of {1}',
    'current_operation': 'Current operation: {0}',
    'processing_item': 'Processing {0}...',
    'start_task': 'Starting {0}...',
    'finish_task': 'Completed {0}',
    'abort_task': 'Aborting {0}...',
    'error_task': 'Error in {0}: {1}',
    'percent': '{0}% completed'
}
