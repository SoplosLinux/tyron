#region imports and class definition
import gi
import os
import shutil
import subprocess
from pathlib import Path
import logging  # Añadir esta importación al inicio

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, GLib, Gdk, Pango
from ..utils.file_filters import create_deb_filter, create_all_filter

from src.locale.strings import get_string, locale_manager, STRINGS
from src.utils.repo_manager import RepoManager
from src.locale.translations.es import SPANISH

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Inicializar logger
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            # Corregir el formato - había un 'levellevelname' incorrecto
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.DEBUG)
        # Definir tooltips para botones
        self.button_tooltips = {
            'buttons.add_file': 'detailed_tooltips.add_package',
            'buttons.upload': 'detailed_tooltips.upload_changes', 
            'buttons.gpg': 'detailed_tooltips.manage_keys',
            'buttons.repo': 'detailed_tooltips.configure_repo',
            'buttons.script': 'detailed_tooltips.generate_script',
            'buttons.exit': 'tips.exit_app',
            'buttons.refresh': 'detailed_tooltips.refresh_list',
            'buttons.remove': 'detailed_tooltips.remove_package',
            'buttons.view': 'detailed_tooltips.sign_package'
        }

        # Asegurar que tenemos strings antes de continuar
        self.strings = STRINGS.get(locale_manager.current_lang, SPANISH)
        
        # Inicializar stores antes de todo
        # Modelo ampliado: 0:ruta, 1:nombre, 2:tamaño, 3:fecha, 4:estado, 5:version, 6:arquitectura, 7:sección, 8:descripción
        self.files_store = Gtk.ListStore(str, str, str, str, str, str, str, str, str)
        # Ampliar el modelo para incluir tamaño, fecha y estado: 0:nombre, 1:versión, 2:arquitectura, 3:sección, 4:descripción, 5:tamaño, 6:fecha, 7:estado
        self.packages_store = Gtk.ListStore(str, str, str, str, str, str, str, str)

        # Inicializar repo_manager primero
        try:
            self.repo = RepoManager(gpg_key=None)
        except Exception as e:
            self.repo = None  # Asegurar que el atributo existe aunque falle
            # Mostraremos el error después de crear la UI

        # Después configurar la ventana y crear la UI
        self.setup_window()
        self.create_ui()

        # Si hubo error al crear repo_manager, mostrarlo ahora que existe la UI
        if not self.repo:
            self.show_error(f"Error inicializando el gestor de repositorio: {str(e)}")
            return

        # Ahora inicializar el gestor de repositorio completamente
        self.init_repo_manager()
        
        # Conectar señales al final
        locale_manager.connect('language-changed', self._on_language_changed)
        self.connect('destroy', self.on_destroy)

    def setup_window(self):
        """Configura la ventana principal"""
        self.set_title(get_string('ui_elements.window_title'))
        self.set_default_size(1024, 768)

        # Corregir la ruta del icono 
        icon_path = "/usr/share/icons/hicolor/128x128/apps/soplos-repo-manager.png"
        if os.path.exists(icon_path):
            try:
                icon = GdkPixbuf.Pixbuf.new_from_file(icon_path)
                self.set_icon(icon)
            except Exception as e:
                self.logger.warning(get_string('errors.load_icon').format(str(e)))

    def init_repo_manager(self):
        """Inicializa el gestor de repositorio"""
        try:
            self.repo = RepoManager()
            
            # Verificar si hay perfiles configurados
            profiles = self.repo.profile_manager.list_profiles()
            
            if not profiles:
                # Si no hay perfiles, mostrar diálogo de configuración inicial
                response = self.show_confirm(get_string('messages.no_profiles'))
                if response:
                    self.on_add_profile(None)
                    if not self.repo.git_token:
                        self.show_error(get_string('messages.config_repo_first'))
                        self.close()
                        return
                else:
                    self.close()
                    return
                    
            # Actualizar combo de perfiles silenciosamente
            self._update_profile_combo_silent()
            
        except Exception as e:
            self.show_error(str(e))
            return

    def _update_profile_combo_silent(self):
        """Actualiza el ComboBox de perfiles sin generar eventos"""
        # Desconectar temporalmente la señal changed
        if hasattr(self, 'profile_combo'):
            self.profile_combo.handler_disconnect(self.profile_handler_id)
            
            self.profile_combo.remove_all()
            profiles = self.repo.profile_manager.list_profiles()
            current_profile = self.repo.current_profile
            
            for profile in profiles:
                self.profile_combo.append_text(profile)
            
            if (current_profile and current_profile in profiles):
                index = profiles.index(current_profile)
                self.profile_combo.set_active(index)
            elif profiles:
                self.profile_combo.set_active(0)
                self.repo.current_profile = profiles[0]
                self.repo.profile_manager.set_current_profile(profiles[0])
                self.repo.load_profile(profiles[0])
            
            # Reconectar la señal
            self.profile_handler_id = self.profile_combo.connect('changed', self.on_profile_changed)

    def show_gpg_key_dialog(self):
        """Muestra un diálogo para seleccionar la clave GPG"""
        dialog = Gtk.Dialog(
            title=get_string('dialogs.select_gpg'),
            parent=self,
            flags=0,
            buttons=(
                get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
                get_string('buttons.ok'), Gtk.ResponseType.OK  # Usar buttons.ok aquí
            )
        )
        dialog.set_default_size(400, 300)

        box = dialog.get_content_area()
        
        # Botones en la parte superior
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.pack_start(button_box, False, False, 10)
        
        # Botón crear
        create_button = Gtk.Button(label=get_string('buttons.create_gpg_key'))
        create_button.connect("clicked", self.on_create_gpg_clicked)
        button_box.pack_start(create_button, True, True, 0)

        # Lista de claves
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        list_store = Gtk.ListStore(str, str, str)  # ID, Nombre, Fecha
        tree_view = Gtk.TreeView(model=list_store)
        
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(get_string('labels.id'), renderer, text=0)
        tree_view.append_column(column)
        
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(get_string('labels.name'), renderer, text=1) 
        tree_view.append_column(column)
        
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(get_string('labels.date'), renderer, text=2)
        tree_view.append_column(column)

        # Obtener y mostrar claves
        repo = RepoManager()
        keys = repo.select_gpg_key()
        for key in keys:
            list_store.append([key['id'], key['name'], key['date']])
            
        scroll.add(tree_view)
        box.pack_start(scroll, True, True, 0)

        # Botón eliminar
        delete_button = Gtk.Button(label=get_string('buttons.delete_gpg_key'))
        delete_button.connect("clicked", self.on_delete_gpg_clicked, tree_view)
        button_box.pack_start(delete_button, True, True, 0)
        
        box.show_all()
        
        response = dialog.run()
        selected_key = None
        
        if response == Gtk.ResponseType.OK:
            selection = tree_view.get_selection()
            model, iter = selection.get_selected()
            if iter:
                selected_key = model[iter][0]
                
        dialog.destroy()
        return selected_key

    def on_delete_gpg_clicked(self, button, tree_view):
        """Manejador para eliminar clave GPG"""
        selection = tree_view.get_selection()
        model, iter = selection.get_selected()
        if not iter:
            self.show_error(get_string('messages.select_gpg_key_delete'))
            return
            
        key_id = model[iter][0]
        name = model[iter][1]
        
        if self.show_confirm(get_string('messages.confirm_delete_gpg').format(name, key_id)):
            success, msg = self.repo.delete_gpg_key(key_id)
            if success:
                model.remove(iter)
                self.show_success(get_string('messages.gpg_deleted'))
            else:
                self.show_error(get_string('messages.gpg_delete_error').format(msg))

    def on_create_gpg_clicked(self, button):
        """Manejador para crear nueva clave GPG"""
        # Obtener el TreeView del diálogo padre antes de crear el nuevo diálogo
        parent_dialog = button.get_toplevel()
        parent_content = parent_dialog.get_content_area()
        gpg_tree_view = None
        for child in parent_content.get_children():
            if isinstance(child, Gtk.ScrolledWindow):
                gpg_tree_view = child.get_child()
                break

        dialog = Gtk.Dialog(
            title=get_string('dialogs.create_gpg'),
            parent=self,
            flags=0,
            buttons=(
                get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
                get_string('buttons.create'), Gtk.ResponseType.OK
            )
        )
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)

        # Campos para la nueva clave
        name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        name_label = Gtk.Label(label=get_string('labels.name'))
        name_entry = Gtk.Entry()
        name_box.pack_start(name_label, False, False, 0)
        name_box.pack_start(name_entry, True, True, 0)

        email_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        email_label = Gtk.Label(label=get_string('labels.email'))
        email_entry = Gtk.Entry()
        email_box.pack_start(email_label, False, False, 0)
        email_box.pack_start(email_entry, True, True, 0)

        box.pack_start(name_box, False, False, 0)
        box.pack_start(email_box, False, False, 0)
        box.show_all()

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            name = name_entry.get_text()
            email = email_entry.get_text()
            
            if name and email:
                success, key_id = self.repo.create_gpg_key(name, email)
                if success:
                    dialog.destroy()
                    self.show_success(get_string('messages.gpg_created').format(key_id))
                    
                    # Actualizar el TreeView si lo encontramos
                    if gpg_tree_view and isinstance(gpg_tree_view, Gtk.TreeView):
                        list_store = gpg_tree_view.get_model()
                        list_store.clear()
                        # Recargar las claves
                        keys = self.repo.select_gpg_key()
                        for key in keys:
                            list_store.append([key['id'], key['name'], key['date']])
                    
                    return key_id
                else:
                    self.show_error(get_string('messages.gpg_create_error').format(key_id))
            else:
                self.show_error(get_string('messages.gpg_name_email_required'))
                
        dialog.destroy()
        return None

    def create_ui(self):
        """Inicializa la interfaz de usuario"""
        # Agregar soporte para atajos de teclado
        self.accel_group = Gtk.AccelGroup()
        self.add_accel_group(self.accel_group)

        # Layout principal con márgenes
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        main_box.set_margin_start(16)
        main_box.set_margin_end(16)
        main_box.set_margin_top(16)
        main_box.set_margin_bottom(16)
        self.add(main_box)

        # Selector de idioma en la parte superior (corregido)
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        lang_box.set_halign(Gtk.Align.END)
        self.lang_label = Gtk.Label(label=get_string('labels.language'))
        self.lang_combo = Gtk.ComboBoxText()
        
        # Añadir idiomas disponibles
        for lang_code in locale_manager.get_available_languages():
            lang_name = locale_manager.get_language_name(lang_code)
            self.lang_combo.append(lang_code, lang_name)
            
        # Seleccionar idioma actual
        self.lang_combo.set_active_id(locale_manager.current_lang)
        self.lang_combo.connect('changed', self.on_language_changed)
        
        lang_box.pack_start(self.lang_label, False, False, 0)
        lang_box.pack_start(self.lang_combo, False, False, 0)
        main_box.pack_start(lang_box, False, False, 0)

        # Atajos para selector de idiomas
        self.lang_combo.add_accelerator("grab_focus", self.accel_group,
            ord('L'), Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)

        # Header común con título y botones de configuración
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        main_box.pack_start(header, False, False, 0)

        # Título principal con logo
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        
        # Añadir logo - Usando rutas relativas para mayor flexibilidad
        # Intentar varias ubicaciones posibles para el logo
        icon_found = False
        possible_paths = [
            os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "assets/icons/soplos-logo.png"),
            "/usr/share/soplos-repo-manager/assets/icons/soplos-logo.png",
            "/usr/local/bin/soplos-repo-manager/assets/icons/soplos-logo.png",
            "/soplos-repo-manager/assets/icons/soplos-logo.png"
        ]
        
        for icon_path in possible_paths:
            if (os.path.exists(icon_path)):
                try:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        icon_path,
                        32, 32,  # width x height
                        True     # preserve aspect ratio
                    )
                    logo = Gtk.Image.new_from_pixbuf(pixbuf)
                    title_box.pack_start(logo, False, False, 0)
                    icon_found = True
                    self.logger.info(f"Logo cargado desde: {icon_path}")
                    break
                except Exception as e:
                    self.logger.warning(get_string('errors.load_icon').format(str(e)))
        
        if not icon_found:
            self.logger.warning("No se pudo encontrar el logo en ninguna ubicación")
        
        # Título - Cambiar para usar la clave correcta
        title = Gtk.Label()
        title.set_markup('<span size="x-large" weight="bold">' + get_string('ui_elements.window_title') + '</span>')
        title.set_halign(Gtk.Align.START)
        title_box.pack_start(title, True, True, 0)
        
        # Guardar referencia al label del título para poder actualizarlo
        self.title_label = title

        header.pack_start(title_box, True, True, 0)

        # Añadir selector de perfiles al header
        profile_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.profile_label = Gtk.Label(label=get_string('labels.profile'))
        self.profile_combo = Gtk.ComboBoxText()
        self.profile_handler_id = self.profile_combo.connect('changed', self.on_profile_changed)
        
        # Cargar y seleccionar el perfil activo
        self.update_profile_combo()
        
        profile_box.pack_start(self.profile_label, False, False, 0)
        profile_box.pack_start(self.profile_combo, True, True, 0)

        # Botones de gestión de perfiles
        add_profile = Gtk.Button.new_from_icon_name("list-add-symbolic", Gtk.IconSize.BUTTON)
        add_profile.connect('clicked', self.on_add_profile)
        del_profile = Gtk.Button.new_from_icon_name("list-remove-symbolic", Gtk.IconSize.BUTTON)
        del_profile.connect('clicked', self.on_del_profile)
        
        profile_box.pack_start(add_profile, False, False, 0)
        profile_box.pack_start(del_profile, False, False, 0)
        
        # Insertar antes de los botones de configuración
        header.pack_start(profile_box, False, False, 0)
        
        # Cargar perfiles existentes
        self.refresh_profiles()

        # Botones de configuración (corregidos)
        self.gpg_button = Gtk.Button()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        icon = Gtk.Image.new_from_icon_name("dialog-password-symbolic", Gtk.IconSize.BUTTON)
        box.pack_start(icon, False, False, 0) 
        label = Gtk.Label()
        label.set_text(get_string('buttons.gpg'))  # Usar get_string aquí
        label.set_use_underline(True)
        box.pack_start(label, False, False, 0)
        self.gpg_button.add(box)
        self.gpg_button.connect('clicked', self.on_gpg_clicked)
        header.pack_start(self.gpg_button, False, False, 0)

        self.repo_button = Gtk.Button()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        icon = Gtk.Image.new_from_icon_name("folder-remote-symbolic", Gtk.IconSize.BUTTON)
        box.pack_start(icon, False, False, 0)
        label = Gtk.Label(get_string('buttons.repo'))
        label.set_use_underline(True)
        box.pack_start(label, False, False, 0)
        self.repo_button.add(box)
        self.repo_button.connect('clicked', self.on_repo_clicked)
        self.repo_button.add_accelerator("clicked", self.accel_group,
            ord('R'), Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        self.repo_button.get_child().get_children()[1].set_text("_Repositorio")
        self.repo_button.get_child().get_children()[1].set_use_underline(True)
        header.pack_start(self.repo_button, False, False, 0)

        # Crear notebook para pestañas
        self.notebook = Gtk.Notebook()
        main_box.pack_start(self.notebook, True, True, 0)

        # Crear páginas
        upload_page = self._create_upload_page()
        manage_page = self._create_manage_page()
        
        # Usar los nuevos strings para las pestañas
        self.notebook.append_page(upload_page, Gtk.Label(label=get_string('ui_elements.tabs.upload')))
        self.notebook.append_page(manage_page, Gtk.Label(label=get_string('ui_elements.tabs.manage')))

        # Reemplazar los aceleradores del notebook por signals de teclado
        self.notebook.connect('key-press-event', self._on_notebook_key_press)

        # Conectar señal switch-page para actualizar contenido
        self.notebook.connect('switch-page', self.on_switch_page)

        # Panel inferior común con barra de progreso y botones
        bottom_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        main_box.pack_start(bottom_box, False, False, 0)

        # Status label común
        self.status_label = Gtk.Label()
        self.status_label.set_text("")
        self.status_label.set_halign(Gtk.Align.START)
        bottom_box.pack_start(self.status_label, False, False, 0)

        # Barra de progreso común
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(True)
        bottom_box.pack_start(self.progress_bar, True, True, 0)

        # Botón generar script común
        self.gen_script_button = Gtk.Button()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        icon = Gtk.Image.new_from_icon_name("text-x-script-symbolic", Gtk.IconSize.BUTTON)
        box.pack_start(icon, False, False, 0)
        label = Gtk.Label(get_string('buttons.script'))
        label.set_use_underline(True)
        box.pack_start(label, False, False, 0)
        self.gen_script_button.add(box)
        self.gen_script_button.connect('clicked', self.on_gen_script_clicked)
        accel = Gtk.accelerator_parse("<Control>s")
        self.gen_script_button.add_accelerator("clicked", self.accel_group,
            accel[0], accel[1], Gtk.AccelFlags.VISIBLE)
        bottom_box.pack_start(self.gen_script_button, False, False, 0)

        # Botón de salir común
        self.exit_button = Gtk.Button()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        icon = Gtk.Image.new_from_icon_name("application-exit-symbolic", Gtk.IconSize.BUTTON)
        box.pack_start(icon, False, False, 0)
        label = Gtk.Label(get_string('buttons.exit'))
        label.set_use_underline(True)
        box.pack_start(label, False, False, 0)
        self.exit_button.add(box)
        self.exit_button.connect('clicked', self.on_exit_clicked)
        accel = Gtk.accelerator_parse("<Control>q")
        self.exit_button.add_accelerator("clicked", self.accel_group,
            accel[0], accel[1], Gtk.AccelFlags.VISIBLE)
        bottom_box.pack_start(self.exit_button, False, False, 0)

        # Añadir handler para Enter en cajas de texto
        def on_entry_activate(entry, dialog):
            dialog.response(Gtk.ResponseType.OK)
        
        for entry in self.get_entries():
            entry.connect("activate", on_entry_activate, entry.get_toplevel())

        # Conectar señal key-press-event para atajos globales
        self.connect('key-press-event', self._on_main_key_press)

    def _on_notebook_key_press(self, widget, event):
        """Maneja las teclas para cambiar de pestaña"""
        keyval = event.keyval
        state = event.state & Gtk.accelerator_get_default_mod_mask()

        if state == Gdk.ModifierType.MOD1_MASK: # Alt
            if keyval == Gdk.KEY_Page_Down:
                self.notebook.next_page()
                return True
            elif keyval == Gdk.KEY_Page_Up:
                self.notebook.prev_page() 
                return True
        return False

    def _on_main_key_press(self, widget, event):
        """Maneja los atajos de teclado globales"""
        keyval = event.keyval
        state = event.state & Gtk.accelerator_get_default_mod_mask()

        if state == Gdk.ModifierType.CONTROL_MASK:
            if keyval == Gdk.KEY_r:
                self.on_refresh_packages(None)
                return True
            elif keyval == Gdk.KEY_s:
                self.on_gen_script_clicked(None)
                return True
            elif keyval == Gdk.KEY_q:
                self.on_exit_clicked(None)
                return True
        return False

    def get_entries(self):
        """Obtiene todas las cajas de texto de la ventana"""
        entries = []
        def find_entries(widget):
            if isinstance(widget, Gtk.Entry):
                entries.append(widget)
            elif isinstance(widget, Gtk.Container):
                widget.foreach(find_entries)
        self.foreach(find_entries)
        return entries

    def update_profile_combo(self):
        """Actualiza el ComboBox de perfiles y selecciona el activo"""
        # Limpiar ComboBox
        self.profile_combo.remove_all()
        
        # Obtener perfiles y perfil activo
        profiles = self.repo.profile_manager.list_profiles()
        current_profile = self.repo.current_profile
        
        # Añadir perfiles al combo
        for profile in profiles:
            self.profile_combo.append_text(profile)
        
        # Seleccionar el perfil activo o el primero disponible
        if current_profile and current_profile in profiles:
            index = profiles.index(current_profile)
            self.profile_combo.set_active(index)
        elif profiles:
            self.profile_combo.set_active(0)
            # Activar el primer perfil si no hay ninguno activo
            self.repo.current_profile = profiles[0]
            self.repo.profile_manager.set_current_profile(profiles[0])
            self.repo.load_profile(profiles[0])

    def refresh_profiles(self):
        """Actualiza la lista de perfiles disponibles"""
        active_profile = self.profile_combo.get_active_text()
        self.profile_combo.remove_all()
        
        for profile in self.repo.profile_manager.list_profiles():
            self.profile_combo.append_text(profile)
            
        if active_profile and active_profile in self.repo.profile_manager.list_profiles():
            self.profile_combo.set_active_id(active_profile)

    def on_profile_changed(self, combo):
        """Manejador del cambio de perfil"""
        profile_name = combo.get_active_text()
        if profile_name and profile_name != self.repo.current_profile:
            if self.repo.load_profile(profile_name):
                self.show_success(get_string('messages.profile_loaded').format(profile_name))
                # Limpiar lista de archivos pero mantener paquetes
                self.files_store.clear()
                # Solo actualizar UI
                self.refresh_file_list()
                # No limpiar packages_store aquí
                self.on_refresh_packages(None)
            else:
                self.show_error(get_string('messages.profile_load_error').format(profile_name))

    def on_add_profile(self, button):
        """Manejador para añadir nuevo perfil"""
        # Primero pedir el nombre del perfil
        profile_dialog = Gtk.Dialog(
            title=get_string('dialogs.new_profile'),
            parent=self,
            flags=0,
            buttons=(get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
                    get_string('buttons.save'), Gtk.ResponseType.OK)
        )
        
        profile_box = profile_dialog.get_content_area()
        profile_box.set_spacing(10)
        profile_box.set_margin_start(10)
        profile_box.set_margin_end(10)
        profile_box.set_margin_top(10)
        profile_box.set_margin_bottom(10)
        
        label = Gtk.Label(label=get_string('labels.profile_name'))
        entry = Gtk.Entry()
        
        profile_box.pack_start(label, False, False, 0)
        profile_box.pack_start(entry, False, False, 0)
        profile_box.show_all()
        
        response = profile_dialog.run()
        name = None
        if response == Gtk.ResponseType.OK:
            name = entry.get_text().strip()
        profile_dialog.destroy()

        # Si proporcionaron un nombre válido, mostrar el diálogo completo de configuración
        if name:
            # Guardar temporalmente el nombre para usarlo después
            temp_profile_name = name
            
            # Mostrar el diálogo completo de configuración del repositorio
            dialog = Gtk.Dialog(
                title=get_string('dialogs.config_repo'),
                parent=self,
                flags=0,
                buttons=(
                    get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
                    get_string('buttons.save'), Gtk.ResponseType.OK
                )
            )
            dialog.set_default_size(500, 300)
            
            box = dialog.get_content_area()
            box.set_spacing(10)
            box.set_margin_start(10)
            box.set_margin_end(10)
            box.set_margin_top(10)
            box.set_margin_bottom(10)

            # Añadir label con instrucciones
            info_label = Gtk.Label()
            info_label.set_markup(get_string('dialogs.repo_instructions'))
            info_label.set_line_wrap(True)
            info_label.set_justify(Gtk.Justification.LEFT)
            info_label.set_halign(Gtk.Align.START)
            box.pack_start(info_label, False, False, 10)

            # Separador
            box.pack_start(Gtk.Separator(), False, False, 10)

            # Añadir campos para título y nombre del archivo list
            title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            title_label = Gtk.Label(label=get_string('labels.repo_title'))
            title_entry = Gtk.Entry()
            title_entry.set_text("Repositorio APT")  # Texto neutro
            title_box.pack_start(title_label, False, False, 0)
            title_box.pack_start(title_entry, True, True, 0)

            list_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            list_label = Gtk.Label(label=get_string('labels.list_filename'))
            list_entry = Gtk.Entry()
            list_entry.set_text(f"{name}.list")  # Usar nombre del perfil para el archivo .list
            list_box.pack_start(list_label, False, False, 0)
            list_box.pack_start(list_entry, True, True, 0)

            # Campo de URL del repositorio
            url_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            url_label = Gtk.Label(label=get_string('labels.repo_url'))
            url_label.set_halign(Gtk.Align.START)
            url_entry = Gtk.Entry()
            url_entry.set_placeholder_text(get_string('placeholders.repo_url'))
            url_box.pack_start(url_label, False, False, 0)
            url_box.pack_start(url_entry, True, True, 0)
            
            # Campo de rama con nota informativa
            branch_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
            branch_input_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            branch_label = Gtk.Label(label=get_string('labels.branch'))
            branch_label.set_halign(Gtk.Align.START)
            branch_entry = Gtk.Entry()
            branch_entry.set_text('main')
            branch_input_box.pack_start(branch_label, False, False, 0)
            branch_input_box.pack_start(branch_entry, True, True, 0)
            
            # Nota sobre la rama
            branch_note = Gtk.Label()
            branch_note.set_markup(get_string('notes.branch'))
            branch_note.set_halign(Gtk.Align.START)
            branch_note.set_line_wrap(True)
            
            branch_box.pack_start(branch_input_box, False, False, 0)
            branch_box.pack_start(branch_note, False, False, 0)

            # Campo de token
            token_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            token_label = Gtk.Label(label=get_string('labels.token'))
            token_label.set_halign(Gtk.Align.START)
            token_entry = Gtk.Entry()
            token_entry.set_visibility(False)  # Ocultar el token
            token_entry.set_placeholder_text(get_string('placeholders.token'))
            token_box.pack_start(token_label, False, False, 0)
            token_box.pack_start(token_entry, True, True, 0)

            # Añadir todos los campos al diálogo en el orden correcto
            box.pack_start(title_box, False, False, 0)
            box.pack_start(list_box, False, False, 0)
            box.pack_start(url_box, False, False, 0)
            box.pack_start(branch_box, False, False, 0)
            box.pack_start(token_box, False, False, 0)
            
            box.show_all()
            
            # Conectar Enter para enviar el formulario
            def on_entry_activate(entry):
                dialog.response(Gtk.ResponseType.OK)
            
            url_entry.connect("activate", on_entry_activate)
            branch_entry.connect("activate", on_entry_activate)
            token_entry.connect("activate", on_entry_activate)
            title_entry.connect("activate", on_entry_activate)
            list_entry.connect("activate", on_entry_activate)
            
            response = dialog.run()
            if response == Gtk.ResponseType.OK:
                try:
                    new_url = url_entry.get_text()
                    new_branch = branch_entry.get_text()
                    new_token = token_entry.get_text()
                    new_title = title_entry.get_text()
                    new_list = list_entry.get_text()
                    
                    if new_url and new_token:
                        # Actualizar configuración del repositorio
                        success = self.repo.configure_repository(
                            git_url=new_url,
                            branch=new_branch,
                            token=new_token,
                            title=new_title,
                            list_name=new_list
                        )
                        
                        if success:
                            # Solicitar información para el README
                            readme_info = self.repo.ask_readme_info(parent_window=self)
                            if readme_info:
                                self.repo.readme_title = readme_info.get('title', 'Repositorio APT')
                                self.repo.repo_description = readme_info.get('description', 'Repositorio de paquetes APT')
                                # Actualizar el README con la nueva información
                                self.repo._ensure_readme()
                            
                            # Guardar el perfil con el nombre proporcionado anteriormente
                            if self.repo.save_current_profile(temp_profile_name):
                                self.refresh_profiles()
                                self.profile_combo.set_active_id(temp_profile_name)
                                self.show_success(get_string('messages.profile_saved'))
                            else:
                                self.show_error(get_string('messages.profile_save_error'))
                        else:
                            self.show_error(get_string('messages.repo_config_error'))
                    else:
                        self.show_error(get_string('messages.config_repo_first'))
                except Exception as e:
                    self.show_error(str(e))
                    
            dialog.destroy()

    def on_del_profile(self, button):
        """Manejador para eliminar perfil"""
        profile_name = self.profile_combo.get_active_text()
        if profile_name:
            if self.show_confirm(get_string('messages.confirm_delete_profile').format(profile_name)):
                if self.repo.profile_manager.delete_profile(profile_name):
                    self.refresh_profiles()
                    self.show_success(get_string('messages.profile_deleted').format(profile_name))
                else:
                    self.show_error(get_string('messages.profile_delete_error').format(profile_name))

    def _create_upload_page(self):
        """Crea la página de subida de paquetes"""
        upload_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        upload_page.set_margin_start(16)
        upload_page.set_margin_end(16)
        upload_page.set_margin_top(16)
        upload_page.set_margin_bottom(16)

        # Encabezado con botones
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        upload_page.pack_start(header, False, False, 0)

        # Botones principales en el header
        self.add_button = Gtk.Button()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        icon = Gtk.Image.new_from_icon_name("list-add-symbolic", Gtk.IconSize.BUTTON)
        box.pack_start(icon, False, False, 0)
        label = Gtk.Label()
        label.set_text("_" + get_string('buttons.add_file'))  # Añadir guión bajo aquí
        label.set_use_underline(True)
        box.pack_start(label, False, False, 0)
        self.add_button.add(box)
        self.add_button.get_style_context().add_class("suggested-action")
        self.add_button.connect('clicked', self.on_add_clicked)
        self.add_button.add_accelerator("clicked", self.accel_group,
            ord('A'), Gdk.ModifierType.CONTROL_MASK, Gtk.AccelFlags.VISIBLE)
        header.pack_start(self.add_button, False, False, 0)

        # Lista de archivos con marco - Mejoramos el borde para hacerlo más visible
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.ETCHED_OUT)  # Tipo de sombra más visible
        frame.set_border_width(4)  # Borde más grueso
        # Añadimos margen exterior al frame para separarlo de los botones
        frame.set_margin_top(8)
        frame.set_margin_bottom(8)
        upload_page.pack_start(frame, True, True, 0)

        # Create files_box
        files_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        files_box.set_margin_start(16)
        files_box.set_margin_end(16)
        files_box.set_margin_top(16)
        files_box.set_margin_bottom(16)
        frame.add(files_box)

        # Lista de archivos mejorada
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.set_shadow_type(Gtk.ShadowType.IN)  # Añadir sombra interna al ScrolledWindow
        files_box.pack_start(scroll, True, True, 0)

        # Modificar el modelo para incluir más información:
        # índices: 0:ruta, 1:nombre, 2:tamaño, 3:fecha, 4:estado, 5:version, 6:arquitectura, 7:sección, 8:descripción
        self.files_view = Gtk.TreeView(model=self.files_store)
        self.files_view.set_headers_visible(True)
        self.files_view.get_style_context().add_class("files-list")
        
        # Configurar ordenamiento de columnas
        self.files_store.set_sort_func(1, self._sort_text_column, 1)  # Nombre
        self.files_store.set_sort_func(2, self._sort_size_column, 2)  # Tamaño
        self.files_store.set_sort_func(3, self._sort_date_column, 3)  # Fecha
        self.files_store.set_sort_func(4, self._sort_text_column, 4)  # Estado
        self.files_store.set_sort_func(5, self._sort_version_column, 5)  # Versión
        self.files_store.set_sort_func(6, self._sort_text_column, 6)  # Arquitectura
        self.files_store.set_sort_func(7, self._sort_text_column, 7)  # Sección
        self.files_store.set_sort_func(8, self._sort_text_column, 8)  # Descripción

        # Columnas mejoradas con las mismas que en la pestaña de gestión
        columns = [
            (get_string('labels.tree_columns.pkg_name'), 1, False),
            (get_string('labels.tree_columns.pkg_version'), 5, False),
            (get_string('labels.tree_columns.pkg_arch'), 6, False),
            (get_string('labels.tree_columns.pkg_section'), 7, False),
            (get_string('labels.columns.size'), 2, False),
            (get_string('labels.columns.date'), 3, False),
            (get_string('labels.columns.status'), 4, False),
            (get_string('labels.tree_columns.pkg_description'), 8, False)
        ]

        for i, (title, col_id, is_toggle) in enumerate(columns):
            if is_toggle:
                renderer = Gtk.CellRendererToggle()
                renderer.set_property('activatable', False)
                column = Gtk.TreeViewColumn(title, renderer, active=col_id)
            else:
                renderer = Gtk.CellRendererText()
                # Añadir un poco de padding a las celdas
                renderer.set_property('xpad', 6)
                renderer.set_property('ypad', 4)
                # Para la descripción, permitir múltiples líneas y limitar el ancho
                if col_id == 8:  # Descripción
                    renderer.set_property('wrap-width', 250)
                    renderer.set_property('wrap-mode', Pango.WrapMode.WORD_CHAR)
                column = Gtk.TreeViewColumn(title, renderer, text=col_id)
            column.set_resizable(True)
            # Hacer que las columnas tengan un tamaño mínimo razonable
            column.set_min_width(80)
            # Establecer anchos específicos para algunas columnas
            if col_id == 8:  # Descripción
                column.set_min_width(200)
                column.set_expand(True)
            elif col_id in [5, 6, 7]:  # Versión, Arquitectura, Sección
                column.set_min_width(100)
            # Activar ordenamiento de columnas
            column.set_sort_column_id(col_id)
            column.set_clickable(True)
            self.files_view.append_column(column)

        scroll.add(self.files_view)

        # Panel inferior con barra de progreso y botones
        bottom_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        upload_page.pack_start(bottom_box, False, False, 0)

        # Botón de subir 
        self.upload_button = Gtk.Button()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        icon = Gtk.Image.new_from_icon_name("document-send-symbolic", Gtk.IconSize.BUTTON)
        box.pack_start(icon, False, False, 0)
        label = Gtk.Label(get_string('buttons.upload'))
        box.pack_start(label, False, False, 0)
        self.upload_button.add(box)
        self.upload_button.get_style_context().add_class("suggested-action")
        self.upload_button.connect('clicked', self.on_upload_clicked)
        self.upload_button.add_accelerator("clicked", self.accel_group,
            ord('U'), Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        bottom_box.pack_start(self.upload_button, False, False, 0)

        return upload_page

    def _create_manage_page(self):
        """Crea la página de gestión de paquetes"""
        manage_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        manage_page.set_margin_start(16)
        manage_page.set_margin_end(16)
        manage_page.set_margin_top(16)
        manage_page.set_margin_bottom(16)

        # Barra de herramientas
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        manage_page.pack_start(toolbar, False, False, 0)

        # Lista de paquetes instalados - Mejoramos el frame para que sea consistente
        packages_frame = Gtk.Frame(label=get_string('labels.packages_in_repo'))
        packages_frame.set_shadow_type(Gtk.ShadowType.ETCHED_OUT)  # Tipo de sombra consistente
        packages_frame.set_border_width(4)  # Borde más grueso
        # Añadir margen exterior para separarlo de otros elementos
        packages_frame.set_margin_top(8)
        packages_frame.set_margin_bottom(8)
        manage_page.pack_start(packages_frame, True, True, 0)

        packages_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        packages_box.set_margin_start(16)  # Aumentado margen interno
        packages_box.set_margin_end(16)    # Aumentado margen interno
        packages_box.set_margin_top(16)    # Aumentado margen interno
        packages_box.set_margin_bottom(16) # Aumentado margen interno
        packages_frame.add(packages_box)

        # Store para paquetes: ampliado para incluir tamaño, fecha y estado
        self.packages_store = Gtk.ListStore(str, str, str, str, str, str, str, str)
        
        # Configurar ordenamiento de columnas
        self.packages_store.set_sort_func(0, self._sort_text_column, 0)    # Nombre
        self.packages_store.set_sort_func(1, self._sort_version_column, 1) # Versión
        self.packages_store.set_sort_func(2, self._sort_text_column, 2)    # Arquitectura
        self.packages_store.set_sort_func(3, self._sort_text_column, 3)    # Sección
        self.packages_store.set_sort_func(4, self._sort_text_column, 4)    # Descripción
        self.packages_store.set_sort_func(5, self._sort_size_column, 5)    # Tamaño
        self.packages_store.set_sort_func(6, self._sort_date_column, 6)    # Fecha
        self.packages_store.set_sort_func(7, self._sort_text_column, 7)    # Estado
        
        packages_scroll = Gtk.ScrolledWindow()
        packages_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        packages_scroll.set_shadow_type(Gtk.ShadowType.IN)  # Añadir sombra interna
        packages_box.pack_start(packages_scroll, True, True, 0)

        self.packages_view = Gtk.TreeView(model=self.packages_store)
        self.packages_view.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
        packages_scroll.add(self.packages_view)

        columns = [
            (get_string('labels.tree_columns.pkg_name'), 0),
            (get_string('labels.tree_columns.pkg_version'), 1),
            (get_string('labels.tree_columns.pkg_arch'), 2),
            (get_string('labels.tree_columns.pkg_section'), 3),
            (get_string('labels.tree_columns.pkg_description'), 4),
            (get_string('labels.columns.size'), 5),
            (get_string('labels.columns.date'), 6),
            (get_string('labels.columns.status'), 7)
        ]

        for i, (title, col_id) in enumerate(columns):
            renderer = Gtk.CellRendererText()
            # Añadir padding para mejor legibilidad
            renderer.set_property('xpad', 6)
            renderer.set_property('ypad', 4)
            # Para la descripción, permitir múltiples líneas y limitar el ancho
            if col_id == 4:  # Descripción
                renderer.set_property('wrap-width', 250)
                renderer.set_property('wrap-mode', Pango.WrapMode.WORD_CHAR)
            column = Gtk.TreeViewColumn(title, renderer, text=col_id)
            column.set_resizable(True)
            # Establecer anchos específicos para algunas columnas
            if col_id == 0:  # Nombre
                column.set_min_width(150)
            elif col_id == 4:  # Descripción
                column.set_min_width(200)
                column.set_expand(True)
            else:
                column.set_min_width(100)
            # Activar ordenamiento
            column.set_sort_column_id(col_id)
            column.set_clickable(True)
            self.packages_view.append_column(column)

        # Botones de acción (corregidos sin guiones bajos)
        action_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        manage_page.pack_start(action_box, False, False, 0)

        # Crear los botones y almacenarlos como atributos
        self.refresh_button = self._create_button(
            "view-refresh-symbolic",
            'buttons.refresh',
            self.on_refresh_packages
        )
        accel = Gtk.accelerator_parse("<Control>r")
        self.refresh_button.add_accelerator("clicked", self.accel_group,
            accel[0], accel[1], Gtk.AccelFlags.VISIBLE)
        action_box.pack_start(self.refresh_button, False, False, 0)

        self.remove_button = self._create_button(
            "edit-delete-symbolic",
            'buttons.remove',
            self.on_remove_package
        )
        self.remove_button.add_accelerator("clicked", self.accel_group,
            ord('D'), Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        action_box.pack_start(self.remove_button, False, False, 0)

        self.view_button = self._create_button(
            "document-properties-symbolic",
            'buttons.view',
            self.on_view_package
        )
        self.view_button.add_accelerator("clicked", self.accel_group,
            ord('V'), Gdk.ModifierType.MOD1_MASK, Gtk.AccelFlags.VISIBLE)
        action_box.pack_start(self.view_button, False, False, 0)

        # Añadir botón de limpiar repositorio
        clean_button = Gtk.Button(label="Limpiar Repositorio")
        clean_button.connect("clicked", self._on_clean_repo_clicked)
        action_box.pack_start(clean_button, False, False, 0)

        return manage_page
    
    # Funciones de ordenamiento personalizadas
    def _sort_text_column(self, model, iter1, iter2, column):
        """Ordena textos de forma natural."""
        value1 = model.get_value(iter1, column) or ""
        value2 = model.get_value(iter2, column) or ""
        return self._natural_sort_compare(value1, value2)
        
    def _sort_size_column(self, model, iter1, iter2, column):
        """Ordena tamaños de archivo correctamente (KB, MB, etc.)."""
        size1 = model.get_value(iter1, column) or ""
        size2 = model.get_value(iter2, column) or ""
        
        # Convertir a bytes para comparación
        def size_to_bytes(size_str):
            try:
                if not size_str:
                    return 0
                parts = size_str.split()
                if len(parts) != 2:
                    return 0
                value = float(parts[0])
                unit = parts[1].upper()
                
                if unit == 'B':
                    return value
                elif unit == 'KB':
                    return value * 1024
                elif unit == 'MB':
                    return value * 1024 * 1024
                elif unit == 'GB':
                    return value * 1024 * 1024 * 1024
                elif unit == 'TB':
                    return value * 1024 * 1024 * 1024 * 1024
                return 0
            except:
                return 0
                
        return size_to_bytes(size1) - size_to_bytes(size2)
    
    def _sort_date_column(self, model, iter1, iter2, column):
        """Ordena fechas en formato YYYY-MM-DD HH:MM."""
        date1 = model.get_value(iter1, column) or ""
        date2 = model.get_value(iter2, column) or ""
        
        # Convertir a timestamp para comparación
        from datetime import datetime
        try:
            if not date1:
                dt1 = datetime.min
            else:
                dt1 = datetime.strptime(date1, '%Y-%m-%d %H:%M')
                
            if not date2:
                dt2 = datetime.min
            else:
                dt2 = datetime.strptime(date2, '%Y-%m-%d %H:%M')
                
            if dt1 < dt2:
                return -1
            elif dt1 > dt2:
                return 1
            return 0
        except:
            # Si hay error en el formato, comparar como texto
            return (date1 > date2) - (date1 < date2)
    
    def _sort_version_column(self, model, iter1, iter2, column):
        """Ordena versiones de paquetes correctamente."""
        ver1 = model.get_value(iter1, column) or ""
        ver2 = model.get_value(iter2, column) or ""
        
        # Usamos apt_pkg para comparar versiones si está disponible
        try:
            import apt_pkg
            apt_pkg.init()
            return apt_pkg.version_compare(ver1, ver2)
        except:
            # Comparación simple como fallback
            return self._natural_sort_compare(ver1, ver2)
    
    def _natural_sort_compare(self, s1, s2):
        """Ordenamiento natural que maneja correctamente números en texto."""
        import re
        def convert(text):
            return int(text) if text.isdigit() else text.lower()
        def alphanum_key(key):
            return [convert(c) for c in re.split('([0-9]+)', key)]
        return (alphanum_key(s1) > alphanum_key(s2)) - (alphanum_key(s1) < alphanum_key(s2))

    def on_refresh_packages(self, button):
        """Actualiza la lista de paquetes del perfil actual"""
        self.packages_store.clear()
        try:
            if not hasattr(self.repo, 'repo_dir') or not self.repo.repo_dir:
                return
                
            packages = self.repo.list_packages()
            if packages:
                for pkg in packages:
                    # Obtener valores o usar valores por defecto para las columnas adicionales
                    size = pkg.get('size', 'Desconocido')
                    date = pkg.get('date', 'Desconocido')
                    status = pkg.get('status', 'Instalado')
                    
                    self.packages_store.append([
                        pkg['name'],
                        pkg['version'],
                        pkg['arch'],
                        pkg['section'],
                        pkg['description'],
                        size,                # Tamaño
                        date,                # Fecha
                        status               # Estado
                    ])
                    
                # Solo mostrar mensaje si fue una actualización manual
                if button is not None:  
                    self.show_success(get_string('messages.packages_found').format(len(packages)))
                    
        except Exception as e:
            # Solo mostrar error si fue una actualización manual
            if button is not None:
                self.show_error(get_string('messages.error_loading_packages').format(str(e)))

    def show_info(self, message):
        """Muestra un diálogo informativo"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=get_string('dialogs.info')
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def on_remove_package(self, button):
        """Elimina los paquetes seleccionados"""
        selection = self.packages_view.get_selection()
        model, paths = selection.get_selected_rows()
        
        if not paths:
            self.show_error(get_string('messages.select_package_delete'))
            return
            
        pkg_names = [model[path][0] for path in paths]
        if not self.show_confirm(get_string('messages.confirm_delete_packages').format(', '.join(pkg_names))):
            return
            
        self.progress_bar.set_fraction(0.0)
        total = len(pkg_names)
        
        for i, pkg_name in enumerate(pkg_names):
            # Actualizar progreso
            fraction = (i + 1) / total
            self.progress_bar.set_fraction(fraction)
            self.progress_bar.set_text(get_string('messages.deleting_package').format(pkg_name))
            self.status_label.set_text(get_string('messages.deleting_package_status').format(i+1, total))
            
            while Gtk.events_pending():
                Gtk.main_iteration()
            
            try:
                success, msg = self.repo.remove_package(pkg_name)
                if not success:
                    self.show_error(get_string('messages.error_deleting_package').format(pkg_name, msg))
                    break
            except Exception as e:
                self.show_error(get_string('messages.error_deleting_package').format(pkg_name, str(e)))
                break
        
        # Limpiar progreso
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text("")
        self.status_label.set_text("")
        
        # Actualizar lista
        self.on_refresh_packages(None)
        
        self.show_success(get_string('messages.packages_deleted'))

    def show_version_select_dialog(self, package_name, versions):
        """Muestra un diálogo para seleccionar la versión a eliminar"""
        dialog = Gtk.Dialog(
            title=get_string('dialogs.select_version').format(package_name),
            parent=self,
            flags=0,
            buttons=(
                get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
                get_string('buttons.delete'), Gtk.ResponseType.OK
            )
        )
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        
        label = Gtk.Label(label=get_string('labels.select_version'))
        box.pack_start(label, False, False, 0)
        
        # Lista de versiones
        list_store = Gtk.ListStore(str)
        for version in versions:
            list_store.append([version])
        
        tree_view = Gtk.TreeView(model=list_store)
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(get_string('labels.version'), renderer, text=0)
        tree_view.append_column(column)
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.add(tree_view)
        box.pack_start(scroll, True, True, 0)
        
        box.show_all()
        
        response = dialog.run()
        selected_version = None
        
        if response == Gtk.ResponseType.OK:
            selection = tree_view.get_selection()
            model, iter = selection.get_selected()
            if iter:
                selected_version = model[iter][0]
        
        dialog.destroy()
        return selected_version

    def on_view_package(self, button):
        """Muestra los detalles del paquete seleccionado"""
        selection = self.packages_view.get_selection()
        model, paths = selection.get_selected_rows()
        if not paths:
            self.show_error(get_string('messages.select_package_view'))
            return

        # Tomar solo el primer paquete seleccionado
        iter = model.get_iter(paths[0])
        pkg_name = model[iter][0]
        details = self.repo.get_package_details(pkg_name)
        
        dialog = Gtk.Dialog(
            title=get_string('dialogs.package_details').format(pkg_name),
            parent=self,
            flags=0
        )
        dialog.set_default_size(650, 500)  # Establecer dimensiones más adecuadas
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_start(16)
        box.set_margin_end(16)
        box.set_margin_top(16)
        box.set_margin_bottom(16)
        
        # Crear notebook para agrupar información
        notebook = Gtk.Notebook()
        box.pack_start(notebook, True, True, 0)
        
        # Página 1: Información general
        info_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        info_page.set_margin_top(10)
        info_page.set_margin_bottom(10)
        info_page.set_margin_start(10)
        info_page.set_margin_end(10)
        
        # Usar ScrolledWindow para manejar contenido grande
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        # Contenedor principal para organizar datos
        grid = Gtk.Grid()
        grid.set_column_spacing(12)
        grid.set_row_spacing(6)
        scroll.add(grid)
        info_page.pack_start(scroll, True, True, 0)
        
        # Campos importantes primero
        priority_fields = ['Nombre', 'Versión', 'Resumen', 'Desarrollador', 
                          'Arquitectura', 'Sección', 'Tamaño del archivo', 
                          'Tamaño instalado', 'Fecha de modificación']
        
        # Luego campos secundarios                  
        secondary_fields = ['Licencia', 'Página web', 'Categorías', 'Ruta del archivo',
                           'Informe de errores', 'Ayuda', 'Donaciones']
        
        # La descripción se mostrará en otra página
        exclude_fields = ['Descripción', 'Historial de versiones', 'Dependencias']
        
        # Organizar los campos
        all_fields = []
        
        # Primero añadir campos prioritarios si existen
        for field in priority_fields:
            if field in details:
                all_fields.append(field)
        
        # Luego añadir campos secundarios si existen
        for field in secondary_fields:
            if field in details:
                all_fields.append(field)
        
        # Finalmente cualquier otro campo que no esté en las listas anteriores ni excluido
        for field in details:
            if field not in priority_fields and field not in secondary_fields and field not in exclude_fields:
                all_fields.append(field)
        
        # Construir la interfaz
        row = 0
        for field in all_fields:
            # Crear etiqueta del campo
            label = Gtk.Label(label=f"{field}:")
            label.set_halign(Gtk.Align.START)
            
            # Dar énfasis a campos importantes
            if field in ['Nombre', 'Versión', 'Desarrollador']:
                label_text = f"<b>{field}:</b>"
                label.set_markup(label_text)
            
            # Crear valor del campo
            value = details.get(field, "")
            value_label = Gtk.Label(label=value)
            value_label.set_halign(Gtk.Align.START)
            value_label.set_line_wrap(True)
            value_label.set_selectable(True)  # Permitir seleccionar/copiar texto
            value_label.set_max_width_chars(60)
            
            # Si es una URL, hacerla clickeable
            if field in ['Página web', 'Informe de errores', 'Ayuda', 'Donaciones'] and value:
                value_label = Gtk.LinkButton(uri=value, label=value)
                value_label.set_halign(Gtk.Align.START)
            
            # Añadir a la cuadrícula
            grid.attach(label, 0, row, 1, 1)
            grid.attach(value_label, 1, row, 1, 1)
            row += 1
            
        # Añadir la página de información general
        notebook.append_page(info_page, Gtk.Label(label="Información General"))
        
        # Página 2: Descripción completa
        if 'Descripción' in details and details['Descripción']:
            desc_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            desc_page.set_margin_top(10)
            desc_page.set_margin_bottom(10)
            desc_page.set_margin_start(10)
            desc_page.set_margin_end(10)
            
            desc_scroll = Gtk.ScrolledWindow()
            desc_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            
            desc_view = Gtk.TextView()
            desc_view.set_wrap_mode(Gtk.WrapMode.WORD)
            desc_view.set_editable(False)
            desc_view.set_cursor_visible(False)
            
            desc_buffer = desc_view.get_buffer()
            desc_buffer.set_text(details['Descripción'])
            
            desc_scroll.add(desc_view)
            desc_page.pack_start(desc_scroll, True, True, 0)
            
            notebook.append_page(desc_page, Gtk.Label(label="Descripción"))
        
        # Página 3: Historial de versiones
        if 'Historial de versiones' in details and details['Historial de versiones']:
            hist_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            hist_page.set_margin_top(10)
            hist_page.set_margin_bottom(10)
            hist_page.set_margin_start(10)
            hist_page.set_margin_end(10)
            
            hist_scroll = Gtk.ScrolledWindow()
            hist_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            
            # Crear lista de versiones
            versions = details['Historial de versiones'].split('\n')
            version_store = Gtk.ListStore(str)
            for version in versions:
                version_store.append([version])
            
            version_view = Gtk.TreeView(model=version_store)
            version_view.set_headers_visible(True)
            
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn("Versión", renderer, text=0)
            version_view.append_column(column)
            
            hist_scroll.add(version_view)
            hist_page.pack_start(hist_scroll, True, True, 0)
            
            notebook.append_page(hist_page, Gtk.Label(label="Historial de versiones"))
        
        # Página 4: Dependencias
        if 'Dependencias' in details and details['Dependencias'] != 'Ninguna':
            deps_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            deps_page.set_margin_top(10)
            deps_page.set_margin_bottom(10)
            deps_page.set_margin_start(10)
            deps_page.set_margin_end(10)
            
            deps_scroll = Gtk.ScrolledWindow()
            deps_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            
            # Procesar dependencias
            deps = details['Dependencias']
            deps_list = deps.split(', ')
            deps_store = Gtk.ListStore(str, str)  # Paquete, versión
            
            for dep in deps_list:
                if '(' in dep:
                    pkg = dep.split(' (')[0]
                    ver = dep.split(' (')[1].rstrip(')')
                    deps_store.append([pkg, ver])
                else:
                    deps_store.append([dep, ""])
            
            deps_view = Gtk.TreeView(model=deps_store)
            deps_view.set_headers_visible(True)
            
            # Columna de paquete
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn("Paquete", renderer, text=0)
            deps_view.append_column(column)
            
            # Columna de versión
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn("Versión requerida", renderer, text=1)
            deps_view.append_column(column)
            
            deps_scroll.add(deps_view)
            deps_page.pack_start(deps_scroll, True, True, 0)
            
            notebook.append_page(deps_page, Gtk.Label(label="Dependencias"))

        # Botón cerrar en la parte inferior
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        button_box.set_halign(Gtk.Align.END)
        
        close_button = Gtk.Button(label=get_string('buttons.close'))
        close_button.connect('clicked', lambda w: dialog.response(Gtk.ResponseType.CLOSE))
        button_box.pack_end(close_button, False, False, 0)
        
        box.pack_end(button_box, False, False, 0)
        
        dialog.show_all()
        dialog.run()
        dialog.destroy()

    def on_add_clicked(self, button):
        """Manejador del botón añadir"""
        dialog = Gtk.FileChooserDialog(
            title=get_string('dialogs.select_files'),
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.set_modal(True)
        dialog.add_buttons(
            get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
            get_string('buttons.select'), Gtk.ResponseType.ACCEPT
        )
        
        # Configurar para selección múltiple y filtro .deb
        dialog.set_select_multiple(True)
        
        # Añadir solo el filtro .deb
        filter_deb = Gtk.FileFilter()
        filter_deb.set_name(get_string('ui_elements.file_filters.deb_packages'))
        filter_deb.add_pattern("*.deb")
        dialog.add_filter(filter_deb)
        
        # Establecer el filtro .deb como predeterminado
        dialog.set_filter(filter_deb)

        response = dialog.run()
        if response == Gtk.ResponseType.ACCEPT:
            # Procesar cada archivo inmediatamente al añadirlo
            for filepath in dialog.get_filenames():
                path = Path(filepath)
                stats = path.stat()
                size = self._format_size(stats.st_size)
                fecha = self._format_date(stats.st_mtime)
                
                # Extraer información adicional del paquete
                version, arquitectura, seccion, descripcion = self._extract_package_info(filepath)
                
                # Procesar el archivo inmediatamente
                success, msg = self.repo.add_package(str(path))
                if success:
                    estado = get_string('package_states.processed')
                else:
                    estado = get_string('package_states.error')
                    self.show_error(msg)
                    
                # Añadir a la lista con toda la información
                self.files_store.append([
                    str(path),             # 0: ruta
                    path.name,             # 1: nombre 
                    size,                  # 2: tamaño
                    fecha,                 # 3: fecha
                    estado,                # 4: estado
                    version,               # 5: versión
                    arquitectura,          # 6: arquitectura
                    seccion,               # 7: sección
                    descripcion            # 8: descripción
                ])
                
                # Actualizar la interfaz
                while Gtk.events_pending():
                    Gtk.main_iteration()
                    
            # Actualizar la lista de paquetes instalados
            self.on_refresh_packages(None)
                
        dialog.destroy()
        
    def _extract_package_info(self, filepath):
        """Extrae información detallada del paquete .deb"""
        try:
            # Usar dpkg-deb para obtener la información del paquete
            result = subprocess.run(
                ['dpkg-deb', '-f', filepath, 'Version', 'Architecture', 'Section', 'Description'],
                capture_output=True,
                text=True,
                check=True
            )
            
            # Dividir la salida por líneas
            lines = result.stdout.strip().split('\n')
            
            # Valores por defecto
            version = "desconocida"
            arquitectura = "all"
            seccion = "desconocida"
            descripcion = "Sin descripción"
            
            # Procesar la salida
            for i, line in enumerate(lines):
                if i == 0:
                    version = line.strip() or version
                elif i == 1:
                    arquitectura = line.strip() or arquitectura
                elif i == 2:
                    seccion = line.strip() or seccion
                else:
                    # El resto es descripción (puede ser multilínea)
                    if line.strip():
                        if descripcion == "Sin descripción":
                            descripcion = line.strip()
                        else:
                            descripcion += " " + line.strip()
            
            # Limitar longitud de la descripción
            if len(descripcion) > 200:
                descripcion = descripcion[:197] + "..."
                
            return version, arquitectura, seccion, descripcion
            
        except Exception as e:
            self.logger.error(f"Error extrayendo información del paquete: {e}")
            return "desconocida", "all", "desconocida", "Error al leer información"

    def _format_size(self, size):
        """Formatea el tamaño del archivo"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"

    def _format_date(self, timestamp):
        """Formatea la fecha del archivo"""
        from datetime import datetime
        return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M')

    def _check_package_status(self, filepath):
        """Verifica el estado del paquete en el repositorio"""
        try:
            # Obtener nombre y versión del paquete
            result = subprocess.run(
                ['dpkg-deb', '-f', filepath, 'Package Version'],
                capture_output=True,
                text=True,
                check=True
            )
            pkg_info = result.stdout.strip().split('\n')
            pkg_name = pkg_info[0]
            
            estados = []
            
            # Verificar en pool local
            pool_dir = os.path.join(self.repo.repo_dir, "pool/main")
            if os.path.exists(pool_dir):
                for root, _, files in os.walk(pool_dir):
                    if any(f.startswith(f"{pkg_name}_") for f in files):
                        estados.append(get_string('package_states.in_pool'))
                        break
            
            # Verificar en GitHub
            if self.repo.check_package_in_github(pkg_name):
                estados.append(get_string('package_states.in_github'))
                        
            # Verificar en incoming
            if os.path.exists(os.path.join(self.repo.incoming_dir, os.path.basename(filepath))):
                estados.append(get_string('package_states.in_incoming'))
            
            return " + ".join(estados) if estados else get_string('package_states.new')
            
        except Exception as e:
            self.logger.error(f"Error verificando estado: {str(e)}")
            return get_string('package_states.unknown')

    def on_upload_clicked(self, button):
        """Manejador del botón subir"""
        # Verificar configuración
        if not getattr(self.repo, 'git_token', None):
            self.show_error(get_string('messages.config_repo_first'))
            return

        # Deshabilitar botones
        self.add_button.set_sensitive(False)
        self.upload_button.set_sensitive(False)
        
        try:
            # Procesar archivos
            total = len(self.files_store)
            for i, row in enumerate(self.files_store):
                # Actualizar progreso
                fraction = (i + 1) / total
                self.progress_bar.set_fraction(fraction)
                self.progress_bar.set_text(get_string('messages.uploading_file').format(row[1]))
                self.status_label.set_text(get_string('messages.uploading'))
                
                # Procesar eventos
                while Gtk.events_pending():
                    Gtk.main_iteration()
                
                # Añadir paquete
                success, msg = self.repo.add_package(row[0])
                if not success:
                    self.show_error(msg)
                    return
            
            # Subir cambios a GitHub
            success, msg = self.repo.push_changes()
            if success:
                self.show_success(get_string('messages.upload_success').format(msg))
                self.status_label.set_text(get_string('messages.upload_complete'))
                # Limpiar lista de archivos
                self.files_store.clear()
                # Actualizar la lista de paquetes instalados
                self.on_refresh_packages(None)
            else:
                self.show_error(msg)
                
        finally:
            # Rehabilitar botones
            self.add_button.set_sensitive(True)
            self.upload_button.set_sensitive(True)
            self.progress_bar.set_text("")
            self.status_label.set_text("")

    def show_error(self, message, secondary=None):
        """Muestra un diálogo de error con soporte multilingüe"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=get_string('dialogs.error')
        )
        
        if secondary:
            dialog.format_secondary_text(secondary)
        else:
            dialog.format_secondary_text(message)
            
        dialog.run()
        dialog.destroy()

    def show_success(self, message):
        """Muestra un diálogo de éxito"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=get_string('dialogs.success')
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def show_confirm(self, message, secondary=None):
        """Muestra un diálogo de confirmación con soporte multilingüe"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,  # Cambiado de YES_NO a NONE para usar botones personalizados
            text=get_string('dialogs.confirm')
        )
        
        if secondary:
            dialog.format_secondary_text(secondary)
        else:
            dialog.format_secondary_text(message)
            
        # Añadir botones con texto traducido
        dialog.add_button(get_string('buttons.no'), Gtk.ResponseType.NO)
        dialog.add_button(get_string('buttons.yes'), Gtk.ResponseType.YES)
            
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.YES

    def ask_overwrite(self, filename):
        """Pregunta si sobreescribir un archivo"""
        return self.show_confirm(get_string('messages.confirm_overwrite').format(filename))

    def on_gpg_clicked(self, button):
        """Manejador del botón de configuración GPG"""
        gpg_key = self.show_gpg_key_dialog()
        if gpg_key:
            try:
                self.repo.gpg_key = gpg_key
                self.repo._create_repo_structure()  # Recrea la estructura con la nueva clave
                self.repo.save_config()  # Guardar la configuración
                self.show_success(get_string('messages.gpg_configured'))
            except Exception as e:
                self.show_error(str(e))

    def on_repo_clicked(self, button):
        """Manejador del botón de configuración del repositorio"""
        dialog = Gtk.Dialog(
            title=get_string('dialogs.config_repo'),
            parent=self,
            flags=0,
            buttons=(
                get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
                get_string('buttons.save'), Gtk.ResponseType.OK
            )
        )
        dialog.set_default_size(500, 300)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)

        # Añadir label con instrucciones
        info_label = Gtk.Label()
        info_label.set_markup(get_string('dialogs.repo_instructions'))
        info_label.set_line_wrap(True)
        info_label.set_justify(Gtk.Justification.LEFT)
        info_label.set_halign(Gtk.Align.START)
        box.pack_start(info_label, False, False, 10)

        # Separador
        box.pack_start(Gtk.Separator(), False, False, 10)

        # Cargar valores del perfil actual si existe
        profile_values = None
        if self.repo.current_profile:
            profile_values = self.repo.profile_manager.get_profile(self.repo.current_profile)

        # Añadir campos para título y nombre del archivo list con valores del perfil
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        title_label = Gtk.Label(label=get_string('labels.repo_title'))
        title_entry = Gtk.Entry()
        
        # Usar valor del perfil si existe, de lo contrario usar el valor del repo
        if profile_values and 'repo_title' in profile_values:
            title_entry.set_text(profile_values['repo_title'])
        else:
            title_entry.set_text(getattr(self.repo, 'repo_title', "Repositorio APT"))
        
        title_box.pack_start(title_label, False, False, 0)
        title_box.pack_start(title_entry, True, True, 0)

        list_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        list_label = Gtk.Label(label=get_string('labels.list_filename'))
        list_entry = Gtk.Entry()
        
        # Usar valor del perfil si existe, de lo contrario usar el valor por defecto
        if profile_values and 'list_filename' in profile_values:
            list_entry.set_text(profile_values['list_filename'])
        else:
            profile_name = self.profile_combo.get_active_text() or ""
            list_entry.set_text(getattr(self.repo, 'list_filename', f"{profile_name}.list"))
        
        list_box.pack_start(list_label, False, False, 0)
        list_box.pack_start(list_entry, True, True, 0)

        # Campo de URL del repositorio
        url_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        url_label = Gtk.Label(label=get_string('labels.repo_url'))
        url_label.set_halign(Gtk.Align.START)
        url_entry = Gtk.Entry()
        # Mostrar URL limpia sin el token
        clean_url = self.repo.get_clean_url() if hasattr(self.repo, 'get_clean_url') else getattr(self.repo, 'git_url', '')
        url_entry.set_text(clean_url or '')
        url_entry.set_placeholder_text(get_string('placeholders.repo_url'))
        url_box.pack_start(url_label, False, False, 0)
        url_box.pack_start(url_entry, True, True, 0)
        
        # Campo de rama con nota informativa actualizada
        branch_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        branch_input_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        branch_label = Gtk.Label(label=get_string('labels.branch'))
        branch_label.set_halign(Gtk.Align.START)
        branch_entry = Gtk.Entry()
        branch_entry.set_text(getattr(self.repo, 'branch', 'main') or 'main')  # Cambiado a 'main'
        branch_input_box.pack_start(branch_label, False, False, 0)
        branch_input_box.pack_start(branch_entry, True, True, 0)
        
        # Nota sobre la rama actualizada
        branch_note = Gtk.Label()
        branch_note.set_markup(get_string('notes.branch'))
        branch_note.set_halign(Gtk.Align.START)
        branch_note.set_line_wrap(True)
        
        branch_box.pack_start(branch_input_box, False, False, 0)
        branch_box.pack_start(branch_note, False, False, 0)

        # Campo de token
        token_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        token_label = Gtk.Label(label=get_string('labels.token'))
        token_label.set_halign(Gtk.Align.START)
        token_entry = Gtk.Entry()
        token_entry.set_visibility(False)  # Ocultar el token
        token_entry.set_text(getattr(self.repo, 'git_token', '') or '')
        token_entry.set_placeholder_text(get_string('placeholders.token'))
        token_box.pack_start(token_label, False, False, 0)
        token_box.pack_start(token_entry, True, True, 0)

        box.pack_start(title_box, False, False, 0)
        box.pack_start(list_box, False, False, 0)
        box.pack_start(url_box, False, False, 0)
        box.pack_start(branch_box, False, False, 0)
        box.pack_start(token_box, False, False, 0)
        
        box.show_all()
        
        # Conectar Enter para enviar el formulario
        def on_entry_activate(entry):
            dialog.response(Gtk.ResponseType.OK)
        
        url_entry.connect("activate", on_entry_activate)
        branch_entry.connect("activate", on_entry_activate)
        token_entry.connect("activate", on_entry_activate)
        title_entry.connect("activate", on_entry_activate)
        list_entry.connect("activate", on_entry_activate)
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            try:
                new_url = url_entry.get_text()
                new_branch = branch_entry.get_text()
                new_token = token_entry.get_text()
                new_title = title_entry.get_text()
                new_list = list_entry.get_text()
                
                # Actualizar configuración del repositorio
                success = self.repo.configure_repository(
                    git_url=new_url,
                    branch=new_branch,
                    token=new_token,
                    title=new_title,
                    list_name=new_list
                )
                
                if success:
                    # Ahora solicitar la información para el README
                    readme_info = self.repo.ask_readme_info(parent_window=self)
                    if readme_info:
                        self.repo.readme_title = readme_info.get('title', 'Repositorio APT')
                        self.repo.repo_description = readme_info.get('description', 'Repositorio de paquetes APT')
                        # Actualizar el README con la nueva información
                        self.repo._ensure_readme()
                    
                    # Guardar la configuración en el perfil activo si existe
                    if self.repo.current_profile:
                        self.repo.save_config()
                        profile_name = self.repo.current_profile
                        self.repo.profile_manager.save_profile(profile_name, {
                            'git_url': self.repo.git_url,
                            'branch': self.repo.branch,
                            'gpg_key': self.repo.gpg_key,
                            'git_token': self.repo.git_token,
                            'repo_dir': self.repo.repo_dir,
                            'repo_title': self.repo.repo_title,
                            'list_filename': self.repo.list_filename
                        })
                        self.show_success(get_string('messages.repo_configured'))
                    else:
                        self.show_error("No hay perfil activo para guardar configuración")
                else:
                    self.show_error(get_string('messages.repo_config_error'))
                    
            except Exception as e:
                self.show_error(str(e))
                
        dialog.destroy()

    def _on_language_changed(self, manager):
        """Maneja el cambio de idioma"""
        # Actualizar el título de la ventana y el título principal
        new_title = get_string('ui_elements.window_title')
        self.set_title(new_title)
        self.title_label.set_markup('<span size="x-large" weight="bold">' + new_title + '</span>')
        
        # Actualizar textos de los botones correctamente
        self.add_button.get_child().get_children()[1].set_text(
            get_string('buttons.add_file')
        )
        self.upload_button.get_child().get_children()[1].set_text(
            get_string('buttons.upload')
        )
        self.files_view.get_column(0).set_title(
            get_string('labels.columns.name')
        )

    def on_language_changed(self, combo):
        """Manejador del cambio de idioma"""
        lang_code = combo.get_active_id()
        if lang_code and locale_manager.set_language(lang_code):
            self.update_ui_strings()

    def update_ui_strings(self):
        """Actualiza todos los textos de la UI al cambiar el idioma"""
        # Actualizar textos principales y botones
        self.set_title(get_string('ui_elements.main_window.title'))
        self.lang_label.set_text(get_string('labels.language'))
        self.profile_label.set_text(get_string('labels.profile'))
        
        # Actualizar pestañas
        self.notebook.set_tab_label_text(
            self.notebook.get_nth_page(0),
            get_string('ui_elements.tabs.upload')
        )
        self.notebook.set_tab_label_text(
            self.notebook.get_nth_page(1),
            get_string('ui_elements.tabs.manage')
        )
        
        # Actualizar botones principales
        self.update_button_label(self.add_button, 'buttons.add_file')
        self.update_button_label(self.upload_button, 'buttons.upload')
        self.update_button_label(self.gpg_button, 'buttons.gpg')
        self.update_button_label(self.repo_button, 'buttons.repo')
        self.update_button_label(self.gen_script_button, 'buttons.script')
        self.update_button_label(self.exit_button, 'buttons.exit')
        
        # Actualizar etiquetas de columnas
        self.update_columns(self.files_view, {
            0: 'labels.tree_columns.file_name',
            1: 'labels.tree_columns.file_size',
            2: 'labels.tree_columns.file_date',
            3: 'labels.tree_columns.file_status'
        })
        
        self.update_columns(self.packages_view, {
            0: 'labels.tree_columns.pkg_name',
            1: 'labels.tree_columns.pkg_version',
            2: 'labels.tree_columns.pkg_arch',
            3: 'labels.tree_columns.pkg_section',
            4: 'labels.tree_columns.pkg_description'
        })
        
        # Actualizar marcos
        if hasattr(self, 'packages_frame'):
            self.packages_frame.set_label(get_string('labels.packages_in_repo'))
        
        # Forzar actualización visual
        self.queue_draw()

        # Actualizar botones principales
        self.update_button_label(self.add_button, 'buttons.add_file')
        self.update_button_label(self.upload_button, 'buttons.upload')
        self.update_button_label(self.gpg_button, 'buttons.gpg') 
        self.update_button_label(self.repo_button, 'buttons.repo')
        self.update_button_label(self.gen_script_button, 'buttons.script')
        self.update_button_label(self.exit_button, 'buttons.exit')
        
        # Actualizar botones de gestión
        if hasattr(self, 'refresh_button'):
            self.update_button_label(self.refresh_button, 'buttons.refresh')
        if hasattr(self, 'remove_button'):    
            self.update_button_label(self.remove_button, 'buttons.remove')
        if hasattr(self, 'view_button'):
            self.update_button_label(self.view_button, 'buttons.view')

    def update_button_label(self, button, key):
        """Actualiza la etiqueta de un botón manteniendo el mnemónico"""
        if button and isinstance(button, Gtk.Button):  # Corregido: && por and
            box = button.get_child()
            if isinstance(box, Gtk.Box):
                for child in box.get_children():
                    if isinstance(child, Gtk.Label):
                        text = get_string(key)
                        # Añadir guión bajo antes de la primera letra para el mnemónico
                        if not '_' in text:
                            text = '_' + text
                        child.set_text(text)
                        child.set_use_underline(True)
                        break

    def update_columns(self, tree_view, column_keys):
        """Actualiza las etiquetas de las columnas"""
        if tree_view:
            for i, key in column_keys.items():
                column = tree_view.get_column(i)
                if column:
                    column.set_title(get_string(key))

    def show_overwrite_dialog(self, filename):
        """Muestra un diálogo de sobrescritura con opción 'aplicar a todos'"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=get_string('dialogs.file_exists')
        )
        
        dialog.format_secondary_text(get_string('messages.file_exists').format(os.path.basename(filename)))
        
        # Añadir checkbox para aplicar a todos
        check = Gtk.CheckButton(label=get_string('dialogs.apply_to_all'))
        dialog.get_content_area().pack_start(check, True, True, 0)
        
        # Añadir botones personalizados
        dialog.add_button(get_string('buttons.no'), Gtk.ResponseType.NO)
        dialog.add_button(get_string('buttons.yes'), Gtk.ResponseType.YES)
        
        dialog.get_content_area().show_all()
        
        response = dialog.run()
        apply_all = check.get_active()
        dialog.destroy()
        
        while Gtk.events_pending():
            Gtk.main_iteration()
            
        return response == Gtk.ResponseType.YES, apply_all

    def refresh_file_list(self):
        """Actualiza los estados de los archivos en la lista"""
        for row in self.files_store:
            filepath = row[0]
            # Solo actualizar el estado del paquete, no la firma
            estado = self._check_package_status(filepath)
            row[4] = estado  # Ajustado el índice ya que eliminamos una columna

    def on_clean_clicked(self, button):
        """Manejador para limpiar el repositorio"""
        if not self.show_confirm(get_string('messages.confirm_clean_repo')):
            return

        # Mostrar diálogo de progreso
        self.progress_bar.set_fraction(0.5)
        self.progress_bar.set_text(get_string('messages.cleaning_repo'))
        self.status_label.set_text(get_string('messages.cleaning_packages'))
        
        while Gtk.events_pending():
            Gtk.main_iteration()

        try:
            success, msg = self.repo.clean_repository()
            if success:
                self.show_success(get_string('messages.repo_cleaned'))
                # Subir cambios a GitHub
                success, msg = self.repo.push_changes(get_string('messages.repo_clean_commit'))
                if not success:
                    self.show_error(get_string('messages.repo_push_error').format(msg))
            else:
                self.show_error(get_string('messages.repo_clean_error').format(msg))
        finally:
            self.progress_bar.set_fraction(0.0)
            self.progress_bar.set_text("")
            self.status_label.set_text("")

    def on_gen_script_clicked(self, button):
        """Manejador para generar script de instalación"""
        if not self.repo.git_url or not self.repo.branch:
            self.show_error(get_string('messages.config_repo_first'))
            return
        
        # Obtener nombre del repositorio para el nombre del archivo
        repo_name = self.repo.git_url.split('/')[-1].replace('.git', '')
        
        dialog = Gtk.FileChooserDialog(
            title=get_string('dialogs.save_install_script'),
            parent=self,
            action=Gtk.FileChooserAction.SAVE,
            buttons=(
                get_string('buttons.cancel'), Gtk.ResponseType.CANCEL,
                get_string('buttons.save'), Gtk.ResponseType.OK
            )
        )
        
        # Obtener el nombre del script usando defaults.install_script_name
        script_name = get_string('defaults.install_script_name').format(repo_name)
        if '[Missing' in script_name:  # Si falla obtener la traducción, usar valor por defecto
            script_name = f'instalar-{repo_name}.sh'
            
        dialog.set_current_name(script_name)
        
        # No usar el diálogo nativo de confirmación, usaremos el nuestro
        dialog.set_do_overwrite_confirmation(False)
        
        # Filtro para archivos .sh
        filter_sh = Gtk.FileFilter()
        filter_sh.set_name(get_string('ui_elements.file_filters.shell_scripts'))
        filter_sh.add_pattern("*.sh")
        dialog.add_filter(filter_sh)
        
        # Establecer el filtro .sh como predeterminado
        dialog.set_filter(filter_sh)

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            filename = dialog.get_filename()
            if not filename.endswith('.sh'):
                filename += '.sh'
            
            dialog.destroy()  # Destruir el diálogo antes de mostrar la confirmación
            
            # Verificar si el archivo existe y preguntar solo una vez
            if os.path.exists(filename):
                if not self.show_confirm(
                    get_string('messages.confirm_overwrite').format(os.path.basename(filename))
                ):
                    return
                
            try:
                # Generar contenido del script USANDO EL MÉTODO DEL REPO_MANAGER
                script_content = self.repo.generate_install_script()
                
                # Guardar script
                with open(filename, 'w') as f:
                    f.write(script_content)
                
                # Hacer ejecutable
                os.chmod(filename, 0o755)
                
                self.show_success(get_string('messages.script_generated'))
            except Exception as e:
                self.show_error(get_string('messages.script_generate_error').format(str(e)))
                return
        else:
            dialog.destroy()

    def on_destroy(self, window):
        """Limpia los __pycache__ antes de cerrar"""
        base_dir = "/usr/local/bin/soplos-repo-manager"
        for root, dirs, files in os.walk(base_dir):
            if '__pycache__' in dirs:
                cache_dir = os.path.join(root, '__pycache__')
                try:
                    shutil.rmtree(cache_dir)
                except Exception as e:
                    self.logger.warning(get_string('messages.cache_delete_error').format(cache_dir, str(e)))

    def on_exit_clicked(self, button):
        """Manejador para salir del programa"""
        if self.show_confirm(get_string('messages.confirm_exit')):
            self.close()

    def on_switch_page(self, notebook, page, page_num):
        """Manejador para cambio de pestañas"""
        # Actualizar silenciosamente sin mostrar mensajes
        if page_num == 0:
            self.refresh_file_list()
        else:
            self.on_refresh_packages(None) # Pasar None para no mostrar mensajes

    def _on_clean_repo_clicked(self, button):
        """Callback para limpiar el repositorio"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text="¿Está seguro de que desea limpiar el repositorio?"
        )
        dialog.format_secondary_text(
            "Esta acción eliminará todos los paquetes del repositorio pero mantendrá la configuración."
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            # Mostrar una barra de progreso mientras limpia
            self.progress_bar.set_fraction(0.5)
            self.progress_bar.set_text("Limpiando repositorio...")
            self.status_label.set_text("Eliminando paquetes y metadatos...")
            
            # Desactivar temporalmente la interfaz de usuario
            self.set_sensitive(False)
            
            # Procesar eventos de GTK para actualizar la UI
            while Gtk.events_pending():
                Gtk.main_iteration()
            
            # Usar GLib.idle_add para no bloquear la interfaz
            def clean_repo_task():
                try:
                    result, message = self.repo.clean_repository()
                    
                    # Restaurar la interfaz de usuario
                    self.progress_bar.set_fraction(0.0)
                    self.progress_bar.set_text("")
                    self.status_label.set_text("")
                    self.set_sensitive(True)
                    
                    if result:
                        self.show_success("Repositorio limpiado correctamente")
                        # Actualizar la lista de paquetes sin mostrar mensaje
                        self.on_refresh_packages(None)
                    else:
                        self.show_error(f"Error limpiando repositorio: {message}")
                except Exception as e:
                    self.set_sensitive(True)
                    self.progress_bar.set_fraction(0.0)
                    self.progress_bar.set_text("")
                    self.status_label.set_text("")
                    self.show_error(f"Error inesperado: {str(e)}")
                return False
                
            GLib.idle_add(clean_repo_task)

    def _ensure_readme(self):
        """Actualiza el README.md con las instrucciones correctas"""
        try:
            # Obtener URLs y valores necesarios
            raw_url = self.repo.get_raw_url()
            if not raw_url:
                raise ValueError("URL del repositorio no configurada")
                
            # Obtener nombre del repo de la URL
            repo_name = self.repo.git_url.split('/')[-1].replace('.git', '')
            
            # Generar nombres de archivo
            readme_path = os.path.join(self.repo.repo_dir, "README.md")
            gpg_file = f"{repo_name}.gpg"
            list_file = self.repo.list_filename or f"{repo_name}.list"

            with open(readme_path, "w") as f:
                f.write(f"""# 📦 {repo_name}

{self.repo_description if hasattr(self, 'repo_description') else 'Repositorio de paquetes APT'}

## 🛠️ Instalación

### 1️⃣ Añadir la clave GPG
```bash
# Descargar e instalar la clave GPG
sudo mkdir -p /usr/share/keyrings
wget -qO - {raw_url}/public.key | sudo gpg --dearmor -o /usr/share/keyrings/{gpg_file}
```

### 2️⃣ Añadir el repositorio

```bash
# Añadir la fuente APT
echo "deb [signed-by=/usr/share/keyrings/{gpg_file} trusted=yes] {raw_url}/ stable main" | sudo tee /etc/apt/sources.list.d/{list_file}

# Actualizar índices
sudo apt update --allow-insecure-repositories
```

### 3️⃣ Instalar paquetes

```bash
sudo apt install nombre-del-paquete
```

## 🔍 Buscar paquetes disponibles
Para ver todos los paquetes disponibles:

```bash
apt search soplos
```

## 🤝 Contribuir
¿Encontraste un error o tienes una sugerencia? ¡Abre un issue!

## 📝 Licencia
Este repositorio está bajo la licencia GPL-3.0.""")
        except Exception as e:
            self.logger.error(f"Error actualizando README: {e}")
            raise

    def _create_button(self, icon_name, label_key, callback):
        """Crea un botón con un ícono y una etiqueta"""
        button = Gtk.Button()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        
        # Crear icono
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
        box.pack_start(icon, False, False, 0)
        
        # Crear etiqueta
        label = Gtk.Label(get_string(label_key))
        label.set_use_underline(True)
        box.pack_start(label, False, False, 0)
        
        # Añadir el box al botón
        button.add(box)
        
        # Conectar el callback
        if callback:
            button.connect('clicked', callback)
            
        return button
