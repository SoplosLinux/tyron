"""Stringhe mancanti in italiano"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Segnala bug',
        'license': 'Licenza',
        'support': 'Supporto',
        'translate': 'Traduci',
        'version': 'Versione',
        'website': 'Sito web'
    },
    'buttons': {
        'accept': 'Accetta',
        'cancel': 'Annulla',
        'clean': 'Pulisci',
        'close': 'Chiudi',
        'create': 'Crea',
        'create_gpg_key': 'Crea chiave GPG',
        'delete': 'Elimina',
        'delete_gpg_key': 'Elimina chiave GPG',
        'no': 'No',
        'overwrite': 'Sovrascrivi',
        'overwrite_all': 'Sovrascrivi tutto',
        'save': 'Salva',
        'select': 'Seleziona',
        'skip': 'Salta',
        'skip_all': 'Salta tutto',
        'update_list': 'Aggiorna lista',
        'yes': 'Sì'
    },
    # ...resto del código con las traducciones al italiano...
}
