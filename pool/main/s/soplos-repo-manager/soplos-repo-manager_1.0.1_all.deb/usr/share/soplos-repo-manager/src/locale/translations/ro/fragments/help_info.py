"""Traduceri pentru ajutor în română"""

FRAGMENT = {
    'help_info': {
        'gpg_setup': 'Cum să configurați GPG',
        'repo_setup': 'Cum să configurați depozitul',
        'profiles': 'Utilizarea profilurilor',
        'packages': 'Gestionarea pachetelor',
        'scripts': 'Scripturi de instalare',
        'updates': 'Actualizări',
        'support': 'Obținere suport',
        'sections': {
            'quick_start': 'Start rapid',
            'configuration': 'Configurare',
            'usage': 'Utilizare de bază',
            'advanced': 'Opțiuni avansate',
            'troubleshooting': 'Depanare',
            'faq': 'Întrebări frecvente'
        }
    }
}
