"""Traduções de filtros de ficheiros em português"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Scripts de Shell (*.sh)',
        }
    }
}
