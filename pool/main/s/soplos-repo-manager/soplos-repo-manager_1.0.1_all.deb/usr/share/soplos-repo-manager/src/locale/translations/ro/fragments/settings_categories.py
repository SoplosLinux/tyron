"""Categorii de configurare în română"""

FRAGMENT = {
    'general': {
        'title': 'General',
        'language': 'Limbă',
        'updates': 'Actualizări',
        'notifications': 'Notificări'
    },
    'appearance': {
        'title': 'Aspect',
        'theme': 'Temă',
        'icons': 'Pictograme',
        'fonts': 'Fonturi'
    },
    'network': {
        'title': 'Rețea',
        'proxy': 'Proxy',
        'timeout': 'Timp de așteptare',
        'retries': 'Reîncercări'
    },
    'advanced': {
        'title': 'Avansat',
        'logging': 'Jurnalizare',
        'debug': 'Depanare',
        'cache': 'Cache'
    },
    'profiles': {
        'title': 'Profiluri',
        'default': 'Profil implicit',
        'auto_load': 'Încarcă ultimul profil',
        'backup': 'Backup automat'
    }
}
