"""Traduzioni dell'aiuto in italiano"""

FRAGMENT = {
    'help_info': {
        'gpg_setup': 'Come configurare GPG',
        'repo_setup': 'Come configurare il repository',
        'profiles': 'Utilizzo dei profili',
        'packages': 'Gestione dei pacchetti',
        'scripts': 'Script di installazione',
        'updates': 'Aggiornamenti',
        'support': 'Ottenere supporto',
        'sections': {
            'quick_start': 'Avvio rapido',
            'configuration': 'Configurazione',
            'usage': 'Utilizzo base',
            'advanced': 'Opzioni avanzate',
            'troubleshooting': 'Risoluzione dei problemi',
            'faq': 'Domande frequenti'
        }
    }
}
