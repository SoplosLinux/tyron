"""Traducciones de atajos de teclado en español"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Atajos de teclado',
        'categories': {
            'general': 'General',
            'navigation': 'Navegación',
            'editing': 'Edición',
            'view': 'Vista'
        },
        'actions': {
            'save': 'Guardar (Ctrl+S)',
            'quit': 'Salir (Ctrl+Q)',
            'refresh': 'Actualizar (Ctrl+R)',
            'search': 'Buscar (Ctrl+F)',
            'preferences': 'Preferencias (Ctrl+P)',
            'help': 'Ayuda (F1)',
            'switch_tab': 'Cambiar pestaña (Ctrl+Tab)',
            'new_item': 'Nuevo elemento (Ctrl+N)',
            'delete_item': 'Eliminar elemento (Supr)',
            'fullscreen': 'Pantalla completa (F11)',
            'zoom_in': 'Aumentar zoom (Ctrl++)',
            'zoom_out': 'Reducir zoom (Ctrl+-)',
            'reset_zoom': 'Restablecer zoom (Ctrl+0)'
        }
    }
}
