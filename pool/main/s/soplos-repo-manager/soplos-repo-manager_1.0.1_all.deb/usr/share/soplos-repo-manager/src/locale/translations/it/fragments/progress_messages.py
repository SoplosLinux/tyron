"""Messaggi di avanzamento in italiano"""

FRAGMENT = {
    'estimated_time': 'Tempo stimato rimanente: {0}',
    'total_progress': 'Progresso totale: {0}%',
    'remaining_items': '{0} elementi rimanenti',
    'task_status': '{0} di {1}',
    'current_operation': 'Operazione corrente: {0}',
    'processing_item': 'Elaborazione di {0}...',
    'start_task': 'Avvio di {0}...',
    'finish_task': 'Completato {0}',
    'abort_task': 'Interruzione di {0}...',
    'error_task': 'Errore in {0}: {1}',
    'percent': '{0}% completato'
}
