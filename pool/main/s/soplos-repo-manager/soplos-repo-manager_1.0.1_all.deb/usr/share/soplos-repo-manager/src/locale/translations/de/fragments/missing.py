"""Fehlende Texte auf Deutsch"""

FRAGMENT = {
    'app_info': {
        'bugs': 'Fehler melden',
        'license': 'Lizenz',
        'support': 'Support',
        'translate': 'Übersetzen',
        'version': 'Version',
        'website': 'Webseite'
    },
    'buttons': {
        'accept': 'Akzeptieren',
        'cancel': 'Abbrechen',
        'clean': 'Bereinigen',
        'close': 'Schließen',
        'create': 'Erstellen',
        'create_gpg_key': 'GPG-Schlüssel erstellen',
        'delete': 'Löschen',
        'delete_gpg_key': 'GPG-Schlüssel löschen',
        'no': 'Nein',
        'overwrite': 'Überschreiben',
        'overwrite_all': 'Alle überschreiben',
        'save': 'Speichern',
        'select': 'Auswählen',
        'skip': 'Überspringen',
        'skip_all': 'Alle überspringen',
        'update_list': 'Liste aktualisieren',
        'yes': 'Ja'
    },
    'dialogs': {
        'colors': {
            'green': '\\033[0;32m',
            'red': '\\033[0;31m',
            'nc': '\\033[0m'
        },
        'confirm_clean_repo': 'Sind Sie sicher, dass Sie das Repository bereinigen möchten?',
        'config_repo': 'Repository konfigurieren',
        'create_gpg': 'Neuen GPG-Schlüssel erstellen',
        'existing_file': 'Vorhandene Datei',
        'file_details': 'Dateidetails',
        'gpg_key_info': 'Der GPG-Schlüssel wird mit folgenden Daten erstellt:',
        'gpg_verification': 'GPG-Verifizierung',
        'install_script': 'Installationsskript',
        'new_profile': 'Neues Profil',
        'package_details': 'Paketdetails {0}',
        'package_list': 'Paketliste',
        'profile_setup': 'Ersteinrichtung',
        'repo_instructions': 'Konfigurieren Sie die Git-Repository-Details.\nSie benötigen ein GitHub-Konto und einen Token mit "repo"-Berechtigungen.',
        'save_script': 'Skript speichern',
        'select_gpg': 'GPG-Schlüssel auswählen',
        'version_select': 'Version auswählen',
        'wait': 'Bitte warten'
    },
    'labels': {
        'arch': 'Architektur',
        'branch': 'Branch',
        'date': 'Datum',
        'description': 'Beschreibung',
        'email': 'E-Mail',
        'id': 'ID',
        'language': 'Sprache',
        'list_filename': 'Name der .list-Datei',
        'name': 'Name',
        'profile': 'Profil',
        'repo_title': 'Repository-Titel',
        'repo_url': 'Repository-URL',
        'section': 'Bereich',
        'size': 'Größe',
        'status': 'Status',
        'token': 'Token',
        'tree_columns': {
            'file_date': 'Datum',
            'file_name': 'Name',
            'file_size': 'Größe',
            'file_status': 'Status',
            'pkg_arch': 'Architektur',
            'pkg_description': 'Beschreibung',
            'pkg_name': 'Name',
            'pkg_section': 'Bereich',
            'pkg_version': 'Version'
        }
    },
    'package_states': {
        'error': 'Fehler',
        'in_github': 'In GitHub',
        'in_incoming': 'In Eingang',
        'in_pool': 'Im Pool',
        'new': 'Neu',
        'processing': 'Verarbeitung',
        'unknown': 'Unbekannt',
        'uploaded': 'Hochgeladen',
        'uploading': 'Wird hochgeladen'
    },
    'placeholders': {
        'branch': 'main',
        'repo_url': 'https://github.com/benutzer/repository',
        'token': 'Geben Sie Ihren persönlichen GitHub-Token ein'
    },
    'progress_messages': {
        'abort_task': 'Breche {0} ab...',
        'current_operation': 'Aktuelle Operation: {0}',
        'error_task': 'Fehler in {0}: {1}',
        'estimated_time': 'Geschätzte Zeit: {0}',
        'finish_task': 'Abgeschlossen {0}',
        'percent': '{0}% abgeschlossen',
        'processing_item': 'Verarbeite {0}...',
        'remaining_items': 'Verbleibende Elemente: {0}',
        'start_task': 'Starte {0}...',
        'task_status': '{0} von {1}',
        'total_progress': 'Gesamtfortschritt: {0}%'
    },
    'notes': {
        'branch': '<small>Es wird empfohlen, standardmäßig "main" zu verwenden</small>'
    },
    'defaults': {
        'install_script_name': 'installieren-{}.sh',
        'list_filename': 'soplos.list',
        'repo_title': 'Soplos Repository'
    }
}
