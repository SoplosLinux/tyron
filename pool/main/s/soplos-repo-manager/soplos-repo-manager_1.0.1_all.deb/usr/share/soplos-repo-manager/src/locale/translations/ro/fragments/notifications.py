"""Notificări în română"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Informație',
        'warning': 'Avertisment',
        'error': 'Eroare',
        'success': 'Succes'
    },
    'messages': {
        'package_added': 'Pachetul {0} a fost adăugat cu succes',
        'package_removed': 'Pachetul {0} a fost șters',
        'upload_started': 'Se începe încărcarea {0}...',
        'upload_complete': 'Încărcare finalizată: {0}',
        'update_available': 'Versiune nouă disponibilă: {0}',
        'repo_synced': 'Depozit sincronizat',
        'backup_created': 'Copie de siguranță creată în {0}'
    }
}
