"""Traductions de l'aide en français"""

FRAGMENT = {
    'help_info': {
        'gpg_setup': 'Comment configurer GPG',
        'repo_setup': 'Comment configurer le dépôt',
        'profiles': 'Utilisation des profils',
        'packages': 'Gestion des paquets',
        'scripts': 'Scripts d\'installation',
        'updates': 'Mises à jour',
        'support': 'Obtenir de l\'aide',
        'sections': {
            'quick_start': 'Démarrage rapide',
            'configuration': 'Configuration',
            'usage': 'Utilisation de base',
            'advanced': 'Options avancées',
            'troubleshooting': 'Résolution des problèmes',
            'faq': 'Questions fréquentes'
        }
    }
}
