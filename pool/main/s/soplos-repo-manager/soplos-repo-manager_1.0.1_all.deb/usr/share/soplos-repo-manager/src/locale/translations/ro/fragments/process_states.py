"""Stări procese în română"""

FRAGMENT = {
    'startup': {
        'loading': 'Se pornește aplicația...',
        'checking_deps': 'Se verifică dependențele...',
        'init_repo': 'Se inițializează depozitul...',
        'loading_profiles': 'Se încarcă profilurile...',
        'ready': 'Sistem pregătit'
    },
    'shutdown': {
        'saving': 'Se salvează modificările...',
        'cleaning': 'Se curăță fișierele temporare...',
        'closing': 'Se închide aplicația...'
    },
    'states': {
        'validating': 'Se validează...',
        'processing': 'Se procesează...',
        'signing': 'Se semnează...',
        'verifying': 'Se verifică...',
        'uploading': 'Se încarcă...',
        'downloading': 'Se descarcă...',
        'installing': 'Se instalează...',
        'removing': 'Se șterge...',
        'cleaning': 'Se curăță...',
        'backing_up': 'Se creează copie...',
        'restoring': 'Se restaurează...',
        'calculating': 'Se calculează...',
        'updating': 'Se actualizează...',
        'indexing': 'Se indexează...'
    }
}
