"""Settings categories translations in English"""

FRAGMENT = {
    'general': {
        'title': 'General',
        'language': 'Language',
        'updates': 'Updates',
        'notifications': 'Notifications'
    },
    'appearance': {
        'title': 'Appearance',
        'theme': 'Theme',
        'icons': 'Icons', 
        'fonts': 'Fonts'
    },
    'network': {
        'title': 'Network',
        'proxy': 'Proxy',
        'timeout': 'Timeout',
        'retries': 'Retries'
    },
    'advanced': {
        'title': 'Advanced',
        'logging': 'Logging',
        'debug': 'Debug',
        'cache': 'Cache'
    },
    'profiles': {
        'title': 'Profiles',
        'default': 'Default profile',
        'auto_load': 'Load last profile',
        'backup': 'Automatic backup'
    }
}
