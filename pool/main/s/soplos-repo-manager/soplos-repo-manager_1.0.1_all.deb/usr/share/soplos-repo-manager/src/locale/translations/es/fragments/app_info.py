"""Información de la aplicación en español"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Usar el mismo nombre en toda la aplicación
    'display_name': 'Soplos Repo Manager',  # Añadir esta línea para el título en la UI
    'version': 'Versión {0}',
    'description': 'Gestor de repositorios APT para Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'Licencia GPL-3.0',
    'website': 'https://soplos.org',
    'bugs': 'Reportar errores',
    'support': 'Soporte',
    'translate': 'Ayuda a traducir',
    'contributors': 'Colaboradores',
    'dependencies': 'Dependencias',
    'system_info': 'Información del sistema'
}
