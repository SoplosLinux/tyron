"""Benachrichtigungen auf Deutsch"""

FRAGMENT = {
    'title': 'Soplos Repo Manager',
    'types': {
        'info': 'Information',
        'warning': 'Warnung',
        'error': 'Fehler',
        'success': 'Erfolg'
    },
    'messages': {
        'package_added': 'Paket {0} erfolgreich hinzugefügt',
        'package_removed': 'Paket {0} entfernt',
        'upload_started': 'Starte Upload von {0}...',
        'upload_complete': 'Upload abgeschlossen: {0}',
        'update_available': 'Neue Version verfügbar: {0}',
        'repo_synced': 'Repository synchronisiert',
        'backup_created': 'Sicherung erstellt in {0}'
    }
}
