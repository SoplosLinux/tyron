"""Info-bulles en français"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Ajouter un nouveau paquet .deb au dépôt',
        'upload_changes': 'Envoyer les changements en attente sur GitHub',
        'manage_keys': 'Gérer les clés GPG',
        'configure_repo': 'Configurer les détails du dépôt',
        'generate_script': 'Générer le script d\'installation',
        'refresh_list': 'Actualiser la liste des paquets',
        'remove_package': 'Supprimer le paquet sélectionné',
        'sign_package': 'Voir les détails du paquet'
    },
    'tips': {
        'exit_app': 'Quitter l\'application'
    }
}
