"""Traduceri pentru scripturi în română"""

FRAGMENT = {
    'downloading_gpg': 'Se descarcă cheia GPG...',
    'error_downloading_gpg': 'Eroare la descărcarea cheii GPG',
    'verify_root': 'Verificare rulare ca root',
    'must_be_root': 'Acest script trebuie rulat ca root',
    'create_keyring': 'Creare director pentru inelul de chei GPG',
    'download_gpg': 'Descărcare și importare cheie GPG',
    'verify_gpg': 'Verificare descărcare corectă a cheii',
    'error_gpg_empty': 'Eroare: Cheia GPG este goală sau nu a fost instalată',
    'config_repo': 'Configurare depozit',
    'configuring_repo': 'Se configurează depozitul...',
    'force_update': 'Forțare actualizare sigură',
    'updating_indices': 'Se actualizează indicii...',
    'verify_repo': 'Verificare configurare depozit',
    'error_repo_not_configured': 'Eroare: Depozitul nu a fost configurat corect',
    'repo_installed': 'Depozit instalat cu succes!',
    'colors': 'Culori pentru mesaje',
    'install_repo': 'Script de instalare pentru depozitul {}'
}
