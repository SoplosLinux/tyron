"""Traduceri ale formatelor de timp în română"""

FRAGMENT = {
    'short_date': '%d/%m/%Y',
    'long_date': '%d %B %Y',
    'time': '%H:%M:%S',
    'datetime': '%d/%m/%Y %H:%M:%S',
    'month_names': [
        'Ianuarie', 'Februarie', 'Martie', 'Aprilie',
        'Mai', 'Iunie', 'Iulie', 'August',
        'Septembrie', 'Octombrie', 'Noiembrie', 'Decembrie'
    ],
    'day_names': [
        'Luni', 'Marți', 'Miercuri', 'Joi',
        'Vineri', 'Sâmbătă', 'Duminică'
    ],
    'relative': {
        'today': 'Astăzi',
        'yesterday': 'Ieri',
        'tomorrow': 'Mâine',
        'past': 'Acum {0}',
        'future': 'În {0}'
    }
}
