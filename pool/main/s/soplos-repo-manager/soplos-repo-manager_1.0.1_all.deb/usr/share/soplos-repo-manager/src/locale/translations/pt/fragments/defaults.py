"""Valores padrão em português"""

FRAGMENT = {
    'install_script_name': 'instalar-{}.sh',
    'list_filename': 'soplos.list',
    'repo_title': 'Repositório Soplos'
}
