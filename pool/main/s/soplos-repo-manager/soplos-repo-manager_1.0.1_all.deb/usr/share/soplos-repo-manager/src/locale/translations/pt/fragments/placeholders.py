"""Textos de posição em português"""

FRAGMENT = {
    'repo_url': 'https://github.com/utilizador/repositorio',
    'token': 'Introduza o seu token pessoal do GitHub',
    'branch': 'main',
    'search': 'Procurar...',
    'filter': 'Filtrar...',
    'comments': 'Escrever comentário...',
    'name': 'Nome completo',
    'email': 'correio@exemplo.com',
    'profile_name': 'Nome do perfil',
    'password': 'Palavra-passe',
    'confirm_password': 'Confirmar palavra-passe'
}
