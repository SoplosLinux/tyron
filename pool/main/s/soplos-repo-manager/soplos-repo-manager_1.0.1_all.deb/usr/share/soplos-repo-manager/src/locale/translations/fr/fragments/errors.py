"""Traductions des erreurs en français"""

FRAGMENT = {
    'git_not_installed': 'GitPython (python3-git) est requis',
    'load_profiles': 'Erreur lors du chargement des profils : {0}',
    'save_profile': 'Erreur lors de l\'enregistrement du profil : {0}',
    'delete_profile': 'Erreur lors de la suppression du profil : {0}',
    'loading_config': 'Erreur lors du chargement de la configuration : {0}',
    'saving_config': 'Erreur lors de l\'enregistrement de la configuration : {0}',
    'repo_init': 'Erreur lors de l\'initialisation du dépôt Git : {0}',
    'get_repo_name': 'Erreur lors de la récupération du nom du dépôt : {0}',
    'readme_dialog': 'Erreur dans le dialogue README : {0}',
    'list_packages': 'Erreur lors de la liste des paquets : {0}',
    'reading_package': 'Erreur lors de la lecture de {0} : {1}',
    'create_structure': 'Erreur lors de la création de la structure : {0}',
    'configure_reprepro': 'Erreur lors de la configuration de reprepro : {0}',
    'init_indices': 'Erreur lors de l\'initialisation des index : {0}',
    'verify_structure': 'Erreur lors de la vérification de la structure : {0}',
    'integrity_check': 'Erreur lors de la vérification de l\'intégrité : {0}',
    'reprepro_stderr': 'Erreur de reprepro : {0}'
}
