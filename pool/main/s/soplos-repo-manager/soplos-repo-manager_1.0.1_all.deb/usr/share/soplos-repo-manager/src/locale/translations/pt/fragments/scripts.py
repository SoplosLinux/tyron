"""Traduções de scripts em português"""

FRAGMENT = {
    'downloading_gpg': 'A descarregar chave GPG...',
    'error_downloading_gpg': 'Erro ao descarregar a chave GPG',
    'verify_root': 'Verificar se está a executar como root',
    'must_be_root': 'Este script deve ser executado como root',
    'create_keyring': 'Criar diretório do chaveiro GPG',
    'download_gpg': 'Descarregar e importar chave GPG',
    'verify_gpg': 'Verificar se a chave foi descarregada corretamente',
    'error_gpg_empty': 'Erro: A chave GPG está vazia ou não foi instalada',
    'config_repo': 'Configurar repositório',
    'configuring_repo': 'A configurar repositório...',
    'force_update': 'Forçar atualização segura',
    'updating_indices': 'A atualizar índices...',
    'verify_repo': 'Verificar se o repositório está configurado',
    'error_repo_not_configured': 'Erro: O repositório não foi configurado corretamente',
    'repo_installed': 'Repositório instalado com sucesso!',
    'colors': 'Cores para mensagens',
    'install_repo': 'Script de instalação para repositório {}'
}
