"""System messages translations in English"""

FRAGMENT = {
    'system': {
        'startup': {
            'loading': 'Starting application...',
            'checking_deps': 'Checking dependencies...',
            'init_repo': 'Initializing repository...',
            'loading_profiles': 'Loading profiles...',
            'ready': 'System ready'
        },
        'shutdown': {
            'saving': 'Saving changes...',
            'cleaning': 'Cleaning temporary files...',
            'closing': 'Closing application...'
        },
        'errors': {
            'critical': 'Critical error: {0}',
            'dependency': 'Missing dependency: {0}',
            'permission': 'Permission error: {0}',
            'connection': 'Connection error: {0}',
            'config': 'Configuration error: {0}'
        },
        'warnings': {
            'disk_space': 'Low disk space',
            'memory': 'Low system memory',
            'connection': 'Unstable connection',
            'outdated': 'Outdated version'
        }
    }
}
