"""Traducciones de etiquetas en español"""

FRAGMENT = {
    'profile': 'Perfil:',
    'profile_name': 'Nombre del perfil:',  # Añadir esta línea
    'repo_url': 'URL del Repositorio:',
    'branch': 'Rama:',
    'token': 'Token GitHub:',
    'repo_title': 'Título del Repositorio:',
    'list_filename': 'Nombre del archivo .list:',
    'name': 'Nombre:',
    'email': 'Email:',
    'filename': 'Nombre del archivo',
    'size': 'Tamaño',
    'date': 'Fecha',
    'status': 'Estado',
    'version': 'Versión',
    'arch': 'Arquitectura',
    'section': 'Sección',
    'description': 'Descripción',
    'id': 'ID',
    'packages_in_repo': 'Paquetes en el Repositorio',
    'debian_packages': 'Paquetes Debian',
    'shell_scripts': 'Scripts de Shell',
    'language': 'Idioma',
    'progress': 'Progreso:',
    'current_task': 'Tarea actual:',
    'package_count': 'Total de paquetes:',
    'selected_count': 'Seleccionados:',
    'total_size': 'Tamaño total:',
    'tree_columns': {
        'file_name': 'Nombre',
        'file_size': 'Tamaño',
        'file_date': 'Fecha',
        'file_status': 'Estado',
        'pkg_name': 'Nombre',
        'pkg_version': 'Versión',
        'pkg_arch': 'Arquitectura',
        'pkg_section': 'Sección',
        'pkg_description': 'Descripción'
    },
    'tab_upload': 'Subir',
    'tab_manage': 'Gestionar',
    'select_version': 'Seleccionar versión',
    'language': 'Idioma',
    'columns': {
        'name': 'Nombre',
        'size': 'Tamaño',
        'date': 'Fecha',
        'status': 'Estado'
    }
}
