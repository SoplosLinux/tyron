"""Validation messages in English"""

FRAGMENT = {
    'url_invalid': 'Invalid URL',
    'token_invalid': 'Invalid token',
    'branch_empty': 'Branch cannot be empty',
    'name_invalid': 'Invalid name',
    'email_invalid': 'Invalid email',
    'duplicate': '{0} already exists',
    'required_field': 'Required field: {0}',
    'invalid_input': 'Invalid input: {0}',
    'config_error': 'Configuration error: {0}',
    'profile_exists': 'A profile with that name already exists',
    'missing_fields': 'All fields are required',
    'gpg_key_required': 'A GPG key is required',
    'invalid_version': 'Invalid version'
}
