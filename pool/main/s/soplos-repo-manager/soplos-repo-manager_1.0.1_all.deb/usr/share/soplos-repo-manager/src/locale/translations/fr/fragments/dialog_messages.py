"""Messages de dialogue en français"""

FRAGMENT = {
    'select_gpg': 'Sélectionner une Clé GPG',
    'wait': 'Veuillez patienter...',
    'config_repo': 'Configurer le Dépôt',
    'new_profile': 'Nouveau Profil',
    'package_list': 'Liste des Paquets',
    'version_select': 'Sélectionner la Version',
    'existing_file': 'Fichier Existant',
    'file_details': 'Détails du Fichier',
    'package_details': 'Détails du Paquet',
    'create_gpg': 'Créer une Nouvelle Clé GPG',
    'select_gpg': 'Sélectionner une Clé GPG',
    'save_script': 'Enregistrer le Script d\'Installation',
    'install_script': 'Script d\'Installation',
    'gpg_verification': 'Vérification GPG',
    'gpg_key_info': 'Informations de la Clé GPG',
    'repo_instructions': 'Instructions du Dépôt',
    'confirm_clean_repo': 'Confirmer le Nettoyage du Dépôt',
    'colors': {
        'green': 'Vert',
        'red': 'Rouge',
        'nc': 'Sans Couleur'
    }
}
