"""Traduzioni dei tooltips in italiano"""

FRAGMENT = {
    'detailed_tooltips': {
        'add_package': 'Aggiungi nuovo pacchetto .deb al repository',
        'upload_changes': 'Carica modifiche in sospeso su GitHub',
        'manage_keys': 'Gestisci chiavi GPG',
        'configure_repo': 'Configura dettagli del repository',
        'generate_script': 'Genera script di installazione',
        'refresh_list': 'Aggiorna lista dei pacchetti',
        'remove_package': 'Rimuovi pacchetto selezionato',
        'sign_package': 'Visualizza dettagli del pacchetto'
    },
    'tips': {
        'exit_app': 'Esci dall\'applicazione'
    }
}
