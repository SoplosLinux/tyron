"""Traduzioni dei filtri file in italiano"""

FRAGMENT = {
    'file_dialogs': {
        'filters': {
            'shell_scripts': 'Script Shell (*.sh)',
        }
    }
}
