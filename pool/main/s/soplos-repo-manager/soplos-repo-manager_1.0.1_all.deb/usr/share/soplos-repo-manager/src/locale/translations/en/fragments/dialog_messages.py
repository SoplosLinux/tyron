"""Dialog messages translations in English"""

FRAGMENT = {
    'select_gpg': 'Select GPG Key',
    'wait': 'Please wait...',
    'config_repo': 'Configure Repository',
    'new_profile': 'New Profile',
    'package_list': 'Package List',
    'version_select': 'Select Version',
    'existing_file': 'Existing File',
    'file_details': 'File Details',
    'package_details': 'Package Details',
    'create_gpg': 'Create New GPG Key',
    'select_gpg': 'Select GPG Key',
    'save_script': 'Save Installation Script',
    'install_script': 'Installation Script',
    'gpg_verification': 'GPG Verification',
    'gpg_key_info': 'GPG Key Information',
    'repo_instructions': 'Repository Instructions',
    'confirm_clean_repo': 'Confirm Repository Clean',
    'colors': {
        'green': 'Green',
        'red': 'Red',
        'nc': 'No Color'
    }
}
