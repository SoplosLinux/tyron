"""Informații despre aplicație în română"""

FRAGMENT = {
    'name': 'Soplos Repo Manager',  # Folosiți același nume în toată aplicația
    'display_name': 'Soplos Repo Manager',  # Nume pentru interfața utilizatorului
    'version': 'Versiunea {0}',
    'description': 'Manager de depozite APT pentru Soplos Linux',
    'copyright': '© 2024 Soplos Linux Team',
    'license': 'Licență GPL-3.0',
    'website': 'https://soplos.org',
    'bugs': 'Raportează erori',
    'support': 'Suport',
    'translate': 'Ajută la traducere',
    'contributors': 'Colaboratori',
    'dependencies': 'Dependențe',
    'system_info': 'Informații sistem'
}
