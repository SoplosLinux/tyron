"""Error translations in English"""

FRAGMENT = {
    'git_not_installed': 'GitPython is required (python3-git)',
    'load_profiles': 'Error loading profiles: {0}',
    'save_profile': 'Error saving profile: {0}',
    'delete_profile': 'Error deleting profile: {0}',
    'loading_config': 'Error loading configuration: {0}',
    'saving_config': 'Error saving configuration: {0}',
    'repo_init': 'Error initializing Git repository: {0}',
    'get_repo_name': 'Error getting repo name: {0}',
    'readme_dialog': 'Error in README dialog: {0}',
    'list_packages': 'Error listing packages: {0}',
    'reading_package': 'Error reading {0}: {1}',
    'create_structure': 'Error creating structure: {0}',
    'configure_reprepro': 'Error configuring reprepro: {0}',
    'init_indices': 'Error initializing indices: {0}',
    'verify_structure': 'Error verifying structure: {0}',
    'integrity_check': 'Error checking integrity: {0}',
    'reprepro_stderr': 'Reprepro error: {0}'
}
