"""Menü-Elemente auf Deutsch"""

FRAGMENT = {
    'menu': {
        'file': '_Datei',
        'edit': '_Bearbeiten',
        'view': '_Ansicht',
        'tools': '_Werkzeuge',
        'help': '_Hilfe'
    },
    'file_menu': {
        'save': '_Speichern',
        'save_as': 'Speichern _unter',
        'preferences': '_Einstellungen',
        'quit': '_Beenden'
    },
    'edit_menu': {
        'undo': '_Rückgängig',
        'redo': '_Wiederholen',
        'cut': '_Ausschneiden',
        'copy': '_Kopieren',
        'paste': '_Einfügen',
        'delete': '_Löschen',
        'select_all': '_Alles auswählen'
    },
    'view_menu': {
        'refresh': '_Aktualisieren',
        'fullscreen': '_Vollbild',
        'zoom_in': 'Vergrößern',
        'zoom_out': 'Verkleinern',
        'reset_zoom': 'Normale Größe'
    },
    'help_menu': {
        'about': '_Über',
        'documentation': '_Dokumentation',
        'keyboard_shortcuts': '_Tastenkombinationen',
        'report_bug': '_Fehler melden',
        'check_updates': 'Nach _Aktualisierungen suchen'
    }
}
