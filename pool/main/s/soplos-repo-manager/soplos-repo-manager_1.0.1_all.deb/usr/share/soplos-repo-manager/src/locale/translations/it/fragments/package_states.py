"""Stati dei pacchetti in italiano"""

FRAGMENT = {
    'new': 'Nuovo',
    'processing': 'In elaborazione',
    'uploading': 'Caricamento',
    'uploaded': 'Caricato',
    'error': 'Errore',
    'in_pool': 'In Pool',
    'in_github': 'Su GitHub',
    'in_incoming': 'In Incoming',
    'unknown': 'Sconosciuto',
    'installed': 'Installato',
    'not_installed': 'Non installato',
    'partially_installed': 'Parzialmente installato',
    'to_install': 'Da installare',
    'to_remove': 'Da rimuovere',
    'to_upgrade': 'Da aggiornare',
    'broken': 'Danneggiato',
    'configured': 'Configurato',
    'not_configured': 'Non configurato',
    'processed': 'Elaborato'
}
