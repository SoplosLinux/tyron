"""Tastenkombinationen auf Deutsch"""

FRAGMENT = {
    'keyboard': {
        'shortcuts': 'Tastenkombinationen',
        'categories': {
            'general': 'Allgemein',
            'navigation': 'Navigation',
            'editing': 'Bearbeitung',
            'view': 'Ansicht'
        },
        'actions': {
            'save': 'Speichern (Strg+S)',
            'quit': 'Beenden (Strg+Q)',
            'refresh': 'Aktualisieren (Strg+R)',
            'search': 'Suchen (Strg+F)',
            'preferences': 'Einstellungen (Strg+P)',
            'help': 'Hilfe (F1)',
            'switch_tab': 'Tab wechseln (Strg+Tab)',
            'new_item': 'Neues Element (Strg+N)',
            'delete_item': 'Element löschen (Entf)',
            'fullscreen': 'Vollbild (F11)',
            'zoom_in': 'Vergrößern (Strg++)',
            'zoom_out': 'Verkleinern (Strg+-)',
            'reset_zoom': 'Zoom zurücksetzen (Strg+0)'
        }
    }
}
