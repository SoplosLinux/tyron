"""Formats de date et heure en français"""

FRAGMENT = {
    'short_date': '%d/%m/%Y',
    'long_date': '%d %B %Y',
    'time': '%H:%M:%S',
    'datetime': '%d/%m/%Y %H:%M:%S',
    'month_names': [
        'Janvier', 'Février', 'Mars', 'Avril',
        'Mai', 'Juin', 'Juillet', 'Août',
        'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ],
    'day_names': [
        'Lundi', 'Mardi', 'Mercredi', 'Jeudi',
        'Vendredi', 'Samedi', 'Dimanche'
    ],
    'relative': {
        'today': 'Aujourd\'hui',
        'yesterday': 'Hier',
        'tomorrow': 'Demain',
        'past': 'Il y a {0}',
        'future': 'Dans {0}'
    }
}
