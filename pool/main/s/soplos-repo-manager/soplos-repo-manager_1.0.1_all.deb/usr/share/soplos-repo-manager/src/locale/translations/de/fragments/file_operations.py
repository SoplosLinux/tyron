"""Dateioperationen auf Deutsch"""

FRAGMENT = {
    'operations': {
        'copying': 'Kopiere {0}...',
        'moving': 'Verschiebe {0}...',
        'removing': 'Lösche {0}...',
        'creating_dir': 'Erstelle Verzeichnis {0}...',
        'reading': 'Lese {0}...',
        'writing': 'Schreibe {0}...'
    },
    'errors': {
        'error_copy': 'Fehler beim Kopieren der Datei: {0}',
        'error_move': 'Fehler beim Verschieben der Datei: {0}',
        'error_remove': 'Fehler beim Löschen der Datei: {0}',
        'error_create': 'Fehler beim Erstellen des Verzeichnisses: {0}',
        'error_read': 'Fehler beim Lesen der Datei: {0}',
        'error_write': 'Fehler beim Schreiben der Datei: {0}'
    }
}
