"""Textos de marcador de posición en español"""

FRAGMENT = {
    'repo_url': 'https://github.com/usuario/repositorio',
    'token': 'Ingrese su token personal de GitHub',
    'branch': 'main',
    'search': 'Buscar...',
    'filter': 'Filtrar...',
    'comments': 'Escribir comentario...',
    'name': 'Nombre completo',
    'email': 'correo@ejemplo.com',
    'profile_name': 'Nombre del perfil',
    'password': 'Contraseña',
    'confirm_password': 'Confirmar contraseña'
}
