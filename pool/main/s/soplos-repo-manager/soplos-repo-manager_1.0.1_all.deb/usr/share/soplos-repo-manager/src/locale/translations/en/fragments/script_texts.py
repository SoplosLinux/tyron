"""Script texts in English"""

FRAGMENT = {
    'script_header': '#!/bin/bash\n# Installation script for repository {0}\n',
    'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo "This script must be run as root"\n    exit 1\nfi\n',
    'add_key': 'Adding GPG key...',
    'add_repo': 'Adding repository...',
    'updating': 'Updating indices...',
    'installing': 'Installing packages...',
    'complete': 'Installation complete',
    'error': 'Error: {0}',
    'warning': 'Warning: {0}',
    'info': 'Info: {0}',
    'debug': 'Debug: {0}',
    'script_footer': 'echo "Process completed"\nexit 0'
}
