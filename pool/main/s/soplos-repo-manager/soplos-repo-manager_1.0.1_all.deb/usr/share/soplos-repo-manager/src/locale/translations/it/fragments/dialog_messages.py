"""Messaggi di dialogo in italiano"""

FRAGMENT = {
    'select_gpg': 'Seleziona Chiave GPG',
    'wait': 'Attendere prego...',
    'config_repo': 'Configura Repository',
    'new_profile': 'Nuovo Profilo',
    'package_list': 'Lista dei Pacchetti',
    'version_select': 'Seleziona versione',
    'existing_file': 'File Esistente',
    'file_details': 'Dettagli del file',
    'package_details': 'Dettagli del pacchetto',
    'create_gpg': 'Crea Nuova Chiave GPG',
    'select_gpg': 'Seleziona Chiave GPG',
    'save_script': 'Salva Script di Installazione',
    'install_script': 'Script di Installazione',
    'gpg_verification': 'Verifica GPG',
    'gpg_key_info': 'Informazioni Chiave GPG',
    'repo_instructions': 'Istruzioni Repository',
    'confirm_clean_repo': 'Conferma Pulizia Repository',
    'colors': {
        'green': 'Verde',
        'red': 'Rosso',
        'nc': 'Senza Colore'
    }
}
