"""Texte pentru scripturi în română"""

FRAGMENT = {
    'script_header': '#!/bin/bash\n# Script de instalare pentru depozit {0}\n',
    'root_check': 'if [ "$(id -u)" != "0" ]; then\n    echo "Acest script trebuie rulat ca root"\n    exit 1\nfi\n',
    'add_key': 'Se adaugă cheia GPG...',
    'add_repo': 'Se adaugă depozitul...',
    'updating': 'Se actualizează indicii...',
    'installing': 'Se instalează pachetele...',
    'complete': 'Instalare finalizată',
    'error': 'Eroare: {0}',
    'warning': 'Avertisment: {0}',
    'info': 'Info: {0}',
    'debug': 'Debug: {0}',
    'script_footer': 'echo "Proces finalizat"\nexit 0'
}
