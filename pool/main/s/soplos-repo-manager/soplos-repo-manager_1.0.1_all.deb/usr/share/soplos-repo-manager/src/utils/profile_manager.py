import os
import json
import logging
import uuid
import shutil

class ProfileManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.config_dir = os.path.expanduser("~/.config/soplos-repo-manager")
        self.profiles_file = os.path.join(self.config_dir, "profiles.json")
        self.current_profile = None
        self.profiles = self._load_profiles()

    def _load_profiles(self):
        """Carga los perfiles guardados"""
        try:
            os.makedirs(self.config_dir, exist_ok=True)
            if os.path.exists(self.profiles_file):
                with open(self.profiles_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            self.logger.error(f"Error cargando perfiles: {e}")
            return {}

    def save_profile(self, name, data):
        """Guarda un nuevo perfil o actualiza uno existente"""
        try:
            # Generar ID único para el perfil si no existe
            if 'id' not in data:
                data['id'] = str(uuid.uuid4())
            
            # Asegurar que tenemos los campos necesarios
            important_fields = ['git_url', 'branch', 'repo_title', 'list_filename', 'gpg_key', 'git_token', 'repo_dir']
            for field in important_fields:
                if field not in data:
                    self.logger.warning(f"Campo importante '{field}' no presente en datos del perfil")
            
            self.profiles[name] = data
            
            # Guardar también el perfil individual para respaldo
            profile_file = os.path.join(self.config_dir, 'profiles', f"{name}.json")
            os.makedirs(os.path.join(self.config_dir, 'profiles'), exist_ok=True)
            with open(profile_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            # Guardar el archivo principal de perfiles
            with open(self.profiles_file, 'w') as f:
                json.dump(self.profiles, f, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error guardando perfil: {e}")
            return False

    def delete_profile(self, name):
        """Elimina un perfil existente y todos sus archivos asociados"""
        try:
            if name in self.profiles:
                # Obtener la información del perfil antes de eliminarlo
                profile_data = self.profiles[name]
                
                # Eliminar el directorio del repositorio si existe
                repo_dir = profile_data.get('repo_dir')
                if repo_dir and os.path.exists(repo_dir):
                    shutil.rmtree(repo_dir)

                # Eliminar archivos de configuración específicos del perfil
                profile_config = os.path.join(self.config_dir, 'profiles', f"{name}.json")
                if os.path.exists(profile_config):
                    os.remove(profile_config)
                    
                # Eliminar archivos de configuración del README si existen
                readme_config = os.path.join(self.config_dir, f'readme_config_{name}.json')
                if os.path.exists(readme_config):
                    os.remove(readme_config)
                
                # Eliminar el perfil del diccionario
                del self.profiles[name]
                
                # Guardar profiles.json actualizado
                with open(self.profiles_file, 'w') as f:
                    json.dump(self.profiles, f, indent=2)
                
                # Si era el perfil activo, limpiarlo
                if self.current_profile == name:
                    self.current_profile = None
                    
                # Si es el último perfil, limpiar config.json y el directorio profiles
                if not self.profiles:
                    # Limpiar config.json
                    if os.path.exists(os.path.join(self.config_dir, 'config.json')):
                        os.remove(os.path.join(self.config_dir, 'config.json'))
                    
                    # Limpiar directorio profiles
                    profiles_dir = os.path.join(self.config_dir, 'profiles')
                    if os.path.exists(profiles_dir):
                        shutil.rmtree(profiles_dir)
                        os.makedirs(profiles_dir, exist_ok=True)
                        
                    # Limpiar profiles.json
                    with open(self.profiles_file, 'w') as f:
                        json.dump({}, f, indent=2)
                        
                return True
                
            return False
        except Exception as e:
            self.logger.error(f"Error eliminando perfil: {e}")
            return False

    def get_profile(self, name):
        """Obtiene un perfil por nombre"""
        return self.profiles.get(name)

    def list_profiles(self):
        """Lista todos los perfiles disponibles"""
        return list(self.profiles.keys())

    def set_current_profile(self, name):
        """Establece el perfil activo"""
        if name in self.profiles:
            self.current_profile = name
            return True
        return False

    def get_current_profile(self):
        """Obtiene el perfil activo"""
        if self.current_profile:
            return self.get_profile(self.current_profile)
        return None
