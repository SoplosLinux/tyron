#!/usr/bin/env python3
"""
Utilidades para manejar operaciones Git
Incluye soporte para gestión de archivos grandes y Git LFS
"""

import os
import subprocess
import logging
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)

def get_file_size_mb(file_path):
    """Retorna el tamaño del archivo en MB"""
    try:
        size_bytes = os.path.getsize(file_path)
        size_mb = size_bytes / (1024 * 1024)
        return size_mb
    except Exception as e:
        logger.error(f"Error al obtener tamaño de archivo {file_path}: {e}")
        return 0

def setup_git_lfs(repo_path, file_patterns=None):
    """Configura Git LFS para archivos grandes"""
    if not file_patterns:
        file_patterns = ["*.deb", "*.iso", "*.img", "*.tar.gz", "*.tar.xz"]
        
    try:
        # Verificar si git-lfs está instalado
        result = subprocess.run(['which', 'git-lfs'], capture_output=True, text=True)
        if result.returncode != 0:
            logger.error("Git LFS no está instalado en el sistema")
            return False
        
        # Instalar Git LFS globalmente si es necesario
        try:
            subprocess.run(['git', 'lfs', 'install'], check=True, capture_output=True)
        except:
            logger.warning("No se pudo instalar Git LFS globalmente")
        
        # Configurar LFS para el repositorio
        logger.info(f"Configurando Git LFS en: {repo_path}")
        
        # Instalar LFS en el repositorio
        cmds = [
            ['git', '-C', repo_path, 'lfs', 'install'],
        ]
        
        # Configurar patrones de archivo
        for pattern in file_patterns:
            cmds.append(['git', '-C', repo_path, 'lfs', 'track', pattern])
        
        for cmd in cmds:
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                logger.error(f"Error ejecutando {cmd}: {result.stderr}")
                # Continuar con el siguiente comando
            
        # Añadir archivo .gitattributes
        result = subprocess.run(['git', '-C', repo_path, 'add', '.gitattributes'], 
                                capture_output=True, text=True)
        
        # Verificar existencia de archivos grandes y convertirlos a LFS
        convert_existing_to_lfs(repo_path)
        
        logger.info(f"Git LFS configurado exitosamente para: {', '.join(file_patterns)}")
        return True
    except Exception as e:
        logger.error(f"Error configurando Git LFS: {e}")
        return False

def convert_existing_to_lfs(repo_path, size_limit_mb=40):
    """Convierte archivos existentes a formato LFS si superan el límite"""
    try:
        # Buscar archivos grandes
        large_files = []
        for root, _, files in os.walk(repo_path):
            # Ignorar directorio .git
            if '.git' in root.split(os.sep):
                continue
                
            for file in files:
                if file.endswith(('.deb', '.iso', '.img', '.tar.gz', '.tar.xz')):
                    file_path = os.path.join(root, file)
                    size_mb = get_file_size_mb(file_path)
                    
                    if size_mb > size_limit_mb:
                        rel_path = os.path.relpath(file_path, repo_path)
                        large_files.append((rel_path, size_mb))
        
        if not large_files:
            logger.info("No se encontraron archivos grandes para convertir a LFS")
            return True
            
        logger.info(f"Convirtiendo {len(large_files)} archivos a formato LFS...")
        
        for rel_path, size_mb in large_files:
            logger.info(f"Preparando archivo grande para LFS: {rel_path} ({size_mb:.2f} MB)")
            
            # Asegurar que el archivo esté en LFS
            track_cmd = ['git', '-C', repo_path, 'lfs', 'track', rel_path]
            subprocess.run(track_cmd, check=False, capture_output=True)
            
            # Añadir el archivo nuevamente para que sea manejado por LFS
            add_cmd = ['git', '-C', repo_path, 'add', rel_path]
            subprocess.run(add_cmd, check=False, capture_output=True)
            
        # Commit de los cambios
        commit_cmd = ['git', '-C', repo_path, 'commit', '-m', 'Convert large files to LFS format']
        try:
            subprocess.run(commit_cmd, check=False, capture_output=True)
        except:
            # Puede fallar si no hay cambios para commit
            pass
            
        return True
    except Exception as e:
        logger.error(f"Error convirtiendo archivos a LFS: {e}")
        return False

def clean_git_history(repo_path):
    """Limpia el historial de Git para eliminar archivos grandes del historial"""
    try:
        logger.info(f"Iniciando limpieza profunda del historial Git en: {repo_path}")
        
        # Verificar si BFG está instalado (herramienta para limpiar historiales Git)
        bfg_cmd = ['which', 'bfg']
        result = subprocess.run(bfg_cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            # Usar BFG para limpiar archivos grandes
            logger.info("Usando BFG para limpiar historial...")
            bfg_clean = ['bfg', '--strip-blobs-bigger-than', '50M', repo_path]
            subprocess.run(bfg_clean, check=False, capture_output=True)
            
            # Recolectar basura y comprimir el repositorio
            gc_cmd = ['git', '-C', repo_path, 'gc', '--aggressive', '--prune=now']
            subprocess.run(gc_cmd, check=False, capture_output=True)
        else:
            logger.warning("BFG no está instalado. Usando Git filter-branch (más lento)...")
            
            # Crear directorio temporal
            temp_dir = os.path.join(repo_path, '.git', 'temp_backup')
            os.makedirs(temp_dir, exist_ok=True)
            
            # Usar git filter-branch - Comando corregido y completado
            filter_cmd = [
                'git', '-C', repo_path, 'filter-branch', '--force', '--index-filter',
                'git rm --cached --ignore-unmatch "*.deb" "*.iso" "*.img" "*.tar.gz" "*.tar.xz"', 
                '--prune-empty', '--tag-name-filter', 'cat', '--', '--all'
            ]
            
            # Ejecutar el comando filter-branch
            logger.info("Ejecutando git filter-branch para limpiar historial...")
            result = subprocess.run(filter_cmd, check=False, capture_output=True)
            if result.returncode != 0:
                logger.warning(f"Error en filter-branch: {result.stderr}")
            
            # Recolectar basura
            gc_cmd = ['git', '-C', repo_path, 'gc', '--aggressive', '--prune=now']
            subprocess.run(gc_cmd, check=False, capture_output=True)
        
        logger.info("Limpieza del historial Git completada")
        return True
    except Exception as e:
        logger.error(f"Error limpiando historial Git: {e}")
        return False

def deep_clean_git_history(repo_path):
    """Limpieza profunda del historial Git para eliminar TODAS las referencias a archivos grandes"""
    try:
        logger.info(f"Iniciando limpieza COMPLETA del historial Git en: {repo_path}")
        
        # 1. Crear commit inicial limpio
        logger.info("Creando nuevo historial limpio...")
        
        # Guardar archivos importantes
        readme_path = os.path.join(repo_path, "README.md")
        has_readme = os.path.exists(readme_path)
        readme_content = None
        if has_readme:
            with open(readme_path, 'r') as f:
                readme_content = f.read()
        
        # Guardar clave pública
        key_path = os.path.join(repo_path, "public.key")
        has_key = os.path.exists(key_path)
        key_content = None
        if has_key:
            with open(key_path, 'rb') as f:
                key_content = f.read()
        
        # Ejecutar comandos para eliminar historial antiguo
        cmds = [
            # Mover a una rama temporal
            ['git', '-C', repo_path, 'checkout', '--orphan', 'temp_clean'],
            
            # Añadir todos los archivos actuales
            ['git', '-C', repo_path, 'add', '-A'],
            
            # Hacer commit con mensaje claro
            ['git', '-C', repo_path, 'commit', '-m', 'Historial limpio completo - eliminadas referencias a archivos grandes'],
            
            # Eliminar todas las ramas anteriores
            ['git', '-C', repo_path, 'branch', '-D', 'main'],
            
            # Renombrar la rama temporal a main
            ['git', '-C', repo_path, 'branch', '-m', 'main'],
            
            # Forzar push a origin
            ['git', '-C', repo_path, 'push', '-f', 'origin', 'main'],
            
            # Limpiar reflog
            ['git', '-C', repo_path, 'reflog', 'expire', '--expire=now', '--all'],
            
            # Eliminar todos los objetos antiguos completamente
            ['git', '-C', repo_path, 'gc', '--prune=now', '--aggressive'],
        ]
        
        # Ejecutar comandos
        for cmd in cmds:
            try:
                logger.info(f"Ejecutando: {' '.join(cmd)}")
                result = subprocess.run(cmd, check=True, capture_output=True, text=True)
                logger.debug(f"Resultado: {result.stdout}")
            except subprocess.CalledProcessError as e:
                logger.warning(f"Error en comando {' '.join(cmd)}: {e.stderr}")
                # Continuar con el siguiente comando
        
        # Restaurar archivos importantes si se eliminaron
        if has_readme and readme_content:
            with open(readme_path, 'w') as f:
                f.write(readme_content)
                
        if has_key and key_content:
            with open(key_path, 'wb') as f:
                f.write(key_content)
                
        # Añadir estos archivos y hacer commit si es necesario
        if has_readme or has_key:
            subprocess.run(['git', '-C', repo_path, 'add', 'README.md', 'public.key'], check=False)
            subprocess.run(['git', '-C', repo_path, 'commit', '-m', 'Restaurar README y clave pública'], check=False)
        
        logger.info("Limpieza profunda del historial Git completada exitosamente")
        return True
    except Exception as e:
        logger.error(f"Error durante la limpieza profunda: {e}")
        return False

def check_repo_for_large_files(repo_path, size_limit=50):
    """Verifica archivos que exceden el límite de tamaño de GitHub"""
    large_files = []
    try:
        for root, _, files in os.walk(repo_path):
            for file in files:
                if file.endswith('.deb') or file.endswith('.iso'):
                    file_path = os.path.join(root, file)
                    size = get_file_size_mb(file_path)
                    if size > size_limit:
                        large_files.append((file_path, size))
        
        if large_files:
            logger.warning(f"Se encontraron {len(large_files)} archivos mayores a {size_limit}MB:")
            for file_path, size in large_files:
                logger.warning(f"  - {file_path}: {size:.2f}MB")
        
        return large_files
    except Exception as e:
        logger.error(f"Error verificando archivos grandes: {e}")
        return []

# Función que se llamará desde repo_manager pero sin crear importación circular
def ensure_repo_attributes(repo_manager_obj):
    """Asegura que el objeto tiene los atributos necesarios para Git"""
    # Solo comprobamos los atributos sin importar RepoManager
    
    if not hasattr(repo_manager_obj, 'repo_dir'):
        logger.error("El objeto repo_manager debe tener un atributo repo_dir")
        return repo_manager_obj
    
    if not hasattr(repo_manager_obj, 'remote_url'):
        # Intentar obtener la URL remota desde la configuración de Git
        try:
            cmd = ['git', '-C', repo_manager_obj.repo_dir, 'config', '--get', 'remote.origin.url']
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
            if result.returncode == 0:
                repo_manager_obj.remote_url = result.stdout.strip()
            else:
                # Establecer un valor predeterminado
                repo_manager_obj.remote_url = "https://github.com/SoplosLinux/tyron.git"
                logger.warning(f"No se pudo determinar la URL remota. Usando valor predeterminado: {repo_manager_obj.remote_url}")
        except Exception as e:
            repo_manager_obj.remote_url = "https://github.com/SoplosLinux/tyron.git"
            logger.warning(f"Error obteniendo URL remota: {e}. Usando valor predeterminado")
    
    if not hasattr(repo_manager_obj, 'github_token'):
        # Intentar obtener el token desde las variables de entorno o archivo de configuración
        token = os.environ.get('GITHUB_TOKEN', '')
        if not token:
            # Buscar en archivo de configuración
            token_file = os.path.join(os.path.expanduser('~'), '.config', 'soplos', 'github_token')
            if os.path.exists(token_file):
                try:
                    with open(token_file, 'r') as f:
                        token = f.read().strip()
                except:
                    pass
        
        repo_manager_obj.github_token = token
    
    if not hasattr(repo_manager_obj, 'branch'):
        # Establecer rama predeterminada
        repo_manager_obj.branch = "main"
        
    return repo_manager_obj
