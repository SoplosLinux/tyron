#!/usr/bin/env python3
"""
RepoManager - Administración de repositorios
"""

import os
import sys
import logging

# Importar GitPython (si está disponible)
HAVE_GIT = True  # Añadir esta variable antes de intentar importar git
try:
    import git
except ImportError:
    HAVE_GIT = False  # Establecer como False si la importación falla
    logging.warning("El módulo 'git' no está disponible. Algunas funciones pueden no ser operativas.")
    # Crear una clase dummy para que el código no falle
    class DummyGitModule:
        class Repo:
            @staticmethod
            def clone_from(*args, **kwargs):
                raise ImportError("El módulo git (GitPython) no está instalado")
                
            @staticmethod
            def init(*args, **kwargs):
                raise ImportError("El módulo git (GitPython) no está instalado")
                
        class exc:
            class GitCommandError(Exception):
                pass
    
    git = DummyGitModule()

import json
import subprocess
import shutil
import tempfile  # Añadir importación de tempfile
import tarfile  # Añadido para manejar archivos tar.gz
from pathlib import Path
from datetime import datetime
import gi
from .profile_manager import ProfileManager

# Añadir importación de get_string
from src.locale.strings import get_string

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

class RepoManager:
    """Clase para gestionar repositorios de paquetes"""
    
    def __init__(self, repo_dir=None, config=None):
        self.logger = logging.getLogger(__name__)
        self.repo_dir = repo_dir
        self.config = config
        # Atributos que serán verificados/completados por git_utils.ensure_repo_attributes
        self.remote_url = None
        self.github_token = None
        self.branch = "main"
    
    def __init__(self, repo_dir=None, gpg_key=None):
        # Configurar logging solo una vez
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.DEBUG)

        if not HAVE_GIT:
            raise ImportError("Se requiere GitPython (python3-git)")
            
        # Inicializar profile_manager antes que nada
        self.profile_manager = ProfileManager()
        self.current_profile = self.profile_manager.current_profile
        
        # Si no hay perfil activo pero hay perfiles disponibles, cargar el primero
        if not self.current_profile:
            profiles = self.profile_manager.list_profiles()
            if profiles:
                self.current_profile = profiles[0]
                self.profile_manager.set_current_profile(profiles[0])
                self.load_profile(profiles[0])
        
        # Inicializar atributos con valores por defecto
        self.git_url = ""
        self.branch = "main"
        self.gpg_key = gpg_key
        self.git_token = None
        self.repo_title = "Repositorio APT"  # Cambiado a un texto más neutro
        self.list_filename = "apt-repo.list"  # Cambiado a un nombre más neutro
        self.config_file = os.path.expanduser("~/.config/soplos-repo-manager/config.json")
        
        # Modificar cómo se define repo_dir para evitar duplicación
        if repo_dir is None:
            if self.current_profile:
                profile = self.profile_manager.get_profile(self.current_profile)
                if profile and 'repo_dir' in profile:
                    # Usar el nombre del repositorio sin prefijos
                    repo_name = profile['git_url'].split('/')[-1].replace('.git', '')
                    self.repo_dir = os.path.expanduser(f"~/apt-repos/{repo_name}")
                else:
                    self.repo_dir = None
            else:
                self.repo_dir = None
        else:
            self.repo_dir = os.path.expanduser(repo_dir)

        # Solo crear directorios si tenemos repo_dir
        if self.repo_dir:
            self.incoming_dir = os.path.join(self.repo_dir, "incoming")
            self.conf_dir = os.path.join(self.repo_dir, "conf")
            
            # Cargar configuración guardada
            self.load_config()
            
            # Si se proporciona una nueva clave GPG, usarla
            if gpg_key:
                self.gpg_key = gpg_key
                self.save_config()

            # Inicializar desde perfil si existe uno activo
            if self.current_profile:
                profile = self.profile_manager.get_profile(self.current_profile)
                if profile:
                    self.git_url = profile.get('git_url', self.git_url)
                    self.branch = profile.get('branch', self.branch)
                    self.gpg_key = profile.get('gpg_key', self.gpg_key)
                    self.git_token = profile.get('git_token', self.git_token)
                    self.repo_dir = profile.get('repo_dir', self.repo_dir)
                    self.incoming_dir = os.path.join(self.repo_dir, "incoming")
                    self.conf_dir = os.path.join(self.repo_dir, "conf")

    def get_clean_url(self):
        """Obtiene la URL base del repositorio sin el token"""
        if not self.git_url:
            return None
            
        # Limpiar URL y remover .git
        url = self.git_url.replace('.git', '').strip('/')
        if '@' in url:
            url = 'https://' + url.split('@')[-1]
        return url

    def get_raw_url(self):
        """Obtiene la URL para archivos raw en GitHub"""
        clean_url = self.get_clean_url()
        if not clean_url:
            return None

        # Formato correcto para URLs de GitHub raw
        if 'github.com' in clean_url:
            # Extraer propietario y repositorio de la URL
            parts = clean_url.split('/')
            if len(parts) >= 5:  # https://github.com/usuario/repo
                owner = parts[3]
                repo = parts[4]
                # Usar formato para raw.githubusercontent.com
                return f"https://raw.githubusercontent.com/{owner}/{repo}/{self.branch or 'main'}"

        # Para otras URLs, mantener el comportamiento actual
        raw_url = clean_url.replace('github.com', 'raw.githubusercontent.com')
        return f"{raw_url}/{self.branch or 'main'}"

    def get_download_url(self):
        """Obtiene la URL para descargar archivos binarios desde GitHub (como .deb)"""
        clean_url = self.get_clean_url()
        if not clean_url:
            return None

        # Formato para archivos binarios usando el formato raw/refs/heads/
        if 'github.com' in clean_url:
            # Extraer propietario y repositorio de la URL
            parts = clean_url.split('/')
            if len(parts) >= 5:  # https://github.com/usuario/repo
                owner = parts[3]
                repo = parts[4]
                branch = self.branch or 'main'
                return f"https://github.com/{owner}/{repo}/raw/refs/heads/{branch}"
                
        # Si no es GitHub, usar el formato estándar
        return f"{clean_url}/raw/refs/heads/{self.branch or 'main'}"

    def get_repo_url(self):
        """Obtiene la URL para operaciones Git"""
        if not self.git_url:
            return None
        
        url = self.git_url
        if not url.endswith('.git'):
            url = f"{url.rstrip('/')}.git"
            
        if self.git_token and '@' not in url:
            url = url.replace('https://', f'https://{self.git_token}@')
            
        return url

    def load_config(self):
        """Carga la configuración guardada"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            if (os.path.exists(self.config_file)):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.git_url = config.get('git_url', '')
                    self.branch = config.get('branch', 'main')
                    self.gpg_key = config.get('gpg_key', None)
                    self.git_token = config.get('git_token', None)
            return True
        except Exception as e:
            self.logger.error(f"Error cargando configuración: {e}")
            return False

    def save_config(self):
        """Guarda la configuración actual"""
        try:
            # Crear directorios necesarios
            config_base = os.path.dirname(self.config_file)
            profiles_dir = os.path.join(config_base, "profiles")
            os.makedirs(profiles_dir, exist_ok=True)

            # Si tenemos un perfil activo, guardar su configuración
            if self.current_profile:
                profile_config = {
                    'git_url': self.git_url,
                    'branch': self.branch,
                    'gpg_key': self.gpg_key,
                    'git_token': self.git_token,
                    'repo_dir': self.repo_dir,
                    'repo_title': self.repo_title,
                    'list_filename': self.list_filename,
                    'readme_title': getattr(self, 'readme_title', self.repo_title),
                    'repo_description': getattr(self, 'repo_description', 'Repositorio de paquetes APT')
                }
                
                profile_file = os.path.join(profiles_dir, f"{self.current_profile}.json")
                with open(profile_file, 'w') as f:
                    json.dump(profile_config, f)

            # Guardar configuración global (solo el perfil activo)
            global_config = {
                'current_profile': self.current_profile
            }
            with open(self.config_file, 'w') as f:
                json.dump(global_config, f)
                
            return True
        except Exception as e:
            self.logger.error(f"Error guardando configuración: {e}")
            return False

    def _get_repo_name_from_url(self, git_url):
        """Obtiene un nombre válido de directorio desde la URL del repo"""
        try:
            # Remover .git y limpiar la URL
            base_name = git_url.rstrip('/').replace('.git', '')
            # Obtener el último componente de la URL
            repo_name = base_name.split('/')[-1]
            # Sanitizar el nombre para usarlo como directorio
            return ''.join(c for c in repo_name if c.isalnum() or c in '-_')
        except Exception as e:
            self.logger.error(f"Error obteniendo nombre del repo: {e}")
            return "default-repo"

    def configure_repository(self, git_url, branch="main", token=None, title=None, list_name=None):
        """Configura el repositorio Git y su clave GPG específica"""
        try:
            # Normalizar URL del repositorio
            if '/' in git_url:
                # Si es una ruta tipo usuario/repo
                if not git_url.startswith(('http://', 'https://')):
                    git_url = f"https://github.com/{git_url}"
                # Asegurar que termina en .git
                if not git_url.endswith('.git'):
                    git_url = f"{git_url}.git"
            else:
                return False, "Formato de URL inválido"

            self.git_url = git_url
            self.branch = branch or 'main'
            self.git_token = token

            # Extraer nombre del repo para los archivos
            repo_name = git_url.split('/')[-1].replace('.git', '')
            
            # Si no se proporcionan título y nombre de archivo, usar el nombre del repo
            if not title:
                title = repo_name
            if not list_name:
                list_name = f"{repo_name}.list"
                
            self.repo_title = title
            self.list_filename = list_name

            # Obtener nombre del repo para la clave GPG
            repo_name = self._get_repo_name_from_url(git_url)
            
            # Verificar si ya existe una clave para este repo
            gpg_key = self._find_repo_gpg_key(repo_name)
            if not gpg_key:
                # Crear nueva clave GPG para este repo
                success, key_id = self.create_gpg_key(
                    name=f"SoplosLinux {repo_name} Repository",
                    email=f"{repo_name}@soplos.org"
                )
                if not success:
                    self.logger.error("Error creando clave GPG para el repositorio")
                    return False
                self.gpg_key = key_id
            else:
                self.gpg_key = gpg_key

            if not self.gpg_key:
                self.logger.error("Debe configurar una clave GPG primero")
                return False
                
            # Respaldar clave GPG existente
            old_gpg_key = self.gpg_key
            
            # Verificar URL
            if not git_url.endswith('.git'):
                git_url = f"{git_url.rstrip('/')}.git"
            
            self.git_url = git_url
            self.branch = branch or 'main'
            self.git_token = token

            if title:
                self.repo_title = title
            if list_name:
                self.list_filename = list_name

            # Restaurar clave GPG
            self.gpg_key = old_gpg_key
            
            # Construir URL con token si existe
            if token:
                auth_url = f"https://{token}@github.com/{git_url.split('github.com/')[-1]}"
            else:
                auth_url = git_url
            
            # Guardar configuración
            if not self.save_config():
                return False

            # Generar nombre de directorio único para este repo
            repo_name = self._get_repo_name_from_url(git_url)
            new_repo_dir = os.path.expanduser(f"~/apt-repos/{repo_name}")

            # Actualizar rutas
            self.repo_dir = new_repo_dir
            self.incoming_dir = os.path.join(self.repo_dir, "incoming")
            self.conf_dir = os.path.join(self.repo_dir, "conf")

            # No solicitar información para el README aquí
            # La solicitaremos después desde la ventana principal
            
            # Clonar/actualizar repositorio Git primero
            if not os.path.exists(os.path.join(self.repo_dir, ".git")):
                if os.path.exists(self.repo_dir):
                    shutil.rmtree(self.repo_dir)
                self.init_repo()
                
            # Crear estructura básica después de clonar
            os.makedirs(self.incoming_dir, exist_ok=True)
            os.makedirs(self.conf_dir, exist_ok=True)

            # Configurar reprepro
            dist_file = os.path.join(self.conf_dir, "distributions")
            with open(dist_file, "w") as f:
                f.write(f"""Origin: SoplosLinux
Label: SoplosLinux
Suite: stable
Codename: stable
Version: 1.0
Architectures: amd64
Components: main
Description: Repositorio de SoplosLinux
SignWith: {self.gpg_key}
Pull: stable
""")

            # Exportar clave pública
            key_file = os.path.join(self.repo_dir, "public.key")
            subprocess.run(
                ['gpg', '--armor', '--export', self.gpg_key],
                stdout=open(key_file, 'w'),
                check=True
            )
            
            # Inicializar índices
            self._initialize_indices()

            # Actualizar README con la nueva información
            self._ensure_readme()

            return True
                
        except Exception as e:
            self.logger.error(f"Error configurando repositorio: {e}")
            return False

    def _find_repo_gpg_key(self, repo_name):
        """Busca una clave GPG existente para el repositorio"""
        try:
            keys = self.select_gpg_key()
            for key in keys:
                if f"SoplosLinux {repo_name} Repository" in key.get('name', ''):
                    return key['id']
            return None
        except Exception as e:
            self.logger.error(f"Error buscando clave GPG: {e}")
            return None

    def init_repo(self):
        """Inicializa o clona el repositorio Git"""
        try:
            if not os.path.exists(os.path.join(self.repo_dir, ".git")):
                # Clonar el repositorio
                self.logger.info(f"Clonando repositorio desde {self.git_url}")
                git_url = self.get_repo_url()
                repo = git.Repo.clone_from(git_url, self.repo_dir)  # Usar git.Repo en lugar de Repo
                
                # Configurar la rama y el seguimiento
                branch = self.branch or 'main'
                git = repo.git
                
                # Verificar si la rama existe localmente
                try:
                    if branch not in repo.branches:
                        # Crear rama local si no existe
                        git.checkout('-b', branch)
                    else:
                        # Cambiar a la rama si ya existe
                        git.checkout(branch)
                except Exception as e:
                    self.logger.warning(f"Error al cambiar a la rama {branch}: {e}")
                    # Si hay error, crear la rama de todos modos
                    git.checkout('-b', branch)
                    
                # Configurar el seguimiento de la rama remota
                try:
                    git.branch('--set-upstream-to', f'origin/{branch}', branch)
                except Exception as e:
                    self.logger.warning(f"Error configurando seguimiento: {e}")
                
                # Si es un repo nuevo, hacer commit inicial si está vacío
                try:
                    if not repo.heads:
                        open(os.path.join(self.repo_dir, 'README.md'), 'w').write(f'# {os.path.basename(self.repo_dir)}\n\nRepositorio APT para Soplos Linux.')
                        repo.git.add('README.md')
                        repo.git.commit('-m', 'Commit inicial')
                        repo.git.push('--set-upstream', 'origin', branch)
                except Exception as e:
                    self.logger.warning(f"Error en commit inicial: {e}")
            else:
                # El repo ya existe, realizar pull
                repo = git.Repo(self.repo_dir)  # Usar git.Repo en lugar de Repo
                git = repo.git
                
                # Configurar el branch actual
                branch = self.branch or 'main'
                
                # Intentar cambiar a la rama solicitada
                try:
                    git.checkout(branch)
                except Exception as e:
                    self.logger.warning(f"Error cambiando a rama {branch}, creándola: {e}")
                    git.checkout('-b', branch)
                
                # Configurar el seguimiento correcto de rama si no está configurado
                try:
                    tracking_branch = repo.active_branch.tracking_branch()
                    if not tracking_branch or tracking_branch.name != f'origin/{branch}':
                        git.branch('--set-upstream-to', f'origin/{branch}', branch)
                except Exception as e:
                    self.logger.warning(f"Error configurando seguimiento: {e}")
                
                # Intentar realizar pull con estrategia de merge
                try:
                    git.pull('--ff-only')
                except Exception as e:
                    self.logger.warning(f"Pull inicial falló (normal si el repo está vacío): {e}")
                    # Intentar hacer rebase en caso de conflicto
                    try:
                        git.pull('--rebase')
                    except Exception as e2:
                        self.logger.warning(f"Pull con rebase también falló: {e2}")

            return True
        except Exception as e:
            self.logger.error(f"Error inicializando repositorio Git: {e}")
            raise RuntimeError(f"Error inicializando repositorio Git: {e}")

    def select_gpg_key(self):
        """Obtiene la lista de claves GPG disponibles"""
        try:
            result = subprocess.run(
                ['gpg', '--list-secret-keys', '--with-colons'],
                capture_output=True,
                text=True,
                check=True
            )
            keys = []
            current_key = {}
            
            for line in result.stdout.split('\n'):
                if line.startswith('sec:'):
                    if current_key:
                        keys.append(current_key)
                    parts = line.split(':')
                    current_key = {'id': parts[4], 'date': parts[5]}
                elif line.startswith('uid:') and current_key:  # Corregir &&
                    parts = line.split(':')
                    current_key['name'] = parts[9]
            
            if current_key:
                keys.append(current_key)
                
            return keys
            
        except subprocess.CalledProcessError:
            return []

    def create_gpg_key(self, name, email):
        """Crea una nueva clave GPG"""
        try:
            # Verificar si ya existe una clave con ese nombre
            keys = self.select_gpg_key()
            for key in keys:
                if name in key.get('name', ''):
                    return True, key['id']

            # Si no existe, crear nueva clave
            config = f"""Key-Type: RSA
Key-Length: 4096
Name-Real: {name}
Name-Email: {email}
Expire-Date: 0
%no-protection
%commit
"""
            config_file = os.path.expanduser("~/.gnupg/key-config")
            os.makedirs(os.path.dirname(config_file), exist_ok=True)
            
            with open(config_file, "w") as f:
                f.write(config)
                
            # Generar la clave
            self.logger.debug("Generando clave GPG...")
            result = subprocess.run(
                ['gpg', '--batch', '--generate-key', config_file],
                capture_output=True,
                text=True,
                check=True
            )
            
            # Obtener el ID de la clave recién generada
            self.logger.debug("Buscando ID de la clave generada...")
            list_result = subprocess.run(
                ['gpg', '--list-secret-keys', '--with-colons', email],
                capture_output=True,
                text=True,
                check=True
            )
            
            # Buscar la línea que comienza con 'sec:' y extraer el ID
            for line in list_result.stdout.split('\n'):
                if line.startswith('sec:'):
                    key_id = line.split(':')[4]
                    self.logger.info(f"Clave GPG generada con ID: {key_id}")
                    return True, key_id
                
            self.logger.error("No se pudo encontrar la clave generada")
            return False, "No se pudo encontrar la clave generada"
            
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Error ejecutando gpg: {e.stderr}")
            return False, f"Error ejecutando gpg: {e.stderr}"
        except Exception as e:
            self.logger.error(f"Error creando clave GPG: {str(e)}")
            return False, str(e)
        finally:
            if os.path.exists(config_file):
                os.remove(config_file)

    def delete_gpg_key(self, key_id):
        """Elimina una clave GPG"""
        try:
            # Primero verificar que no es la clave actual del repositorio
            if self.gpg_key == key_id:
                return False, "No se puede eliminar la clave actual del repositorio"

            # Obtener la huella digital completa de la clave
            result = subprocess.run(
                ['gpg', '--list-secret-keys', '--with-colons', key_id],
                capture_output=True,
                text=True,
                check=True
            )
            
            fingerprint = None
            for line in result.stdout.split('\n'):
                if line.startswith('fpr:'):  # fpr = fingerprint
                    fingerprint = line.split(':')[9]
                    break
                    
            if not fingerprint:
                return False, "No se pudo obtener la huella digital de la clave"

            # Eliminar clave usando la huella digital completa
            subprocess.run(
                ['gpg', '--batch', '--yes', '--delete-secret-and-public-key', fingerprint],
                check=True,
                capture_output=True
            )
            return True, "Clave eliminada correctamente"
            
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Error eliminando clave GPG: {e.stderr}")
            return False, str(e.stderr)
        except Exception as e:
            self.logger.error(f"Error eliminando clave GPG: {str(e)}")
            return False, str(e)

    def get_gpg_filename(self):
        """Genera un nombre de archivo GPG basado en el repositorio"""
        if self.git_url:
            # Extraer nombre del repo de la URL
            repo_name = self.git_url.split('/')[-1].replace('.git', '')
            return f"{repo_name}.gpg"
        return "repo.gpg"  # Nombre por defecto

    def _create_repo_structure(self):
        """Crea la estructura básica del repositorio APT"""
        try:
            if not self.gpg_key:
                self.logger.error("No hay clave GPG configurada")
                return False

            # 1. Crear directorios base con permisos correctos
            directories = [
                self.incoming_dir,
                os.path.join(self.repo_dir, "dists/stable/main/binary-amd64"),
                os.path.join(self.repo_dir, "pool/main"),
                os.path.join(self.repo_dir, "db"),
                self.conf_dir,
            ]
            
            for directory in directories:
                os.makedirs(directory, exist_ok=True)
                os.chmod(directory, 0o755)

            # 2. Configurar reprepro con SignWith válido
            dist_file = os.path.join(self.conf_dir, "distributions")
            with open(dist_file, "w") as f:
                f.write(f"""Origin: SoplosLinux
Label: SoplosLinux
Suite: stable
Codename: stable
Version: 1.0
Architectures: amd64
Components: main
Description: Repositorio de SoplosLinux
SignWith: {self.gpg_key or 'default'}
Pull: stable
""")
                os.chmod(dist_file, 0o644)

            # 3. Configurar options y incoming
            self._configure_reprepro()

            # 4. Exportar clave GPG
            key_file = os.path.join(self.repo_dir, "public.key")
            subprocess.run(
                ['gpg', '--armor', '--export', self.gpg_key],
                stdout=open(key_file, 'w'),
                check=True
            )
            os.chmod(key_file, 0o644)

            return True

        except Exception as e:
            self.logger.error(f"Error creando estructura: {str(e)}")
            return False

    def _configure_reprepro(self):
        """Configura los archivos necesarios para reprepro"""
        try:
            # 1. Crear archivo distributions si no existe
            dist_file = os.path.join(self.conf_dir, "distributions")
            if not os.path.exists(dist_file):
                with open(dist_file, "w") as f:
                    f.write(f"""Origin: SoplosLinux
Label: SoplosLinux
Suite: stable
Codename: stable
Version: 1.0
Architectures: amd64
Components: main
Description: Repositorio de SoplosLinux
SignWith: {self.gpg_key}
Pull: stable
""")
                os.chmod(dist_file, 0o644)

            # 2. Crear archivo options sin nogpgme
            options_file = os.path.join(self.conf_dir, "options")
            with open(options_file, "w") as f:
                f.write("""basedir .
verbose
ask-passphrase
""")
            os.chmod(options_file, 0o644)

            # 3. Crear archivo incoming
            incoming_file = os.path.join(self.conf_dir, "incoming")
            with open(incoming_file, "w") as f:
                f.write("""Name: default
IncomingDir: incoming
TempDir: tmp
Allow: stable
Cleanup: on_deny on_error
""")
            os.chmod(incoming_file, 0o644)

        except Exception as e:
            self.logger.error(f"Error configurando reprepro: e")
            raise

    def _initialize_indices(self):
        """Inicializa los índices de reprepro de forma segura"""
        try:
            # 1. Crear directorio temporal si no existe
            tmp_dir = os.path.join(self.repo_dir, "tmp")
            os.makedirs(tmp_dir, exist_ok=True)
            os.chmod(tmp_dir, 0o755)

            # 2. Limpiar y recrear estructura de directorios
            pool_dir = os.path.join(self.repo_dir, "pool/main")
            dists_dir = os.path.join(self.repo_dir, "dists/stable")
            for dir in [pool_dir, dists_dir]:
                os.makedirs(dir, exist_ok=True)
                os.chmod(dir, 0o755)

            # 3. Configurar conf/distributions
            dist_file = os.path.join(self.conf_dir, "distributions")
            with open(dist_file, 'w') as f:
                f.write(f"""Origin: SoplosLinux
Label: SoplosLinux
Suite: stable
Codename: stable
Version: 1.0
Architectures: amd64
Components: main
Description: Repositorio de SoplosLinux
SignWith: {self.gpg_key}
Pull: stable
""")

            # 4. Inicializar índices
            env = os.environ.copy()
            env['GNUPGHOME'] = os.path.expanduser('~/.gnupg')
            
            subprocess.run(
                ['reprepro', '-b', self.repo_dir, '--export=force', 'export'],
                check=True,
                capture_output=True,
                env=env
            )

            # 5. Ya no necesitamos corregir los índices porque los archivos tendrán el formato correcto
            # La función _fix_package_indices() ha sido eliminada

            # 6. Asegurar permisos correctos
            for root, dirs, files in os.walk(self.repo_dir):
                for d in dirs:
                    os.chmod(os.path.join(root, d), 0o755)
                for f in files:
                    os.chmod(os.path.join(root, f), 0o644)

        except subprocess.CalledProcessError as e:
            self.logger.error(f"Error en reprepro: {e.stderr.decode()}")
            raise
        except Exception as e:
            self.logger.error(f"Error inicializando índices: {e}")
            raise

    def verify_repository_structure(self):
        """Verifica que la estructura del repositorio es correcta"""
        try:
            # Verificar directorios requeridos
            required_dirs = [
                self.repo_dir,  # Verificar el directorio base primero
                self.incoming_dir,
                self.conf_dir,
                os.path.join(self.repo_dir, "db"),
                os.path.join(self.repo_dir, "dists"),
                os.path.join(self.repo_dir, "pool"),
            ]
            
            for directory in required_dirs:
                if not os.path.exists(directory):
                    self.logger.warning(f"Directorio faltante: {directory}")
                    return False
                    
            return True
            
        except Exception as e:
            self.logger.error(f"Error verificando estructura: {e}")
            return False

    def repair_repository(self):
        """Repara la estructura del repositorio si hay problemas"""
        try:
            if not self.gpg_key:
                return False, "Debe configurar una clave GPG primero"
                
            self.logger.info("Reparando estructura del repositorio...")

            # Asegurar directorios básicos
            os.makedirs(self.repo_dir, exist_ok=True)
            os.makedirs(self.incoming_dir, exist_ok=True)
            os.makedirs(self.conf_dir, exist_ok=True)

            # Recrear archivo distributions
            dist_file = os.path.join(self.conf_dir, "distributions")
            with open(dist_file, "w") as f:
                f.write(f"""Origin: SoplosLinux
Label: SoplosLinux
Suite: stable
Codename: stable
Version: 1.0
Architectures: amd64
Components: main
Description: Repositorio de SoplosLinux
SignWith: {self.gpg_key}
Pull: stable
""")

            # Inicializar repositorio con reprepro
            self.logger.info("Inicializando repositorio con reprepro")
            self._initialize_indices()

            # Recrear clave pública GPG
            key_file = os.path.join(self.repo_dir, "public.key")
            self.logger.info(f"Regenerando clave GPG pública: {key_file}")
            subprocess.run(
                ['gpg', '--armor', '--export', self.gpg_key],
                stdout=open(key_file, 'w'),
                check=True
            )

            # Asegurar README
            self._ensure_readme()

            return True, "Repositorio reparado correctamente"

        except subprocess.CalledProcessError as e:
            self.logger.error(f"Error en comando externo: {e.stderr}")
            return False, f"Error reparando repositorio: {e.stderr}"
        except Exception as e:
            self.logger.error(f"Error inesperado: {str(e)}")
            return False, f"Error reparando repositorio: {str(e)}"

    def _ensure_readme(self):
        """Actualiza el README.md con las instrucciones correctas"""
        try:
            # Si no existe el directorio del repo, salimos
            if not os.path.exists(self.repo_dir):
                self.logger.warning(f"No se puede actualizar README: El directorio {self.repo_dir} no existe")
                return False
                
            # Obtener URLs y valores necesarios
            raw_url = self.get_raw_url()
            if not raw_url:
                self.logger.warning("No se puede actualizar README: URL del repositorio no configurada")
                return False
                
            # Obtener nombre del repo de la URL
            repo_name = self._get_repo_name_from_url(self.git_url)
            
            # Generar nombres de archivo
            readme_path = os.path.join(self.repo_dir, "README.md")
            gpg_file = f"{repo_name}.gpg"
            list_file = self.list_filename or f"{repo_name}.list"
            
            # Construir la URL para sources.list con formato correcto para GitHub
            github_parts = []
            if 'github.com' in self.git_url:
                parts = self.git_url.split('github.com/')
                if len(parts) > 1:
                    # Extraer usuario/repo de la URL
                    user_repo = parts[1].replace('.git', '')
                    github_parts = user_repo.split('/')
            
            # Usar la URL con formato correcto para el sources.list
            if github_parts and len(github_parts) >= 2:
                owner = github_parts[0]
                repo = github_parts[1]
                branch = self.branch or 'main'
                sources_url = f"https://github.com/{owner}/{repo}/raw/refs/heads/{branch}"
            else:
                sources_url = raw_url

            # Asegurar que tenemos título y descripción con valores neutros
            if not hasattr(self, 'readme_title'):
                self.readme_title = "📦 Repositorio APT"  # Añadido emoji de caja
            elif not self.readme_title.startswith("📦"):
                self.readme_title = f"📦 {self.readme_title}"  # Añadir emoji si no lo tiene

            if not hasattr(self, 'repo_description'):
                self.repo_description = "Repositorio de paquetes APT"

            # Crear README básico si no existe
            with open(readme_path, "w") as f:
                f.write(f"""# {self.readme_title}

{self.repo_description}

## 🛠️ Instalación

### 1️⃣ Añadir la clave GPG
```bash
# Descargar e instalar la clave GPG
sudo mkdir -p /usr/share/keyrings
wget -qO - {raw_url}/public.key | sudo gpg --dearmor -o /usr/share/keyrings/{gpg_file}
```

### 2️⃣ Añadir el repositorio

```bash
# Añadir la fuente APT
echo "deb [signed-by=/usr/share/keyrings/{gpg_file} trusted=yes] {sources_url}/ stable main" | sudo tee /etc/apt/sources.list.d/{list_file}

# Actualizar índices
sudo apt update --allow-insecure-repositories
```

### 3️⃣ Instalar paquetes

```bash
sudo apt install nombre-del-paquete
```

## 🔍 Buscar paquetes disponibles
Para ver todos los paquetes disponibles:

```bash
apt search {repo_name}
```

## 🤝 Contribuir
¿Encontraste un error o tienes una sugerencia? ¡Abre un issue!

## 📝 Licencia
Este repositorio está bajo la licencia GPL-3.0.""")

            return True
        except Exception as e:
            self.logger.error(f"Error actualizando README: {e}")
            return False

    def ask_readme_info(self, parent_window=None):
        """Solicita información para personalizar el README usando GTK"""
        try:
            # Configuración básica por defecto con valores neutros
            self.repo_description = "Repositorio de paquetes APT"
            self.readme_title = "Repositorio APT"
            
            # Si estamos en modo CLI o hay algún problema con GTK, devolver config por defecto
            if not parent_window:
                return {
                    'title': self.readme_title,
                    'description': self.repo_description,
                    'links': {}
                }
                
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk

            dialog = Gtk.Dialog(
                title="Configuración del README",
                parent=parent_window,
                flags=0,
                buttons=(
                    "Cancelar", Gtk.ResponseType.CANCEL,
                    "Guardar", Gtk.ResponseType.OK
                )
            )
            dialog.set_default_size(500, 400)

            box = dialog.get_content_area()
            box.set_spacing(10)
            box.set_margin_start(10)
            box.set_margin_end(10)
            box.set_margin_top(10)
            box.set_margin_bottom(10)

            # Título del README (nuevo campo)
            title_label = Gtk.Label()
            title_label.set_markup("<b>Título del README:</b>")
            title_label.set_halign(Gtk.Align.START)
            box.pack_start(title_label, False, False, 0)

            title_entry = Gtk.Entry()
            title_entry.set_text(self.readme_title if hasattr(self, 'readme_title') else "Repositorio APT")
            box.pack_start(title_entry, False, False, 0)
            
            # Separador después del título
            box.pack_start(Gtk.Separator(), False, False, 5)

            # Descripción del repositorio
            desc_label = Gtk.Label()
            desc_label.set_markup("<b>Descripción del Repositorio:</b>")
            desc_label.set_halign(Gtk.Align.START)
            box.pack_start(desc_label, False, False, 0)

            desc_view = Gtk.TextView()
            desc_view.set_wrap_mode(Gtk.WrapMode.WORD)
            desc_buffer = desc_view.get_buffer()
            desc_buffer.set_text(self.repo_description if hasattr(self, 'repo_description') else "Repositorio de paquetes APT")
            
            scroll = Gtk.ScrolledWindow()
            scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            scroll.add(desc_view)
            scroll.set_size_request(-1, 100)
            box.pack_start(scroll, True, True, 0)

            # Separador
            box.pack_start(Gtk.Separator(), False, False, 10)

            # URLs
            urls_label = Gtk.Label()
            urls_label.set_markup("<b>Enlaces adicionales (opcional):</b>")
            urls_label.set_halign(Gtk.Align.START)
            box.pack_start(urls_label, False, False, 0)

            # Campos para URLs básicas
            entries = {}
            fields = {
                'website': ('🌐', "URL del sitio web:"),
                'docs': ('📚', "URL de la documentación:"), 
                'forum': ('💬', "URL del foro:"),
                'telegram': ('📱', "URL de Telegram:"),
                'matrix': ('💫', "URL de Matrix:")
            }

            # Grid para campos
            fields_grid = Gtk.Grid()
            fields_grid.set_column_spacing(10)
            fields_grid.set_row_spacing(5)
            box.pack_start(fields_grid, False, False, 0)

            row = 0
            for key, (icon, label) in fields.items():
                # Label con icono
                field_label = Gtk.Label(f"{icon} {label}")
                field_label.set_halign(Gtk.Align.START)
                
                # Entry para URL
                field_entry = Gtk.Entry()
                field_entry.set_hexpand(True)
                field_entry.set_placeholder_text(f"https://...")
                
                # Añadir al grid
                fields_grid.attach(field_label, 0, row, 1, 1)
                fields_grid.attach(field_entry, 1, row, 1, 1)
                
                entries[key] = field_entry
                row += 1

            box.show_all()
            response = dialog.run()
            
            result = {
                'title': "Repositorio APT",
                'description': "Repositorio de paquetes APT",
                'links': {}
            }
            
            if response == Gtk.ResponseType.OK:
                # Obtener título del README
                title_text = title_entry.get_text().strip()
                if title_text:
                    result['title'] = title_text
                    self.readme_title = title_text
                
                # Obtener texto de descripción
                start, end = desc_buffer.get_bounds()
                description = desc_buffer.get_text(start, end, False).strip()
                if description:
                    result['description'] = description
                    self.repo_description = description
                
                # Obtener URLs
                for key, entry in entries.items():
                    url = entry.get_text().strip()
                    if url:
                        result['links'][key] = url
            
            dialog.destroy()
            return result
        
        except Exception as e:
            self.logger.error(f"Error en diálogo de README: {e}")
            # En caso de error, devolver valores por defecto neutros
            self.readme_title = "Repositorio APT"
            self.repo_description = "Repositorio de paquetes APT"
            return {
                'title': self.readme_title,
                'description': self.repo_description,
                'links': {}
            }

    def list_packages(self):
        """Lista los paquetes del repositorio que están en GitHub"""
        try:
            if not hasattr(self, 'repo_dir') or not self.repo_dir or not self.git_url:
                return []
                
            packages = []
            seen_versions = set() # Para evitar duplicados
            
            # Primero buscar en pool local
            pool_dir = os.path.join(self.repo_dir, "pool/main")
            if (os.path.exists(pool_dir)):
                for root, dirs, files in os.walk(pool_dir):
                    for file in files:
                        if file.endswith('.deb'):
                            try:
                                # Obtener ruta completa
                                deb_path = os.path.join(root, file)
                                
                                # Obtener información del archivo usando dpkg-deb
                                result = subprocess.run(
                                    ['dpkg-deb', '-f', deb_path, 'Package', 'Version', 'Architecture', 'Section', 'Description'],
                                    capture_output=True,
                                    text=True,
                                    check=True
                                )
                                
                                # Dividir la salida por líneas
                                info = result.stdout.strip().split('\n')
                                
                                # Limpiar los prefijos "Package:", "Version:", etc.
                                pkg_name = info[0].replace("Package:", "").strip() if "Package:" in info[0] else info[0].strip()
                                pkg_version = info[1].replace("Version:", "").strip() if "Version:" in info[1] else info[1].strip()
                                pkg_arch = info[2].replace("Architecture:", "").strip() if "Architecture:" in info[2] else info[2].strip()
                                pkg_section = info[3].replace("Section:", "").strip() if "Section:" in info[3] else info[3].strip()
                                
                                # Procesar la descripción que puede ser multilínea
                                pkg_description = ""
                                for i in range(4, len(info)):
                                    line = info[i].replace("Description:", "").strip() if i == 4 and "Description:" in info[i] else info[i].strip()
                                    if pkg_description:
                                        pkg_description += " " + line
                                    else:
                                        pkg_description = line
                                
                                # Limitar descripción para la interfaz
                                if len(pkg_description) > 200:
                                    pkg_description = pkg_description[:197] + "..."
                                
                                # Crear clave única para evitar duplicados
                                pkg_key = f"{pkg_name}_{pkg_version}_{pkg_arch}"
                                
                                if pkg_key not in seen_versions:
                                    seen_versions.add(pkg_key)
                                    
                                    # Obtener fecha y tamaño del archivo
                                    stats = os.stat(deb_path)
                                    file_size = self._format_size(stats.st_size)
                                    mod_date = self._format_date(stats.st_mtime)
                                    
                                    packages.append({
                                        'name': pkg_name,
                                        'version': pkg_version,
                                        'arch': pkg_arch,
                                        'section': pkg_section,
                                        'description': pkg_description,
                                        'size': file_size,
                                        'date': mod_date,
                                        'status': 'Instalado'
                                    })
                                    
                            except Exception as e:
                                self.logger.warning(f"Error procesando {file}: {e}")
                                
            return packages
                    
        except Exception as e:
            self.logger.error(f"Error listando paquetes: {e}")
            return []

    def _format_size(self, size):
        """Formatea el tamaño del archivo"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"

    def _format_date(self, timestamp):
        """Formatea la fecha del archivo"""
        from datetime import datetime
        return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M')

    def add_package(self, deb_file):
        """Añade un paquete .deb al repositorio actual"""
        try:
            if not os.path.exists(deb_file):
                return False, "No se encuentra el archivo"

            # Obtener nombre y versión del paquete del nombre del archivo
            filename = os.path.basename(deb_file)
            pkg_name = filename.split('_')[0]
            pkg_version = filename.split('_')[1].split('.deb')[0]

            # Verificar si existe el paquete
            pool_dir = os.path.join(self.repo_dir, "pool/main")
            pkg_first_letter = pkg_name[0].lower()
            pkg_dir = os.path.join(pool_dir, pkg_first_letter, pkg_name)

            if os.path.exists(pkg_dir):
                # Eliminar versiones existentes
                for existing_file in os.listdir(pkg_dir):
                    if existing_file.endswith('.deb'):
                        existing_path = os.path.join(pkg_dir, existing_file)
                        try:
                            os.remove(existing_path)
                        except Exception as e:
                            self.logger.warning(f"No se pudo eliminar {existing_path}: {e}")

            # Copiar .deb a la estructura correcta pool/main/letra/paquete/
            os.makedirs(pkg_dir, exist_ok=True)
            dest_file = os.path.join(pkg_dir, os.path.basename(deb_file))
            shutil.copy2(deb_file, dest_file)

            # Extraer el paquete en un directorio temporal
            extract_dir = tempfile.mkdtemp(prefix=f"soplos-{pkg_name}-")
            try:
                # Extraer el paquete
                subprocess.run(
                    ['dpkg-deb', '-x', deb_file, extract_dir],
                    check=True,
                    capture_output=True
                )
                
                # Extraer también el directorio DEBIAN para obtener el control
                debian_dir = os.path.join(extract_dir, 'DEBIAN')
                os.makedirs(debian_dir, exist_ok=True)
                subprocess.run(
                    ['dpkg-deb', '-e', deb_file, debian_dir],
                    check=True,
                    capture_output=True
                )
                
                # Procesar los archivos del paquete (metainfo, icons, screenshots)
                self._process_package_files(extract_dir, pkg_name)
                
            finally:
                # Limpiar directorio temporal
                if os.path.exists(extract_dir):
                    shutil.rmtree(extract_dir)

            # Incluir en el repositorio usando reprepro
            try:
                subprocess.run(
                    ['reprepro', '-b', self.repo_dir, 'includedeb', 'stable', dest_file],
                    check=True,
                    capture_output=True
                )
            except subprocess.CalledProcessError as e:
                return False, f"Error al incluir paquete en reprepro: {e.stderr.decode()}"

            # Exportar los índices y generar metadatos AppStream
            try:
                subprocess.run(
                    ['reprepro', '-b', self.repo_dir, '--export=force', 'export'],
                    check=True,
                    capture_output=True
                )
                
                # Generar metadatos AppStream
                self._generate_appstream_data()
                
            except subprocess.CalledProcessError as e:
                return False, f"Error al exportar índices: {e.stderr.decode()}"

            return True, f"Paquete {pkg_name} versión {pkg_version} procesado correctamente"

        except Exception as e:
            self.logger.error(f"Error procesando paquete: {str(e)}")
            return False, str(e)

    def _process_package_files(self, extract_dir, pkg_name):
        """Procesa los archivos extraídos del .deb"""
        try:
            # 1. Crear directorios necesarios
            appstream_dir = os.path.join(self.repo_dir, "appstream")
            media_dir = os.path.join(self.repo_dir, "media", pkg_name)
            os.makedirs(appstream_dir, exist_ok=True)
            os.makedirs(os.path.join(media_dir, "icons"), exist_ok=True)
            os.makedirs(os.path.join(media_dir, "screenshots"), exist_ok=True)

            # 2. Buscar archivos metainfo/appdata
            metainfo_found = False
            icon_found = False
            screenshot_found = False
            
            # Procesar todos los archivos para encontrar metainfo y screenshots
            for root, _, files in os.walk(extract_dir):
                for file in files:
                    # Procesar metainfo/appdata
                    if file.endswith(('.metainfo.xml', '.appdata.xml')):
                        src = os.path.join(root, file)
                        dst = os.path.join(appstream_dir, f"{pkg_name}.metainfo.xml")
                        shutil.copy2(src, dst)
                        self.logger.info(f"Archivo metainfo copiado: {file} a {dst}")
                        metainfo_found = True
                    
                    # Buscar screenshots en cualquier ubicación
                    if file.endswith(('.png', '.jpg', '.jpeg')) and ('screenshot' in file.lower() or 'screen-' in file.lower()):
                        src = os.path.join(root, file)
                        dst = os.path.join(media_dir, "screenshots", file)
                        shutil.copy2(src, dst)
                        self.logger.info(f"Screenshot copiado: {file} a {dst}")
                        screenshot_found = True

            # Buscar iconos en ubicaciones estándar
            icon_paths = [
                'usr/share/icons/hicolor/128x128/apps',
                'usr/share/icons/hicolor/scalable/apps',
                'usr/share/pixmaps',
                'usr/share/icons',
                'usr/share/app-install/icons'
            ]
            
            for icon_path in icon_paths:
                full_path = os.path.join(extract_dir, icon_path)
                if os.path.exists(full_path):
                    for icon_file in os.listdir(full_path):
                        if icon_file.endswith(('.png', '.svg', '.xpm')):
                            src = os.path.join(full_path, icon_file)
                            dst = os.path.join(media_dir, "icons", icon_file)
                            shutil.copy2(src, dst)
                            self.logger.info(f"Icono copiado: {icon_file} a {dst}")
                            icon_found = True
                
                if icon_found:
                    break
            
            # Buscar screenshots en ubicaciones específicas
            screenshot_paths = [
                'usr/share/screenshots',
                'usr/share/pixmaps/screenshots',
                'usr/share/app-install/screenshots',
                'usr/share/doc/' + pkg_name + '/screenshots',
                'opt/' + pkg_name + '/screenshots'
            ]
            
            for screenshot_path in screenshot_paths:
                full_path = os.path.join(extract_dir, screenshot_path)
                if os.path.exists(full_path):
                    for screenshot_file in os.listdir(full_path):
                        if screenshot_file.endswith(('.png', '.jpg', '.jpeg')):
                            src = os.path.join(full_path, screenshot_file)
                            dst = os.path.join(media_dir, "screenshots", screenshot_file)
                            shutil.copy2(src, dst)
                            self.logger.info(f"Screenshot copiado desde ubicación específica: {screenshot_file} a {dst}")
                            screenshot_found = True

            # Si no se encuentra metainfo, crear uno básico
            if not metainfo_found:
                self._create_basic_metainfo(pkg_name, extract_dir)

            # Si no se encuentra icono, usar uno por defecto
            if not icon_found:
                default_icon = "/usr/share/icons/hicolor/128x128/apps/package.png"
                if os.path.exists(default_icon):
                    dst = os.path.join(media_dir, "icons", f"{pkg_name}.png")
                    shutil.copy2(default_icon, dst)
                    self.logger.info(f"Usando icono por defecto para {pkg_name}")
        
            # Log informativo sobre screenshots
            if screenshot_found:
                self.logger.info(f"Se encontraron y copiaron screenshots para {pkg_name}")
            else:
                self.logger.info(f"No se encontraron screenshots para {pkg_name}")

        except Exception as e:
            self.logger.error(f"Error procesando archivos: {e}")
            raise

    def _create_basic_metainfo(self, pkg_name, extract_dir):
        """Crea un archivo metainfo básico basado en la información del paquete"""
        try:
            # Obtener información básica del paquete
            control_file = os.path.join(extract_dir, 'DEBIAN/control')
            pkg_info = {}
            
            if os.path.exists(control_file):
                with open(control_file, 'r') as f:
                    for line in f:
                        if ':' in line:
                            key, value = line.split(':', 1)
                            pkg_info[key.strip()] = value.strip()

            # Crear archivo metainfo básico con el formato correcto
            metainfo_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright 2024 SoplosLinux -->
<component type="desktop-application">
  <id>{pkg_name}</id>
  <metadata_license>MIT</metadata_license>
  <project_license>{pkg_info.get('License', 'GPL-3.0')}</project_license>
  <name>{pkg_info.get('Package', pkg_name)}</name>
  <summary>{pkg_info.get('Description', '').split('\n')[0]}</summary>
  <description>
    <p>{pkg_info.get('Description', '')}</p>
  </description>
  <categories>
    <category>Utility</category>
  </categories>
  <developer_name>{pkg_info.get('Maintainer', 'SoplosLinux')}</developer_name>
  <update_contact>{pkg_info.get('Maintainer', 'admin@soplos.org')}</update_contact>
  <project_group>SoplosLinux</project_group>
  <launchable type="desktop-id">{pkg_name}.desktop</launchable>
  <releases>
    <release version="{pkg_info.get('Version', '1.0.0')}" date="{datetime.now().strftime('%Y-%m-%d')}"/>
  </releases>
</component>"""

            metainfo_file = os.path.join(self.repo_dir, "appstream", f"{pkg_name}.metainfo.xml")
            with open(metainfo_file, 'w') as f:
                f.write(metainfo_content)

        except Exception as e:
            self.logger.error(f"Error creando metainfo básico: {e}")
            raise

    def clean_repository(self):
        """Limpia los paquetes del repositorio manteniendo la configuración"""
        try:
            self.logger.debug("Iniciando limpieza del repositorio...")
            
            # 1. Asegurar que tenemos el .gitignore correcto
            self._ensure_gitignore()
            
            # 2. Respaldar archivos importantes
            key_files = {
                'public.key': os.path.join(self.repo_dir, "public.key"),
                'soplos.gpg': os.path.join(self.repo_dir, "soplos.gpg"),
                'distributions': os.path.join(self.conf_dir, "distributions")
            }
            
            backups = {}
            for name, path in key_files.items():
                if os.path.exists(path):
                    with open(path, 'rb') as f:
                        backups[name] = f.read()
                        
            # 3. Limpiar directorios
            dirs_to_clean = [
                os.path.join(self.repo_dir, "pool"),
                os.path.join(self.repo_dir, "db"),
                os.path.join(self.repo_dir, "dists"),
                os.path.join(self.repo_dir, "media"),  # Añadido directorio media
                os.path.join(self.repo_dir, "appstream")  # Añadido directorio appstream
            ]
            
            for dir_path in dirs_to_clean:
                if os.path.exists(dir_path):
                    shutil.rmtree(dir_path)
                    os.makedirs(dir_path, exist_ok=True)
            
            # Asegurar que existen los directorios necesarios
            os.makedirs(os.path.join(self.repo_dir, "pool/main"), exist_ok=True)
            os.makedirs(os.path.join(self.repo_dir, "media"), exist_ok=True)
            os.makedirs(os.path.join(self.repo_dir, "appstream"), exist_ok=True)
                
            # 4. Restaurar archivos importantes
            for name, content in backups.items():
                path = key_files[name]
                with open(path, 'wb') as f:
                    f.write(content)
                    
            # 5. Actualizar índices de reprepro
            subprocess.run(
                ['reprepro', '-b', self.repo_dir, '--export=force', 'export'],
                check=True,
                capture_output=True
            )
            
            # 6. Commit y push a GitHub
            repo = git.Repo(self.repo_dir)  # Usar git.Repo en lugar de Repo
            
            # Solo añadir los directorios permitidos
            dirs_to_push = ['pool/', 'appstream/', 'media/', 'dists/', 'public.key', 'README.md']
            for dir_path in dirs_to_push:
                full_path = os.path.join(self.repo_dir, dir_path)
                if os.path.exists(full_path):
                    repo.git.add(dir_path)
            
            repo.index.commit("Limpieza completa del repositorio")
            remote_url = f"https://{self.git_token}@github.com/{self.git_url.split('github.com/')[-1]}"
            repo.git.push('-f', remote_url, f'HEAD:{self.branch}')
            
            self.logger.debug("Repositorio limpiado correctamente")
            return True, "Repositorio limpiado completamente"
            
        except Exception as e:
            self.logger.error(f"Error limpiando repositorio: {str(e)}")
            return False, str(e)

    def _configure_logging(self):
        """Configura el logging para evitar información sensible"""
        class TokenFilter(logging.Filter):
            def filter(self, record):
                if hasattr(record, 'msg'):
                    if isinstance(record.msg, str):
                        if '@' in record.msg:
                            record.msg = record.msg.replace(record.msg.split('@')[0], '***')
                return True

        self.logger.addFilter(TokenFilter())

    def check_package_in_github(self, package_name):
        """Verifica si un paquete existe en el repositorio remoto"""
        try:
            # Construir URL base del repositorio
            url = self.get_clean_url()
            
            # Verificación para evitar error de índice
            if not url:
                self.logger.warning("URL del repositorio no configurada")
                return False
                
            url = url.replace('.git', '')
            
            # Asegurar que tenemos la rama correcta
            branch = self.branch or 'main'
            
            # Construir URL correctamente usando la rama
            url = f"{url}/raw/{branch}/pool/main/"
            
            # Verificar primera letra del paquete
            if not package_name or len(package_name) == 0:
                self.logger.warning("Nombre de paquete inválido")
                return False
                
            first_letter = package_name[0].lower()
            url = f"{url}/{first_letter}/{package_name}/"
            
            # Usar git ls-remote para verificar existencia
            if self.git_token:
                auth_url = url.replace('https://', f'https://{self.git_token}@')
                result = subprocess.run(
                    ['git', 'ls-remote', auth_url],
                    capture_output=True,
                    text=True
                )
                return result.returncode == 0
            else:
                # Alternativa usando wget si no hay token
                result = subprocess.run(
                    ['wget', '--spider', '--quiet', url],
                    capture_output=True,
                    text=True
                )
                return result.returncode == 0
        except Exception as e:
            self.logger.error(f"Error verificando paquete en GitHub: {e}")
            return False

    def get_package_details(self, package_name):
        """Obtiene detalles de un paquete específico"""
        try:
            details = {}
            
            # 1. Buscar primero en el directorio appstream
            appstream_file = os.path.join(self.repo_dir, "appstream", f"{package_name}.metainfo.xml")
            
            if os.path.exists(appstream_file):
                # Parsear el archivo metainfo.xml
                import xml.etree.ElementTree as ET
                tree = ET.parse(appstream_file)
                root = tree.getroot()
                
                # Extraer información básica
                details = self._extract_metadata_from_xml(root)
                self.logger.info(f"Información de {package_name} obtenida desde appstream")
                
                # Buscar el .deb para complementar con tamaño y fecha
                deb_path = self._find_deb_file(package_name)
                if deb_path:
                    details['Ruta del archivo'] = deb_path
                    file_size = os.path.getsize(deb_path)
                    details['Tamaño del archivo'] = self._format_size(file_size)
                    mod_time = os.path.getmtime(deb_path)
                    details['Fecha de modificación'] = self._format_date(mod_time)
                    
                    # Añadir info adicional desde dpkg-deb si es necesario
                    try:
                        result = subprocess.run(
                            ['dpkg-deb', '-I', deb_path],
                            capture_output=True,
                            text=True,
                            check=True
                        )
                        
                        # Buscar campos que no estén en el metainfo
                        for line in result.stdout.splitlines():
                            line = line.strip()
                            if ': ' in line:
                                key, value = line.split(': ', 1)
                                key = key.strip()
                                value = value.strip()
                                
                                # Mapear claves en inglés a español
                                key_mapping = {
                                    'Installed-Size': 'Tamaño instalado',
                                    'Depends': 'Dependencias',
                                    'Priority': 'Prioridad',
                                }
                                
                                if key in key_mapping and key_mapping[key] not in details:
                                    details[key_mapping[key]] = value
                    except:
                        # Si falla, no es crítico, ya tenemos la info básica
                        pass
                    
                return details
            
            # 2. Si no encuentra appstream, buscar el archivo .deb
            deb_path = self._find_deb_file(package_name)
            if not deb_path:
                self.logger.warning(f"No se encontró el archivo .deb para {package_name}")
                return {
                    'Nombre': package_name,
                    'Estado': 'No disponible localmente',
                    'Nota': 'No se encontró el archivo .deb ni metadatos en el repositorio'
                }

            # 3. Extraer información del archivo .deb
            result = subprocess.run(
                ['dpkg-deb', '-I', deb_path],
                capture_output=True,
                text=True,
                check=True
            )
            
            details = {
                'Nombre': package_name,
                'Versión': 'Desconocida',
                'Arquitectura': 'Desconocida',
                'Sección': 'Desconocida',
                'Descripción': 'Sin descripción',
                'Mantenedor': 'Desconocido',
                'Tamaño instalado': 'Desconocido',
                'Dependencias': 'Ninguna'
            }
            
            # 4. Analizar la salida del comando
            for line in result.stdout.splitlines():
                line = line.strip()
                if ': ' in line:
                    key, value = line.split(': ', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # Mapear claves en inglés a español
                    key_mapping = {
                        'Package': 'Nombre',
                        'Version': 'Versión',
                        'Architecture': 'Arquitectura',
                        'Section': 'Sección',
                        'Description': 'Descripción',
                        'Maintainer': 'Mantenedor',
                        'Installed-Size': 'Tamaño instalado',
                        'Depends': 'Dependencias',
                        'Priority': 'Prioridad',
                        'Homepage': 'Página web'
                    }
                    
                    if key in key_mapping:
                        details[key_mapping[key]] = value
            
            # 5. Añadir información adicional
            if os.path.exists(deb_path):
                file_size = os.path.getsize(deb_path)
                details['Tamaño del archivo'] = self._format_size(file_size)
                
                mod_time = os.path.getmtime(deb_path)
                details['Fecha de modificación'] = self._format_date(mod_time)
                
                details['Ruta del archivo'] = deb_path
                
            return details
            
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Error obteniendo detalles del paquete: {e.stderr}")
            return {
                'Nombre': package_name,
                'Error': f"Error al leer información: {e.stderr}"
            }
        except Exception as e:
            self.logger.error(f"Error inesperado en get_package_details: {str(e)}")
            return {
                'Nombre': package_name,
                'Error': f"Error inesperado: {str(e)}"
            }
    
    def _extract_metadata_from_xml(self, root):
        """Extrae información de un archivo metainfo.xml"""
        details = {
            'Nombre': '',
            'Versión': 'Desconocida',
            'Descripción': 'Sin descripción',
            'Desarrollador': 'Desconocido'
        }
        
        # Mapeo de etiquetas XML a claves en español
        xml_mapping = {
            'id': 'ID',
            'name': 'Nombre',
            'summary': 'Resumen',
            'description': 'Descripción',
            'project_license': 'Licencia',
            'metadata_license': 'Licencia de metadatos',
            'developer_name': 'Desarrollador',
            'update_contact': 'Contacto',
            'project_group': 'Grupo'
        }
        
        # Extraer valores básicos
        for xml_tag, key in xml_mapping.items():
            element = root.find(xml_tag)
            if element is not None and element.text:
                if xml_tag == 'description':
                    # Para la descripción, procesamos párrafos anidados
                    desc_text = []
                    for p in element.findall(".//p"):
                        if p.text and p.text.strip():
                            desc_text.append(p.text.strip())
                    if desc_text:
                        details[key] = "\n\n".join(desc_text)
                    elif element.text and element.text.strip():
                        details[key] = element.text.strip()
                else:
                    details[key] = element.text.strip()
        
        # Extraer URLs
        urls = {}
        for url_element in root.findall("url"):
            url_type = url_element.get('type')
            if url_type and url_element.text:
                url_name = {
                    'homepage': 'Página web',
                    'bugtracker': 'Informe de errores',
                    'help': 'Ayuda',
                    'donation': 'Donaciones',
                    'translate': 'Traducción'
                }.get(url_type, url_type)
                urls[url_name] = url_element.text.strip()
        
        # Añadir URLs al diccionario principal
        details.update(urls)
        
        # Extraer categorías
        categories = []
        for cat in root.findall(".//category"):
            if cat.text and cat.text.strip():
                categories.append(cat.text.strip())
        
        if categories:
            details['Categorías'] = ", ".join(categories)
        
        # Extraer versiones de los releases
        releases = []
        for release in root.findall(".//release"):
            version = release.get('version')
            date = release.get('date')
            if version:
                release_info = f"Versión {version}"
                if date:
                    release_info += f" ({date})"
                releases.append(release_info)
        
        if releases:
            details['Historial de versiones'] = "\n".join(releases)
            # Usar la versión más reciente como la versión principal
            if 'Versión' not in details or details['Versión'] == 'Desconocida':
                details['Versión'] = releases[0].replace("Versión ", "").split(" ")[0]
        
        return details
    
    def _find_deb_file(self, package_name):
        """Busca el archivo .deb de un paquete en el repositorio"""
        # Limpiar el nombre del paquete si contiene "Package:" (error común)
        if package_name.startswith("Package: "):
            original_name = package_name
            package_name = package_name.replace("Package: ", "").strip()
            self.logger.debug(f"Nombre de paquete corregido: '{original_name}' → '{package_name}'")
        
        # Buscar en pool/main/letra/nombre/
        pool_dir = os.path.join(self.repo_dir, "pool/main")
        if not os.path.exists(pool_dir):
            self.logger.info(f"Directorio pool/main no encontrado: {pool_dir}")
            return None
            
        # Método 1: Buscar directamente por la ruta estándar: pool/main/letra/nombre/
        if len(package_name) > 0:
            pkg_first_letter = package_name[0].lower()
            possible_dir = os.path.join(pool_dir, pkg_first_letter, package_name)
            
            self.logger.debug(f"Buscando en directorio: {possible_dir}")
            
            if os.path.exists(possible_dir):
                # Listar todos los archivos .deb en ese directorio
                deb_files = [f for f in os.listdir(possible_dir) if f.endswith(".deb")]
                self.logger.debug(f"Archivos .deb encontrados: {deb_files}")
                
                for deb_file in deb_files:
                    if deb_file.startswith(f"{package_name}_"):
                        return os.path.join(possible_dir, deb_file)
        
        # Método 2: Buscar en todo el directorio pool/ por patrón de nombre
        self.logger.debug(f"Buscando {package_name} en todo el directorio pool/")
        for root, _, files in os.walk(pool_dir):
            deb_files = [f for f in files if f.endswith(".deb") and f.startswith(f"{package_name}_")]
            if deb_files:
                self.logger.debug(f"Archivo encontrado: {deb_files[0]} en {root}")
                return os.path.join(root, deb_files[0])
                    
        # Método 3: Verificar con dpkg-deb todos los archivos .deb
        self.logger.debug(f"Verificando todos los archivos .deb para encontrar {package_name}")
        for root, _, files in os.walk(pool_dir):
            for file in files:
                if file.endswith(".deb"):
                    try:
                        result = subprocess.run(
                            ['dpkg-deb', '-f', os.path.join(root, file), 'Package'],
                            capture_output=True,
                            text=True,
                            check=True
                        )
                        result_pkg = result.stdout.strip()
                        if result_pkg == package_name:
                            self.logger.debug(f"Encontrado mediante dpkg-deb: {file} en {root}")
                            return os.path.join(root, file)
                    except Exception as e:
                        # Ignorar errores al leer archivos
                        self.logger.debug(f"Error verificando {file}: {e}")
                        pass
        
        self.logger.warning(f"No se encontró el archivo .deb para {package_name}")
        return None

    def remove_package(self, package_name):
        """Elimina un paquete específico del repositorio"""
        try:
            self.logger.info(f"Eliminando {package_name} de reprepro...")
            
            # 1. Asegurar que tenemos el .gitignore correcto
            self._ensure_gitignore()
            
            # Lista de archivos eliminados
            deleted_files = []
            
            # Limpiar el nombre del paquete si contiene "Package:" (error común)
            if package_name.startswith("Package: "):
                original_name = package_name
                package_name = package_name.replace("Package: ", "").strip()
                self.logger.info(f"Nombre de paquete corregido: '{original_name}' → '{package_name}'")
            
            # 2. Eliminar archivos físicos del pool
            pool_dir = os.path.join(self.repo_dir, "pool/main")
            if len(package_name) == 0:
                raise ValueError("Nombre de paquete vacío")
                
            pkg_first_letter = package_name[0].lower()
            package_dir = os.path.join(pool_dir, pkg_first_letter, package_name)
            
            package_found = False
            
            # Buscar en estructura estándar pool/main/letra/paquete/
            if os.path.exists(package_dir):
                self.logger.info(f"Eliminando directorio del paquete: {package_dir}")
                for root, dirs, files in os.walk(package_dir):
                    for file in files:
                        deleted_files.append(os.path.join(root, file))
                shutil.rmtree(package_dir)
                package_found = True

            # Buscar en todo pool/ por nombre de paquete (para casos que no siguen estructura estándar)
            if not package_found and os.path.exists(pool_dir):
                self.logger.info(f"Buscando archivos del paquete {package_name} en todo pool/")
                for root, dirs, files in os.walk(pool_dir):
                    # Buscar archivos que coincidan con el patrón del paquete
                    package_files = [f for f in files if f.startswith(f"{package_name}_") and f.endswith('.deb')]
                    if package_files:
                        for file in package_files:
                            file_path = os.path.join(root, file)
                            self.logger.info(f"Eliminando archivo de paquete: {file_path}")
                            os.remove(file_path)
                            deleted_files.append(file_path)
                            package_found = True

            # 3. Eliminar metadatos (appstream)
            metainfo_file = os.path.join(self.repo_dir, "appstream", f"{package_name}.metainfo.xml")
            if os.path.exists(metainfo_file):
                self.logger.info(f"Eliminando archivo metainfo: {metainfo_file}")
                os.remove(metainfo_file)
                deleted_files.append(metainfo_file)
                package_found = True

            # 4. Eliminar archivos multimedia
            media_dir = os.path.join(self.repo_dir, "media", package_name)
            if os.path.exists(media_dir):
                self.logger.info(f"Eliminando directorio multimedia: {media_dir}")
                shutil.rmtree(media_dir)
                deleted_files.append(media_dir)
                package_found = True

            # 5. Eliminar de reprepro y regenerar índices
            try:
                self.logger.info(f"Eliminando {package_name} de la base de datos reprepro")
                result = subprocess.run(
                    ['reprepro', '-b', self.repo_dir, 'remove', 'stable', package_name],
                    capture_output=True,
                    text=True,
                    check=True
                )
                self.logger.debug(f"Salida de reprepro remove: {result.stdout}")
                
                # Regenerar índices
                self.logger.info(f"Regenerando índices de reprepro")
                result = subprocess.run(
                    ['reprepro', '-b', self.repo_dir, '--export=force', 'export'],
                    capture_output=True,
                    text=True,
                    check=True
                )
                self.logger.debug(f"Salida de reprepro export: {result.stdout}")
                package_found = True
                
            except subprocess.CalledProcessError as e:
                self.logger.error(f"Error de reprepro: {e.stderr}")
                # No salir con error aquí, intentar continuar con el resto del proceso

            # Regenerar metadatos AppStream después de eliminar el paquete
            self._generate_appstream_data()
            
            # 6. Commit y push solo si se eliminaron archivos o se encontró el paquete
            if deleted_files or package_found:
                try:
                    repo = git.Repo(self.repo_dir)  # Usar git.Repo en lugar de Repo
                    
                    # Solo añadir los directorios permitidos
                    dirs_to_push = ['pool/', 'appstream/', 'media/', 'dists/', 'public.key', 'README.md']
                    for dir_path in dirs_to_push:
                        full_path = os.path.join(self.repo_dir, dir_path)
                        if os.path.exists(full_path):
                            repo.git.add(dir_path)
                    
                    repo.index.commit(f"Eliminado paquete: {package_name}")
                    
                    # Usar la URL con token para push
                    if self.git_token:
                        remote_url = f"https://{self.git_token}@{self.git_url.split('https://')[-1]}"
                    else:
                        remote_url = self.git_url
                    
                    self.logger.info(f"Subiendo cambios a la rama {self.branch}")
                    repo.git.push('-f', remote_url, f'HEAD:{self.branch}')
                    
                    self.logger.info(f"Paquete {package_name} eliminado correctamente")
                    return
                    
                except Exception as e:
                    self.logger.error(f"Error en Git: {str(e)}")
                    raise RuntimeError(f"Error al subir cambios a Git: {str(e)}")
            else:
                if not package_found:
                    error_msg = f"No se encontró el paquete {package_name}"
                    self.logger.warning(error_msg)
                    raise ValueError(error_msg)
                else:
                    error_msg = f"No se eliminaron archivos para el paquete {package_name}"
                    self.logger.warning(error_msg)
                    # No lanzar error si se encontró el paquete pero no se eliminaron archivos
                    # Podría ser un caso donde solo existía en la base de datos de reprepro
                    return
                
        except Exception as e:
            self.logger.error(f"Error eliminando paquete: {str(e)}")
            raise RuntimeError(f"Error al eliminar el paquete {package_name}: {str(e)}")

    def remove_package_version(self, package_name, version):
        """Elimina una versión específica de un paquete"""
        try:
            # 1. Asegurar que tenemos el .gitignore correcto
            self._ensure_gitignore()
            
            # 2. Eliminar el paquete con reprepro
            result = subprocess.run(
                ['reprepro', '-b', self.repo_dir, 'remove', 'stable', package_name],
                capture_output=True,
                text=True
            )
            
            # 3. Eliminar el archivo .deb específico
            pool_dir = os.path.join(self.repo_dir, "pool/main")
            deleted = False
            if os.path.exists(pool_dir):
                target_file = f"{package_name}_{version}"
                for root, _, files in os.walk(pool_dir):
                    for file in files:
                        if file.startswith(target_file) and file.endswith(".deb"):
                            os.remove(os.path.join(root, file))
                            deleted = True
                            
            if not deleted:
                return False, f"No se encontró el archivo para {package_name} versión {version}"
                
            # 4. Actualizar índices
            subprocess.run(
                ['reprepro', '-b', self.repo_dir, '--export=force', 'export'],
                check=True,
                capture_output=True
            )
            
            # 5. Commit y push
            repo = git.Repo(self.repo_dir)  # Usar git.Repo en lugar de Repo
            
            # Solo añadir los directorios permitidos
            dirs_to_push = ['pool/', 'appstream/', 'media/', 'dists/', 'public.key', 'README.md']
            for dir_path in dirs_to_push:
                full_path = os.path.join(self.repo_dir, dir_path)
                if os.path.exists(full_path):
                    repo.git.add(dir_path)
            
            repo.index.commit(f"Eliminado {package_name} versión {version}")
            remote_url = f"https://{self.git_token}@github.com/{self.git_url.split('github.com/')[-1]}"
            repo.git.push('-f', remote_url, f'HEAD:{self.branch}')
            
            return True, f"Versión {version} de {package_name} eliminada correctamente"
            
        except subprocess.CalledProcessError as e:
            return False, f"Error de reprepro: {e.stderr}"
        except Exception as e:
            return False, f"Error: {str(e)}"

    def _update_readme(self):
        """Actualiza el README con las instrucciones correctas de instalación"""
        try:
            readme_path = os.path.join(self.repo_dir, "README.md")
            repo_url = self.get_clean_url().replace('.git', '').rstrip('/')
            branch = self.branch or 'main'
            gpg_file = self.get_gpg_filename()
            
            # Cargar configuración del README si existe
            readme_config = os.path.join(os.path.dirname(self.config_file), 'readme_config.json')
            links = {}
            if not os.path.exists(readme_config):
                links = self.ask_readme_info()
            else:
                with open(readme_config, 'r') as f:
                    links = json.load(f)
                    
            # Generar sección de links solo si hay alguno configurado
            links_section = ""
            if any(links.values()):
                links_section = "\n## 🔗 Links útiles\n\n"
                if links.get('website'): links_section += f"- [🌐 Sitio web]({links['website']})\n"
                if links.get('docs'): links_section += f"- [📚 Documentación]({links['docs']})\n" 
                if links.get('forum'): links_section += f"- [💬 Foro]({links['forum']})\n"
                if links.get('telegram'): links_section += f"- [📱 Telegram]({links['telegram']})\n"
                if links.get('matrix'): links_section += f"- [💫 Matrix]({links['matrix']})\n"
                
            with open(readme_path, "w") as f:
                f.write(f"""# 📦 Repositorio SoplosLinux APT

Repositorio oficial de paquetes para SoplosLinux.

## ⚡ Características

- 🔒 Paquetes firmados con GPG
- 🔄 Actualizaciones automáticas vía APT
- 🚀 Alto rendimiento y velocidad
- 💻 Compatibilidad total con Debian/Ubuntu

## 🛠️ Instalación

### 1️⃣ Añadir la clave GPG

```bash
# Descargar e instalar la clave GPG
sudo mkdir -p /usr/share/keyrings
wget -qO - {repo_url}/raw/{branch}/public.key | sudo gpg --dearmor -o /usr/share/keyrings/{gpg_file}
```

### 2️⃣ Añadir el repositorio

```bash
# Añadir la fuente APT
echo "deb [signed-by=/usr/share/keyrings/{gpg_file}] {repo_url}/raw/{branch}/ stable main" > /etc/apt/sources.list.d/soploslinux.list

# Actualizar índices
sudo apt update
```

### 3️⃣ Instalar paquetes

```bash
sudo apt install nombre-del-paquete
```

## 🔍 Buscar paquetes disponibles

Para ver todos los paquetes disponibles:

```bash
apt search soplos
```

## 🤝 Contribuir

¿Encontraste un error o tienes una sugerencia? ¡Abre un issue!

## 📝 Licencia

Este repositorio está bajo la licencia GPL-3.0.
{links_section}""")
                
        except Exception as e:
            self.logger.error(f"Error actualizando README: {e}")

    def verify_repo_integrity(self):
        """Verifica la integridad del repositorio"""
        try:
            issues = []
            packages = self.list_packages()

            # Verificar índices
            result = subprocess.run(
                ['reprepro', '-b', self.repo_dir, 'check'],
                capture_output=True,
                text=True
            )

            # Agrupar por nombre de paquete
            pkg_versions = {}
            for pkg in packages:
                name = pkg.get('name')
                if name:
                    if name not in pkg_versions:
                        pkg_versions[name] = []
                    pkg_versions[name].append(pkg.get('version'))

            return True

        except Exception as e:
            self.logger.error(f"Error verificando integridad: {e}")
            return False

    def save_current_profile(self, name):
        """Guarda la configuración actual como un perfil"""
        try:
            if not self.git_url or not self.git_token:
                return False, "Se requiere URL y token de GitHub"

            if not self.gpg_key:
                return False, "Se requiere una clave GPG"

            # Crear directorio único basado en el nombre del repositorio
            repo_name = self.git_url.split('/')[-1].replace('.git', '')
            self.repo_dir = os.path.expanduser(f"~/apt-repos/{repo_name}")
            
            # Guardar datos del perfil con su configuración específica
            profile_data = {
                'git_url': self.git_url,
                'branch': self.branch,
                'gpg_key': self.gpg_key,
                'git_token': self.git_token,
                'repo_dir': self.repo_dir,
                'repo_title': self.repo_title,
                'list_filename': self.list_filename
            }

            # Crear estructura específica para este perfil
            os.makedirs(self.repo_dir, exist_ok=True)
            os.makedirs(os.path.join(self.repo_dir, "incoming"), exist_ok=True)
            os.makedirs(os.path.join(self.repo_dir, "conf"), exist_ok=True)
            
            # Guardar el perfil y establecerlo como activo
            success = self.profile_manager.save_profile(name, profile_data)
            if success:
                self.current_profile = name
                self.profile_manager.set_current_profile(name)
            
            # Inicializar el repositorio para este perfil
            self._create_repo_structure()
            self.init_repo()

            return success

        except Exception as e:
            self.logger.error(f"Error guardando perfil: {e}")
            return False

    def load_profile(self, name):
        """Carga un perfil existente"""
        try:
            profile = self.profile_manager.get_profile(name)
            if profile:
                self.git_url = profile['git_url']
                self.branch = profile['branch'] 
                self.gpg_key = profile['gpg_key']
                self.git_token = profile['git_token']
                self.repo_dir = profile['repo_dir']
                
                # Asegurarse de cargar estos campos del perfil también
                if 'repo_title' in profile:
                    self.repo_title = profile['repo_title']
                else:
                    self.repo_title = 'Repositorio APT'
                    
                if 'list_filename' in profile:
                    self.list_filename = profile['list_filename']
                else:
                    repo_name = profile['git_url'].split('/')[-1].replace('.git', '')
                    self.list_filename = f"{repo_name}.list"
                
                # Para el readme
                if 'readme_title' in profile:
                    self.readme_title = profile['readme_title']
                    
                if 'repo_description' in profile:
                    self.repo_description = profile['repo_description']
                
                self.incoming_dir = os.path.join(self.repo_dir, "incoming")
                self.conf_dir = os.path.join(self.repo_dir, "conf")
                
                # Establecer como perfil activo
                self.current_profile = name
                self.profile_manager.set_current_profile(name)
                
                # Verificar y reparar estructura si es necesario
                if not self.verify_repository_structure():
                    self.repair_repository()
                    
                return True
            return False
        except Exception as e:
            self.logger.error(f"Error cargando perfil: {e}")
            return False

    def _ensure_gitignore(self):
        """Asegura que existe un .gitignore con las exclusiones correctas"""
        gitignore_path = os.path.join(self.repo_dir, '.gitignore')
        ignored_paths = [
            'db/',
            'conf/',
            'tmp/',
            'incoming/',
            '*.pyc',
            '__pycache__/',
            '.DS_Store'
        ]
        
        try:
            # Crear o actualizar .gitignore
            with open(gitignore_path, 'w') as f:
                f.write('\n'.join(ignored_paths))
            
            # Solo intentar el git rm si el repo está inicializado y tiene archivos
            repo = git.Repo(self.repo_dir)  # Usar git.Repo en lugar de Repo
            if os.path.exists(os.path.join(self.repo_dir, ".git")):
                try:
                    # Verificar si hay archivos tracked
                    if repo.head.commit.tree:
                        repo.git.rm('-r', '--cached', '.')
                except Exception as e:
                    self.logger.debug(f"No hay archivos que limpiar del cache: {e}")
                    
        except Exception as e:
            self.logger.error(f"Error configurando .gitignore: {e}")

    def push_changes(self):
        """Sube los cambios al repositorio remoto"""
        success = False
        message = ""
        
        # Importación tardía para evitar circular
        from src.utils.git_utils import ensure_repo_attributes, setup_git_lfs, check_repo_for_large_files
        
        try:
            # Asegurar que tenemos todos los atributos necesarios
            ensure_repo_attributes(self)
            
            # Verificar archivos grandes antes de intentar subir
            large_files = check_repo_for_large_files(self.repo_dir, 40)
            if large_files:
                self.logger.warning(f"Se encontraron {len(large_files)} archivos grandes. Configurando Git LFS...")
                
                # Configurar Git LFS y convertir archivos existentes
                if setup_git_lfs(self.repo_dir):
                    self.logger.info("Git LFS configurado correctamente")
                else:
                    self.logger.error("No se pudo configurar Git LFS")
            
            # Repo es una instancia de GitPython
            repo = git.Repo(self.repo_dir)
            
            # Preparar URL remota con token
            remote_url = self.remote_url
            if self.github_token:
                remote_url = remote_url.replace('https://', f'https://{self.github_token}@')
            
            # Git add, commit y push
            repo.git.add('--all')
            
            # Commit solo si hay cambios
            if repo.is_dirty() or len(repo.untracked_files) > 0:
                repo.git.commit('-m', 'Actualizar repositorio')
            
            # Push
            output = repo.git.push('--force', remote_url, f'HEAD:{self.branch}')
            self.logger.info(f"Push completado: {output}")
            success = True
            message = "Cambios subidos correctamente"
            
        except git.exc.GitCommandError as e:
            self.logger.error(f"Error subiendo cambios: {e}")
            success = False
            message = str(e)
        except Exception as e:
            self.logger.error(f"Error general: {e}")
            success = False
            message = str(e)
        
        return success, message

    def _generate_appstream_data(self):
        """Genera el archivo Components-amd64.xml.gz para GNOME Software y Discover"""
        try:
            # Verificar que appstream-util está instalado
            if subprocess.run(['which', 'appstream-util'], capture_output=True).returncode != 0:
                self.logger.warning("appstream-util no está instalado. Los metadatos pueden no ser óptimos.")

            # Crear directorios necesarios
            dep11_dir = os.path.join(self.repo_dir, "dists/stable/main/dep11")
            os.makedirs(dep11_dir, exist_ok=True)
            
            # Verificar archivos metainfo
            appstream_dir = os.path.join(self.repo_dir, "appstream")
            if not os.path.exists(appstream_dir):
                os.makedirs(appstream_dir, exist_ok=True)
                self.logger.warning(f"Directorio appstream no encontrado. Creado: {appstream_dir}")
                return False
                
            xml_files = [f for f in os.listdir(appstream_dir) if f.endswith('.xml')]
            if not xml_files:
                self.logger.warning("No hay archivos metainfo.xml en el directorio appstream.")
                return False

            # Generar Components-amd64.xml directamente
            output_xml = os.path.join(dep11_dir, "Components-amd64.xml")
            
            # Header del archivo con DOCTYPE correcto para AppStream
            with open(output_xml, 'w') as f:
                f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
                f.write('<!DOCTYPE components PUBLIC "-//freedesktop//DTD AppStream Collection 0.7//EN" "https://www.freedesktop.org/software/appstream/docs/collection.dtd">\n')
                f.write('<components version="0.7">\n')
            
            # Añadir cada componente
            for xml_file in xml_files:
                file_path = os.path.join(appstream_dir, xml_file)
                try:
                    # Leer el archivo XML
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # Extraer el elemento <component> y sus contenidos
                    import re
                    component_match = re.search(r'<component[^>]*>.*?</component>', content, re.DOTALL)
                    if component_match:
                        component_xml = component_match.group(0)
                        # Añadir al archivo de salida
                        with open(output_xml, 'a', encoding='utf-8') as out:
                            out.write("  " + component_xml.replace("\n", "\n  ") + "\n")
                    else:
                        # Si no se encuentra el tag component, intentar agregar el archivo completo
                        # pero quitando el XML header y cualquier DOCTYPE
                        content = re.sub(r'<\?xml[^>]+\?>', '', content)
                        content = re.sub(r'<!DOCTYPE[^>]+>', '', content)
                        with open(output_xml, 'a', encoding='utf-8') as out:
                            out.write("  " + content.strip().replace("\n", "\n  ") + "\n")
                        self.logger.warning(f"No se encontró tag <component> en {xml_file}, se añadió el contenido completo")
                except Exception as e:
                    self.logger.error(f"Error procesando {xml_file}: {str(e)}")
            
            # Cerrar el archivo XML
            with open(output_xml, 'a') as f:
                f.write('</components>\n')

            # Validar el archivo XML si tenemos appstream-util
            if subprocess.run(['which', 'appstream-util'], capture_output=True).returncode == 0:
                validate_result = subprocess.run(
                    ['appstream-util', 'validate', output_xml],
                    capture_output=True,
                    text=True
                )
                
                if validate_result.returncode != 0:
                    self.logger.warning(f"Validación de AppStream falló: {validate_result.stderr}")
                else:
                    self.logger.info("Archivo AppStream validado correctamente")

            # Comprimir Components-amd64.xml
            subprocess.run(['gzip', '-f', output_xml], check=True)
            
            # Asegurar permisos correctos para que APT pueda leerlo
            os.chmod(f"{output_xml}.gz", 0o644)
            
            # Generar archivo de iconos Icons-64x64.tar.gz
            self._generate_appstream_icons(dep11_dir)
            
            self.logger.info(f"Metadatos AppStream generados correctamente: {output_xml}.gz")
            return True

        except Exception as e:
            self.logger.error(f"Error generando metadatos AppStream: {str(e)}")
            return False

    def _generate_appstream_icons(self, dep11_dir):
        """Genera el archivo Icons-64x64.tar.gz con los iconos de los paquetes"""
        try:
            # Ruta del archivo a generar
            icons_path = os.path.join(dep11_dir, "Icons-64x64.tar.gz")
            
            # Buscar iconos en media/*/icons/
            media_dir = os.path.join(self.repo_dir, "media")
            if not os.path.exists(media_dir):
                # Crear un archivo tar.gz vacío pero válido
                self._create_empty_icons_tarball(icons_path)
                return
                
            # Crear un directorio temporal para los iconos
            import tempfile
            temp_dir = tempfile.mkdtemp(prefix="soplos-icons-")
            
            # Variable para indicar si se encontraron iconos
            icons_found = False
            
            try:
                # Recopilar iconos de la carpeta media
                for pkg_dir in os.listdir(media_dir):
                    pkg_icons_dir = os.path.join(media_dir, pkg_dir, "icons")
                    if os.path.isdir(pkg_icons_dir):
                        for icon_file in os.listdir(pkg_icons_dir):
                            if icon_file.endswith('.png') or icon_file.endswith('.svg'):
                                # Copiar el icono al directorio temporal
                                icon_path = os.path.join(pkg_icons_dir, icon_file)
                                # Crear directorio de destino si no existe
                                icon_dest_dir = os.path.join(temp_dir, pkg_dir)
                                os.makedirs(icon_dest_dir, exist_ok=True)
                                shutil.copy2(icon_path, os.path.join(icon_dest_dir, icon_file))
                                icons_found = True
                
                # También buscar iconos en la ruta del repositorio Soplos si está disponible
                tyron_media_dir = "/soplos/apt-repos/tyron/media"
                if os.path.exists(tyron_media_dir):
                    for app_dir in os.listdir(tyron_media_dir):
                        app_icons_dir = os.path.join(tyron_media_dir, app_dir, "icons")
                        if os.path.isdir(app_icons_dir):
                            for icon_file in os.listdir(app_icons_dir):
                                if icon_file.endswith('.png') or icon_file.endswith('.svg'):
                                    # Copiar el icono al directorio temporal
                                    icon_path = os.path.join(app_icons_dir, icon_file)
                                    # Crear directorio de destino si no existe
                                    icon_dest_dir = os.path.join(temp_dir, app_dir.replace('-', ''))
                                    os.makedirs(icon_dest_dir, exist_ok=True)
                                    shutil.copy2(icon_path, os.path.join(icon_dest_dir, icon_file))
                                    icons_found = True
                
                # Crear archivo tar.gz con los iconos
                if icons_found:
                    with tarfile.open(icons_path, "w:gz") as tar:
                        tar.add(temp_dir, arcname=".")
                    os.chmod(icons_path, 0o644)
                    self.logger.info(f"Archivo de iconos generado: {icons_path}")
                else:
                    self._create_empty_icons_tarball(icons_path)
                    
            finally:
                # Limpiar directorio temporal
                shutil.rmtree(temp_dir)
        
        except Exception as e:
            self.logger.error(f"Error generando archivo de iconos: {str(e)}")
            self._create_empty_icons_tarball(icons_path)

    def _create_empty_icons_tarball(self, icons_path):
        """Crea un archivo tar.gz vacío pero válido para Icons-64x64.tar.gz"""
        import tarfile
        import tempfile
        
        # Crear directorio temporal vacío
        temp_dir = tempfile.mkdtemp()
        try:
            with tarfile.open(icons_path, "w:gz") as tar:
                # Añadir el directorio temporal como un directorio vacío en el archivo
                tar.add(temp_dir, arcname=".")
            # Establecer permisos correctos
            os.chmod(icons_path, 0o644)
            self.logger.info(f"Creado archivo de iconos vacío: {icons_path}")
        finally:
            # Limpiar el directorio temporal
            shutil.rmtree(temp_dir)

    def generate_install_script(self):
        """Genera el contenido del script de instalación"""
        try:
            if not hasattr(self, 'repo_dir') or not self.repo_dir:
                raise ValueError("RepoManager no está inicializado")

            # Verificar si hay que cargar datos del perfil
            if self.current_profile:
                profile = self.profile_manager.get_profile(self.current_profile)
                if profile:
                    # Actualizar los valores desde el perfil
                    if 'git_url' in profile:
                        self.git_url = profile['git_url']
                    if 'branch' in profile:
                        self.branch = profile['branch']
                    if 'repo_title' in profile:
                        self.repo_title = profile['repo_title']
                    if 'list_filename' in profile:
                        self.list_filename = profile['list_filename']

            # Obtener URLs correctas
            raw_url = self.get_raw_url()
            if not raw_url:
                raise ValueError("URL del repositorio no configurada")
            
            # Usar valores del repo o valores por defecto
            repo_name = self.git_url.split('/')[-1].replace('.git', '') if self.git_url else 'apt-repo'
            branch = self.branch or 'main'
            
            # Usar valores específicos del repositorio configurado
            list_file = self.list_filename or f"{repo_name}.list"
            repo_title = self.repo_title or repo_name
            gpg_file = f"{repo_name}.gpg"  # Usar nombre del repo para el archivo GPG
            
            # Extraer componentes de la URL para construir la URL correcta para GitHub
            github_parts = []
            if 'github.com' in self.git_url:
                parts = self.git_url.split('github.com/')
                if len(parts) > 1:
                    # Extraer usuario/repo de la URL
                    user_repo = parts[1].replace('.git', '')
                    # Construir la URL con formato correcto para raw en refs/heads
                    github_parts = user_repo.split('/')
            
            # Construir la URL para sources.list con formato correcto para GitHub
            if github_parts and len(github_parts) >= 2:
                owner = github_parts[0]
                repo = github_parts[1]
                sources_url = f"https://github.com/{owner}/{repo}/raw/refs/heads/{branch}"
            else:
                # Fallback a la URL raw normal
                sources_url = raw_url

            script = f"""#!/bin/bash
# Script de instalación para repositorio {repo_name}

# Colores para mensajes
GREEN="\\033[0;32m"
RED="\\033[0;31m"
NC="\\033[0m"

# Verificar si se ejecuta como root
if [ "$(id -u)" != "0" ]; then
    echo -e "${{RED}}Este script debe ejecutarse como root${{NC}}"
    exit 1
fi

# Crear directorio de llavero GPG
mkdir -p /usr/share/keyrings

# Descargar e importar clave GPG
echo -e "${{GREEN}}Descargando clave GPG...${{NC}}"
if ! wget -qO - {raw_url}/public.key | gpg --dearmor -o /usr/share/keyrings/{gpg_file}; then
    echo -e "${{RED}}Error al descargar la clave GPG${{NC}}"
    exit 1
fi

# Verificar que la clave se descargó correctamente
if [ ! -s /usr/share/keyrings/{gpg_file} ]; then
    echo -e "${{RED}}Error: La clave GPG está vacía o no se instaló${{NC}}"
    exit 1
fi

# Configurar repositorio
echo -e "${{GREEN}}Configurando repositorio...${{NC}}"
echo "deb [signed-by=/usr/share/keyrings/{gpg_file} trusted=yes] {sources_url}/ stable main" > /etc/apt/sources.list.d/{list_file}

# Forzar actualización segura
echo -e "${{GREEN}}Actualizando índices...${{NC}}"
rm -f /var/lib/apt/lists/*{repo_name}*
apt-get update --allow-insecure-repositories

# Verificar que el repositorio está configurado
if ! apt-cache policy | grep -q "{sources_url}"; then
    echo -e "${{RED}}Error: El repositorio no se configuró correctamente${{NC}}"
    exit 1
fi

echo -e "${{GREEN}}¡Repositorio instalado correctamente!${{NC}}"
"""
            return script

        except Exception as e:
            self.logger.error(f"Error generando script: {e}")
            return """#!/bin/bash
# Error en la generación del script
echo "Error: No se pudo generar el script correctamente."
echo "Por favor contacte al administrador del repositorio."
exit 1
"""
