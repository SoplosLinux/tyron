#!/usr/bin/env python3

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib
import os
import threading
import logging
import sys
import subprocess
from pathlib import Path

# Acceder a las funciones del módulo principal
main_dir = Path(__file__).parent.parent.parent
sys.path.insert(0, str(main_dir))
import main as repo_manager_main

logger = logging.getLogger(__name__)

class LargeFileHandlerDialog(Gtk.Dialog):
    """Diálogo para manejar archivos demasiado grandes para GitHub"""
    
    def __init__(self, parent, repo_path, large_files):
        super().__init__(
            title="Archivos grandes detectados",
            transient_for=parent,
            flags=0
        )
        
        self.repo_path = repo_path
        self.large_files = large_files
        self.set_default_size(550, 400)
        
        self.add_buttons(
            "Cancelar", Gtk.ResponseType.CANCEL,
            "Configurar Git LFS", Gtk.ResponseType.OK
        )
        
        # Contenido del diálogo
        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(15)
        box.set_margin_bottom(15)
        box.set_margin_start(15)
        box.set_margin_end(15)
        
        # Mensaje principal
        title_label = Gtk.Label()
        title_label.set_markup("<b>Se han detectado archivos demasiado grandes para GitHub</b>")
        title_label.set_halign(Gtk.Align.START)
        box.pack_start(title_label, False, False, 5)
        
        explanation = Gtk.Label(
            label="GitHub tiene un límite de 100MB por archivo. Para archivos más grandes "
                  "se necesita Git LFS (Large File Storage). Git LFS almacena estos archivos "
                  "por separado del repositorio principal."
        )
        explanation.set_line_wrap(True)
        explanation.set_halign(Gtk.Align.START)
        box.pack_start(explanation, False, False, 5)
        
        # Lista de archivos grandes
        files_frame = Gtk.Frame(label="Archivos grandes detectados")
        box.pack_start(files_frame, True, True, 5)
        
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(150)
        files_frame.add(scrolled)
        
        liststore = Gtk.ListStore(str, float, str)  # path, size_mb, formatted_size
        for file_path, size_mb in large_files:
            formatted_size = f"{size_mb:.2f} MB"
            # Obtener ruta relativa
            rel_path = os.path.relpath(file_path, self.repo_path) if os.path.isabs(file_path) else file_path
            liststore.append([rel_path, size_mb, formatted_size])
        
        treeview = Gtk.TreeView(model=liststore)
        
        # Columna para la ruta
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Archivo", renderer_text, text=0)
        column.set_expand(True)
        column.set_resizable(True)
        treeview.append_column(column)
        
        # Columna para el tamaño
        renderer_text = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("Tamaño", renderer_text, text=2)
        column.set_alignment(0.5)
        treeview.append_column(column)
        
        scrolled.add(treeview)
        
        # Opciones adicionales
        options_frame = Gtk.Frame(label="Opciones")
        box.pack_start(options_frame, False, False, 5)
        
        options_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        options_box.set_margin_top(5)
        options_box.set_margin_bottom(5)
        options_box.set_margin_start(5)
        options_box.set_margin_end(5)
        options_frame.add(options_box)
        
        self.clean_history = Gtk.CheckButton(
            label="Limpiar historial Git (recomendado si los archivos estaban en commits anteriores)"
        )
        self.clean_history.set_active(True)
        options_box.pack_start(self.clean_history, False, False, 0)
        
        self.show_all()
    
    def configure_lfs_and_clean(self):
        """Configura Git LFS y limpia el historial si es necesario"""
        try:
            # Configurar Git LFS
            if not repo_manager_main.setup_git_lfs(self.repo_path):
                return False, "No se pudo configurar Git LFS"
            
            # Limpiar historial si está marcada la opción
            if self.clean_history.get_active():
                if not repo_manager_main.clean_git_history(self.repo_path):
                    return False, "Se configuró Git LFS pero no se pudo limpiar el historial"
            
            # Convertir archivos existentes a LFS
            repo_manager_main.convert_existing_to_lfs(self.repo_path)
            
            return True, "Git LFS configurado correctamente"
        except Exception as e:
            logger.error(f"Error en configure_lfs_and_clean: {e}")
            return False, f"Error: {e}"
