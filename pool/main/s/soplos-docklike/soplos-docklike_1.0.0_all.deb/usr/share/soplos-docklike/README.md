# Soplos Dock Manager

## 📝 Descripción
Herramienta oficial de Soplos Linux para gestionar el plugin Docklike en XFCE4, permitiendo una organización eficiente de los iconos del panel.

## ✨ Características
- 🔄 Organización de iconos por drag & drop
- ➕ Gestión de aplicaciones ancladas
- 🔍 Buscador integrado de aplicaciones
- ⌨️ Atajos de teclado personalizables
- 🌍 Soporte multiidioma
- 📱 Interfaz adaptativa

## 🛠️ Requisitos
- XFCE 4.14+
- Python 3.6+
- GTK+ 3.0
- Plugin Docklike para XFCE

## 📥 Instalación

### Vía APT (recomendado)
```bash
sudo apt install soplos-docklike
```

### Desde Fuente
```bash
git clone https://github.com/SoplosLinux/tyron
```

## ⌨️ Atajos de Teclado
- **Ctrl+S**: Guardar cambios
- **Ctrl+Q**: Salir
- **Alt+↑**: Mover icono arriba
- **Alt+↓**: Mover icono abajo
- **Delete**: Eliminar icono
- **Ctrl+A**: Añadir aplicación

## 🔧 Dependencias
- PyGObject >= 3.36.0
- pycairo >= 1.16.0
- dbus-python >= 1.2.16
- GTK+ 3.0
- gettext >= 0.20.0
- xfconf >= 4.14.0

## 🌍 Idiomas
- 🇪🇸 Español (es)
- 🇬🇧 Inglés (en)
- 🇫🇷 Francés (fr)
- 🇩🇪 Alemán (de)
- 🇮🇹 Italiano (it)
- 🇵🇹 Portugués (pt)
- 🇷🇴 Rumano (ro)
- 🇷🇺 Ruso (ru)

## 📞 Contacto
- **Web**: https://soploslinux.com/
- **GitHub**: https://github.com/SoplosLinux
- **Email**: info@soploslinux.com

## 📄 Licencia
GPL-3.0 © 2024 Soplos Team
