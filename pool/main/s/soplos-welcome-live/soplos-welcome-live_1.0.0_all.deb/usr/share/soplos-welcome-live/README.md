# Soplos Welcome

Welcome screen application for Soplos Linux. This application helps new users configure their system and install commonly used software.

## Features

- Software Center integration
- Driver management
- System customization tools
- Recommended software installation
- Multi-language support (8 languages)
- Hardware detection and configuration
- Locale and keyboard layout configuration
- CHROOT recovery tools
- Integration with GParted for disk management
- Autostart toggle for the welcome screen
- NumLock activation toggle

## Project Information

- **GitHub Repository**: [https://github.com/SoplosLinux](https://github.com/SoplosLinux)
- **Website**: [https://soploslinux.com/](https://soploslinux.com/)
- **Contact Email**: [info@soploslinux.com](mailto:info@soploslinux.com)

## Installation

```bash
sudo apt install soplos-welcome
```

## Development

Requirements:
- Python 3.9+
- GTK 3
- PyGObject
- Additional dependencies listed in requirements.txt

## License

This project is licensed under GPL-3.0
