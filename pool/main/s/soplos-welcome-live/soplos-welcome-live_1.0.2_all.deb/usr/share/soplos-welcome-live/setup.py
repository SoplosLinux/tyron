from setuptools import setup, find_packages

setup(
    name="soplos-welcome-live",
    version="2023.2",
    packages=find_packages(),
    install_requires=[
        'PyGObject>=3.40.0',
    ],
    data_files=[
        ('share/icons/hicolor/128x128/apps', ['assets/icons/soplos-welcome-live.png'])
    ],
    entry_points={
        'console_scripts': [
            'soplos-welcome-live=main:main',
        ],
    },
    author="Soplos Linux Team",
    author_email="info@soplos.org",
    description="Welcome screen for Soplos Linux Live Environment",
    license="GPL-3.0",
)
