import os
import shutil

def clean_pycache():
    """Limpia todos los archivos __pycache__ del proyecto"""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for root, dirs, files in os.walk(base_dir):
        if '__pycache__' in dirs:
            shutil.rmtree(os.path.join(root, '__pycache__'))
