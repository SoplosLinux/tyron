#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Configurar variables de entorno antes de importar GTK
import os
import sys

# Prevenir la creación de archivos .pyc desde el inicio
sys.dont_write_bytecode = True

# Definir base_dir como variable global al inicio
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

os.environ['NO_AT_BRIDGE'] = '1'
os.environ['GTK_MODULES'] = ''
os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''

import gi
import shutil
import subprocess  # Añadir esta importación
import atexit  # Añadir para limpieza al salir

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gio  # Añadir Gio
from ui.main_window import MainWindow
from config.strings import STRINGS
from config.paths import ICON_PATH  # Añadir esta importación

def clean_pycache():
    """Limpia todos los archivos __pycache__, .pyc y .pyo del proyecto"""
    # Usar la variable global BASE_DIR
    base_dir = BASE_DIR
    
    # Lista de patrones a limpiar
    patterns_to_clean = [
        '**/__pycache__',
        '**/*.pyc',
        '**/*.pyo',
        '**/*.pyd'
    ]
    
    import glob
    
    for pattern in patterns_to_clean:
        full_pattern = os.path.join(base_dir, pattern)
        
        # Buscar archivos/carpetas que coincidan con el patrón
        try:
            matches = glob.glob(full_pattern, recursive=True)
            
            for match in matches:
                try:
                    if os.path.isdir(match):
                        shutil.rmtree(match, ignore_errors=True)
                        print(f"Eliminada carpeta: {match}")
                    elif os.path.isfile(match):
                        os.remove(match)
                        print(f"Eliminado archivo: {match}")
                except (OSError, PermissionError) as e:
                    print(f"No se pudo eliminar {match}: {e}")
        except Exception:
            continue  # Ignorar errores de glob
    
    # Limpieza adicional manual para directorios específicos
    specific_dirs = ['utils', 'ui', 'config', 'core']
    for dir_name in specific_dirs:
        try:
            dir_path = os.path.join(base_dir, dir_name)
            if os.path.exists(dir_path):
                pycache_path = os.path.join(dir_path, '__pycache__')
                if os.path.exists(pycache_path):
                    try:
                        shutil.rmtree(pycache_path, ignore_errors=True)
                        print(f"Eliminada carpeta específica: {pycache_path}")
                    except Exception as e:
                        print(f"Error eliminando {pycache_path}: {e}")
        except Exception:
            continue

def aggressive_cleanup():
    """Limpieza agresiva que se ejecuta continuamente"""
    try:
        # Usar la variable global BASE_DIR en lugar de __file__
        base_dir = BASE_DIR
        
        # Buscar y eliminar cualquier __pycache__ que aparezca
        for root, dirs, files in os.walk(base_dir):
            try:
                for dir_name in dirs[:]:  # usar slice para poder modificar la lista
                    if dir_name == '__pycache__':
                        pycache_path = os.path.join(root, dir_name)
                        try:
                            shutil.rmtree(pycache_path, ignore_errors=True)
                            dirs.remove(dir_name)  # remover de la lista para no volver a procesarlo
                            print(f"Eliminado automáticamente: {pycache_path}")
                        except:
                            pass
                
                # Eliminar archivos .pyc individuales
                for file_name in files:
                    if file_name.endswith(('.pyc', '.pyo', '.pyd')):
                        file_path = os.path.join(root, file_name)
                        try:
                            os.remove(file_path)
                            print(f"Eliminado archivo: {file_path}")
                        except:
                            pass
            except Exception:
                continue  # Continuar con el siguiente directorio
    except Exception:
        pass  # Ignorar errores silenciosamente en cleanup

def get_system_locale():
    """Obtiene el locale del sistema"""
    # Primero intentar leer de locale.conf
    if os.path.exists('/etc/locale.conf'):
        try:
            with open('/etc/locale.conf', 'r') as f:
                for line in f:
                    if line.startswith('LANG='):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
    
    # Si no existe o falla, usar la variable LANG o default en_US.UTF-8
    return os.getenv('LANG', 'en_US.UTF-8')

def get_language_code():
    """Obtiene el código de idioma del sistema y devuelve uno válido"""
    current_locale = get_system_locale()
    
    # Si es C.UTF-8 o similar, usar inglés por defecto
    if current_locale.startswith('C.') or current_locale == 'C':
        return 'en'
    
    # Obtener el código de idioma (primeras dos letras)
    lang_code = current_locale.split('_')[0]
    
    # Verificar si el código existe en STRINGS, si no, usar inglés
    return lang_code if lang_code in STRINGS else 'en'

# Añadir esta función para verificar el entorno
def check_environment():
    """Verifica y configura el entorno necesario"""
    # Verificar usuario
    if os.getenv('USER') != 'liveuser':
        print("Warning: No se está ejecutando como liveuser")
    
    # Verificar variables críticas
    required_vars = {
        'DISPLAY': ':0',
        'XAUTHORITY': os.path.expanduser('~/.Xauthority'),
        'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
        'XDG_SESSION_TYPE': 'x11',
        'LANG': os.getenv('LANG', 'en_US.UTF-8')
    }
    
    for var, default in required_vars.items():
        if not os.getenv(var):
            os.environ[var] = default

def diagnose_locale():
    """Diagnostica la configuración de locale del sistema"""
    print("\n=== Diagnóstico de Locale ===")
    
    # 1. Variable LANG
    print(f"LANG={os.getenv('LANG', 'no definido')}")
    
    # 2. Contenido de /etc/default/locale
    try:
        with open('/etc/default/locale', 'r') as f:
            print("\n/etc/default/locale:")
            print(f.read().strip())
    except:
        print("\n/etc/default/locale: no existe o no es accesible")
    
    # 3. Locales generados
    try:
        output = subprocess.check_output(['locale', '-a'], text=True)
        print("\nLocales disponibles:")
        print(output.strip())
    except:
        print("\nError al obtener locales disponibles")
    
    # 4. Estado actual de locale
    try:
        output = subprocess.check_output(['locale'], text=True)
        print("\nEstado actual de locale:")
        print(output.strip())
    except:
        print("\nError al obtener estado de locale")
    
    print("\n==========================")

def set_app_icon():
    """Establece el icono de la aplicación silenciosamente"""
    try:
        if os.path.exists(ICON_PATH):
            Gtk.Window.set_default_icon_from_file(ICON_PATH)
        else:
            Gtk.Window.set_default_icon_name("system-software-install")
    except:
        Gtk.Window.set_default_icon_name("system-software-install")

class SoplosWelcomeLive(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.soplos.welcomelive",
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window = None
        self.cleanup_timeout_id = None

    def do_activate(self):
        # Limpiar DESPUÉS de que todos los módulos estén cargados
        aggressive_cleanup()  # Limpieza inicial agresiva
        set_app_icon()   # Establecer icono por defecto
        if not self.window:
            self.window = MainWindow()
            self.window.set_application(self)
            
            # Establecer icono usando el icon theme primero
            try:
                icon_theme = Gtk.IconTheme.get_default()
                icon = icon_theme.load_icon("soplos-welcome-live", 128, 0)
                self.window.set_icon(icon)
            except:
                # Fallback a archivo local
                if os.path.exists(ICON_PATH):
                    self.window.set_icon_from_file(ICON_PATH)

            self.window.connect("destroy", lambda x: self.on_quit())
        self.window.show_all()
        
        # Programar limpieza periódica
        self.cleanup_timeout_id = GLib.timeout_add_seconds(2, self.periodic_cleanup)

    def periodic_cleanup(self):
        """Limpieza periódica cada 2 segundos"""
        try:
            aggressive_cleanup()
            return True  # Continuar ejecutando
        except Exception:
            return False  # Detener si hay error

    def on_quit(self):
        """Limpia la caché y cierra la aplicación"""
        try:
            # Cancelar timeout si existe
            if self.cleanup_timeout_id:
                GLib.source_remove(self.cleanup_timeout_id)
                self.cleanup_timeout_id = None
            
            aggressive_cleanup()  # Limpieza final
        except Exception:
            pass  # Ignorar errores en cleanup
        finally:
            self.quit()

def main():
    try:
        # Registrar limpieza al salir del programa
        atexit.register(aggressive_cleanup)
        
        app = SoplosWelcomeLive()
        exit_code = app.run(sys.argv)
        
        # Limpieza final después de que la app termine
        try:
            aggressive_cleanup()
        except Exception:
            pass  # Ignorar errores en cleanup final
        
        return exit_code
    except Exception as e:
        print(f"Error en main: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())