import os
import subprocess

class NumlockxManager:
    def __init__(self):
        self.packages_conf = "/etc/calamares/modules/packages.conf"
        self.system_script = "/usr/local/bin/disable-numlockx"  # Usar script del sistema

    def disable_numlockx(self):
        """Prepara la desactivación de numlockx"""
        try:
            # 1. Modificar packages.conf para desinstalar numlockx
            with open(self.packages_conf, 'r') as f:
                content = f.readlines()
            
            for i, line in enumerate(content):
                if "'soplos-packager'" in line:
                    content.insert(i + 1, "      - 'numlockx'\n")
                    break
            
            with open('/tmp/packages.conf', 'w') as f:
                f.writelines(content)
            
            subprocess.run(['pkexec', 'mv', '/tmp/packages.conf', self.packages_conf], check=True)

            # 2. Modificar el shellprocess.conf existente para usar el script del sistema
            if os.path.exists('/etc/calamares/modules/shellprocess.conf'):
                with open('/etc/calamares/modules/shellprocess.conf', 'r') as f:
                    content = f.readlines()
                
                # Buscar la sección script: y añadir nuestro script
                for i, line in enumerate(content):
                    if 'script:' in line:
                        content.insert(i + 1, f'   - "{self.system_script}"\n')
                        break
                
                with open('/tmp/shellprocess.conf', 'w') as f:
                    f.writelines(content)
                
                subprocess.run(['pkexec', 'mv', '/tmp/shellprocess.conf', 
                              '/etc/calamares/modules/shellprocess.conf'], check=True)

        except Exception as e:
            raise Exception(f"Error desactivando numlockx: {str(e)}")

    def enable_numlockx(self):
        """Prepara la reactivación de numlockx"""
        try:
            # 1. Modificar packages.conf para mantener numlockx
            with open(self.packages_conf, 'r') as f:
                content = f.readlines()
            
            content = [line for line in content if "'numlockx'" not in line]
            
            with open('/tmp/packages.conf', 'w') as f:
                f.writelines(content)
            
            subprocess.run(['pkexec', 'mv', '/tmp/packages.conf', self.packages_conf], check=True)

            # 2. Actualizar configuración del módulo shellprocess
            shellprocess_conf = """---
# Módulo shellprocess para gestionar numlockx
type: job
name: shellprocess@manage_numlockx
command: "/etc/calamares/scripts/manage-numlockx.sh"
configurations:
  - exec: /etc/calamares/scripts/manage-numlockx.sh enable
    timeout: 10
    chroot: true
"""
            with open('/tmp/shellprocess_manage_numlockx.conf', 'w') as f:
                f.write(shellprocess_conf)
            
            subprocess.run(['pkexec', 'mv', '/tmp/shellprocess_manage_numlockx.conf',
                          '/etc/calamares/modules/shellprocess_manage_numlockx.conf'], check=True)

            # 3. Asegurar que el módulo está en la secuencia
            self._update_calamares_sequence('shellprocess@manage_numlockx')

        except Exception as e:
            raise Exception(f"Error activando numlockx: {str(e)}")

    def _update_calamares_sequence(self, module_name):
        """Actualiza la secuencia de módulos de Calamares"""
        try:
            with open('/etc/calamares/settings.conf', 'r') as f:
                settings = f.readlines()

            # Buscar la sección de sequence y añadir nuestro módulo si no existe
            module_exists = any(module_name in line for line in settings)
            if not module_exists:
                for i, line in enumerate(settings):
                    if '- packages' in line:
                        settings.insert(i, f'  - {module_name}\n')
                        break

                with open('/tmp/settings.conf', 'w') as f:
                    f.writelines(settings)

                subprocess.run(['pkexec', 'mv', '/tmp/settings.conf', 
                              '/etc/calamares/settings.conf'], check=True)

        except Exception as e:
            raise Exception(f"Error actualizando secuencia de Calamares: {str(e)}")

    def is_enabled(self):
        """Verifica si numlockx está habilitado en lightdm.conf"""
        try:
            with open('/etc/lightdm/lightdm.conf', 'r') as f:
                for line in f:
                    if 'greeter-setup-script=/usr/bin/numlockx on' in line:
                        # Si la línea está comentada, devuelve False
                        return not line.strip().startswith('#')
            return False
        except Exception:
            # Si hay algún error, asumimos que está habilitado (comportamiento por defecto)
            return True