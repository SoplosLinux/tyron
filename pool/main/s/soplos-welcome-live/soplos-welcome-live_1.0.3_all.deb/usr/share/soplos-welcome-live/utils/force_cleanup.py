#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys

def force_cleanup():
    """Limpieza forzada usando herramientas del sistema"""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    print("Iniciando limpieza forzada...")
    
    # Usar find para eliminar todos los __pycache__
    try:
        subprocess.run([
            'find', base_dir, '-type', 'd', '-name', '__pycache__', 
            '-exec', 'rm', '-rf', '{}', '+'
        ], check=True, capture_output=True)
        print("Eliminados directorios __pycache__ con find")
    except:
        pass
    
    # Usar find para eliminar archivos .pyc
    try:
        subprocess.run([
            'find', base_dir, '-name', '*.pyc', '-delete'
        ], check=True, capture_output=True)
        print("Eliminados archivos .pyc con find")
    except:
        pass
    
    # Usar find para eliminar archivos .pyo
    try:
        subprocess.run([
            'find', base_dir, '-name', '*.pyo', '-delete'
        ], check=True, capture_output=True)
        print("Eliminados archivos .pyo con find")
    except:
        pass
    
    print("Limpieza forzada completada")

if __name__ == "__main__":
    force_cleanup()
