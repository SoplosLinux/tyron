import os
import sys

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Paquete de configuración

# Importar las rutas necesarias
from .paths import (
    LOGO_PATH,
    ICON_PATH,
    SLIDE_PATH,
    BASE_DIR,
    ASSETS_DIR,
    SLIDES_DIR,  # Añadir SLIDES_DIR
    ICONS_DIR     # Añadir ICONS_DIR
)

from .strings import STRINGS

# Asegurar que los directorios de assets existen
os.makedirs(ICONS_DIR, exist_ok=True)  # Cambiar a ICONS_DIR específicamente
os.makedirs(SLIDES_DIR, exist_ok=True)  # Cambiar a SLIDES_DIR específicamente

__all__ = ['STRINGS', 'LOGO_PATH', 'ICON_PATH', 'SLIDE_PATH', 'BASE_DIR', 'ASSETS_DIR', 'ICONS_DIR', 'SLIDES_DIR']