import os
import shutil

class AutostartManager:
    def __init__(self):
        self.autostart_dir = os.path.expanduser('~/.config/autostart')
        self.desktop_source = '/usr/share/applications/com.soplos.welcomelive.desktop'
        self.desktop_target = os.path.join(self.autostart_dir, 'com.soplos.welcomelive.desktop')

    def is_enabled(self):
        """Verifica si welcome-live está en autostart"""
        return os.path.exists(self.desktop_target)

    def toggle(self):
        """Activa/desactiva el autostart"""
        if self.is_enabled():
            # Desactivar
            if os.path.exists(self.desktop_target):
                os.remove(self.desktop_target)
        else:
            # Activar
            os.makedirs(self.autostart_dir, exist_ok=True)
            if os.path.exists(self.desktop_source):
                shutil.copy2(self.desktop_source, self.desktop_target)
            else:
                print(f"Error: No se encuentra el archivo de escritorio en {self.desktop_source}")

    def enable(self):
        """Activa el autostart"""
        if not self.is_enabled():
            os.makedirs(self.autostart_dir, exist_ok=True)
            if os.path.exists(self.desktop_source):
                shutil.copy2(self.desktop_source, self.desktop_target)
            else:
                print(f"Error: No se encuentra el archivo de escritorio en {self.desktop_source}")

    def disable(self):
        """Desactiva el autostart"""
        if os.path.exists(self.desktop_target):
            os.remove(self.desktop_target)