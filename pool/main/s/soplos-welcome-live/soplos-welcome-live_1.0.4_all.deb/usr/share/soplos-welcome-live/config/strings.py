STRINGS = {
    'es': {
        'welcome': 'Soplos Linux',
        'welcome_desc': '¡La distribución Linux hecha para ti!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Salir',
            'website': 'Sitio Web',
            'forums': 'Foros',
            'wiki': 'Wiki',
            'donate': 'Donar',
            'install': 'Instalar Soplos _Linux',
            'chroot': 'Recuperar sistema con _CHROOT',
            'open_gparted': 'Abrir _GParted',
            'close': '_Cerrar',
            'next': '_Siguiente',
            'cancel': '_Cancelar',
            'mount': '_Montar'
        },
        'dialog': {
            'exit_title': '¿Está seguro que desea salir?',
            'exit_desc': 'Se cerrará el programa de bienvenida.',
            'error': 'Error',
            'select_disk': 'Por favor, seleccione un disco',
            'select_root': 'Debe seleccionar una partición raíz (/)',
            'no_partitions': 'No se encontraron particiones en este disco',
            'partition_header': 'Seleccione las particiones a montar:'
        },
        'locale': {
            'error_generating': 'Error al generar los locales:',
            'error_updating': 'Error al establecer el locale predeterminado:',
            'error_restart': 'Error al reiniciar LightDM',
            'not_found_locale_gen': 'No se encuentra el comando locale-gen.\nPor favor, instale el paquete locales.',
            'not_found_update_locale': 'No se encuentra update-locale'
        },
        'chroot': {
            'title': 'Recuperación CHROOT',
            'select_disk': 'Seleccione el disco del sistema',
            'open_gparted': 'Abrir GParted',
            'select_partitions': 'Seleccionar particiones',
            'mount': 'Montar',
            'cancel': 'Cancelar',
            'mounting_root': 'Montando partición raíz',
            'mounting_boot': 'Montando partición /boot',
            'mounting_efi': 'Montando partición EFI',
            'mounting_virtual': 'Montando sistemas de archivos virtuales',
            'terminal_title': 'CHROOT - Soplos Linux Recovery',
            'welcome_message': 'Bienvenido al entorno CHROOT de recuperación de Soplos Linux.\nYa está dentro del sistema instalado y puede ejecutar comandos para repararlo.',
            'instructions': 'Puede usar comandos como:\n  • apt update && apt upgrade (actualizar paquetes)\n  • dpkg --configure -a (configurar paquetes)\n  • update-grub (regenerar GRUB)\n  • passwd usuario (cambiar contraseña)',
            'exit_message': 'Para salir del entorno CHROOT, presione Ctrl+D o escriba "exit".\nAl salir se desmontarán automáticamente todas las particiones.',
            'exit_chroot': 'Saliendo del entorno CHROOT...',
            'unmounting': 'Desmontando sistemas de archivos...',
            'unmount_complete': 'Todos los sistemas de archivos han sido desmontados correctamente.',
            'cleanup_question': '¿Desea eliminar el directorio de montaje {mount_point}? (s/N): ',
            'process_complete': 'Proceso de recuperación CHROOT completado.'
        },
        'autostart': 'Mostrar al inicio:',
        'labels': {
            'language': 'Idioma:',
            'show_startup': 'Mostrar al inicio:',
            'device': 'Dispositivo',
            'size': 'Tamaño',
            'model': 'Modelo',
            'filesystem': 'Sistema de archivos',
            'mountpoint': 'Punto de montaje',
            'select_option': '-- Seleccionar --',
            'numlockx': 'Activar teclado numérico:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Esta versión Live te permite probar Soplos Linux\nsin necesidad de instalar nada en tu ordenador.\nCuando estés listo, usa el botón naranja para instalarlo.'
        },
        'thanks': '¡Gracias por probar Soplos Linux!',
        'messages': {
            'selected_disk': 'Disco seleccionado: {}',
            'error_loading_disks': 'Error al cargar discos',
            'error_loading_partitions': 'Error al obtener particiones',
            'error_mounting': 'Error al montar particiones'
        },
        'progress': {
            'configuring': 'Configurando el sistema...'
        }
    },
    'en': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'The Linux distribution made for you!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Exit',
            'website': 'Website',
            'forums': 'Forums',
            'wiki': 'Wiki',
            'donate': 'Donate',
            'install': 'Install Soplos _Linux',
            'chroot': 'Recover system with _CHROOT',
            'open_gparted': 'Open _GParted',
            'close': '_Close',
            'next': '_Next',
            'cancel': '_Cancel',
            'mount': '_Mount'
        },
        'dialog': {
            'exit_title': 'Are you sure you want to exit?',
            'exit_desc': 'The welcome program will close.',
            'error': 'Error',
            'select_disk': 'Please select a disk',
            'select_root': 'You must select a root partition (/)',
            'no_partitions': 'No partitions found on this disk',
            'partition_header': 'Select the partitions to mount:'
        },
        'locale': {
            'error_generating': 'Error generating locales:',
            'error_updating': 'Error setting default locale:',
            'error_restart': 'Error restarting LightDM',
            'not_found_locale_gen': 'locale-gen command not found.\nPlease install locales package.',
            'not_found_update_locale': 'update-locale not found'
        },
        'chroot': {
            'title': 'CHROOT Recovery',
            'select_disk': 'Select system disk',
            'open_gparted': 'Open GParted',
            'select_partitions': 'Select partitions',
            'mount': 'Mount',
            'cancel': 'Cancel',
            'mounting_root': 'Mounting root partition',
            'mounting_boot': 'Mounting /boot partition',
            'mounting_efi': 'Mounting EFI partition',
            'mounting_virtual': 'Mounting virtual filesystems',
            'terminal_title': 'CHROOT - Soplos Linux Recovery',
            'welcome_message': 'Welcome to the Soplos Linux CHROOT recovery environment.\nYou are now inside the installed system and can execute commands to repair it.',
            'instructions': 'You can use commands like:\n  • apt update && apt upgrade (update packages)\n  • dpkg --configure -a (configure packages)\n  • update-grub (regenerate GRUB)\n  • passwd user (change password)',
            'exit_message': 'To exit the CHROOT environment, press Ctrl+D or type "exit".\nAll partitions will be automatically unmounted upon exit.',
            'exit_chroot': 'Exiting CHROOT environment...',
            'unmounting': 'Unmounting filesystems...',
            'unmount_complete': 'All filesystems have been unmounted successfully.',
            'cleanup_question': 'Do you want to remove the mount directory {mount_point}? (y/N): ',
            'process_complete': 'CHROOT recovery process completed.'
        },
        'autostart': 'Show at startup:',
        'labels': {
            'language': 'Language:',
            'show_startup': 'Show at startup:',
            'device': 'Device',
            'size': 'Size',
            'model': 'Model',
            'filesystem': 'Filesystem',
            'mountpoint': 'Mountpoint',
            'select_option': '-- Select --',
            'numlockx': 'Enable numeric keypad:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'This Live version allows you to try Soplos Linux\nwithout installing anything on your computer.\nWhen you are ready, use the orange button to install it.'
        },
        'thanks': 'Thanks for trying Soplos Linux!',
        'messages': {
            'selected_disk': 'Selected disk: {}',
            'error_loading_disks': 'Error loading disks',
            'error_loading_partitions': 'Error getting partitions',
            'error_mounting': 'Error mounting partitions'
        },
        'progress': {
            'configuring': 'Configuring system...'
        }
    },
    'pt': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'A distribuição Linux feita para você!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Sair',
            'website': 'Site',
            'forums': 'Fóruns',
            'wiki': 'Wiki',
            'donate': 'Doar',
            'install': 'Instalar Soplos _Linux',
            'chroot': 'Recuperar sistema com _CHROOT',
            'open_gparted': 'Abrir _GParted',
            'close': '_Fechar',
            'next': '_Próximo',
            'cancel': '_Cancelar',
            'mount': '_Montar'
        },
        'dialog': {
            'exit_title': 'Tem certeza que deseja sair?',
            'exit_desc': 'O programa de boas-vindas será fechado.',
            'error': 'Erro',
            'select_disk': 'Por favor, selecione um disco',
            'select_root': 'Você deve selecionar uma partição raiz (/)',
            'no_partitions': 'Nenhuma partição encontrada neste disco',
            'partition_header': 'Selecione as partições a serem montadas:'
        },
        'locale': {
            'error_generating': 'Erro ao gerar locales:',
            'error_updating': 'Erro ao definir o locale padrão:',
            'error_restart': 'Erro ao reiniciar o LightDM',
            'not_found_locale_gen': 'Comando locale-gen não encontrado.\nPor favor, instale o pacote locales.',
            'not_found_update_locale': 'update-locale não encontrado'
        },
        'chroot': {
            'title': 'Recuperação CHROOT',
            'select_disk': 'Selecione o disco do sistema',
            'open_gparted': 'Abrir GParted',
            'select_partitions': 'Selecionar partições',
            'mount': 'Montar',
            'cancel': 'Cancelar',
            'mounting_root': 'Montando partição raiz',
            'mounting_boot': 'Montando partição /boot',
            'mounting_efi': 'Montando partição EFI',
            'mounting_virtual': 'Montando sistemas de arquivos virtuais',
            'terminal_title': 'CHROOT - Recuperação Soplos Linux',
            'welcome_message': 'Bem-vindo ao ambiente de recuperação CHROOT do Soplos Linux.\nVocê está agora dentro do sistema instalado e pode executar comandos para repará-lo.',
            'instructions': 'Você pode usar comandos como:\n  • apt update && apt upgrade (atualizar pacotes)\n  • dpkg --configure -a (configurar pacotes)\n  • update-grub (regenerar GRUB)\n  • passwd usuário (alterar senha)',
            'exit_message': 'Para sair do ambiente CHROOT, pressione Ctrl+D ou digite "exit".\nTodas as partições serão desmontadas automaticamente ao sair.',
            'exit_chroot': 'Saindo do ambiente CHROOT...',
            'unmounting': 'Desmontando sistemas de arquivos...',
            'unmount_complete': 'Todos os sistemas de arquivos foram desmontados com sucesso.',
            'cleanup_question': 'Deseja remover o diretório de montagem {mount_point}? (s/N): ',
            'process_complete': 'Processo de recuperação CHROOT concluído.'
        },
        'autostart': 'Mostrar na inicialização:',
        'labels': {
            'language': 'Idioma:',
            'show_startup': 'Mostrar na inicialização:',
            'device': 'Dispositivo',
            'size': 'Tamanho',
            'model': 'Modelo',
            'filesystem': 'Sistema de arquivos',
            'mountpoint': 'Ponto de montagem',
            'select_option': '-- Selecionar --',
            'numlockx': 'Ativar teclado numérico:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Esta versão Live permite que você experimente o Soplos Linux\nsem instalar nada no seu computador.\nQuando estiver pronto, use o botão laranja para instalá-lo.'
        },
        'thanks': 'Obrigado por experimentar o Soplos Linux!',
        'messages': {
            'selected_disk': 'Disco selecionado: {}',
            'error_loading_disks': 'Erro ao carregar discos',
            'error_loading_partitions': 'Erro ao obter partições',
            'error_mounting': 'Erro ao montar partições'
        },
        'progress': {
            'configuring': 'Configurando o sistema...'
        }
    },
    'fr': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'La distribution Linux faite pour vous !',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Quitter',
            'website': 'Site Web',
            'forums': 'Forums',
            'wiki': 'Wiki',
            'donate': 'Faire un don',
            'install': 'Installer Soplos _Linux',
            'chroot': 'Récupérer le système avec _CHROOT',
            'open_gparted': 'Ouvrir _GParted',
            'close': '_Fermer',
            'next': '_Suivant',
            'cancel': '_Annuler',
            'mount': '_Monter'
        },
        'dialog': {
            'exit_title': 'Êtes-vous sûr de vouloir quitter ?',
            'exit_desc': 'Le programme de bienvenue se fermera.',
            'error': 'Erreur',
            'select_disk': 'Veuillez sélectionner un disque',
            'select_root': 'Vous devez sélectionner une partition racine (/)',
            'no_partitions': 'Aucune partition trouvée sur ce disque',
            'partition_header': 'Sélectionnez les partitions à monter :'
        },
        'locale': {
            'error_generating': 'Erreur lors de la génération des locales :',
            'error_updating': 'Erreur lors de la définition de la locale par défaut :',
            'error_restart': 'Erreur lors du redémarrage de LightDM',
            'not_found_locale_gen': 'Commande locale-gen introuvable.\nVeuillez installer le paquet locales.',
            'not_found_update_locale': 'update-locale introuvable'
        },
        'chroot': {
            'title': 'Récupération CHROOT',
            'select_disk': 'Sélectionnez le disque système',
            'open_gparted': 'Ouvrir GParted',
            'select_partitions': 'Sélectionner les partitions',
            'mount': 'Monter',
            'cancel': 'Annuler',
            'mounting_root': 'Montage de la partition racine',
            'mounting_boot': 'Montage de la partition /boot',
            'mounting_efi': 'Montage de la partition EFI',
            'mounting_virtual': 'Montage des systèmes de fichiers virtuels',
            'terminal_title': 'CHROOT - Récupération Soplos Linux',
            'welcome_message': 'Bienvenue dans l\'environnement de récupération CHROOT de Soplos Linux.\nVous êtes maintenant à l\'intérieur du système installé et pouvez exécuter des commandes pour le réparer.',
            'instructions': 'Vous pouvez utiliser des commandes comme:\n  • apt update && apt upgrade (mettre à jour les paquets)\n  • dpkg --configure -a (configurer les paquets)\n  • update-grub (régénérer GRUB)\n  • passwd utilisateur (changer le mot de passe)',
            'exit_message': 'Pour quitter l\'environnement CHROOT, appuyez sur Ctrl+D ou tapez "exit".\nToutes les partitions seront automatiquement démontées à la sortie.',
            'exit_chroot': 'Sortie de l\'environnement CHROOT...',
            'unmounting': 'Démontage des systèmes de fichiers...',
            'unmount_complete': 'Tous les systèmes de fichiers ont été démontés avec succès.',
            'cleanup_question': 'Voulez-vous supprimer le répertoire de montage {mount_point}? (o/N): ',
            'process_complete': 'Processus de récupération CHROOT terminé.'
        },
        'autostart': 'Afficher au démarrage:',
        'labels': {
            'language': 'Langue :',
            'show_startup': 'Afficher au démarrage :',
            'device': 'Appareil',
            'size': 'Taille',
            'model': 'Modèle',
            'filesystem': 'Système de fichiers',
            'mountpoint': 'Point de montage',
            'select_option': '-- Sélectionner --',
            'numlockx': 'Activer le pavé numérique:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Cette version Live vous permet d\'essayer Soplos Linux\nsans rien installer sur votre ordinateur.\nLorsque vous êtes prêt, utilisez le bouton orange pour l\'installer.'
        },
        'thanks': 'Merci d\'avoir essayé Soplos Linux!',
        'messages': {
            'selected_disk': 'Disque sélectionné: {}',
            'error_loading_disks': 'Erreur lors du chargement des disques',
            'error_loading_partitions': 'Erreur lors de l\'obtention des partitions',
            'error_mounting': 'Erreur lors du montage des partitions'
        },
        'progress': {
            'configuring': 'Configuration du système...'
        }
    },
    'de': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'Die Linux-Distribution für Sie!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Beenden',
            'website': 'Webseite',
            'forums': 'Foren',
            'wiki': 'Wiki',
            'donate': 'Spenden',
            'install': 'Soplos _Linux installieren',
            'chroot': 'System mit _CHROOT wiederherstellen',
            'open_gparted': '_GParted öffnen',
            'close': '_Schließen',
            'next': '_Weiter',
            'cancel': '_Abbrechen',
            'mount': '_Einbinden'
        },
        'dialog': {
            'exit_title': 'Sind Sie sicher, dass Sie beenden möchten?',
            'exit_desc': 'Das Willkommensprogramm wird geschlossen.',
            'error': 'Fehler',
            'select_disk': 'Bitte wählen Sie eine Festplatte aus',
            'select_root': 'Sie müssen eine Root-Partition (/) auswählen',
            'no_partitions': 'Keine Partitionen auf dieser Festplatte gefunden',
            'partition_header': 'Wählen Sie die zu mountenden Partitionen aus:'
        },
        'locale': {
            'error_generating': 'Fehler beim Generieren der Locales:',
            'error_updating': 'Fehler beim Setzen der Standard-Locale:',
            'error_restart': 'Fehler beim Neustart von LightDM',
            'not_found_locale_gen': 'locale-gen Befehl nicht gefunden.\nBitte installieren Sie das Paket locales.',
            'not_found_update_locale': 'update-locale nicht gefunden'
        },
        'chroot': {
            'title': 'CHROOT Wiederherstellung',
            'select_disk': 'Systemfestplatte auswählen',
            'open_gparted': 'GParted öffnen',
            'select_partitions': 'Partitionen auswählen',
            'mount': 'Einbinden',
            'cancel': 'Abbrechen',
            'mounting_root': 'Root-Partition wird eingebunden',
            'mounting_boot': '/boot-Partition wird eingebunden',
            'mounting_efi': 'EFI-Partition wird eingebunden',
            'mounting_virtual': 'Virtuelle Dateisysteme werden eingebunden',
            'terminal_title': 'CHROOT - Soplos Linux Wiederherstellung',
            'welcome_message': 'Willkommen in der CHROOT-Wiederherstellungsumgebung von Soplos Linux.\nSie befinden sich jetzt im installierten System und können Befehle zur Reparatur ausführen.',
            'instructions': 'Sie können Befehle verwenden wie:\n  • apt update && apt upgrade (Pakete aktualisieren)\n  • dpkg --configure -a (Pakete konfigurieren)\n  • update-grub (GRUB regenerieren)\n  • passwd benutzer (Passwort ändern)',
            'exit_message': 'Um die CHROOT-Umgebung zu verlassen, drücken Sie Ctrl+D oder geben Sie "exit" ein.\nAlle Partitionen werden beim Beenden automatisch ausgehängt.',
            'exit_chroot': 'CHROOT-Umgebung wird verlassen...',
            'unmounting': 'Dateisysteme werden ausgehängt...',
            'unmount_complete': 'Alle Dateisysteme wurden erfolgreich ausgehängt.',
            'cleanup_question': 'Möchten Sie das Mount-Verzeichnis {mount_point} entfernen? (j/N): ',
            'process_complete': 'CHROOT-Wiederherstellungsprozess abgeschlossen.'
        },
        'autostart': 'Beim Start anzeigen:',
        'labels': {
            'language': 'Sprache:',
            'show_startup': 'Beim Start anzeigen:',
            'device': 'Gerät',
            'size': 'Größe',
            'model': 'Modell',
            'filesystem': 'Dateisystem',
            'mountpoint': 'Einhängepunkt',
            'select_option': '-- Auswählen --',
            'numlockx': 'Numerische Tastatur aktivieren:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Diese Live-Version ermöglicht es Ihnen, Soplos Linux\nzu testen, ohne etwas auf Ihrem Computer zu installieren.\nWenn Sie bereit sind, verwenden Sie die orangefarbene Schaltfläche, um es zu installieren.'
        },
        'thanks': 'Danke, dass Sie Soplos Linux ausprobiert haben!',
        'messages': {
            'selected_disk': 'Ausgewählte Festplatte: {}',
            'error_loading_disks': 'Fehler beim Laden der Festplatten',
            'error_loading_partitions': 'Fehler beim Abrufen der Partitionen',
            'error_mounting': 'Fehler beim Einbinden der Partitionen'
        },
        'progress': {
            'configuring': 'System wird konfiguriert...'
        }
    },
    'it': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'La distribuzione Linux fatta per te!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Uscire',
            'website': 'Sito Web',
            'forums': 'Forum',
            'wiki': 'Wiki',
            'donate': 'Donare',
            'install': 'Installa Soplos _Linux',
            'chroot': 'Recupera sistema con _CHROOT',
            'open_gparted': 'Apri _GParted',
            'close': '_Chiudi',
            'next': '_Avanti',
            'cancel': '_Annulla',
            'mount': '_Monta'
        },
        'dialog': {
            'exit_title': 'Sei sicuro di voler uscire?',
            'exit_desc': 'Il programma di benvenuto verrà chiuso.',
            'error': 'Errore',
            'select_disk': 'Per favore, seleziona un disco',
            'select_root': 'Devi selezionare una partizione root (/)',
            'no_partitions': 'Nessuna partizione trovata su questo disco',
            'partition_header': 'Seleziona le partizioni da montare:'
        },
        'locale': {
            'error_generating': 'Errore durante la generazione delle locali:',
            'error_updating': 'Errore durante l\'impostazione della locale predefinita:',
            'error_restart': 'Errore durante il riavvio di LightDM',
            'not_found_locale_gen': 'Comando locale-gen non trovato.\nInstallare il pacchetto locales.',
            'not_found_update_locale': 'update-locale non trovato'
        },
        'chroot': {
            'title': 'Recupero CHROOT',
            'select_disk': 'Seleziona il disco di sistema',
            'open_gparted': 'Apri GParted',
            'select_partitions': 'Seleziona partizioni',
            'mount': 'Monta',
            'cancel': 'Annulla',
            'mounting_root': 'Montaggio partizione root',
            'mounting_boot': 'Montaggio partizione /boot',
            'mounting_efi': 'Montaggio partizione EFI',
            'mounting_virtual': 'Montaggio filesystem virtuali',
            'terminal_title': 'CHROOT - Recupero Soplos Linux',
            'welcome_message': 'Benvenuto nell\'ambiente di recupero CHROOT di Soplos Linux.\nOra sei all\'interno del sistema installato e puoi eseguire comandi per ripararlo.',
            'instructions': 'Puoi usare comandi come:\n  • apt update && apt upgrade (aggiornare pacchetti)\n  • dpkg --configure -a (configurare pacchetti)\n  • update-grub (rigenerare GRUB)\n  • passwd utente (cambiare password)',
            'exit_message': 'Per uscire dall\'ambiente CHROOT, premi Ctrl+D o digita "exit".\nTutte le partizioni saranno automaticamente smontate all\'uscita.',
            'exit_chroot': 'Uscita dall\'ambiente CHROOT...',
            'unmounting': 'Smontaggio filesystem...',
            'unmount_complete': 'Tutti i filesystem sono stati smontati con successo.',
            'cleanup_question': 'Vuoi rimuovere la directory di mount {mount_point}? (s/N): ',
            'process_complete': 'Processo di recupero CHROOT completato.'
        },
        'autostart': 'Mostra all\'avvio:',
        'labels': {
            'language': 'Lingua:',
            'show_startup': 'Mostra all\'avvio:',
            'device': 'Dispositivo',
            'size': 'Dimensione',
            'model': 'Modello',
            'filesystem': 'File system',
            'mountpoint': 'Punto di montaggio',
            'select_option': '-- Seleziona --',
            'numlockx': 'Attiva tastierino numerico:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Questa versione Live ti permette di provare Soplos Linux\nsenza installare nulla sul tuo computer.\nQuando sei pronto, usa il pulsante arancione per installarlo.'
        },
        'thanks': 'Grazie per aver provato Soplos Linux!',
        'messages': {
            'selected_disk': 'Disco selezionato: {}',
            'error_loading_disks': 'Errore durante il caricamento dei dischi',
            'error_loading_partitions': 'Errore durante l\'ottenimento delle partizioni',
            'error_mounting': 'Errore durante il montaggio delle partizioni'
        },
        'progress': {
            'configuring': 'Configurazione del sistema...'
        }
    },
    'ro': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'Distribuția Linux făcută pentru tine!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Ieșire',
            'website': 'Site Web',
            'forums': 'Forum',
            'wiki': 'Wiki',
            'donate': 'Donează',
            'install': 'Instalează Soplos _Linux',
            'chroot': 'Recuperează sistemul cu _CHROOT',
            'open_gparted': 'Deschide _GParted',
            'close': '_Închide',
            'next': '_Următorul',
            'cancel': '_Anulează',
            'mount': '_Montează'
        },
        'dialog': {
            'exit_title': 'Sigur doriți să ieșiți?',
            'exit_desc': 'Programul de bun venit se va închide.',
            'error': 'Eroare',
            'select_disk': 'Vă rugăm să selectați un disc',
            'select_root': 'Trebuie să selectați o partiție root (/)',
            'no_partitions': 'Nu s-au găsit partiții pe acest disc',
            'partition_header': 'Selectați partițiile de montat:'
        },
        'locale': {
            'error_generating': 'Eroare la generarea localelor:',
            'error_updating': 'Eroare la setarea localei implicite:',
            'error_restart': 'Eroare la repornirea LightDM',
            'not_found_locale_gen': 'Comanda locale-gen nu a fost găsită.\nVă rugăm să instalați pachetul locales.',
            'not_found_update_locale': 'update-locale nu a fost găsit'
        },
        'chroot': {
            'title': 'Recuperare CHROOT',
            'select_disk': 'Selectați discul sistem',
            'open_gparted': 'Deschide GParted',
            'select_partitions': 'Selectați partițiile',
            'mount': 'Montare',
            'cancel': 'Anulare',
            'mounting_root': 'Montarea partiției root',
            'mounting_boot': 'Montarea partiției /boot',
            'mounting_efi': 'Montarea partiției EFI',
            'mounting_virtual': 'Montarea sistemelor de fișiere virtuale',
            'terminal_title': 'CHROOT - Recuperare Soplos Linux',
            'welcome_message': 'Bun venit în mediul de recuperare CHROOT Soplos Linux.\nAcum sunteți în interiorul sistemului instalat și puteți executa comenzi pentru a-l repara.',
            'instructions': 'Puteți folosi comenzi precum:\n  • apt update && apt upgrade (actualizare pachete)\n  • dpkg --configure -a (configurare pachete)\n  • update-grub (regenerare GRUB)\n  • passwd utilizator (schimbare parolă)',
            'exit_message': 'Pentru a ieși din mediul CHROOT, apăsați Ctrl+D sau tastați "exit".\nToate partițiile vor fi demontate automat la ieșire.',
            'exit_chroot': 'Ieșire din mediul CHROOT...',
            'unmounting': 'Demontarea sistemelor de fișiere...',
            'unmount_complete': 'Toate sistemele de fișiere au fost demontate cu succes.',
            'cleanup_question': 'Doriți să eliminați directorul de montare {mount_point}? (d/N): ',
            'process_complete': 'Procesul de recuperare CHROOT finalizat.'
        },
        'autostart': 'Arată la pornire:',
        'labels': {
            'language': 'Limbă:',
            'show_startup': 'Arată la pornire:',
            'device': 'Dispozitiv',
            'size': 'Dimensiune',
            'model': 'Model',
            'filesystem': 'Sistem de fișiere',
            'mountpoint': 'Punct de montare',
            'select_option': '-- Selectați --',
            'numlockx': 'Activare tastatură numerică:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Această versiune Live vă permite să încercați Soplos Linux\nfără a instala nimic pe computerul dvs.\nCând sunteți gata, utilizați butonul portocaliu pentru a-l instala.'
        },
        'thanks': 'Mulțumim că ați încercat Soplos Linux!',
        'messages': {
            'selected_disk': 'Disc selectat: {}',
            'error_loading_disks': 'Eroare la încărcarea discurilor',
            'error_loading_partitions': 'Eroare la obținerea partițiilor',
            'error_mounting': 'Eroare la montarea partițiilor'
        },
        'progress': {
            'configuring': 'Configurarea sistemului...'
        }
    },
    'ru': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'Дистрибутив Linux, созданный для вас!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Выход',
            'website': 'Сайт',
            'forums': 'Форумы',
            'wiki': 'Вики',
            'donate': 'Поддержать',
            'install': 'Установить Soplos _Linux',
            'chroot': 'Восстановить систему с _CHROOT',
            'open_gparted': 'Открыть _GParted',
            'close': '_Закрыть',
            'next': '_Далее',
            'cancel': '_Отмена',
            'mount': '_Монтировать'
        },
        'dialog': {
            'exit_title': 'Вы уверены, что хотите выйти?',
            'exit_desc': 'Программа приветствия будет закрыта.',
            'error': 'Ошибка',
            'select_disk': 'Пожалуйста, выберите диск',
            'select_root': 'Вы должны выбрать корневой раздел (/)',
            'no_partitions': 'На этом диске не найдено разделов',
            'partition_header': 'Выберите разделы для монтирования:'
        },
        'locale': {
            'error_generating': 'Ошибка при генерации локалей:',
            'error_updating': 'Ошибка при установке локали по умолчанию:',
            'error_restart': 'Ошибка при перезапуске LightDM',
            'not_found_locale_gen': 'Команда locale-gen не найдена.\nПожалуйста, установите пакет locales.',
            'not_found_update_locale': 'update-locale не найден'
        },
        'chroot': {
            'title': 'Восстановление CHROOT',
            'select_disk': 'Выберите системный диск',
            'open_gparted': 'Открыть GParted',
            'select_partitions': 'Выберите разделы',
            'mount': 'Монтировать',
            'cancel': 'Отмена',
            'mounting_root': 'Монтирование корневого раздела',
            'mounting_boot': 'Монтирование раздела /boot',
            'mounting_efi': 'Монтирование раздела EFI',
            'mounting_virtual': 'Монтирование виртуальных файловых систем',
            'terminal_title': 'CHROOT - Восстановление Soplos Linux',
            'welcome_message': 'Добро пожаловать в среду восстановления CHROOT Soplos Linux.\nВы теперь находитесь внутри установленной системы и можете выполнять команды для её восстановления.',
            'instructions': 'Вы можете использовать команды:\n  • apt update && apt upgrade (обновить пакеты)\n  • dpkg --configure -a (настроить пакеты)\n  • update-grub (пересоздать GRUB)\n  • passwd пользователь (изменить пароль)',
            'exit_message': 'Для выхода из среды CHROOT нажмите Ctrl+D или введите "exit".\nВсе разделы будут автоматически отмонтированы при выходе.',
            'exit_chroot': 'Выход из среды CHROOT...',
            'unmounting': 'Отмонтирование файловых систем...',
            'unmount_complete': 'Все файловые системы успешно отмонтированы.',
            'cleanup_question': 'Хотите удалить директорию монтирования {mount_point}? (д/N): ',
            'process_complete': 'Процесс восстановления CHROOT завершён.'
        },
        'autostart': 'Показывать при запуске:',
        'labels': {
            'language': 'Язык:',
            'show_startup': 'Показывать при запуске:',
            'device': 'Устройство',
            'size': 'Размер',
            'model': 'Модель',
            'filesystem': 'Файловая система',
            'mountpoint': 'Точка монтирования',
            'select_option': '-- Выбрать --',
            'numlockx': 'Включить цифровую клавиатуру:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Эта версия Live позволяет вам попробовать Soplos Linux\nбез установки чего-либо на ваш компьютер.\nКогда будете готовы, используйте оранжевую кнопку для установки.'
        },
        'thanks': 'Спасибо, что попробовали Soplos Linux!',
        'messages': {
            'selected_disk': 'Выбранный диск: {}',
            'error_loading_disks': 'Ошибка при загрузке дисков',
            'error_loading_partitions': 'Ошибка при получении разделов',
            'error_mounting': 'Ошибка при монтировании разделов'
        },
        'progress': {
            'configuring': 'Настройка системы...'
        }
    }
}
