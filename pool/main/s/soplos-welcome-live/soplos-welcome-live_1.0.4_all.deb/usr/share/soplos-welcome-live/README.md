# Soplos Welcome Live

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.4-green.svg)]()

Pantalla de bienvenida para el entorno Live de Soplos Linux que ayuda a los usuarios a navegar por el sistema y realizar la instalación.

*Welcome screen for Soplos Linux Live Environment that helps users navigate the system and perform installation.*

## 📝 Descripción

Una aplicación de bienvenida avanzada para el entorno Live de Soplos Linux que proporciona una experiencia completa de configuración, instalación y recuperación del sistema. Incluye herramientas especializadas para administradores de sistemas y usuarios avanzados.

## ✨ Características Principales

### 🎯 Instalación y Configuración
- **Instalación directa** con integración Calamares
- **Configuración automática de idioma** con soporte completo para 8 idiomas
- **Migración inteligente de carpetas XDG** al cambiar idioma
- **Detección automática de locale** del sistema
- **Configuración de teclado** sincronizada con el idioma seleccionado

### 🛠️ Herramientas de Recuperación
- **Sistema CHROOT avanzado** para recuperación completa del sistema
- **Detección inteligente de particiones** con sugerencias automáticas de montaje
- **Terminal de recuperación especializada** con comandos preconfigurados
- **Montaje seguro de sistemas de archivos** con validación automática
- **Integración con GParted** para gestión avanzada de discos

### ⚙️ Configuración del Sistema
- **Control de NumLock** para activación automática del teclado numérico
- **Gestión de autostart** para la aplicación de bienvenida
- **Configuración persistente** de preferencias del usuario
- **Soporte completo para sistemas EFI y BIOS**

### 🌐 Internacionalización Completa
- **8 idiomas soportados** con traducciones profesionales
- **Mnemonics (teclas de acceso rápido)** en todos los idiomas
- **Adaptación cultural** de mensajes y formatos
- **Detección automática** del idioma del sistema
- **Migración de carpetas del usuario** según el idioma seleccionado

### 🔧 Características Técnicas Avanzadas
- **Limpieza automática de caché** Python en tiempo real
- **Gestión avanzada de memoria** con limpieza periódica
- **Detección robusta de hardware** con soporte para múltiples tipos de disco
- **Validación de sistemas de archivos** antes del montaje CHROOT
- **Manejo inteligente de errores** con recuperación automática

## 📸 Capturas de pantalla

### Pantalla de bienvenida Live
![Pantalla de bienvenida](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot1.png)

### Herramientas de recuperación CHROOT
![CHROOT Recovery](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot2.png)

### Configuración multiidioma
![Configuración de idioma](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot3.png)

## 🔧 Instalación

```bash
sudo apt update
sudo apt install soplos-welcome-live
```

### Dependencias
- `python3` (≥3.8)
- `python3-gi`
- `gir1.2-gtk-3.0`
- `calamares` (recomendado)
- `gparted` (recomendado)
- `locales`
- `x11-xkb-utils`
- `ptyxis` o terminal compatible

## 🌐 Idiomas soportados

| Idioma | Código | Estado |
|--------|--------|---------|
| Español | `es` | ✅ Completo |
| English | `en` | ✅ Completo |
| Português | `pt` | ✅ Completo |
| Français | `fr` | ✅ Completo |
| Deutsch | `de` | ✅ Completo |
| Italiano | `it` | ✅ Completo |
| Română | `ro` | ✅ Completo |
| Русский | `ru` | ✅ Completo |

## 🚀 Uso

### Inicio Automático
La aplicación se inicia automáticamente en el entorno Live. Puede desactivarse desde la propia interfaz.

### Instalación del Sistema
1. Seleccionar idioma deseado
2. Hacer clic en "Instalar Soplos Linux"
3. Seguir el asistente de Calamares

### Recuperación CHROOT
1. Hacer clic en "Recuperar sistema con CHROOT"
2. Seleccionar el disco del sistema instalado
3. Elegir las particiones apropiadas
4. Trabajar en el entorno de recuperación

### Configuración de NumLock
- Usar el switch "Activar teclado numérico" para configurar NumLock
- La configuración se aplica al sistema instalado durante la instalación

## 🛠️ Desarrollo

### Estructura del Proyecto
```
soplos-welcome-live/
├── main.py                 # Punto de entrada principal
├── ui/                     # Interfaz de usuario
│   ├── main_window.py      # Ventana principal
│   ├── welcome_tab.py      # Pestaña de bienvenida
│   └── chroot_window.py    # Ventana de recuperación CHROOT
├── config/                 # Configuración
│   ├── strings.py          # Cadenas traducidas
│   └── paths.py           # Rutas de recursos
├── core/                   # Lógica central
│   └── chroot_operations.py # Operaciones CHROOT
├── utils/                  # Utilidades
│   ├── autostart.py        # Gestión de autostart
│   └── numlockx_manager.py # Gestión de NumLock
└── assets/                 # Recursos gráficos
    ├── icons/              # Iconos
    └── slides/             # Imágenes de presentación
```

### Requisitos de Desarrollo
```bash
pip install -r requirements.txt
```

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- ✅ La libertad de usar el programa para cualquier propósito
- ✅ La libertad de estudiar cómo funciona el programa y modificarlo
- ✅ La libertad de distribuir copias del programa
- ✅ La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos Linux](https://soploslinux.com)

## 🔗 Enlaces

- [Página web oficial](https://soploslinux.com)
- [Repositorio GitHub](https://github.com/SoplosLinux/tyron)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Foros de la comunidad](https://soploslinux.com/foros/)
- [Wiki y documentación](https://sourceforge.net/p/soplos-linux/wiki/Home/)
- [Contacto](mailto:info@soploslinux.com)

## 📦 Historial de Versiones

### v1.0.4 (Actual)
- ✨ **Nueva funcionalidad CHROOT avanzada** con detección inteligente de particiones
- 🌐 **Internacionalización completa** en 8 idiomas con mnemonics
- ⚙️ **Gestión de NumLock** integrada en el sistema
- 🔧 **Migración automática de carpetas XDG** al cambiar idioma
- 🛠️ **Limpieza automática de caché** Python en tiempo real
- 🎯 **Detección robusta de sistemas de archivos** para CHROOT
- 📱 **Interfaz mejorada** con mejor organización visual
- 🚀 **Optimización de rendimiento** y gestión de memoria

### v1.0.3
- 🌐 Mejoras en la internacionalización
- 🔧 Correcciones en la configuración de locale
- 📱 Optimizaciones de interfaz

### v1.0.2
- ⚙️ Mejoras en la detección de hardware
- 🛠️ Correcciones en las operaciones CHROOT
- 🎯 Estabilidad general mejorada

### v1.0.1
- 🐛 Correcciones menores de errores
- 📱 Mejoras en la interfaz de usuario
- 🔧 Optimizaciones de configuración

### v1.0.0 (27/01/2024)
- 🎉 Versión inicial de lanzamiento
- 📱 Interfaz básica de bienvenida
- 🛠️ Funcionalidad CHROOT básica
- 🌐 Soporte multiidioma inicial

---

**Soplos Welcome Live v1.0.4** - La herramienta definitiva para el entorno Live de Soplos Linux
