import gi
import os
import subprocess
import shutil
import sys

# Prevenir creación de archivos .pyc
sys.dont_write_bytecode = True

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib
from core.chroot_operations import SystemOperations
from config.strings import STRINGS  # Cambiar la importación

# Desactivar warnings de accesibilidad
os.environ['NO_AT_BRIDGE'] = '1'

class ChRootWindow(Gtk.Window):
    def __init__(self):
        # Limpiar pycache antes de inicializar
        self.clean_pycache()
        
        # Obtener idioma del sistema de forma más robusta
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        # Si es C.UTF-8 o similar, usar inglés por defecto
        if current_locale.startswith('C.') or current_locale == 'C':
            self.current_lang = 'en'
        else:
            self.current_lang = current_locale.split('_')[0]
            # Si el idioma no existe en STRINGS, usar inglés
            if self.current_lang not in STRINGS:
                self.current_lang = 'en'
        
        print(f"DEBUG: Detected locale: {current_locale}, using language: {self.current_lang}")
        
        Gtk.Window.__init__(self, title=STRINGS[self.current_lang]['chroot']['title'])
        self.set_default_size(600, 400)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(10)
        
        self.sys_ops = SystemOperations()
        
        # Contenedor principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Etiqueta de título
        title_label = Gtk.Label()
        title_label.set_markup(f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['chroot']['select_disk']}</span>")
        main_box.pack_start(title_label, False, False, 10)
        
        # Lista de discos
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        main_box.pack_start(scrolled, True, True, 0)
        
        self.disks_store = Gtk.ListStore(str, str, str)  # Dispositivo, Tamaño, Modelo
        self.disks_view = Gtk.TreeView(model=self.disks_store)
        
        # Columnas
        columns = [
            (STRINGS[self.current_lang]['labels']['device'], 0),
            (STRINGS[self.current_lang]['labels']['size'], 1),
            (STRINGS[self.current_lang]['labels']['model'], 2)
        ]
        
        for title, col_id in columns:
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(title, renderer, text=col_id)
            self.disks_view.append_column(column)
        
        scrolled.add(self.disks_view)
        
        # Botón GParted
        gparted_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['open_gparted'])
        gparted_button.set_use_underline(True)
        gparted_button.connect("clicked", self.on_gparted_clicked)
        main_box.pack_start(gparted_button, False, False, 0)
        
        # Botones inferiores
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(button_box, False, False, 0)
        
        close_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['close'])
        close_button.set_use_underline(True)
        close_button.connect("clicked", self.on_close_clicked)
        button_box.pack_start(close_button, True, True, 0)
        
        next_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['next'])
        next_button.set_use_underline(True)
        next_button.connect("clicked", self.on_next_clicked)
        button_box.pack_start(next_button, True, True, 0)
        
        # Conectar la señal de borrado (cierre de ventana)
        self.connect("delete-event", self.on_window_close)
        
        # Cargar discos
        self.load_disks()

    def _init_ui(self):
        """Inicializa la interfaz de usuario"""
        self.set_title(STRINGS[self.current_lang]['chroot']['title'])
        self.set_default_size(600, 400)
        
        # Conectar la señal de borrado (cierre de ventana)
        self.connect("delete-event", self.on_window_close)
        
        # Box principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_border_width(20)
        self.add(main_box)
        
        # Título
        title_label = Gtk.Label()
        title_label.set_markup(f"<span size='x-large' weight='bold'>{STRINGS[self.current_lang]['chroot']['title']}</span>")
        main_box.pack_start(title_label, False, False, 0)
        
        # Selector de disco
        disk_frame = Gtk.Frame(label=STRINGS[self.current_lang]['chroot']['select_disk'])
        main_box.pack_start(disk_frame, False, False, 0)
        
        disk_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        disk_box.set_border_width(10)
        disk_frame.add(disk_box)
        
        self.disk_combo = Gtk.ComboBoxText()
        disk_box.pack_start(self.disk_combo, True, True, 0)
        
        # Botón GParted con mnemonic
        gparted_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['open_gparted'])
        gparted_button.set_use_underline(True)
        gparted_button.connect("clicked", self.on_gparted_clicked)
        disk_box.pack_start(gparted_button, False, False, 0)
        
        # Área de información del disco
        self.disk_info_label = Gtk.Label()
        main_box.pack_start(self.disk_info_label, False, False, 0)
        
        # Botones principales con mnemonics
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        button_box.set_halign(Gtk.Align.END)
        main_box.pack_end(button_box, False, False, 0)
        
        # Botón cerrar con mnemonic
        close_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['close'])
        close_button.set_use_underline(True)
        close_button.connect("clicked", self.on_close_clicked)
        button_box.pack_start(close_button, False, False, 0)
        
        # Botón siguiente con mnemonic
        self.next_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['next'])
        self.next_button.set_use_underline(True)
        self.next_button.set_sensitive(False)
        self.next_button.connect("clicked", self.on_next_clicked)
        button_box.pack_start(self.next_button, False, False, 0)
        
        # Conectar señales
        self.disk_combo.connect("changed", self.on_disk_changed)
        
        # Cargar discos
        self.load_disks()
    
    def load_disks(self):
        """Carga la lista de discos"""
        try:
            self.disks_store.clear()
            for device, size, model in self.sys_ops.get_disks():
                self.disks_store.append([device, size, model])
        except Exception as e:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                STRINGS[self.current_lang]['messages']['error_loading_disks']
            )
    
    def on_gparted_clicked(self, button):
        """Ejecuta GParted"""
        try:
            # Ejecutar GParted de forma directa con pkexec
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'], 
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
        except Exception as e:
            self.show_error("Error", str(e))
    
    def on_next_clicked(self, button):
        """Procede al siguiente paso"""
        selection = self.disks_view.get_selection()
        model, iter = selection.get_selected()
        
        # Error messages
        if iter is None:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                STRINGS[self.current_lang]['dialog']['select_disk']
            )
            return
        
        selected_disk = model[iter][0]
        print(STRINGS[self.current_lang]['messages']['selected_disk'].format(selected_disk))
        
        try:
            # Obtener particiones del disco
            partitions = self.sys_ops.get_disk_partitions(selected_disk)
            
            # Mostrar diálogo de selección de particiones
            self.show_partitions_dialog(partitions)
        except Exception as e:
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                STRINGS[self.current_lang]['messages']['error_loading_partitions']
            )
    
    def on_window_close(self, window, event):
        """Maneja el cierre de la ventana"""
        try:
            # Limpiar cualquier montaje pendiente - usar sys_ops en lugar de operations
            self.sys_ops.unmount_all()
        except Exception as e:
            print(f"Error durante la limpieza al cerrar: {e}")
        finally:
            return False  # Permitir que la ventana se cierre

    def on_close_clicked(self, button):
        """Maneja el clic en el botón Cerrar"""
        try:
            # Limpiar cualquier montaje pendiente - usar sys_ops en lugar de operations
            self.sys_ops.unmount_all()
        except Exception as e:
            print(f"Error durante la limpieza: {e}")
        finally:
            self.destroy()

    def show_partitions_dialog(self, partitions):
        """Muestra diálogo para seleccionar particiones con mnemonics"""
        dialog = Gtk.Dialog(
            title=STRINGS[self.current_lang]['chroot']['select_partitions'],
            parent=self,
            flags=0
        )
        dialog.set_default_size(500, 400)
        
        # Agregar botones con mnemonics manualmente
        cancel_button = dialog.add_button(STRINGS[self.current_lang]['buttons']['cancel'], Gtk.ResponseType.CANCEL)
        mount_button = dialog.add_button(STRINGS[self.current_lang]['buttons']['mount'], Gtk.ResponseType.OK)
        
        # Configurar mnemonics para los botones
        cancel_button.set_use_underline(True)
        mount_button.set_use_underline(True)
        
        # Hacer que el botón Mount sea el predeterminado
        mount_button.set_can_default(True)
        mount_button.grab_default()
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_border_width(10)
        
        if not partitions:
            label = Gtk.Label(label=STRINGS[self.current_lang]['dialog']['no_partitions'])
            box.pack_start(label, False, False, 0)
            box.show_all()
            dialog.run()
            dialog.destroy()
            return
            
        # Label de encabezado con mnemonic
        header_label = Gtk.Label()
        header_label.set_markup(f"<b>{STRINGS[self.current_lang]['dialog']['partition_header']}</b>")
        header_label.set_halign(Gtk.Align.START)
        box.pack_start(header_label, False, False, 0)
        
        # Crear scrolled window para la lista de particiones
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_size_request(-1, 200)
        box.pack_start(scrolled, True, True, 0)
        
        # Grid para particiones
        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        grid.set_row_spacing(5)
        grid.set_border_width(10)
        scrolled.add(grid)
        
        # Crear los encabezados con formato
        headers = [
            STRINGS[self.current_lang]['labels']['mountpoint'],
            STRINGS[self.current_lang]['labels']['device'],
            STRINGS[self.current_lang]['labels']['size'],
            STRINGS[self.current_lang]['labels']['filesystem']
        ]
        for i, header in enumerate(headers):
            label = Gtk.Label()
            label.set_markup(f"<b>{header}</b>")
            label.set_halign(Gtk.Align.START)
            grid.attach(label, i, 0, 1, 1)
        
        # Crear las filas de particiones
        mount_points = ['/', '/boot', '/boot/efi', '/home']
        self.partition_combos = {}
        
        for i, mount in enumerate(mount_points, 1):
            # Etiqueta del punto de montaje con formato
            mount_label = Gtk.Label()
            mount_label.set_markup(f"<tt><b>{mount}</b></tt>")
            mount_label.set_halign(Gtk.Align.START)
            grid.attach(mount_label, 0, i, 1, 1)
            
            # Combo para seleccionar partición
            combo = Gtk.ComboBoxText()
            combo.append_text(STRINGS[self.current_lang]['labels']['select_option'])
            
            # Agregar particiones al combo
            for part in partitions:
                text = f"{part['device']} ({part['size']} - {part['fstype']})"
                combo.append_text(text)
            
            combo.set_active(0)
            
            # Si hay una sugerencia, seleccionarla
            for j, part in enumerate(partitions, 1):
                if part.get('suggested_mount') == mount:
                    combo.set_active(j)
                    break
            
            self.partition_combos[mount] = combo
            grid.attach(combo, 1, i, 3, 1)
        
        # Mostrar todo
        box.show_all()
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.process_selected_partitions()
        
        dialog.destroy()
    
    def process_selected_partitions(self):
        """Procesa las particiones seleccionadas y ejecuta el chroot"""
        try:
            mount_points = {}
            for mount, combo in self.partition_combos.items():
                device = combo.get_active_text()
                if device and device != "-- Seleccionar --":
                    device = device.split()[0]  # Obtener solo el dispositivo
                    mount_points[mount] = device

            if '/' not in mount_points:
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    STRINGS[self.current_lang]['dialog']['select_root']
                )
                return

            # Ejecutar el montaje y chroot
            self.sys_ops.mount_and_chroot(
                root_part=mount_points['/'],
                boot_part=mount_points.get('/boot'),
                efi_part=mount_points.get('/boot/efi')
            )
            
        except Exception as e:
            self.show_error("Error", str(e))
    
    def show_error(self, title, message):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=STRINGS[self.current_lang]['dialog']['error']
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def clean_pycache(self):
        """Limpia todos los archivos __pycache__, .pyc y .pyo del proyecto"""
        try:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            
            # Limpieza inmediata y agresiva
            for root, dirs, files in os.walk(base_dir):
                try:
                    for dir_name in dirs[:]:  # usar slice para poder modificar la lista
                        if dir_name == '__pycache__':
                            pycache_path = os.path.join(root, dir_name)
                            try:
                                shutil.rmtree(pycache_path, ignore_errors=True)
                                dirs.remove(dir_name)  # remover de la lista
                                print(f"Eliminado: {pycache_path}")
                            except:
                                pass
                    
                    # Eliminar archivos .pyc individuales
                    for file_name in files:
                        if file_name.endswith(('.pyc', '.pyo', '.pyd')):
                            file_path = os.path.join(root, file_name)
                            try:
                                os.remove(file_path)
                                print(f"Eliminado archivo: {file_path}")
                            except:
                                pass
                except Exception:
                    continue  # Continuar con el siguiente directorio
            
            # Forzar limpieza de directorios específicos
            specific_dirs = ['utils', 'ui', 'config', 'core']
            for dir_name in specific_dirs:
                try:
                    dir_path = os.path.join(base_dir, dir_name)
                    if os.path.exists(dir_path):
                        pycache_path = os.path.join(dir_path, '__pycache__')
                        if os.path.exists(pycache_path):
                            try:
                                # Forzar eliminación incluso con archivos en uso
                                subprocess.run(['rm', '-rf', pycache_path], 
                                             check=False, capture_output=True)
                                print(f"Forzado eliminado: {pycache_path}")
                            except Exception:
                                pass
                except Exception:
                    continue
        except Exception:
            pass  # Ignorar todos los errores silenciosamente en este contexto
