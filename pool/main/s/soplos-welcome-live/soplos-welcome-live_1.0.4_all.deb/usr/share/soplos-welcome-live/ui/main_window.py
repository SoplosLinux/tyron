import gi
import os
import subprocess
import sys
import shutil  # Agregar importación de shutil

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, Gdk, GLib
from ui.welcome_tab import WelcomeTab
from config.paths import LOGO_PATH, ICON_PATH  # Añadir ICON_PATH a la importación
from config.strings import STRINGS  # Cambiar la importación
from utils.autostart import AutostartManager
from ui.chroot_window import ChRootWindow

# Diccionario de idiomas y sus configuraciones (movido desde welcome_tab.py)
LANGUAGES = {
    'Español': {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    'English': {'locale': 'en_US.UTF-8', 'layout': 'us'},
    'Português': {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    'Français': {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    'Deutsch': {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    'Italiano': {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    'Română': {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    'Русский': {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class MainWindow(Gtk.ApplicationWindow):  # Cambiar de Gtk.Window a Gtk.ApplicationWindow
    def __init__(self):
        super().__init__()
        
        # Establecer WM_CLASS para que coincida con el .desktop
        self.set_wmclass("com.soplos.welcomelive", "com.soplos.welcomelive")
        
        # Establecer el icono de la ventana explícitamente
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.welcomelive", 128, 0)
                self.set_icon(icon)
            except:
                # Fallback a ruta absoluta si falla la carga por nombre
                if os.path.exists(ICON_PATH):
                    self.set_icon_from_file(ICON_PATH)
        except Exception as e:
            print(f"Error al establecer el icono: {e}")
        
        app = Gtk.Application.get_default()
        Gtk.ApplicationWindow.__init__(self, application=app)
        self.set_title("Soplos Welcome Live")
        
        # Detectar el idioma actual del sistema de manera segura
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        # Si es C.UTF-8 o similar, usar inglés por defecto
        if current_locale.startswith('C.') or current_locale == 'C':
            self.current_lang = 'en'
        else:
            self.current_lang = current_locale.split('_')[0]
            # Si el idioma no existe en STRINGS, usar inglés
            if self.current_lang not in STRINGS:
                self.current_lang = 'en'
        
        # Buscar el nombre del idioma en LANGUAGES
        current_language_name = None
        for name, config in LANGUAGES.items():
            if config['locale'].startswith(current_locale[:5]):
                current_language_name = name
                break
        
        Gtk.Window.__init__(self, title=STRINGS[self.current_lang]['welcome'])
        self.set_wmclass('soplos-welcome-live', 'soplos-welcome-live')
        
        self.set_border_width(10)
        
        self.set_default_size(800, 400)
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Contenedor principal horizontal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Sub-contenedor horizontal para logo y contenido
        content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(content_box, True, True, 0)

        # Panel izquierdo para logo (ahora va en content_box)
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left_panel.set_size_request(200, -1)
        content_box.pack_start(left_panel, False, False, 5)

        try:
            header_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                filename=LOGO_PATH,
                width=150,
                height=150,
                preserve_aspect_ratio=True
            )
            logo_image = Gtk.Image.new_from_pixbuf(header_pixbuf)
            left_panel.pack_start(logo_image, False, False, 10)
        except Exception as e:
            print(f"Error al cargar el logo: {e}")
        
        welcome_label = Gtk.Label()
        welcome_label.set_markup(
            f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['welcome']}</span>\n" +
            f"<span size='small'>{STRINGS[self.current_lang]['thanks']}</span>"
        )
        welcome_label.set_justify(Gtk.Justification.CENTER)
        welcome_label.set_line_wrap(True)
        left_panel.pack_start(welcome_label, False, False, 5)
        
        # Añadir espacio flexible que empujará el selector de idioma hacia abajo
        left_panel.pack_start(Gtk.Box(), True, True, 0)
        
        # Selector de idioma y autostart en el panel izquierdo
        controls_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        left_panel.pack_end(controls_box, False, False, 0)

        # Switch de numlockx
        numlockx_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        numlockx_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['numlockx'])
        numlockx_box.pack_start(numlockx_label, False, False, 0)
        
        self.numlockx_switch = Gtk.Switch()
        # Verificar estado inicial de numlockx
        from utils.numlockx_manager import NumlockxManager
        numlockx_manager = NumlockxManager()
        self.numlockx_switch.set_active(numlockx_manager.is_enabled())
        self.numlockx_switch.connect("notify::active", self.on_numlockx_toggled)
        numlockx_box.pack_end(self.numlockx_switch, False, False, 0)
        
        controls_box.pack_start(numlockx_box, False, False, 5)

        # Switch de autostart
        autostart_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        autostart_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['show_startup'])
        autostart_box.pack_start(autostart_label, False, False, 0)
        
        self.autostart_switch = Gtk.Switch()
        self.autostart_manager = AutostartManager()
        self.autostart_switch.set_active(self.autostart_manager.is_enabled())
        self.autostart_switch.connect("notify::active", self.on_autostart_toggled)
        autostart_box.pack_end(self.autostart_switch, False, False, 0)
        
        controls_box.pack_start(autostart_box, False, False, 5)
        
        # Selector de idioma en el panel izquierdo, ahora se alineará con el botón de salida
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        lang_box.set_margin_bottom(5)  # Margen inferior para alinear con el botón de salida
        controls_box.pack_start(lang_box, False, False, 0)  # Usamos pack_end en lugar de pack_start
        
        lang_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['language'])
        lang_box.pack_start(lang_label, False, False, 0)
        
        self.lang_combo = Gtk.ComboBoxText()
        # Añadir idiomas y guardar el índice del idioma actual
        current_index = 0
        for i, (lang, config) in enumerate(LANGUAGES.items()):
            self.lang_combo.append_text(lang)
            if config['locale'].startswith(current_locale[:5]):
                current_index = i
        
        # Seleccionar el idioma actual por índice
        self.lang_combo.set_active(current_index)
        self.lang_combo.connect("changed", self.on_language_changed)
        lang_box.pack_start(self.lang_combo, True, True, 5)
        
        # Panel derecho (ahora va en content_box)
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        content_box.pack_start(right_panel, True, True, 0)
        
        welcome_tab = WelcomeTab(self)
        right_panel.pack_start(welcome_tab, True, True, 0)
        
        # Panel inferior con botones
        button_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        right_panel.pack_end(button_panel, False, False, 5)

        # Botones (mantener el orden existente)
        exit_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['exit'])
        exit_button.set_use_underline(True)
        exit_button.connect("clicked", self.on_exit_clicked)
        button_panel.pack_end(exit_button, False, False, 0)

        chroot_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['chroot'])
        chroot_button.set_use_underline(True)
        chroot_button.connect("clicked", self.on_chroot_clicked)
        button_panel.pack_end(chroot_button, False, False, 5)

        install_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['install'])
        install_button.set_use_underline(True)
        install_button.connect("clicked", self.on_install_clicked)
        install_button.get_style_context().add_class("install-button")
        button_panel.pack_end(install_button, False, False, 5)

        # Barra de progreso al final del main_box
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(False)  # Inicialmente sin texto
        self.progress_bar.set_visible(False)
        main_box.pack_end(self.progress_bar, False, True, 0)

        # Añadir CSS para el botón de instalación
        css_provider = Gtk.CssProvider()
        css = b"""
            .install-button {
                background: #e95420;
                color: white;
                padding: 5px 10px;
                font-weight: bold;
            }
            .install-button:hover {
                background: #e9662b;
            }
        """
        css_provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def on_language_changed(self, combo):
        lang_name = combo.get_active_text()
        lang_config = LANGUAGES[lang_name]
        
        # Mostrar barra de progreso con texto
        self.progress_bar.set_visible(True)
        self.progress_bar.set_show_text(True)  # Ahora mostramos el texto
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text(STRINGS[self.current_lang]['progress']['configuring'])
        
        try:
            # Actualizar la barra de progreso mientras se realizan las tareas
            self.progress_bar.set_fraction(0.2)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Verificar cuál archivo existe y modificarlo apropiadamente
            # Generalmente uno es un enlace simbólico al otro
            locale_conf = '/etc/locale.conf'
            debian_locale = '/etc/default/locale'
            
            # Crear contenido para la configuración de locale
            locale_content = f'LANG={lang_config["locale"]}\n'
            
            # Determinar qué archivo modificar (preferimos /etc/locale.conf si existe)
            target_file = locale_conf if os.path.exists(locale_conf) else debian_locale
            
            # Escribir en el archivo apropiado
            subprocess.run(['pkexec', 'bash', '-c', f'echo "{locale_content}" > {target_file}'], 
                         check=True, capture_output=True)

            self.progress_bar.set_fraction(0.4)
            while Gtk.events_pending():
                Gtk.main_iteration()
            
            # Configurar layout de teclado
            subprocess.run(['setxkbmap', lang_config['layout']], check=True)
            
            # Hacer el cambio permanente
            xorg_conf = f"""Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{lang_config['layout']}"
EndSection"""
            
            # Crear directorio si no existe
            os.makedirs("/etc/X11/xorg.conf.d", exist_ok=True)
            
            # Escribir configuración
            subprocess.run(['pkexec', 'bash', '-c', 
                          f'echo \'{xorg_conf}\' > /etc/X11/xorg.conf.d/00-keyboard.conf'],
                         check=True, capture_output=True)

            self.progress_bar.set_fraction(0.6)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Migrar carpetas XDG
            home_dir = os.path.expanduser('~')
            
            # 1. Obtener nombres actuales y nuevos de las carpetas
            old_dirs = {}
            with open(os.path.join(home_dir, '.config/user-dirs.dirs'), 'r') as f:
                for line in f:
                    if line.startswith('XDG_'):
                        key, value = line.strip().split('=')
                        old_dirs[key] = value.strip('"').replace('$HOME/', '')

            # 2. Forzar la actualización de los nombres pero con el nuevo idioma
            subprocess.run(['env', f'LANG={lang_config["locale"]}', 'xdg-user-dirs-update', '--force'])
            
            # 3. Obtener los nuevos nombres post-actualización
            new_dirs = {}
            with open(os.path.join(home_dir, '.config/user-dirs.dirs'), 'r') as f:
                for line in f:
                    if line.startswith('XDG_'):
                        key, value = line.strip().split('=')
                        new_dirs[key] = value.strip('"').replace('$HOME/', '')

            # 4. Migrar el contenido de forma segura
            for key in old_dirs:
                old_path = os.path.join(home_dir, old_dirs[key])
                new_path = os.path.join(home_dir, new_dirs[key])
                
                if os.path.exists(old_path):
                    # Si la carpeta nueva ya existe, mover el contenido
                    if os.path.exists(new_path):
                        try:
                            # Mover todo el contenido de old_path a new_path
                            for item in os.listdir(old_path):
                                old_item = os.path.join(old_path, item)
                                new_item = os.path.join(new_path, item)
                                # Si el destino no existe, mover
                                if not os.path.exists(new_item):
                                    shutil.move(old_item, new_item)
                        except (shutil.Error, OSError) as e:
                            print(f"Error moving {old_item}: {e}")
                            continue
                    else:
                        # Si la carpeta nueva no existe, renombrar directamente
                        try:
                            shutil.move(old_path, new_path)
                        except (shutil.Error, OSError) as e:
                            print(f"Error renaming {old_path}: {e}")
                            continue
                
                # Intentar eliminar la carpeta antigua si está vacía
                try:
                    if os.path.exists(old_path) and not os.listdir(old_path):
                        os.rmdir(old_path)
                except OSError:
                    continue

            # 5. Actualizar la configuración de xdg-user-dirs
            subprocess.run(['xdg-user-dirs-update'])

            # 6. Restaurar la configuración de XFCE para mostrar solo home y papelera
            xfce_config = os.path.expanduser('~/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml')
            if os.path.exists(xfce_config):
                # Hacer backup del archivo original
                shutil.copy2(xfce_config, f"{xfce_config}.bak")
                
                # Activar los iconos del escritorio
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/style',
                    '--set', '2'  # Cambiado de 0 a 2 para mostrar iconos
                ])
                
                # Configurar qué iconos mostrar
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-filesystem',
                    '--set', 'false'
                ])
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-home',
                    '--set', 'true'  # Mostrar carpeta personal
                ])
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-trash',
                    '--set', 'true'  # Mostrar papelera
                ])
                subprocess.run([
                    'xfconf-query',
                    '--channel', 'xfce4-desktop',
                    '--property', '/desktop-icons/file-icons/show-removable',
                    '--set', 'false'
                ])

            self.progress_bar.set_fraction(0.8)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Reiniciar LightDM después de la migración
            subprocess.run(['pkexec', 'systemctl', 'restart', 'lightdm'], 
                         check=True, capture_output=True)

            self.progress_bar.set_fraction(1.0)
            while Gtk.events_pending():
                Gtk.main_iteration()

        except subprocess.CalledProcessError as e:
            self.progress_bar.set_visible(False)
            error_msg = e.stderr.decode() if e.stderr else str(e)
            self.show_error_dialog(f"{STRINGS[self.current_lang]['locale']['error_generating']}\n{error_msg}")
    
    def show_error_dialog(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def on_exit_clicked(self, widget):
        """Manejador para el botón de salida"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=STRINGS[self.current_lang]['dialog']['exit_title']
        )
        dialog.format_secondary_text(STRINGS[self.current_lang]['dialog']['exit_desc'])
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            app = self.get_application()
            if app:
                app.quit()
    
    def on_window_destroy(self, window):
        """Manejador para la señal destroy"""
        app = self.get_application()
        if app:
            app.quit()

    def on_chroot_clicked(self, button):
        """Abre la ventana de CHROOT"""
        os.environ['NO_AT_BRIDGE'] = '1'
        os.environ['GTK_MODULES'] = ''
        os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''
        os.environ['XDG_RUNTIME_DIR'] = f"/run/user/{os.getuid()}"
        os.environ['DISPLAY'] = ':0'
        
        from ui.chroot_window import ChRootWindow
        chroot_window = ChRootWindow()
        chroot_window.show_all()

    def on_gparted_clicked(self, button):
        """Ejecuta GParted"""
        os.system('sudo gparted')  # Usar os.system directamente

    def on_install_clicked(self, button):
        """Ejecuta el instalador Calamares"""
        subprocess.Popen(['sudo', 'calamares'])  # Primero ejecutamos calamares
        GLib.timeout_add(1000, lambda: self.destroy())  # Luego destruimos la ventana después de 1 segundo

    def on_autostart_toggled(self, switch, gparam):
        """Maneja el cambio en el switch de autostart"""
        if switch.get_active():
            self.autostart_manager.enable()
        else:
            self.autostart_manager.disable()

    def on_numlockx_toggled(self, switch, gparam):
        """Maneja el cambio en el switch de numlockx"""
        from utils.numlockx_manager import NumlockxManager
        
        numlockx_manager = NumlockxManager()
        try:
            if switch.get_active():
                numlockx_manager.enable_numlockx()
            else:
                numlockx_manager.disable_numlockx()
        except Exception as e:
            self.show_error_dialog(str(e))