"""
Módulo para diálogos de la interfaz gráfica
"""

from src.gui.dialogs.repo_dialog import RepoDialog
from src.gui.dialogs.speed_dialog import RepoSpeedDialog
