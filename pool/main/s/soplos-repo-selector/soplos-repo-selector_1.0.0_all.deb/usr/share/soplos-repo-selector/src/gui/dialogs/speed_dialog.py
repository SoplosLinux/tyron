import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Pango, GObject
import threading
import time
import socket
from urllib.parse import urlparse
import subprocess
import platform
import os
# Importar el sistema de internacionalización
from src.i18n.strings import get_string

# Actualizar las distribuciones Debian para incluir más opciones de repositorios
DEBIAN_DISTRIBUTIONS = [
    "stable",
    "stable-updates",
    "stable-security",
    "stable-backports",
    "testing",
    "testing-updates",
    "testing-security",
    "testing-proposed-updates",
    "testing-backports",
    "unstable",
    "sid",
    "bookworm",
    "bookworm-updates",
    "bookworm-security",
    "bookworm-backports",
    "bullseye",
    "bullseye-updates", 
    "bullseye-security",
    "bullseye-backports",
    "trixie",
    "trixie-updates",
    "trixie-security",
    "trixie-backports",
    "experimental"
]

# Ampliar la lista de componentes comunes
COMMON_COMPONENTS = [
    "main", 
    "contrib", 
    "non-free",
    "non-free-firmware"
]

# Mapeo de tipos de repositorios según su distribución
REPO_TYPE_MAPPING = {
    "security": "https://security.debian.org/debian-security/",
    "updates": "mirror",  # Usar el mismo mirror que el base
    "proposed-updates": "mirror",  # Usar el mismo mirror que el base
    "backports": "mirror"  # Usar el mismo mirror que el base
}

class RepoSpeedTester(GObject.GObject):
    """Clase para probar la velocidad de repositorios"""
    
    __gsignals__ = {
        'test-completed': (GObject.SignalFlags.RUN_FIRST, None, (str, float)),
        'all-tests-completed': (GObject.SignalFlags.RUN_FIRST, None, ())
    }
    
    def __init__(self):
        GObject.GObject.__init__(self)
        self.mirrors = self.get_all_mirrors()
        self.stop_requested = False
        self.results = {}
    
    def get_all_mirrors(self):
        """Obtiene una lista completa de mirrors de Debian"""
        mirrors_dict = self.get_country_mirrors()
        all_mirrors = []
        
        for country, mirrors in mirrors_dict.items():
            for mirror in mirrors:
                all_mirrors.append({
                    'url': mirror,
                    'country': country
                })
        
        return all_mirrors
    
    def get_country_mirrors(self):
        """Devuelve un diccionario con mirrors por país usando traducciones"""
        return {
            get_string('country_global', 'Global (CDN)'): ['http://deb.debian.org/debian'],
            get_string('country_usa', 'Estados Unidos'): [
                'http://ftp.us.debian.org/debian',
                'http://mirrors.kernel.org/debian'
            ],
            get_string('country_uk', 'Reino Unido'): [
                'http://ftp.uk.debian.org/debian',
                'http://mirror.bytemark.co.uk/debian'
            ],
            get_string('country_germany', 'Alemania'): [
                'http://ftp.de.debian.org/debian',
                'http://ftp.gwdg.de/pub/linux/debian'
            ],
            get_string('country_france', 'Francia'): [
                'http://ftp.fr.debian.org/debian',
                'http://debian.mirrors.ovh.net/debian'
            ],
            get_string('country_spain', 'España'): [
                'http://ftp.es.debian.org/debian',
                'http://debian.redimadrid.es/debian'
            ],
            get_string('country_italy', 'Italia'): ['http://ftp.it.debian.org/debian'],
            get_string('country_brazil', 'Brasil'): ['http://ftp.br.debian.org/debian'],
            get_string('country_japan', 'Japón'): ['http://ftp.jp.debian.org/debian'],
            get_string('country_australia', 'Australia'): ['http://ftp.au.debian.org/debian'],
            get_string('country_canada', 'Canadá'): ['http://ftp.ca.debian.org/debian'],
            get_string('country_russia', 'Rusia'): ['http://ftp.ru.debian.org/debian'],
            get_string('country_switzerland', 'Suiza'): ['http://ftp.ch.debian.org/debian'],
            get_string('country_sweden', 'Suecia'): ['http://ftp.se.debian.org/debian'],
            get_string('country_netherlands', 'Países Bajos'): ['http://ftp.nl.debian.org/debian'],
            get_string('country_china', 'China'): ['http://ftp.cn.debian.org/debian']
        }
    
    def measure_ping(self, url):
        """Mide el tiempo de respuesta (ping) a un repositorio"""
        hostname = urlparse(url).netloc
        
        try:
            # Intentar primero con ping
            if platform.system() == "Windows":
                ping_cmd = ["ping", "-n", "3", hostname]
            else:
                ping_cmd = ["ping", "-c", "3", hostname]
            
            try:
                start_time = time.time()
                result = subprocess.run(ping_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5, text=True)
                ping_time = time.time() - start_time
                
                if result.returncode == 0:
                    # Extraer tiempo de respuesta
                    if "min/avg/max" in result.stdout:
                        # Linux format
                        parts = result.stdout.split("min/avg/max")[1].strip()
                        if "=" in parts:
                            avg_time = float(parts.split("=")[1].split("/")[1])
                            return avg_time
                    
                    # Si no podemos extraer, usar el tiempo total dividido por 3
                    return ping_time / 3
            except:
                pass
            
            # Si ping falla, intentar con socket
            start = time.time()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2.0)
            s.connect((hostname, 80))
            s.close()
            latency = time.time() - start
            return latency * 1000  # Convertir a ms
            
        except Exception as e:
            print(f"Error al medir ping para {url}: {e}")
            return 9999.0  # Valor alto para indicar error
    
    def start_speed_test(self, filtered_mirrors=None):
        """
        Inicia pruebas de velocidad en segundo plano
        
        Args:
            filtered_mirrors: Lista opcional de mirrors para probar (por defecto, usa todos)
        """
        self.stop_requested = False
        self.results = {}
        
        # Usar los mirrors filtrados si se especifican
        self.test_mirrors = filtered_mirrors if filtered_mirrors is not None else self.mirrors
        
        # Iniciar en un hilo para no bloquear la UI
        threading.Thread(target=self._do_speed_test, daemon=True).start()
    
    def stop_speed_test(self):
        """Detiene las pruebas de velocidad en curso"""
        self.stop_requested = True
    
    def _do_speed_test(self):
        """Realiza pruebas de velocidad para cada mirror"""
        all_results = []  # Lista para almacenar todos los resultados
        
        for mirror in self.test_mirrors:  # Usar self.test_mirrors en lugar de self.mirrors
            if self.stop_requested:
                break
                
            url = mirror['url']
            ping_time = self.measure_ping(url)
            country = mirror['country']
            
            # Almacenar resultados
            all_results.append((url, ping_time, country))
            self.results[url] = {
                'ping': ping_time,
                'country': country
            }
            
            # Emitir señal con resultados parciales
            GLib.idle_add(self.emit, 'test-completed', url, ping_time)
            
            # Breve pausa para no sobrecargar
            time.sleep(0.2)
        
        # Ordenar resultados por ping antes de emitir la señal final
        all_results.sort(key=lambda x: x[1])  # Ordenar por ping (segundo elemento)
        
        # Actualizar resultados ordenados
        self.ordered_results = all_results
        
        # Emitir señal de finalización
        GLib.idle_add(self.emit, 'all-tests-completed')

    # Añadir método para obtener resultados ordenados
    def get_ordered_results(self):
        """Devuelve los repositorios ordenados por velocidad"""
        if hasattr(self, 'ordered_results'):
            return self.ordered_results
        else:
            # Si no hay resultados ordenados, ordenar los existentes
            sorted_results = sorted(
                [(url, data['ping'], data['country']) for url, data in self.results.items()],
                key=lambda x: x[1]
            )
            return sorted_results
    
    def get_fastest_mirrors(self, limit=10):
        """Devuelve los repositorios más rápidos"""
        # Ordenar por ping (menor primero)
        sorted_results = sorted(
            [(url, data['ping'], data['country']) for url, data in self.results.items()],
            key=lambda x: x[1]
        )
        
        # Devolver los más rápidos
        return sorted_results[:limit]


class RepoSpeedDialog(Gtk.Dialog):
    """Diálogo para encontrar y seleccionar los repositorios más rápidos"""
    
    def __init__(self, parent, current_repos=None):
        super().__init__(
            title=get_string("find_fastest_repos", "Buscar Repositorios Más Rápidos"),
            transient_for=parent,
            flags=Gtk.DialogFlags.MODAL,
            buttons=(get_string("cancel", "_Cancelar"), Gtk.ResponseType.CANCEL,
                    get_string("select", "_Seleccionar"), Gtk.ResponseType.OK)
        )
        
        self.set_default_size(800, 500)
        self.set_default_response(Gtk.ResponseType.OK)
        
        self.current_repos = current_repos or []
        self.selected_repos = []
        self.speed_tester = RepoSpeedTester()
        
        # Inicializar los modelos de datos antes de crear los widgets
        # y conectar las señales
        self.speed_store = Gtk.ListStore(bool, str, str, float, str)  # Seleccionado, URL, País, Ping, Estado
        self.dist_store = Gtk.ListStore(bool, str, bool, str)  # Seleccionado, Distribución, Backports, Componentes
        
        # Mantener una copia completa de todas las distribuciones para poder filtrar
        self.all_distributions = []
        
        # Llenar el modelo de distribuciones con datos iniciales
        for dist in DEBIAN_DISTRIBUTIONS:
            is_backport = "backport" in dist
            
            # Seleccionar componentes adecuados según la distribución
            if dist == "experimental":
                components = "main contrib non-free"
            elif "bookworm" in dist or dist == "trixie":
                components = "main contrib non-free non-free-firmware"
            elif is_backport:
                components = "main contrib non-free"
            else:
                components = "main contrib non-free"
            
            # Guardar en la lista completa para filtrado posterior
            self.all_distributions.append({
                'name': dist,
                'is_backport': is_backport,
                'components': components,
                'selected': True  # Por defecto todos seleccionados
            })
                
            self.dist_store.append([True, dist, is_backport, components])
        
        # Conectar señales del tester
        self.speed_tester.connect('test-completed', self.on_test_completed)
        self.speed_tester.connect('all-tests-completed', self.on_all_tests_completed)
        
        # Contenido principal
        content_area = self.get_content_area()
        content_area.set_margin_top(10)
        content_area.set_margin_bottom(10)
        content_area.set_margin_start(10)
        content_area.set_margin_end(10)
        content_area.set_spacing(10)
        
        # Panel superior con controles de filtro
        control_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        content_area.pack_start(control_box, False, True, 0)
        
        # Selector de país
        country_label = Gtk.Label(label=get_string("country", "País") + ":")
        control_box.pack_start(country_label, False, False, 0)
        
        self.country_combo = Gtk.ComboBoxText()
        self.country_combo.append_text(get_string("all_countries", "Todos los países"))
        
        # Añadir países
        for country in sorted(self.speed_tester.get_country_mirrors().keys()):
            self.country_combo.append_text(country)
        
        self.country_combo.set_active(0)  # "Todos los países" por defecto
        self.country_combo.connect('changed', self.on_filter_changed)
        control_box.pack_start(self.country_combo, False, True, 0)
        
        # Selector de distribución
        dist_label = Gtk.Label(label=get_string("distribution", "Distribución") + ":")
        control_box.pack_start(dist_label, False, False, 0)
        
        self.dist_combo = Gtk.ComboBoxText()
        self.dist_combo.append_text(get_string("all_distributions", "Todas las distribuciones"))
        
        # Añadir distribuciones
        for dist in DEBIAN_DISTRIBUTIONS:
            self.dist_combo.append_text(dist)
        
        self.dist_combo.set_active(0)  # "Todas las distribuciones" por defecto
        self.dist_combo.connect('changed', self.on_filter_changed)
        control_box.pack_start(self.dist_combo, False, True, 0)
        
        # Espaciador
        control_box.pack_start(Gtk.Box(), True, True, 0)
        
        # Botón para iniciar/detener test
        self.test_button = Gtk.Button(label=get_string("start_speed_test", "Iniciar prueba de velocidad"))
        self.test_button.connect("clicked", self.on_test_button_clicked)
        control_box.pack_start(self.test_button, False, False, 0)
        
        # Spinner para indicar que la prueba está en progreso
        self.spinner = Gtk.Spinner()
        control_box.pack_start(self.spinner, False, False, 0)
        
        # Etiqueta de estado - IMPORTANTE: Mover esta definición antes de usar el notebook
        self.status_label = Gtk.Label(label=get_string("select_repos_and_start", "Seleccione repositorios y haga clic en 'Iniciar prueba de velocidad'"))
        self.status_label.set_halign(Gtk.Align.START)
        content_area.pack_start(self.status_label, False, False, 0)
        
        # Panel principal con notebook
        self.notebook = Gtk.Notebook()
        content_area.pack_start(self.notebook, True, True, 0)
        
        # Pestaña de resultados de velocidad
        speed_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.notebook.append_page(speed_page, Gtk.Label(label=get_string("speed_results", "Resultados de velocidad")))
        
        # Lista de resultados de velocidad
        self.speed_view = Gtk.TreeView(model=self.speed_store)
        
        # Añadir columnas
        self._add_column_to_view(self.speed_view, get_string("select", "Seleccionar"), 0, True)
        self._add_column_to_view(self.speed_view, get_string("repository", "Repositorio"), 1)
        self._add_column_to_view(self.speed_view, get_string("country", "País"), 2)
        self._add_column_to_view(self.speed_view, get_string("ping_ms", "Ping (ms)"), 3, False, True)
        self._add_column_to_view(self.speed_view, get_string("state", "Estado"), 4)
        
        # Scrolled window para la vista
        sw_speed = Gtk.ScrolledWindow()
        sw_speed.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw_speed.add(self.speed_view)
        speed_page.pack_start(sw_speed, True, True, 0)
        
        # Botón para continuar a la siguiente pestaña
        continue_button = Gtk.Button(label=get_string("continue_to_distributions", "Continuar con selección de distribuciones →"))
        continue_button.get_style_context().add_class("suggested-action")
        continue_button.connect("clicked", self.on_continue_clicked)
        speed_page.pack_start(continue_button, False, False, 0)
        
        # Pestaña de selección de distribuciones
        dist_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.notebook.append_page(dist_page, Gtk.Label(label=get_string("distribution_selection", "Selección de distribuciones")))
        
        # Panel informativo
        info_label = Gtk.Label()
        info_label.set_markup("<b>" + get_string("select_distributions_prompt", "Seleccione las distribuciones que desea añadir para los repositorios seleccionados:") + "</b>")
        info_label.set_halign(Gtk.Align.START)
        dist_page.pack_start(info_label, False, False, 0)
        
        # Vista de árbol para distribuciones
        self.dist_view = Gtk.TreeView(model=self.dist_store)
        
        # Añadir columnas
        self._add_column_to_view(self.dist_view, get_string("select", "Seleccionar"), 0, True)
        self._add_column_to_view(self.dist_view, get_string("distribution", "Distribución"), 1)
        self._add_column_to_view(self.dist_view, get_string("backports", "Backports"), 2, True)
        
        # Columna de componentes editable
        renderer_text = Gtk.CellRendererText()
        renderer_text.set_property("editable", True)
        renderer_text.connect("edited", self.on_component_edited)
        column = Gtk.TreeViewColumn(get_string("components", "Componentes"), renderer_text, text=3)
        column.set_resizable(True)
        self.dist_view.append_column(column)
        
        # Scrolled window para la vista de distribuciones
        sw_dist = Gtk.ScrolledWindow()
        sw_dist.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw_dist.add(self.dist_view)
        dist_page.pack_start(sw_dist, True, True, 0)
        
        # Botones para seleccionar/deseleccionar todo
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        dist_page.pack_start(button_box, False, False, 0)
        
        select_all_button = Gtk.Button(label=get_string("select_all", "Seleccionar todo"))
        select_all_button.connect("clicked", self.on_select_all_clicked, True)
        button_box.pack_start(select_all_button, False, False, 0)
        
        deselect_all_button = Gtk.Button(label=get_string("deselect_all", "Deseleccionar todo"))
        deselect_all_button.connect("clicked", self.on_select_all_clicked, False)
        button_box.pack_start(deselect_all_button, False, False, 0)
        
        # Botón para volver a la primera pestaña
        back_button = Gtk.Button(label=get_string("back_to_repos", "← Volver a selección de repositorios"))
        back_button.connect("clicked", self.on_back_clicked)
        button_box.pack_end(back_button, False, False, 0)
        
        # Inicializar la lista de repositorios
        self._populate_repos()
        
        # IMPORTANTE: Conectar la señal del notebook después de que todos los
        # atributos necesarios estén inicializados
        self.notebook.connect('switch-page', self.on_notebook_page_switched)
        
        self.show_all()
    
    def on_continue_clicked(self, button):
        """Maneja el clic en el botón Continuar"""
        # Verificar si hay repositorios seleccionados
        selected_repos_count = sum(1 for row in self.speed_store if row[0])
        
        if selected_repos_count == 0:
            self.status_label.set_text(get_string("please_select_repo", "⚠️ Por favor, seleccione al menos un repositorio antes de continuar"))
            return
        
        # Asegurar que se aplica el filtro actual al cambiar de pestaña
        selected_dist = self.dist_combo.get_active_text()
        if selected_dist != get_string("all_distributions", "Todas las distribuciones"):
            self._filter_distributions(selected_dist)
        
        # Cambiar a la pestaña de distribuciones
        self.notebook.set_current_page(1)
        
        # Actualizar mensaje de estado
        visible_dist_count = len(self.dist_store)
        self.status_label.set_text(
            get_string("selected_repos_and_distributions", 
                       "Seleccionados {0} repositorios. Hay {1} distribuciones disponibles según el filtro actual.").format(
                selected_repos_count, visible_dist_count)
        )

    def on_back_clicked(self, button):
        """Maneja el clic en el botón Volver"""
        # Cambiar a la pestaña de repositorios
        self.notebook.set_current_page(0)
        
        # Actualizar mensaje de estado
        selected_count = sum(1 for row in self.speed_store if row[0])
        self.status_label.set_text(get_string("selected_repos_count", "Seleccionados {0} repositorios.").format(selected_count))
    
    def on_notebook_page_switched(self, notebook, page, page_num):
        """Maneja el cambio entre pestañas"""
        # Verificar que los atributos necesarios estén inicializados
        if not hasattr(self, 'dist_store') or not hasattr(self, 'speed_store'):
            print("Advertencia: Algunos atributos necesarios no están inicializados")
            return
        
        # Actualizar filtros de distribuciones al cambiar de pestaña
        selected_dist = self.dist_combo.get_active_text()
        all_distributions_text = get_string("all_distributions", "Todas las distribuciones")
        if selected_dist != all_distributions_text and page_num == 1:
            self._filter_distributions(selected_dist)
            
        if page_num == 1:  # Cuando cambia a la pestaña de selección de distribuciones
            # Actualizar el estado de selección basado en la pestaña de resultados
            selected_repos_count = sum(1 for row in self.speed_store if row[0])
            
            if selected_repos_count == 0:
                self.status_label.set_text(get_string("warning_no_repos", "⚠️ Atención: No hay repositorios seleccionados en la pestaña anterior."))
            else:
                # Contar distribuciones visibles después del filtrado
                visible_dist_count = len(self.dist_store)
                
                self.status_label.set_text(
                    get_string("selected_repos_and_distributions", 
                               "Has seleccionado {0} repositorios. Hay {1} distribuciones disponibles según el filtro actual.").format(
                        selected_repos_count, visible_dist_count)
                )
        elif page_num == 0:  # Cuando cambia a la pestaña de resultados de velocidad
            # Mostrar número de distribuciones seleccionadas
            dist_count = sum(1 for row in self.dist_store if row[0])
            repo_count = sum(1 for row in self.speed_store if row[0])
            
            if repo_count > 0:
                self.status_label.set_text(
                    get_string("selected_repos_and_dists_count", 
                               "Seleccionados {0} repositorios y {1} distribuciones.").format(repo_count, dist_count)
                )
    
    def _add_column_to_view(self, view, title, column_id, is_toggle=False, is_numeric=False):
        """Añade una columna a la vista de árbol"""
        if is_toggle:
            renderer = Gtk.CellRendererToggle()
            renderer.connect("toggled", self.on_cell_toggled, view, column_id)
            column = Gtk.TreeViewColumn(title, renderer, active=column_id)
        else:
            renderer = Gtk.CellRendererText()
            renderer.set_property("xpad", 8)  # Añadir padding horizontal
            if is_numeric:
                column = Gtk.TreeViewColumn(title, renderer, text=column_id)
                # Formatear números con 2 decimales
                column.set_cell_data_func(renderer, self._format_numeric_cell)
            else:
                column = Gtk.TreeViewColumn(title, renderer, text=column_id)
        
        column.set_resizable(True)  # Asegurar que las columnas sean redimensionables
        
        # Configurar anchos mínimos sin impedir redimensionado manual
        if not is_toggle:
            column.set_expand(True)
            
            # Configurar anchos mínimos específicos para speed_view
            if view == self.speed_view:
                if column_id == 1:  # URL
                    column.set_min_width(250)
                elif column_id == 2:  # País
                    column.set_min_width(120)
                elif column_id == 3:  # Ping
                    column.set_min_width(80)
                elif column_id == 4:  # Estado
                    column.set_min_width(100)
            # Configurar anchos mínimos para dist_view
            elif view == self.dist_view:
                if column_id == 1:  # Distribución
                    column.set_min_width(150)
                elif column_id == 3:  # Componentes
                    column.set_min_width(250)
        
        if is_numeric:
            column.set_sort_column_id(column_id)
        view.append_column(column)
        return column
    
    def _populate_repos(self):
        """Llena la lista de repositorios disponibles con filtrado"""
        # Limpiar la lista existente
        self.speed_store.clear()
        
        # Obtener el país y la distribución seleccionados para filtrar
        selected_country = self.country_combo.get_active_text()
        selected_dist = self.dist_combo.get_active_text()
        
        # Obtener todos los repositorios
        for mirror in self.speed_tester.mirrors:
            url = mirror['url']
            country = mirror['country']
            
            # Aplicar filtro de país si no es "Todos los países"
            if selected_country != get_string("all_countries", "Todos los países") and country != selected_country:
                continue
            
            # Verificar si ya existe en los repositorios actuales
            exists = url in self.current_repos
            
            # Añadir a la lista
            self.speed_store.append([not exists, url, country, 0.0, get_string("not_tested", "No probado")])

        # Ya no usamos ajuste automático que interfiere con el redimensionado manual
    
    def on_test_completed(self, tester, url, ping):
        """Actualiza la UI cuando se completa una prueba"""
        # Buscar y actualizar la fila correspondiente
        for row in self.speed_store:
            if row[1] == url:
                row[3] = ping
                
                if ping < 50:
                    state = get_string("excellent", "Excelente")
                elif ping < 100:
                    state = get_string("good", "Bueno")
                elif ping < 200:
                    state = get_string("regular", "Regular")
                elif ping < 500:
                    state = get_string("slow", "Lento")
                else:
                    state = get_string("very_slow", "Muy lento")
                
                if ping >= 9999:
                    state = get_string("error", "Error")
                    
                row[4] = state
                break
                
    def _populate_repos(self):
        """Llena la lista de repositorios disponibles con filtrado"""
        # Limpiar la lista existente
        self.speed_store.clear()
        
        # Obtener el país y la distribución seleccionados para filtrar
        selected_country = self.country_combo.get_active_text()
        selected_dist = self.dist_combo.get_active_text()
        
        # Obtener todos los repositorios
        for mirror in self.speed_tester.mirrors:
            url = mirror['url']
            country = mirror['country']
            
            # Aplicar filtro de país si no es "Todos los países"
            if selected_country != get_string("all_countries", "Todos los países") and country != selected_country:
                continue
            
            # Verificar si ya existe en los repositorios actuales
            exists = url in self.current_repos
            
            # Añadir a la lista
            self.speed_store.append([not exists, url, country, 0.0, get_string("not_tested", "No probado")])

        # Ya no usamos ajuste automático que interfiere con el redimensionado manual
    
    def on_test_completed(self, tester, url, ping):
        """Actualiza la UI cuando se completa una prueba"""
        # Buscar y actualizar la fila correspondiente
        for row in self.speed_store:
            if row[1] == url:
                row[3] = ping
                
                if ping < 50:
                    state = get_string("excellent", "Excelente")
                elif ping < 100:
                    state = get_string("good", "Bueno")
                elif ping < 200:
                    state = get_string("regular", "Regular")
                elif ping < 500:
                    state = get_string("slow", "Lento")
                else:
                    state = get_string("very_slow", "Muy lento")
                
                if ping >= 9999:
                    state = get_string("error", "Error")
                    
                row[4] = state
                break

    def _filter_distributions(self, selected_dist):
        """Filtra la lista de distribuciones según el filtro seleccionado"""
        # Preservar el estado de selección actual
        selected_dists = {}
        for i, row in enumerate(self.dist_store):
            selected_dists[row[1]] = row[0]  # Guardar si estaba seleccionada
        
        # Limpiar la lista actual
        self.dist_store.clear()
        
        # Si no hay filtro específico, mostrar todas
        if selected_dist == "Todas las distribuciones":
            for dist_info in self.all_distributions:
                # Recuperar estado de selección anterior si existe
                selected = selected_dists.get(dist_info['name'], True)
                self.dist_store.append([
                    selected, 
                    dist_info['name'], 
                    dist_info['is_backport'], 
                    dist_info['components']
                ])
            return
        
        # Aplicar filtro específico
        # Ejemplos de filtros comunes:
        if selected_dist in ["stable", "testing", "unstable", "experimental"]:
            # Si es una rama principal, mostrar todas las relacionadas
            for dist_info in self.all_distributions:
                dist_name = dist_info['name']
                if dist_name.startswith(selected_dist) or dist_name == selected_dist:
                    # Para ramas principales, seleccionar automáticamente
                    self.dist_store.append([
                        True,  # Siempre seleccionado
                        dist_name,
                        dist_info['is_backport'],
                        dist_info['components']
                    ])
        elif selected_dist in ["bookworm", "bullseye", "buster", "trixie"]:
            # Si es una versión específica, mostrar la versión y sus variantes
            for dist_info in self.all_distributions:
                dist_name = dist_info['name']
                if dist_name.startswith(selected_dist) or dist_name == selected_dist:
                    # Para versiones específicas, seleccionar automáticamente
                    self.dist_store.append([
                        True,  # Siempre seleccionado
                        dist_name,
                        dist_info['is_backport'],
                        dist_info['components']
                    ])
        else:
            # Para cualquier otra selección específica
            for dist_info in self.all_distributions:
                dist_name = dist_info['name']
                if dist_name == selected_dist:
                    # Si es exactamente la distribución seleccionada
                    self.dist_store.append([
                        True,  # Seleccionado
                        dist_name,
                        dist_info['is_backport'],
                        dist_info['components']
                    ])
        
        # Ya no usamos ajuste automático que interfiere con el redimensionado manual
    
    def on_all_tests_completed(self, tester):
        """Actualiza la UI cuando todas las pruebas se han completado"""
        self.test_button.set_label(get_string("start_speed_test", "Iniciar prueba de velocidad"))
        self.spinner.stop()
        
        # Limpiar la lista actual
        self.speed_store.clear()
        
        # Obtener resultados ordenados
        ordered_results = self.speed_tester.get_ordered_results()
        
        # Añadir resultados ordenados a la lista
        for url, ping, country in ordered_results:
            # Determinar el estado según el ping
            if ping < 50:
                state = get_string("excellent", "Excelente")
            elif ping < 100:
                state = get_string("good", "Bueno")
            elif ping < 200:
                state = get_string("regular", "Regular")
            elif ping < 500:
                state = get_string("slow", "Lento")
            else:
                state = get_string("very_slow", "Muy lento")
        
        if ping >= 9999:
            state = get_string("error", "Error")
        
        # Determinar si ya existe en los repos actuales
        exists = url in self.current_repos
        
        # Añadir fila (ahora ordenada por velocidad)
        # Seleccionar automáticamente los 3 más rápidos si tienen buen ping
        auto_select = not exists and ordered_results.index((url, ping, country)) < 3 and ping < 200
        self.speed_store.append([auto_select, url, country, ping, state])
    
        # Actualizar etiqueta de estado
        if ordered_results:
            best_repo = ordered_results[0]
            self.status_label.set_text(
                get_string("test_completed", 
                          "Prueba completada. Se han preseleccionado los 3 repositorios más rápidos. Repositorio más rápido: {0} ({1}, {2:.2f} ms)").format(
                    best_repo[0], best_repo[2], best_repo[1]
                )
            )
            
            # Agregar un retraso visual para que el usuario vea los resultados antes de cambiar de página
            GLib.timeout_add(2500, self._show_continue_suggestion)
        else:
            self.status_label.set_text(get_string("no_valid_repos_found", "Prueba completada. No se encontraron repositorios válidos."))
    
    def _show_continue_suggestion(self):
        """Muestra una sugerencia para continuar después de un retraso"""
        self.status_label.set_text(
            get_string("select_repos_and_continue", 
                      "Seleccione los repositorios deseados y haga clic en 'Continuar' o en la pestaña 'Selección de distribuciones'")
        )
        return False  # Importante para el timeout_add
    
    def get_selected_repos(self):
        """Devuelve los repositorios seleccionados con su distribución"""
        result = []
        
        # Obtener repositorios seleccionados
        selected_urls = []
        for row in self.speed_store:
            if row[0]:  # Si está seleccionado
                selected_urls.append({
                    'url': row[1],
                    'country': row[2],
                    'ping': row[3]
                })
        
        # Obtener distribuciones seleccionadas
        selected_dists = []
        for row in self.dist_store:
            if row[0]:  # Si está seleccionado
                dist_name = row[1]
                
                # Identificar si es un tipo especial (security, updates, etc.)
                dist_type = "base"  # Por defecto
                for suffix in ["security", "updates", "proposed-updates", "backports"]:
                    if dist_name.endswith(f"-{suffix}"):
                        dist_type = suffix
                        break
                
                selected_dists.append({
                    'name': dist_name,
                    'is_backport': row[2],
                    'components': row[3],
                    'type': dist_type
                })
        
        # Si no hay ninguna selección, mostrar un mensaje y cambiar a la pestaña correspondiente
        if not selected_urls:
            self.status_label.set_text(get_string("please_select_repo", "⚠️ Por favor, seleccione al menos un repositorio"))
            self.notebook.set_current_page(0)  # Cambiar a la pestaña de resultados
            return []
        
        if not selected_dists:
            self.status_label.set_text(get_string("please_select_dist", "⚠️ Por favor, seleccione al menos una distribución"))
            self.notebook.set_current_page(1)  # Cambiar a la pestaña de distribuciones
            return []
        
        # Crear todas las combinaciones de repositorio + distribución
        for repo_info in selected_urls:
            for dist in selected_dists:
                url = repo_info['url']
                
                # Si es un repositorio de seguridad, usar la URL específica
                if dist['type'] == "security":
                    url = REPO_TYPE_MAPPING["security"]
                
                # Asegurar que los componentes sean válidos
                components = dist['components'].strip()
                if not components:
                    components = "main"
                    
                # Para cada URL, devolver una entrada por cada distribución
                result.append({
                    'uri': url,
                    'distribution': dist['name'],
                    'components': components,
                    'signed_by': "/usr/share/keyrings/debian-archive-keyring.gpg"
                })
        
        return result

    def on_filter_changed(self, combo):
        """Filtra la lista de repositorios según criterios seleccionados"""
        # Obtener los valores de filtro actuales
        selected_country = self.country_combo.get_active_text()
        selected_dist = self.dist_combo.get_active_text()
        
        # Recargar la lista de repositorios con los filtros aplicados
        self._populate_repos()
        
        # Filtrar también la lista de distribuciones
        self._filter_distributions(selected_dist)
        
        # Actualizar la etiqueta de estado con el filtro actual
        filter_text = []
        all_countries = get_string("all_countries", "Todos los países")
        all_distributions = get_string("all_distributions", "Todas las distribuciones")
        
        if selected_country != all_countries:
            filter_text.append(f"País: {selected_country}")
        if selected_dist != all_distributions:
            filter_text.append(f"Distribución: {selected_dist}")
        
        if filter_text:
            self.status_label.set_text(get_string("filtered_by", "Filtrado por: {0}").format(", ".join(filter_text)))
        else:
            self.status_label.set_text(get_string("showing_all_repos", "Mostrando todos los repositorios"))
    
    def on_test_button_clicked(self, button):
        """Inicia o detiene la prueba de velocidad"""
        if button.get_label() == get_string("start_speed_test", "Iniciar prueba de velocidad"):
            # Iniciar prueba
            button.set_label(get_string("stop_test", "Detener prueba"))
            self.spinner.start()
            self.status_label.set_text(get_string("testing_repos", "Probando repositorios... Esto puede tardar unos minutos."))
            
            # Filtrar los repos por país si hay un país seleccionado
            filtered_mirrors = None
            selected_country = self.country_combo.get_active_text()
            if selected_country != get_string("all_countries", "Todos los países"):
                filtered_mirrors = [m for m in self.speed_tester.mirrors if m['country'] == selected_country]
            
            # Limpiar resultados anteriores
            for row in self.speed_store:
                row[3] = 0.0
                row[4] = get_string("waiting", "Esperando...")
            
            # Iniciar prueba
            self.speed_tester.start_speed_test(filtered_mirrors)
        else:
            # Detener prueba
            button.set_label(get_string("start_speed_test", "Iniciar prueba de velocidad"))
            self.spinner.stop()
            self.status_label.set_text(get_string("test_stopped", "Prueba detenida por el usuario"))
            self.speed_tester.stop_speed_test()
    
    def _format_numeric_cell(self, column, renderer, model, iter, data):
        """Formatea celdas numéricas para mostrar con 2 decimales"""
        value = model.get_value(iter, 3)
        if value >= 9999:
            renderer.set_property("text", "Timeout")
        else:
            renderer.set_property("text", f"{value:.2f}")
    
    def _populate_repos(self):
        """Llena la lista de repositorios disponibles con filtrado"""
        # Limpiar la lista existente
        self.speed_store.clear()
        
        # Obtener el país y la distribución seleccionados para filtrar
        selected_country = self.country_combo.get_active_text()
        selected_dist = self.dist_combo.get_active_text()
        
        # Obtener todos los repositorios
        for mirror in self.speed_tester.mirrors:
            url = mirror['url']
            country = mirror['country']
            
            # Aplicar filtro de país si no es "Todos los países"
            if selected_country != get_string("all_countries", "Todos los países") and country != selected_country:
                continue
            
            # Verificar si ya existe en los repositorios actuales
            exists = url in self.current_repos
            
            # Añadir a la lista
            self.speed_store.append([not exists, url, country, 0.0, get_string("not_tested", "No probado")])

        # Ya no usamos ajuste automático que interfiere con el redimensionado manual
    
    def on_cell_toggled(self, cell, path, view, column_id):
        """Maneja el evento de toggle en una celda"""
        model = view.get_model()
        iter = model.get_iter(path)
        current = model[iter][column_id]
        model[iter][column_id] = not current
        
        # Si estamos en la vista de resultados, actualizar conteo
        if view == self.speed_view:
            selected_count = sum(1 for row in self.speed_store if row[0])
            if selected_count > 0:
                self.status_label.set_text(get_string("selected_repos_count", "Seleccionados {0} repositorios.").format(selected_count))
            else:
                self.status_label.set_text(get_string("no_repos_selected", "No hay repositorios seleccionados."))
    
    def on_component_edited(self, renderer, path, new_text):
        """Maneja la edición de componentes"""
        self.dist_store[path][3] = new_text
        
        # Mostrar un indicador para sugerir componentes comunes
        components = new_text.split()
        missing_components = []
        
        # Verificar componentes comunes que no están incluidos
        for comp in COMMON_COMPONENTS:
            if comp not in components:
                missing_components.append(comp)
        
        if missing_components and len(components) < 3:
            # Sugerir algunos componentes comunes que faltan
            suggestions = ", ".join(missing_components[:3])
            self.status_label.set_text(get_string("component_suggestion", "Sugerencia: considere añadir estos componentes: {0}").format(suggestions))
    
    def on_select_all_clicked(self, button, select_all):
        """Selecciona o deselecciona todas las distribuciones visibles"""
        # Recorrer todas las filas visibles y actualizar el estado de selección
        for row in self.dist_store:
            row[0] = select_all
        
        # Actualizar la etiqueta de estado
        if select_all:
            count = len(self.dist_store)
            self.status_label.set_text(get_string("selected_all_visible", "Se han seleccionado todas las distribuciones visibles ({0}).").format(count))
        else:
            self.status_label.set_text(get_string("deselected_all", "Se han deseleccionado todas las distribuciones."))