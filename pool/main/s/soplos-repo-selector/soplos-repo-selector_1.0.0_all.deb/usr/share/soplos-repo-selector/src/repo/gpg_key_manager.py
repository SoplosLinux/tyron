"""
Gestor de claves GPG para repositorios APT
"""

import os
import subprocess
import urllib.request
import tempfile
import re
from urllib.parse import urlparse
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from src.config.constants import COMMON_REPO_KEYS, KEYRINGS_DIR, ETC_KEYRINGS_DIR
from src.utils.error_handler import log_info, log_warning, log_error

# Mapa de URLs de claves GPG para repositorios comunes
GPG_KEY_URLS = {
    "dl.google.com": "https://dl.google.com/linux/linux_signing_key.pub",
    "packages.microsoft.com": "https://packages.microsoft.com/keys/microsoft.asc",
    "download.docker.com": "https://download.docker.com/linux/debian/gpg",
    "ppa.launchpad.net/obsproject": "http://keyserver.ubuntu.com/pks/lookup?op=get&search=0xBC7345F522079769",
    "deb.debian.org": None,  # Ya incluida en el sistema
    "security.debian.org": None,  # Ya incluida en el sistema
}

# Expresiones regulares para extraer información de llaves públicas GPG
KEY_ID_REGEX = re.compile(r'pub\s+(?:rsa|dsa)?(?:\d+)?\s+(?:\d{4}-\d{2}-\d{2})\s+([0-9A-F]{8,16})')
KEY_USER_REGEX = re.compile(r'uid\s+\[\s*\w+\]\s+(.*)')

def get_key_path_for_repo(repo_uri):
    """
    Determina la ruta de la clave GPG para un repositorio dado
    
    Args:
        repo_uri: URI del repositorio
        
    Returns:
        La ruta de la clave GPG si está definida en COMMON_REPO_KEYS, None en caso contrario
    """
    hostname = urlparse(repo_uri).netloc
    
    # Buscar coincidencias parciales en el mapa de claves conocidas
    for repo_host, key_paths in COMMON_REPO_KEYS.items():
        if repo_host in hostname:
            # Devolver la primera clave que existe
            for key_path in key_paths:
                if os.path.exists(key_path):
                    return key_path
    
    return None

def get_key_url_for_repo(repo_uri):
    """
    Determina la URL para descargar la clave GPG de un repositorio
    
    Args:
        repo_uri: URI del repositorio
        
    Returns:
        URL para descargar la clave GPG o None si no hay una URL conocida
    """
    hostname = urlparse(repo_uri).netloc
    
    # Buscar coincidencias parciales en el mapa de URLs de claves
    for repo_host, url in GPG_KEY_URLS.items():
        if repo_host in hostname:
            return url
    
    return None

def ensure_directory_exists(directory):
    """
    Asegura que un directorio exista, con permisos adecuados
    
    Args:
        directory: Ruta del directorio
        
    Returns:
        True si el directorio existe o fue creado, False en caso contrario
    """
    try:
        if not os.path.exists(directory):
            # Intentar crear directorio con pkexec
            subprocess.run(
                ["pkexec", "mkdir", "-p", directory],
                check=True,
                capture_output=True
            )
            subprocess.run(
                ["pkexec", "chmod", "755", directory],
                check=True,
                capture_output=True
            )
        return True
    except subprocess.CalledProcessError as e:
        log_error(f"Error al crear directorio {directory}: {e.stderr}")
        return False
    except Exception as e:
        log_error(f"Error al crear directorio {directory}: {str(e)}")
        return False

def download_and_install_key(url, key_name=None, parent_window=None):
    """
    Descarga e instala una clave GPG desde una URL
    
    Args:
        url: URL de la clave GPG
        key_name: Nombre para la clave (opcional)
        parent_window: Ventana padre para diálogos (opcional)
        
    Returns:
        Tupla (éxito, mensaje_o_ruta)
    """
    if not url:
        return False, "No URL provided"
    
    try:
        # Descargar la clave a un archivo temporal
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_path = temp_file.name
            
            with urllib.request.urlopen(url, timeout=10) as response:
                key_data = response.read()
                temp_file.write(key_data)
        
        # Determinar información básica sobre la clave descargada
        try:
            result = subprocess.run(
                ["gpg", "--show-keys", "--with-colons", temp_path],
                check=True,
                capture_output=True,
                text=True
            )
            
            # Extraer ID y usuario de la clave
            key_id = None
            key_user = None
            
            for line in result.stdout.splitlines():
                if line.startswith("pub"):
                    parts = line.split(":")
                    if len(parts) > 4:
                        key_id = parts[4][-8:].upper()  # Últimos 8 caracteres del ID
                elif line.startswith("uid"):
                    parts = line.split(":")
                    if len(parts) > 9:
                        key_user = parts[9]
            
            # Si se encontró ID y no hay nombre especificado, usarlo para nombrar la clave
            if key_id and not key_name:
                if key_user:
                    # Usar parte del nombre de usuario para generar un nombre descriptivo
                    clean_user = re.sub(r'[^a-zA-Z0-9]', '-', key_user.split('<')[0].strip())
                    key_name = f"{clean_user}-{key_id}.gpg"
                else:
                    key_name = f"key-{key_id}.gpg"
        except:
            # Si no se puede analizar, usar un nombre genérico con timestamp
            if not key_name:
                import time
                key_name = f"key-{int(time.time())}.gpg"
        
        # Asegurar que termina en .gpg
        if not key_name.endswith('.gpg'):
            key_name = f"{key_name}.gpg"
            
        # Asegurar que existe el directorio de destino
        target_dir = ETC_KEYRINGS_DIR  # Preferir /etc/apt/keyrings
        if not ensure_directory_exists(target_dir):
            target_dir = KEYRINGS_DIR  # Fallback a /usr/share/keyrings
            if not ensure_directory_exists(target_dir):
                return False, "No se pudo crear el directorio de destino"
        
        # Ruta final de la clave
        target_path = os.path.join(target_dir, key_name)
        
        # Convertir la clave a formato binario GPG y guardarla
        try:
            # Usar pkexec para tener permisos de escritura
            result = subprocess.run(
                ["pkexec", "sh", "-c", f"cat {temp_path} | gpg --dearmor > {target_path} && chmod 644 {target_path}"],
                check=True,
                capture_output=True
            )
            return True, target_path
            
        except subprocess.CalledProcessError as e:
            log_error(f"Error al instalar la clave GPG: {e.stderr}")
            return False, str(e.stderr)
            
    except Exception as e:
        log_error(f"Error al descargar/instalar la clave GPG: {e}")
        return False, str(e)
    finally:
        # Limpiar el archivo temporal
        if 'temp_path' in locals():
            try:
                os.unlink(temp_path)
            except:
                pass

def ensure_key_for_repo(repo_uri, parent_window=None):
    """
    Asegura que exista una clave GPG para el repositorio
    
    Args:
        repo_uri: URI del repositorio
        parent_window: Ventana padre para diálogos (opcional)
        
    Returns:
        Tupla (éxito, mensaje_o_ruta)
    """
    hostname = urlparse(repo_uri).netloc
    
    # 1. Verificar si ya existe una clave para este repositorio
    key_path = get_key_path_for_repo(repo_uri)
    if key_path and os.path.exists(key_path):
        log_info(f"Clave GPG para {repo_uri} ya existe: {key_path}")
        return True, key_path
    
    # 2. Determinar la URL de la clave
    key_url = get_key_url_for_repo(repo_uri)
    if not key_url:
        log_warning(f"No se conoce URL de clave GPG para {repo_uri}")
        return False, "No se conoce URL de clave GPG"
    
    # 3. Generar un nombre de clave basado en el hostname
    key_name = f"{hostname.replace('.', '-')}.gpg"
    
    # 4. Descargar e instalar la clave
    log_info(f"Descargando clave GPG para {repo_uri} desde {key_url}")
    return download_and_install_key(key_url, key_name, parent_window)
