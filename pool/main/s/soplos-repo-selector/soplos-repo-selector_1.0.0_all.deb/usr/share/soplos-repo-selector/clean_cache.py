#!/usr/bin/env python3
"""
Script para limpiar archivos de caché Python (.pyc) y directorios __pycache__
"""

import os
import sys
import shutil
import argparse
from pathlib import Path

def clean_pycache(directory, verbose=False, dry_run=False):
    """
    Elimina todos los archivos .pyc y directorios __pycache__
    
    Args:
        directory: Directorio base donde buscar
        verbose: Mostrar información detallada
        dry_run: No eliminar, solo mostrar qué se eliminaría
    """
    pycache_dirs = []
    pyc_files = []
    
    # Buscar todos los archivos .pyc y directorios __pycache__
    for root, dirs, files in os.walk(directory):
        # Saltar directorios de venv y .git
        if '.git' in dirs:
            dirs.remove('.git')
        if 'venv' in dirs:
            dirs.remove('venv')
        
        # Buscar directorios __pycache__
        if '__pycache__' in dirs:
            pycache_dir = os.path.join(root, '__pycache__')
            pycache_dirs.append(pycache_dir)
            dirs.remove('__pycache__')  # Evitar entrar en él
            
        # Buscar archivos .pyc/.pyo
        for file in files:
            if file.endswith(('.pyc', '.pyo')):
                pyc_files.append(os.path.join(root, file))
    
    # Eliminar archivos .pyc
    for pyc_file in pyc_files:
        if verbose or dry_run:
            print(f"{'Sería eliminado' if dry_run else 'Eliminando'}: {pyc_file}")
        
        if not dry_run:
            try:
                os.remove(pyc_file)
            except Exception as e:
                print(f"Error al eliminar {pyc_file}: {e}")
    
    # Eliminar directorios __pycache__
    for pycache_dir in pycache_dirs:
        if verbose or dry_run:
            print(f"{'Sería eliminado' if dry_run else 'Eliminando directorio'}: {pycache_dir}")
        
        if not dry_run:
            try:
                shutil.rmtree(pycache_dir)
            except Exception as e:
                print(f"Error al eliminar {pycache_dir}: {e}")
    
    # Mostrar resumen
    if verbose or dry_run:
        print(f"\nResumen: {'Se eliminarían' if dry_run else 'Eliminados'} {len(pyc_files)} archivos .pyc y {len(pycache_dirs)} directorios __pycache__")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Limpiador de archivos caché Python')
    parser.add_argument('-v', '--verbose', action='store_true', help='Mostrar información detallada')
    parser.add_argument('-d', '--dry-run', action='store_true', help='No eliminar, solo mostrar qué se eliminaría')
    parser.add_argument('--directory', default=os.path.dirname(os.path.abspath(__file__)), 
                        help='Directorio base donde buscar (por defecto, el directorio actual)')
    
    args = parser.parse_args()
    
    print(f"Limpiando archivos de caché Python en: {args.directory}")
    clean_pycache(args.directory, args.verbose, args.dry_run)
