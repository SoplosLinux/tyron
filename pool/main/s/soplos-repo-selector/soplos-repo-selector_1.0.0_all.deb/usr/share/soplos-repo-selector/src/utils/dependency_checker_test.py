"""
Test para el verificador de dependencias
"""
import os
import subprocess
import importlib
from importlib import reload
from unittest import mock
import sys

# Añadir el directorio raíz al path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

# Implementar funciones auxiliares faltantes
def is_command_available(command):
    """Verifica si un comando está disponible en el sistema"""
    try:
        # Verificar en PATH usando 'which' en Unix o 'where' en Windows
        if os.name == 'nt':  # Windows
            subprocess.run(['where', command], check=True, stdout=subprocess.PIPE)
        else:  # Unix/Linux/MacOS
            subprocess.run(['which', command], check=True, stdout=subprocess.PIPE)
        return True
    except (subprocess.SubprocessError, FileNotFoundError):
        return False

def is_module_available(module_name):
    """Verifica si un módulo Python está disponible"""
    try:
        importlib.import_module(module_name)
        return True
    except ImportError:
        return False

def test_dependency_checker():
    """Prueba el verificador de dependencias"""
    # Mockear las funciones que verifican la disponibilidad
    with mock.patch('src.utils.dependency_checker.is_command_available') as mock_cmd:
        with mock.patch('src.utils.dependency_checker.is_module_available') as mock_mod:
            # Hacer que todas las dependencias estén disponibles excepto apt-key
            def mock_cmd_side_effect(cmd):
                return cmd != 'apt-key'
                
            mock_cmd.side_effect = mock_cmd_side_effect
            mock_mod.return_value = True
            
            # Recargar el módulo para que use nuestras funciones simuladas
            from src.utils import dependency_checker
            reload(dependency_checker)
            
            # Verificar dependencias - debería devolver True porque apt-key ya no es crítico
            result = dependency_checker.check_dependencies()
            
            # Debe retornar True incluso sin apt-key
            assert result == True, "El verificador debería pasar incluso sin apt-key"
            
            # Verificar que se llamó a is_command_available con apt-key
            mock_cmd.assert_any_call('apt-key')

if __name__ == "__main__":
    test_dependency_checker()
    print("¡Todas las pruebas pasaron!")
