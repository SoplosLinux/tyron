import gi
import logging
import sys
import traceback
from datetime import datetime
from functools import wraps
gi.require_version('Gtk', '3.0')  # Añadido para corregir el warning
from gi.repository import GLib, Gtk

class ErrorHandler:
    """
    Sistema centralizado para manejo de errores de la aplicación.
    Proporciona registro, formateo y presentación de errores.
    """
    
    # Niveles de gravedad
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL
    
    _instance = None
    _log_file = None
    _logger = None
    _parent_window = None
    
    @classmethod
    def initialize(cls, log_file=None, parent_window=None):
        """Inicializa el gestor de errores"""
        cls._log_file = log_file
        cls._parent_window = parent_window
        
        # Configurar el logger
        cls._logger = logging.getLogger('soplos-repo-selector')
        cls._logger.setLevel(logging.INFO)
        
        # Handler para consola
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        cls._logger.addHandler(console_handler)
        
        # Handler para archivo si se especifica
        if log_file:
            try:
                file_handler = logging.FileHandler(log_file)
                file_handler.setLevel(logging.INFO)
                file_handler.setFormatter(formatter)
                cls._logger.addHandler(file_handler)
            except Exception as e:
                cls._logger.error(f"No se pudo configurar el archivo de registro: {e}")
    
    @classmethod
    def log(cls, level, message, exception=None):
        """Registra un mensaje con el nivel especificado"""
        if not cls._logger:
            cls.initialize()
        
        # Registrar mensaje
        cls._logger.log(level, message)
        
        # Si hay excepción, registrar detalles adicionales
        if exception:
            cls._logger.log(level, f"Excepción: {exception}")
            cls._logger.log(level, ''.join(traceback.format_exception(
                type(exception), exception, exception.__traceback__)))
    
    @classmethod
    def show_error_dialog(cls, title, message, parent=None):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=parent or cls._parent_window,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    @classmethod
    def show_info_dialog(cls, title, message, parent=None):
        """Muestra un diálogo informativo"""
        dialog = Gtk.MessageDialog(
            transient_for=parent or cls._parent_window,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    @classmethod
    def show_confirm_dialog(cls, title, message, parent=None):
        """Muestra un diálogo de confirmación y retorna True si el usuario confirma"""
        dialog = Gtk.MessageDialog(
            transient_for=parent or cls._parent_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=title
        )
        dialog.format_secondary_text(message)
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.YES


# Alias para uso más conveniente
log_info = lambda msg: ErrorHandler.log(ErrorHandler.INFO, msg)
log_warning = lambda msg, exc=None: ErrorHandler.log(ErrorHandler.WARNING, msg, exc)
log_error = lambda msg, exc=None: ErrorHandler.log(ErrorHandler.ERROR, msg, exc)
log_critical = lambda msg, exc=None: ErrorHandler.log(ErrorHandler.CRITICAL, msg, exc)

def handle_uncaught_exceptions(exc_type, exc_value, exc_traceback):
    """Manejador global de excepciones no capturadas"""
    # No interrumpir KeyboardInterrupt (Ctrl+C)
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    
    # Registrar la excepción no capturada
    log_critical("Excepción no capturada", exc_value)


# Instalar el manejador de excepciones no capturadas
sys.excepthook = handle_uncaught_exceptions
