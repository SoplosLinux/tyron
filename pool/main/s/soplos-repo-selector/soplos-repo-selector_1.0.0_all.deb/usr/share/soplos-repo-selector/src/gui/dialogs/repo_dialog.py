import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib
from src.i18n.strings import get_string

class RepoDialog(Gtk.Dialog):
    def __init__(self, parent, repo=None):
        super().__init__(
            title=get_string("add_repo", "Añadir repositorio") if repo is None else get_string("edit_repo", "Editar repositorio"),
            transient_for=parent,
            flags=0
        )
        
        self.set_default_size(500, -1)
        self.set_modal(True)
        
        # Añadir botones SIN mnemonics visibles
        self.ok_button = self.add_button(get_string("ok", "Aceptar"), Gtk.ResponseType.OK)
        self.cancel_button = self.add_button(get_string("cancel", "Cancelar"), Gtk.ResponseType.CANCEL)
        self.set_default_response(Gtk.ResponseType.OK)
        
        # Obtener el área de contenido
        content_area = self.get_content_area()
        content_area.set_margin_top(10)
        content_area.set_margin_bottom(10)
        content_area.set_margin_start(10)
        content_area.set_margin_end(10)
        content_area.set_spacing(10)
        
        # Checkbox para activar/desactivar
        self.active_check = Gtk.CheckButton(label=get_string("repo_active", "Repositorio activo"))
        content_area.pack_start(self.active_check, False, False, 0)
        
        # Campo para tipo (deb, deb-src)
        type_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        content_area.pack_start(type_box, False, False, 0)
        
        type_label = Gtk.Label(label=get_string("repo_type", "Tipo:"))
        type_label.set_size_request(100, -1)
        type_label.set_halign(Gtk.Align.START)
        type_box.pack_start(type_label, False, False, 0)
        
        self.type_combo = Gtk.ComboBoxText()
        self.type_combo.append_text("deb")
        self.type_combo.append_text("deb-src")
        self.type_combo.set_active(0)
        type_box.pack_start(self.type_combo, True, True, 0)
        
        # Campo para URI
        uri_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        content_area.pack_start(uri_box, False, False, 0)
        
        uri_label = Gtk.Label(label=get_string("repo_uri", "URI:"))
        uri_label.set_size_request(100, -1)
        uri_label.set_halign(Gtk.Align.START)
        uri_box.pack_start(uri_label, False, False, 0)
        
        self.uri_entry = Gtk.Entry()
        self.uri_entry.set_placeholder_text(get_string("uri_placeholder", "https://ejemplo.com/repo"))
        uri_box.pack_start(self.uri_entry, True, True, 0)
        
        # Campo para distribución (ahora con combo de opciones comunes)
        dist_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        content_area.pack_start(dist_box, False, False, 0)
        
        dist_label = Gtk.Label(label=get_string("repo_dist", "Distribución:"))
        dist_label.set_size_request(100, -1)
        dist_label.set_halign(Gtk.Align.START)
        dist_box.pack_start(dist_label, False, False, 0)
        
        dist_combo_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        dist_box.pack_start(dist_combo_box, True, True, 0)
        
        # Combo para distribuciones comunes
        self.dist_combo = Gtk.ComboBoxText()
        self.dist_combo.set_entry_text_column(0)
        
        # Añadir distribuciones comunes
        debian_dists = [
            "$(lsb_release -cs)",  # Actual/detected
            "stable",              # Estable actual
            "trixie",              # Versión específica
            "bookworm",            # Debian 12
            "bullseye",            # Debian 11
            "buster",              # Debian 10
            "testing",             # Rama testing
            "sid",                 # Inestable
            "experimental"         # Experimental
        ]
        
        for dist in debian_dists:
            self.dist_combo.append_text(dist)
        
        self.dist_combo.set_active(0)  # Seleccionar la primera opción por defecto
        dist_combo_box.pack_start(self.dist_combo, False, False, 0)
        
        # Añadir opción para especificar manualmente o añadir sufijos
        self.dist_entry = Gtk.Entry()
        self.dist_entry.set_placeholder_text(get_string("dist_placeholder", "O especifique otra distribución o añada sufijos (ej: bookworm-backports)"))
        dist_combo_box.pack_start(self.dist_entry, False, False, 0)
        
        # Conectar cambio en combo para actualizar entrada
        self.dist_combo.connect("changed", self.on_dist_combo_changed)
        
        # Campo para componentes con opciones comunes
        comp_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        content_area.pack_start(comp_box, False, False, 0)
        
        comp_label = Gtk.Label(label=get_string("repo_comp", "Componentes:"))
        comp_label.set_size_request(100, -1)
        comp_label.set_halign(Gtk.Align.START)
        comp_box.pack_start(comp_label, False, False, 0)
        
        # Caja para componentes
        comp_combo_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        comp_box.pack_start(comp_combo_box, True, True, 0)
        
        # Opciones comunes - TRADUCIR LAS ETIQUETAS
        self.comp_options = {
            get_string("main", "Principal"): "main",
            get_string("non_free", "No libre"): "non-free",
            get_string("contrib", "Contrib"): "contrib",
            get_string("non_free_firmware", "No libre-firmware"): "non-free-firmware",
            get_string("backports", "Backports"): "main contrib non-free"
        }
        
        # Crear checkboxes para componentes comunes
        self.comp_checks = {}
        comp_check_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        comp_combo_box.pack_start(comp_check_box, False, False, 0)
        
        col = 0
        for label, value in self.comp_options.items():
            check = Gtk.CheckButton(label=label)
            check.connect("toggled", self.on_comp_check_toggled)
            self.comp_checks[label] = check
            comp_check_box.pack_start(check, True, True, 0)
            col += 1
            # Nueva fila cada 3 componentes
            if col >= 3:
                col = 0
                comp_check_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                comp_combo_box.pack_start(comp_check_box, False, False, 0)
                
        # Campo para componentes personalizados
        self.comp_entry = Gtk.Entry()
        self.comp_entry.set_placeholder_text(get_string("comp_placeholder", "O especifique componentes manualmente"))
        comp_combo_box.pack_start(self.comp_entry, False, False, 0)
        
        # Campo para comentario
        comment_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        content_area.pack_start(comment_box, False, False, 0)
        
        comment_label = Gtk.Label(label=get_string("repo_comment", "Comentario:"))
        comment_label.set_size_request(100, -1)
        comment_label.set_halign(Gtk.Align.START)
        comment_box.pack_start(comment_label, False, False, 0)
        
        self.comment_entry = Gtk.Entry()
        self.comment_entry.set_placeholder_text(get_string("comment_placeholder", "# Descripción opcional"))
        comment_box.pack_start(self.comment_entry, True, True, 0)
        
        # Si estamos editando, rellenar los campos
        if repo:
            self.active_check.set_active(repo['active'])
            self.type_combo.set_active(0 if repo['type'] == 'deb' else 1)
            self.uri_entry.set_text(repo['uri'])
            
            # Buscar si la distribución está en la lista
            dist_found = False
            for i, dist in enumerate(debian_dists):
                if repo['distribution'] == dist:
                    self.dist_combo.set_active(i)
                    dist_found = True
                    break
            
            if not dist_found:
                self.dist_entry.set_text(repo['distribution'])
                
            # Actualizar componentes
            components = repo['components'].split()
            for label, value in self.comp_options.items():
                values = value.split()
                if all(comp in components for comp in values):
                    self.comp_checks[label].set_active(True)
                    for comp in values:
                        if comp in components:
                            components.remove(comp)
            
            if components:
                self.comp_entry.set_text(' '.join(components))
                
            self.comment_entry.set_text(repo['comment'])
        else:
            self.active_check.set_active(True)
            # Activar main por defecto
            main_label = get_string("main", "Principal")
            if main_label in self.comp_checks:
                self.comp_checks[main_label].set_active(True)
        
        # Mostrar todos los widgets
        self.show_all()
    
    def on_dist_combo_changed(self, combo):
        """Actualiza la entrada de distribución cuando se selecciona una del combo"""
        selected = combo.get_active_text()
        if selected:
            self.dist_entry.set_text(selected)
    
    def on_comp_check_toggled(self, check):
        """Actualiza la entrada de componentes cuando se activan/desactivan checkboxes"""
        components = []
        
        # Recopilar componentes seleccionados
        for label, checkbox in self.comp_checks.items():
            if checkbox.get_active():
                components.extend(self.comp_options[label].split())
                
        # Añadir cualquier componente personalizado
        custom_comps = self.comp_entry.get_text().strip()
        if custom_comps:
            for comp in custom_comps.split():
                if comp not in components:
                    components.append(comp)
            
        # Eliminar duplicados y actualizar la entrada
        unique_comps = list(dict.fromkeys(components))
        self.comp_entry.set_text(' '.join(unique_comps))
    
    def get_repo(self):
        """Devuelve los datos del repositorio"""
        uri = self.uri_entry.get_text().strip()
        
        # Obtener la distribución (priorizar la entrada sobre el combo)
        dist = self.dist_entry.get_text().strip()
        if not dist and self.dist_combo.get_active() >= 0:
            dist = self.dist_combo.get_active_text()
        
        # Obtener componentes
        components = self.comp_entry.get_text().strip()
        
        # Validación básica
        if not uri or not dist:
            return None
        
        return {
            'active': self.active_check.get_active(),
            'type': self.type_combo.get_active_text(),
            'uri': uri,
            'distribution': dist,
            'components': components,
            'comment': self.comment_entry.get_text().strip()
        }
