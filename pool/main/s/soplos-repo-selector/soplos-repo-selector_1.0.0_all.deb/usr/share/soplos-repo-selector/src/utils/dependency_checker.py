"""
Módulo para verificar dependencias del sistema
"""
import subprocess
import sys
import importlib
import shutil
import os
from pathlib import Path

class DependencyChecker:
    """Verifica que todas las dependencias necesarias estén disponibles"""
    
    # Dependencias Python requeridas
    PYTHON_DEPENDENCIES = {
        "gi": "pygobject",          # GTK+
        "debian": "python3-debian", # Para archivos .sources
    }
    
    # Dependencias de sistema requeridas
    SYSTEM_DEPENDENCIES = {
        "apt": "apt",
        "dpkg": "dpkg",
        "curl": "curl",
        "gpg": "gnupg",
        "pkexec": "policykit-1"
    }
    
    # Dependencias opcionales
    OPTIONAL_DEPENDENCIES = {
        "python3-debian": "Soporte avanzado para archivos .sources",
    }
    
    @classmethod
    def check_python_dependency(cls, module_name):
        """
        Verifica si un módulo Python está instalado
        
        Args:
            module_name: Nombre del módulo a verificar
            
        Returns:
            bool: True si está disponible, False si no
        """
        try:
            importlib.import_module(module_name)
            return True
        except ImportError:
            return False
    
    @classmethod
    def check_system_dependency(cls, command):
        """
        Verifica si un comando del sistema está disponible
        
        Args:
            command: Nombre del comando a verificar
            
        Returns:
            bool: True si está disponible, False si no
        """
        return shutil.which(command) is not None
    
    @classmethod
    def check_all_dependencies(cls, verbose=True):
        """
        Verifica todas las dependencias y devuelve un reporte
        
        Args:
            verbose: Si es True, imprime mensajes mientras verifica
            
        Returns:
            tuple: (ok, missing_required, missing_optional)
                donde ok es un booleano,
                missing_required es una lista de dependencias requeridas faltantes
                missing_optional es una lista de dependencias opcionales faltantes
        """
        missing_required = []
        missing_optional = []
        
        # Verificar dependencias Python
        if verbose:
            print("Verificando dependencias Python...")
            
        for module, package in cls.PYTHON_DEPENDENCIES.items():
            if not cls.check_python_dependency(module):
                missing_required.append(f"{module} ({package})")
                if verbose:
                    print(f"  ❌ Falta {module} ({package})")
            elif verbose:
                print(f"  ✓ {module}")
        
        # Verificar dependencias del sistema
        if verbose:
            print("\nVerificando dependencias del sistema...")
            
        for cmd, package in cls.SYSTEM_DEPENDENCIES.items():
            if not cls.check_system_dependency(cmd):
                missing_required.append(f"{cmd} ({package})")
                if verbose:
                    print(f"  ❌ Falta {cmd} ({package})")
            elif verbose:
                print(f"  ✓ {cmd}")
        
        # Verificar dependencias opcionales
        optional_missing = []
        
        # python3-debian no está en PYTHON_DEPENDENCIES pero lo verificamos aquí
        if not cls.check_python_dependency("debian.deb822"):
            missing_optional.append("python3-debian")
            if verbose:
                print("  ⚠️ Módulo opcional python3-debian no encontrado (soporte para archivos .sources)")
        
        # Verificar si falta alguna dependencia requerida
        ok = len(missing_required) == 0
        
        if verbose and ok:
            print("\nTodas las dependencias requeridas están instaladas.")
            if missing_optional:
                print("Algunas dependencias opcionales están faltando:")
                for dep in missing_optional:
                    print(f"  - {dep}: {cls.OPTIONAL_DEPENDENCIES.get(dep, '')}")
        
        return (ok, missing_required, missing_optional)
    
    @classmethod
    def get_missing_dependencies_message(cls):
        """
        Genera un mensaje con instrucciones para instalar dependencias faltantes
        
        Returns:
            str: Mensaje con instrucciones o None si no faltan dependencias
        """
        ok, missing_required, missing_optional = cls.check_all_dependencies(verbose=False)
        
        if ok and not missing_optional:
            return None
            
        message = []
        
        if not ok:
            message.append("Faltan dependencias requeridas para el funcionamiento del programa:")
            
            apt_pkgs = []
            pip_pkgs = []
            
            for dep in missing_required:
                if "(" in dep and ")" in dep:
                    name, pkg = dep.split("(")[0].strip(), dep.split("(")[1].strip().rstrip(")")
                    if pkg.startswith("python3-"):
                        apt_pkgs.append(pkg)
                    else:
                        apt_pkgs.append(pkg)
            
            if apt_pkgs:
                message.append("\nPuede instalar las dependencias con apt:")
                message.append(f"  sudo apt install {' '.join(apt_pkgs)}")
            
            if pip_pkgs:
                message.append("\nAlgunas dependencias requieren pip:")
                message.append(f"  pip install {' '.join(pip_pkgs)}")
                
        if missing_optional:
            if message:
                message.append("\n")
            
            message.append("Dependencias opcionales que mejoran la funcionalidad:")
            for dep in missing_optional:
                desc = cls.OPTIONAL_DEPENDENCIES.get(dep, "")
                message.append(f"  - {dep}: {desc}")
                
            message.append("\nInstalar dependencias opcionales:")
            message.append(f"  sudo apt install {' '.join(missing_optional)}")
        
        return "\n".join(message)

def check_dependencies(show_dialog=True):
    """
    Ejecuta una verificación de dependencias y muestra una ventana si faltan algunas
    
    Args:
        show_dialog: Si es True, muestra un diálogo gráfico si faltan dependencias
        
    Returns:
        bool: True si todas las dependencias requeridas están instaladas, False si no
    """
    # Verificar dependencias
    ok, missing_required, missing_optional = DependencyChecker.check_all_dependencies()
    
    # Si todo está bien, no hacer nada más
    if ok:
        return True
        
    # Si faltan dependencias requeridas y se solicita mostrar diálogo
    if show_dialog:
        try:
            import gi
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk
            
            # Solo mostrar el diálogo si tenemos GTK disponible
            message = DependencyChecker.get_missing_dependencies_message()
            
            dialog = Gtk.MessageDialog(
                flags=0,
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.OK,
                text="Dependencias faltantes"
            )
            dialog.format_secondary_text(message)
            dialog.run()
            dialog.destroy()
        except ImportError:
            # Si no tenemos GTK, solo mostrar el mensaje en consola
            print("ADVERTENCIA: Faltan dependencias requeridas")
            print(DependencyChecker.get_missing_dependencies_message())
    
    return False

# Si se ejecuta directamente, verificar dependencias
if __name__ == "__main__":
    print("Verificando dependencias del sistema...")
    ok, missing_required, missing_optional = DependencyChecker.check_all_dependencies()
    
    if ok:
        print("\nTodas las dependencias requeridas están instaladas.")
        if missing_optional:
            print("Algunas funcionalidades opcionales no estarán disponibles.")
        sys.exit(0)
    else:
        print("\nFaltan algunas dependencias requeridas.")
        print(DependencyChecker.get_missing_dependencies_message())
        sys.exit(1)
