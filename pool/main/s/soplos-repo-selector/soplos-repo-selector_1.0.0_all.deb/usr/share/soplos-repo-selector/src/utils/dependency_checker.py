"""
Verificador de dependencias del sistema para Soplos Repo Selector
"""
import os
import sys
import importlib
import platform
import subprocess
import shutil
import socket
from typing import List, Dict, Tuple, Optional
from pathlib import Path

from src.utils.error_handler import log_info, log_error, log_warning

class DependencyChecker:
    """Verifica dependencias del sistema y paquetes Python"""
    
    def __init__(self):
        """Inicializa el verificador de dependencias"""
        # Dependencias requeridas - sistema
        self.required_commands = [
            'apt-get',
            'pkexec',
            'gpg'
        ]
        
        # Dependencias requeridas - Python
        self.required_modules = [
            'gi',
            'apt',
            'requests'
        ]
        
        # Dependencias opcionales
        self.optional_modules = [
            'python-debian',
        ]
        
        # Resultados del checkeo
        self.results = {}
    
    def check_python_version(self) -> Tuple[bool, str]:
        """Verifica la versión de Python"""
        current_version = sys.version_info
        min_version = (3, 7)  # Versión mínima requerida
        
        version_str = "{}.{}.{}".format(
            current_version.major,
            current_version.minor,
            current_version.micro
        )
        
        if current_version.major < min_version[0] or \
           (current_version.major == min_version[0] and current_version.minor < min_version[1]):
            return False, version_str
        
        return True, version_str
    
    def check_python_module(self, module_name: str) -> bool:
        """Verifica si un módulo Python está disponible"""
        try:
            importlib.import_module(module_name)
            return True
        except ImportError:
            return False
    
    def check_system_command(self, command: str) -> bool:
        """Verifica si un comando del sistema está disponible"""
        return shutil.which(command) is not None
    
    def check_file_permissions(self, file_path: str, required_permissions: str = 'r') -> bool:
        """Verifica permisos de archivo"""
        if not os.path.exists(file_path):
            return False
        
        readable = os.access(file_path, os.R_OK)
        writable = os.access(file_path, os.W_OK)
        executable = os.access(file_path, os.X_OK)
        
        if 'r' in required_permissions and not readable:
            return False
        if 'w' in required_permissions and not writable:
            return False
        if 'x' in required_permissions and not executable:
            return False
        
        return True
    
    def check_disk_space(self, path: str = '/tmp', min_mb: int = 100) -> Tuple[bool, float]:
        """Verifica espacio disponible en disco"""
        try:
            stat = os.statvfs(path)
            # Calcular espacio libre en MB
            free_bytes = stat.f_bfree * stat.f_frsize
            free_mb = free_bytes / (1024 * 1024)
            
            return free_mb >= min_mb, free_mb
        except Exception as e:
            log_warning(f"Error al verificar espacio en disco: {e}")
            return False, 0.0
    
    def check_apt_sources(self) -> Tuple[bool, List[str]]:
        """Verifica si los archivos sources.list existen y son legibles"""
        sources_paths = [
            '/etc/apt/sources.list',
            '/etc/apt/sources.list.d'
        ]
        
        missing = []
        
        for path in sources_paths:
            if os.path.exists(path):
                if os.path.isdir(path):
                    # Es un directorio, verificar si tiene archivos .list
                    list_files = [f for f in os.listdir(path) if f.endswith('.list') or f.endswith('.sources')]
                    if not list_files:
                        missing.append(f"{path} (directorio vacío)")
                else:
                    # Es un archivo, verificar si es legible
                    if not self.check_file_permissions(path, 'r'):
                        missing.append(f"{path} (no legible)")
            else:
                missing.append(f"{path} (no existe)")
        
        return len(missing) == 0, missing
    
    def check_internet_connectivity(self) -> bool:
        """Verifica la conectividad a internet"""
        try:
            # Intentar conectarse a un servidor conocido
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            pass
        
        try:
            # Segunda opción: debian.org
            socket.create_connection(("debian.org", 80), timeout=3)
            return True
        except OSError:
            return False
    
    def check_all_dependencies(self) -> Dict[str, any]:
        """Verifica todas las dependencias y devuelve resultados"""
        results = {
            'python': self.check_python_version(),
            'internet': self.check_internet_connectivity(),
            'disk_space': self.check_disk_space(),
            'apt_sources': self.check_apt_sources(),
            'commands': {},
            'modules': {}
        }
        
        # Verificar comandos del sistema
        for cmd in self.required_commands:
            results['commands'][cmd] = self.check_system_command(cmd)
        
        # Verificar módulos Python
        for mod in self.required_modules:
            results['modules'][mod] = self.check_python_module(mod)
        
        # Verificar módulos opcionales
        results['optional_modules'] = {}
        for mod in self.optional_modules:
            results['optional_modules'][mod] = self.check_python_module(mod)
        
        # Guardar resultados para consultas posteriores
        self.results = results
        
        return results
    
    def get_missing_dependencies(self) -> List[str]:
        """Obtiene lista de dependencias faltantes"""
        missing = []
        
        # Si aún no hemos verificado, hacerlo ahora
        if not self.results:
            self.check_all_dependencies()
        
        # Verificar versión de Python
        if not self.results['python'][0]:
            missing.append(f"Python versión {self.results['python'][1]} (se requiere 3.7+)")
        
        # Verificar comandos del sistema
        for cmd, available in self.results['commands'].items():
            if not available:
                missing.append(f"Comando: {cmd}")
        
        # Verificar módulos Python
        for mod, available in self.results['modules'].items():
            if not available:
                missing.append(f"Módulo Python: {mod}")
        
        # No añadir módulos opcionales a las dependencias faltantes
        
        return missing
    
    def get_missing_optional(self) -> List[str]:
        """Obtiene lista de dependencias opcionales faltantes"""
        missing = []
        
        # Si aún no hemos verificado, hacerlo ahora
        if not self.results:
            self.check_all_dependencies()
        
        # Verificar módulos opcionales
        for mod, available in self.results.get('optional_modules', {}).items():
            if not available:
                missing.append(f"Módulo opcional: {mod}")
        
        return missing
    
    def generate_install_command(self) -> Optional[str]:
        """Genera un comando para instalar las dependencias faltantes"""
        missing = self.get_missing_dependencies()
        
        if not missing:
            return None
        
        # Mapeo de dependencias Python a paquetes Debian
        package_map = {
            'gi': 'python3-gi gir1.2-gtk-3.0',
            'apt': 'python3-apt',
            'requests': 'python3-requests'
        }
        
        packages = []
        
        for item in missing:
            if item.startswith("Módulo Python: "):
                module = item.replace("Módulo Python: ", "")
                if module in package_map:
                    packages.append(package_map[module])
        
        if packages:
            return f"sudo apt update && sudo apt install -y {' '.join(packages)}"
        
        return None
    
    def generate_report(self) -> str:
        """Genera un reporte completo de dependencias"""
        if not self.results:
            self.check_all_dependencies()
        
        python_ok, python_version = self.results['python']
        
        lines = [
            "Reporte de dependencias para Soplos Repo Selector",
            "=" * 50,
            f"Python: {'✓' if python_ok else '✗'} v{python_version}",
            f"Internet: {'✓' if self.results['internet'] else '✗'}",
            f"Espacio en disco: {'✓' if self.results['disk_space'][0] else '✗'} ({self.results['disk_space'][1]:.1f} MB)"
        ]
        
        # Añadir información sobre sources.list
        apt_sources_ok, missing_sources = self.results['apt_sources']
        lines.append(f"Fuentes APT: {'✓' if apt_sources_ok else '✗'}")
        if not apt_sources_ok:
            lines.append("  Fuentes faltantes o no legibles:")
            for source in missing_sources:
                lines.append(f"  - {source}")
        
        # Añadir información sobre comandos
        lines.append("\nComandos requeridos:")
        for cmd, available in self.results['commands'].items():
            lines.append(f"  {cmd}: {'✓' if available else '✗'}")
        
        # Añadir información sobre módulos Python
        lines.append("\nMódulos Python requeridos:")
        for mod, available in self.results['modules'].items():
            lines.append(f"  {mod}: {'✓' if available else '✗'}")
        
        # Añadir información sobre módulos opcionales
        lines.append("\nMódulos Python opcionales:")
        for mod, available in self.results.get('optional_modules', {}).items():
            lines.append(f"  {mod}: {'✓' if available else '✗'}")
        
        # Añadir comando de instalación si es necesario
        install_cmd = self.generate_install_command()
        if install_cmd:
            lines.append("\nComando para instalar dependencias faltantes:")
            lines.append(f"  {install_cmd}")
        
        return "\n".join(lines)

def check_dependencies() -> bool:
    """
    Función de conveniencia para verificar dependencias básicas
    
    Returns:
        True si todas las dependencias están satisfechas
    """
    checker = DependencyChecker()
    results = checker.check_all_dependencies()
    
    # Verificar dependencias críticas
    python_ok = results['python'][0]
    modules_ok = all(results['modules'].values())
    commands_ok = all(results['commands'].values())
    
    # apt-key ya no es crítico (obsoleto en Debian 11+)
    if 'apt-key' in results['commands'] and not results['commands']['apt-key']:
        # Reemplazamos la verificación para apt-key
        log_warning("apt-key está obsoleto, pero no es crítico para la operación")
        # Recalcular si todos los comandos están ok, excluyendo apt-key
        filtered_commands = {k: v for k, v in results['commands'].items() if k != 'apt-key'}
        commands_ok = all(filtered_commands.values())
    
    return python_ok and modules_ok and commands_ok

def print_dependency_report():
    """Imprime un informe completo de dependencias"""
    checker = DependencyChecker()
    print(checker.generate_report())

if __name__ == '__main__':
    print_dependency_report()
