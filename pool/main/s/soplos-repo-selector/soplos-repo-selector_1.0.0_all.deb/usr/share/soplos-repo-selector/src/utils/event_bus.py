"""
Sistema de bus de eventos para comunicación entre componentes
"""
from typing import Dict, List, Callable, Any
from src.utils.error_handler import log_info, log_warning

# Constantes de eventos
EVENT_REPO_CHANGED = "repo_changed"
EVENT_GPG_KEY_IMPORTED = "gpg_key_imported"
EVENT_LANGUAGE_CHANGED = "language_changed" 
EVENT_SETTINGS_CHANGED = "settings_changed"
EVENT_CACHE_CLEARED = "cache_cleared"

class EventBus:
    """
    Bus de eventos centralizado para la aplicación.
    Permite comunicación débilmente acoplada entre componentes.
    """
    
    _subscribers: Dict[str, List[Callable]] = {}
    
    @classmethod
    def subscribe(cls, event_type: str, callback: Callable) -> None:
        """
        Suscribe un callback a un tipo de evento
        
        Args:
            event_type: Tipo de evento
            callback: Función a llamar cuando ocurra el evento
        """
        if event_type not in cls._subscribers:
            cls._subscribers[event_type] = []
        
        if callback not in cls._subscribers[event_type]:
            cls._subscribers[event_type].append(callback)
            from src.i18n.strings import get_string
            log_info(get_string("event_subscribed", f"Suscrito a evento: {event_type}"))
    
    @classmethod
    def unsubscribe(cls, event_type: str, callback: Callable) -> None:
        """
        Desuscribe un callback de un tipo de evento
        
        Args:
            event_type: Tipo de evento
            callback: Función a desuscribir
        """
        if event_type in cls._subscribers:
            try:
                cls._subscribers[event_type].remove(callback)
            except ValueError:
                pass
    
    @classmethod
    def publish(cls, event_type: str, *args, **kwargs) -> None:
        """
        Publica un evento a todos los suscriptores
        
        Args:
            event_type: Tipo de evento
            *args: Argumentos posicionales para los callbacks
            **kwargs: Argumentos nombrados para los callbacks
        """
        from src.i18n.strings import get_string
        
        if event_type in cls._subscribers:
            log_info(get_string("event_published", f"Evento publicado: {event_type}"))
            
            for callback in cls._subscribers[event_type]:
                try:
                    callback(*args, **kwargs)
                except Exception as e:
                    log_warning(f"Error en callback de evento {event_type}: {e}")
    
    @classmethod
    def clear_all_subscribers(cls) -> None:
        """Limpia todos los suscriptores"""
        cls._subscribers.clear()
    
    @classmethod
    def get_subscriber_count(cls, event_type: str) -> int:
        """Obtiene el número de suscriptores para un evento"""
        return len(cls._subscribers.get(event_type, []))
