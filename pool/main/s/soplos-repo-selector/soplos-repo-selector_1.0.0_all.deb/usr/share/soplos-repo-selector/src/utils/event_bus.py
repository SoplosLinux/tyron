"""
EventBus simple para Soplos Repo Selector
Permite suscribirse y emitir eventos entre componentes.
"""

class EventBus:
    _subscribers = {}

    @classmethod
    def subscribe(cls, event_name, callback):
        if event_name not in cls._subscribers:
            cls._subscribers[event_name] = []
        cls._subscribers[event_name].append(callback)

    @classmethod
    def unsubscribe(cls, event_name, callback):
        if event_name in cls._subscribers:
            cls._subscribers[event_name].remove(callback)

    @classmethod
    def emit(cls, event_name, *args, **kwargs):
        for callback in cls._subscribers.get(event_name, []):
            callback(*args, **kwargs)

# Instancia global para uso directo
event_bus = EventBus
