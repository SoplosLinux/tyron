"""
Sistema de eventos simple para comunicación entre componentes
"""
from typing import Dict, List, Callable, Any

# Definición de eventos
EVENT_REPO_ADDED = "repo:added"
EVENT_REPO_REMOVED = "repo:removed"
EVENT_REPO_UPDATED = "repo:updated"
EVENT_SETTINGS_CHANGED = "settings:changed"

class EventBus:
    """
    Bus de eventos que permite a los componentes comunicarse entre sí
    sin estar directamente acoplados
    """
    
    # Almacena los suscriptores a eventos
    _subscribers: Dict[str, List[Callable]] = {}
    
    @classmethod
    def subscribe(cls, event_type: str, callback: Callable) -> None:
        """
        Suscribe una función de callback a un tipo de evento
        
        Args:
            event_type: Tipo de evento al que suscribirse
            callback: Función a llamar cuando ocurra el evento
        """
        if event_type not in cls._subscribers:
            cls._subscribers[event_type] = []
        
        if callback not in cls._subscribers[event_type]:
            cls._subscribers[event_type].append(callback)
    
    @classmethod
    def unsubscribe(cls, event_type: str, callback: Callable) -> None:
        """
        Cancela la suscripción de una función a un tipo de evento
        
        Args:
            event_type: Tipo de evento
            callback: Función a eliminar de la suscripción
        """
        if event_type in cls._subscribers and callback in cls._subscribers[event_type]:
            cls._subscribers[event_type].remove(callback)
    
    @classmethod
    def publish(cls, event_type: str, *args: Any, **kwargs: Any) -> None:
        """
        Publica un evento a todos los suscriptores
        
        Args:
            event_type: Tipo de evento a publicar
            *args, **kwargs: Argumentos a pasar a las funciones suscritas
        """
        if event_type in cls._subscribers:
            # Crear una copia de la lista para evitar problemas si un suscriptor
            # se da de baja durante la publicación
            subscribers = cls._subscribers[event_type].copy()
            
            for callback in subscribers:
                try:
                    callback(*args, **kwargs)
                except Exception as e:
                    from src.utils.error_handler import log_error
                    log_error(f"Error en callback de evento {event_type}: {e}", e)
    
    @classmethod
    def clear_subscribers(cls, event_type: str = None) -> None:
        """
        Elimina todos los suscriptores para un tipo de evento o para todos
        
        Args:
            event_type: Tipo de evento a limpiar, o None para todos
        """
        if event_type:
            if event_type in cls._subscribers:
                cls._subscribers[event_type] = []
        else:
            cls._subscribers = {}
