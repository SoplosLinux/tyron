import os
import sys
import subprocess
import locale as stdlib_locale
from pathlib import Path

# Añadir el directorio raíz al PYTHONPATH
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, root_dir)

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib, GdkPixbuf, Gdk
from src.repo.manager import RepoManager
from src.i18n.strings import get_string, set_language, get_available_languages, get_current_language
from src.gui.dialogs.speed_dialog import RepoSpeedDialog
from src.gui.dialogs.repo_dialog import RepoDialog
from src.gui.widgets.repo_list import RepoListWidget
from src.gui.widgets.gpg_list import GPGKeyListWidget
# Importar correctamente las constantes de la aplicación desde constants.py en lugar de main
from src.config.constants import APP_ID, APP_NAME, APP_VERSION, DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT
from src.utils.error_handler import ErrorHandler, log_info, log_error, log_warning
from src.repo.gpg_key_manager import ensure_key_for_repo

def escape_markup(text):
    """Escapa caracteres especiales para markup GTK"""
    return text.replace('&', '&amp;')\
               .replace('<', '&lt;')\
               .replace('>', '&gt;')\
               .replace('"', '&quot;')\
               .replace("'", '&#39;')

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Usar las constantes definidas en src.config.constants
        self.app_id = APP_ID
        # WMCLASS debería ser igual a APP_ID
        self.wmclass = APP_ID
        
        # Establecer el WM_CLASS primero
        self.set_wmclass(self.wmclass, self.wmclass)
        
        # Establecer el icono desde el sistema primero
        self.set_icon_name(self.app_id)
        
        # Si no encuentra el icono del sistema, usar el local
        if not self.get_icon():
            try:
                window_icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                       'assets/icons/com.soplos.reposelector.png')
                window_icon = GdkPixbuf.Pixbuf.new_from_file(window_icon_path)
                self.set_icon(window_icon)
                Gtk.Window.set_default_icon(window_icon)
            except Exception as e:
                print(f"Error al cargar el icono: {e}")

        # Establecer el título de la ventana usando el nombre de la aplicación
        self.set_title(get_string('window_title', APP_NAME))
        
        # Conectar señal delete-event antes de todo
        self.connect('delete-event', self.on_delete_event)
        
        # Obtener dimensiones de la pantalla
        display = Gdk.Display.get_default()
        monitor = display.get_primary_monitor()
        geometry = monitor.get_geometry()
        screen_height = geometry.height
        
        # Ajustar tamaño de ventana usando las constantes definidas
        self.set_default_size(DEFAULT_WINDOW_WIDTH, min(DEFAULT_WINDOW_HEIGHT, screen_height - 100))

        # Inicializar el gestor de repositorios
        self.repo_manager = RepoManager()
        
        # Inicializar el sistema de manejo de errores con esta ventana como padre
        ErrorHandler.initialize(parent_window=self)
        
        # Crear la interfaz
        self._create_ui()
        
        # Cargar los repositorios existentes
        self._load_repos()
        
        # Inicializar el caché de widgets para optimizar búsquedas
        self._widget_cache = {}
        
    def _create_ui(self):
        """Crea la interfaz de usuario principal"""
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        self.add(main_box)
        
        # Panel superior con idioma
        top_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        top_panel.set_halign(Gtk.Align.END)
        main_box.pack_start(top_panel, False, False, 0)
        
        # Selector de idioma
        language_label = Gtk.Label(label=get_string("language", "Idioma") + ":")
        language_label.set_name("language_label")
        top_panel.pack_start(language_label, False, False, 0)
        
        self.language_combo = Gtk.ComboBoxText()
        languages = get_available_languages()
        current_lang = get_current_language()
        
        # Ordenar idiomas de manera personalizada
        # Definir un orden específico para los idiomas prioritarios
        priority_langs = ['en', 'es', 'de', 'fr', 'it', 'pt', 'ru', 'ro']
        
        # Primero añadir los idiomas prioritarios en el orden especificado
        for lang_code in priority_langs:
            if lang_code in languages:
                self.language_combo.append(lang_code, languages[lang_code])
                if lang_code == current_lang:
                    self.language_combo.set_active_id(lang_code)
        
        # Luego añadir el resto de idiomas en orden alfabético por nombre
        remaining_langs = [(code, name) for code, name in languages.items() if code not in priority_langs]
        for code, name in sorted(remaining_langs, key=lambda x: x[1]):
            self.language_combo.append(code, name)
            if code == current_lang and self.language_combo.get_active() == -1:
                self.language_combo.set_active_id(code)
        
        self.language_combo.connect('changed', self.on_language_changed)
        top_panel.pack_start(self.language_combo, False, False, 0)
        
        # Crear notebook para separar repositorios y claves GPG
        self.notebook = Gtk.Notebook()
        main_box.pack_start(self.notebook, True, True, 0)
        
        # Página 1: Repositorios
        repo_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notebook.append_page(repo_page, Gtk.Label(label=get_string("repositories", "Repositorios")))
        
        # Título de la sección de repositorios
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        repo_page.pack_start(title_box, False, False, 0)
        
        # Título y descripción
        title_icon = Gtk.Image.new_from_icon_name("software-properties", Gtk.IconSize.DIALOG)
        title_box.pack_start(title_icon, False, False, 0)
        
        title_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_box.pack_start(title_text_box, True, True, 0)
        
        self.title_label = Gtk.Label()
        self.title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('repo_manager', 'Gestor de Repositorios Debian')}</span>")
        self.title_label.set_halign(Gtk.Align.START)
        self.title_label.set_name("title_label")
        title_text_box.pack_start(self.title_label, False, False, 0)
        
        self.desc_label = Gtk.Label(label=get_string('repo_description', 'Administra los repositorios APT de tu sistema'))
        self.desc_label.set_halign(Gtk.Align.START)
        self.desc_label.set_name("description_label")
        title_text_box.pack_start(self.desc_label, False, False, 0)
        
        # Separador
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        repo_page.pack_start(separator, False, False, 0)
        
        # Widget de lista de repositorios
        self.repo_list = RepoListWidget()
        self.repo_list.connect('repo-changed', self.on_repo_changed)
        repo_page.pack_start(self.repo_list, True, True, 0)
        
        # Botón para buscar repositorios más rápidos
        fast_repos_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        repo_page.pack_start(fast_repos_box, False, False, 0)
        
        # Reemplazar el botón de solo ícono por uno con texto
        self.fast_repos_button = Gtk.Button(label=get_string("find_fastest_repos", "Buscar Repositorios Más Rápidos"))
        self.fast_repos_button.connect("clicked", self.on_find_fastest_repos_clicked)
        fast_repos_box.pack_start(self.fast_repos_button, False, False, 0)
        
        # Espaciador
        fast_repos_box.pack_start(Gtk.Box(), True, True, 0)
        
        # Botón de actualización
        self.update_button = Gtk.Button(label=get_string("update_repos", "Actualizar Repositorios"))
        self.update_button.connect("clicked", self.on_update_repos_clicked)
        fast_repos_box.pack_start(self.update_button, False, False, 0)
        
        # Frame para repositorios predefinidos populares
        self.predef_frame = Gtk.Frame(label=get_string("popular_repos", "Repositorios Predefinidos Populares"))
        self.predef_frame.set_name("predef_frame")  # Establecer nombre para búsqueda posterior
        repo_page.pack_start(self.predef_frame, False, True, 0)
        
        predef_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        predef_box.set_margin_top(10)
        predef_box.set_margin_bottom(10)
        predef_box.set_margin_start(10)
        predef_box.set_margin_end(10)
        self.predef_frame.add(predef_box)
        
        # Botones para repositorios predefinidos
        repo_buttons = [
            ("Google Chrome", ["google-chrome", "chrome", "web-browser"], self.on_chrome_repo_clicked),
            ("VSCode", ["code", "visual-studio-code", "vscode", "text-editor"], self.on_vscode_repo_clicked),
            ("Docker", ["docker", "application-x-docker", "applications-system"], self.on_docker_repo_clicked),
            ("OBS Studio", ["com.obsproject.Studio", "obs", "obs-studio", "camera-video", "video-display"], self.on_obs_repo_clicked)
        ]
        
        for label, icon_names, callback in repo_buttons:
            button = Gtk.Button()
            button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
            
            # Buscar el primer icono disponible en la lista
            icon = None
            icon_found = False
            
            for icon_name in icon_names:
                try:
                    icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
                    # Verificar si el icono existe realmente
                    icon_theme = Gtk.IconTheme.get_default()
                    if icon_theme.has_icon(icon_name):
                        icon_found = True
                        break
                except Exception as e:
                    print(f"Error al cargar icono {icon_name}: {e}")
                    pass
            
            # Si no se encuentra ningún icono, usar uno genérico
            if not icon_found:
                icon = Gtk.Image.new_from_icon_name("package", Gtk.IconSize.DIALOG)
            
            button_box.pack_start(icon, False, False, 0)
            
            # Etiqueta del repositorio
            repo_label = Gtk.Label(label=label)
            button_box.pack_start(repo_label, False, False, 0)
            
            button.add(button_box)
            button.connect("clicked", callback)
            predef_box.pack_start(button, True, True, 0)
        
        # Página 2: Claves GPG
        gpg_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notebook.append_page(gpg_page, Gtk.Label(label=get_string("gpg_keys", "Claves GPG")))
        
        # Título de la sección de claves GPG
        gpg_title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        gpg_page.pack_start(gpg_title_box, False, False, 0)
        
        # Título y descripción
        gpg_title_icon = Gtk.Image.new_from_icon_name("dialog-password", Gtk.IconSize.DIALOG)
        gpg_title_box.pack_start(gpg_title_icon, False, False, 0)
        
        gpg_title_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        gpg_title_box.pack_start(gpg_title_text_box, True, True, 0)
        
        self.gpg_title_label = Gtk.Label()
        self.gpg_title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('gpg_key_manager', 'Gestor de Claves GPG')}</span>")
        self.gpg_title_label.set_halign(Gtk.Align.START)
        self.gpg_title_label.set_name("gpg_title_label")
        gpg_title_text_box.pack_start(self.gpg_title_label, False, False, 0)
        
        self.gpg_desc_label = Gtk.Label(label=get_string('gpg_key_description', 'Administra las claves GPG para tus repositorios'))
        self.gpg_desc_label.set_halign(Gtk.Align.START)
        self.gpg_desc_label.set_name("gpg_description_label")
        gpg_title_text_box.pack_start(self.gpg_desc_label, False, False, 0)
        
        # Separador
        gpg_separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        gpg_page.pack_start(gpg_separator, False, False, 0)
        
        # Widget de lista de claves GPG
        self.gpg_key_list = GPGKeyListWidget()
        self.gpg_key_list.connect('key-imported', self.on_key_imported)
        gpg_page.pack_start(self.gpg_key_list, True, True, 0)
        
        # Barra de progreso
        self.progress_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.progress_box.set_no_show_all(True)  # Inicialmente oculto
        main_box.pack_start(self.progress_box, False, False, 0)
        
        progress_label_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.progress_box.pack_start(progress_label_box, False, False, 0)
        
        self.progress_spinner = Gtk.Spinner()
        progress_label_box.pack_start(self.progress_spinner, False, False, 0)
        
        self.progress_label = Gtk.Label(label=get_string("processing", "Procesando..."))
        self.progress_label.set_halign(Gtk.Align.START)
        progress_label_box.pack_start(self.progress_label, True, True, 0)
        
        # Barra de progreso
        self.progressbar = Gtk.ProgressBar()
        self.progressbar.set_show_text(True)
        self.progress_box.pack_start(self.progressbar, False, False, 0)
        
        # Botones principales
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        button_box.set_halign(Gtk.Align.END)
        button_box.set_margin_top(10)
        main_box.pack_end(button_box, False, False, 0)
        
        self.close_button = Gtk.Button(label=get_string("close", "Cerrar"))
        self.close_button.set_use_underline(True)
        self.close_button.connect("clicked", self.on_close_clicked)
        button_box.pack_start(self.close_button, False, False, 0)
        
        self.apply_button = Gtk.Button(label=get_string("apply", "Aplicar Cambios"))
        self.apply_button.set_use_underline(True)
        self.apply_button.connect("clicked", self.on_apply_changes_clicked)
        self.apply_button.get_style_context().add_class("suggested-action")
        button_box.pack_start(self.apply_button, False, False, 0)
        
        # Spinner para operaciones
        self.spinner = Gtk.Spinner()
        button_box.pack_start(self.spinner, False, False, 0)
        
    def _load_repos(self):
        """Carga los repositorios del sistema"""
        self.repo_list.clear()
        
        # Mostrar spinner mientras carga
        self.spinner.start()
        self.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("loading_repos", "Cargando repositorios..."), 0.0)
        
        # Usar GLib.idle_add para no bloquear la UI
        GLib.idle_add(self._do_load_repos)
    
    def _do_load_repos(self):
        """Realiza la carga de repositorios en segundo plano"""
        try:
            repos = self.repo_manager.get_all_repos()
            
            total = len(repos)
            for i, repo in enumerate(repos):
                # Actualizar barra de progreso
                fraction = float(i) / max(total, 1)
                GLib.idle_add(self.progressbar.set_fraction, fraction)
                GLib.idle_add(self.progressbar.set_text, 
                             get_string("loading_repo_progress", "Cargando repositorio {0} de {1}").format(i+1, total))
                
                self.repo_list.add_repo(
                    not repo['disabled'],  # Activo
                    repo['type'],          # Tipo
                    repo['uri'],           # URI
                    repo['distribution'],  # Distribución
                    repo['components'],    # Componentes
                    repo['comment']        # Comentario
                )
            
            # Actualizar barra de progreso a completado
            GLib.idle_add(self.progressbar.set_fraction, 1.0)
            GLib.idle_add(self.progressbar.set_text, 
                         get_string("loaded_repos", "Cargados {0} repositorios").format(total))
            
        except Exception as e:
            log_error("Error al cargar repositorios", e)
            GLib.idle_add(self._hide_progress_bar)
            GLib.idle_add(lambda: ErrorHandler.show_error_dialog(
                get_string("error", "Error"), 
                get_string("error_loading_repos", "Error al cargar repositorios: {0}").format(str(e)),
                self
            ))
        
        # Detener spinner y restaurar sensibilidad
        GLib.idle_add(self.spinner.stop)
        GLib.idle_add(self.set_sensitive, True)
        
        # Ocultar barra de progreso después de un retraso
        GLib.timeout_add(1500, self._hide_progress_bar)
        
        return False  # Importante para GLib.idle_add
    
    def _show_progress_bar(self, message, fraction=0.0):
        """Muestra la barra de progreso con un mensaje"""
        self.progress_label.set_text(message)
        self.progressbar.set_fraction(fraction)
        self.progressbar.set_text(f"{int(fraction * 100)}%")
        self.progress_spinner.start()
        
        # Cambiar a set_visible(True) en lugar de usar show_all()
        self.progress_box.set_no_show_all(False)
        self.progress_box.set_visible(True)
        self.progress_box.show_all()

    def _update_progress_bar(self, fraction, text=None):
        """Actualiza el progreso de la barra"""
        self.progressbar.set_fraction(fraction)
        if text:
            self.progressbar.set_text(text)
        else:
            self.progressbar.set_text(f"{int(fraction * 100)}%")
    
    def _hide_progress_bar(self):
        """Oculta la barra de progreso"""
        self.progress_spinner.stop()
        self.progress_box.set_visible(False)
        self.progress_box.set_no_show_all(True)
        return False  # Importante para usar con GLib.timeout_add
    
    def on_repo_changed(self, widget):
        """Maneja los cambios en los repositorios"""
        # Este método se llama cuando hay cambios en la lista de repositorios
        # Se puede usar para habilitar/deshabilitar botones, actualizar contadores, etc.
        pass
    
    def on_key_imported(self, widget, success, path_or_error):
        """Maneja el evento de importación de clave GPG"""
        if success:
            self._show_info_dialog(get_string('key_imported', 'Clave importada:') + f" {os.path.basename(path_or_error)}")
        else:
            self._show_error_dialog(get_string('key_import_error', 'Error al importar clave:') + f" {path_or_error}")
    
    def on_find_fastest_repos_clicked(self, button):
        """Abre el diálogo para buscar los repositorios más rápidos"""
        try:
            # Obtener los repositorios actuales
            current_repos = []
            
            def collect_repos(model, path, iter, data):
                data.append(model[iter][2])  # Añadir la URI
                return False
            
            self.repo_list.foreach(collect_repos, current_repos)
            
            # Crear y mostrar el diálogo
            dialog = RepoSpeedDialog(self, current_repos)
            response = dialog.run()
            
            if response == Gtk.ResponseType.OK:
                selected_repo_data = dialog.get_selected_repos()
                
                # Añadir los repositorios seleccionados si no existen ya
                if selected_repo_data:
                    # Mostrar barra de progreso
                    self._show_progress_bar(get_string("adding_selected_repos", "Añadiendo repositorios seleccionados..."), 0.0)
                    
                    total = len(selected_repo_data)
                    added_count = 0
                    
                    for i, repo_data in enumerate(selected_repo_data):
                        # Actualizar barra de progreso
                        fraction = (i + 1) / total
                        GLib.idle_add(self._update_progress_bar, fraction, 
                                     get_string("adding_repo_progress", "Añadiendo repositorio {0} de {1}").format(i+1, total))
                        
                        # Comprobar si ya existe el repositorio con la misma distribución
                        exists = False
                        
                        def check_exists(model, path, iter, data):
                            if (model[iter][2] == data['uri'] and 
                                model[iter][3] == data['distribution']):
                                data['exists'] = True
                                return True
                            return False
                        
                        check_data = {'uri': repo_data['uri'], 
                                     'distribution': repo_data['distribution'],
                                     'exists': False}
                        
                        self.repo_list.foreach(check_exists, check_data)
                        
                        if not check_data['exists']:
                            # Añadir el repositorio con los valores dados
                            self.repo_list.add_repo(
                                True,  # Activo
                                'deb',  # Tipo
                                repo_data['uri'],  # URI
                                repo_data['distribution'],  # Distribución
                                repo_data['components'],  # Componentes
                                get_string("auto_added_repo_comment", "# Repositorio añadido automáticamente ({0})").format(repo_data["distribution"])
                            )
                            added_count += 1
                    
                    # Mostrar mensaje final antes de ocultar
                    GLib.idle_add(self._update_progress_bar, 1.0, 
                                 get_string("added_repos_count", "Añadidos {0} de {1} repositorios").format(added_count, total))
                    
                    if added_count > 0:
                        self._show_info_dialog(get_string("repos_added", "Se han añadido {0} repositorios").format(added_count))
                    else:
                        self._show_info_dialog(get_string("no_new_repos", "No se han añadido nuevos repositorios"))
                    
                    # Ocultar barra de progreso después de un retraso
                    GLib.timeout_add(2000, self._hide_progress_bar)
            
            dialog.destroy()
        except Exception as e:
            log_error("Error al buscar repositorios rápidos", e)
            self._hide_progress_bar()
            self._show_error_dialog(get_string("error_finding_repos", "Error al buscar repositorios rápidos: {0}").format(str(e)))
    
    def on_update_repos_clicked(self, button):
        """Actualiza la lista de paquetes (apt update)"""
        # Guardar los repositorios actuales antes de actualizar
        self.save_current_repos_state()
        
        self.spinner.start()
        button.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("updating_repos", "Actualizando repositorios..."), 0.0)
        
        # Usar GLib.idle_add para ejecutar apt update en segundo plano
        GLib.idle_add(self._do_update_repos, button)
        
    def save_current_repos_state(self):
        """Guarda el estado actual de los repositorios para restaurarlos después de actualizar"""
        self.saved_repos = []
        self.repo_list.foreach(self._collect_repos, self.saved_repos)
    
    def _collect_repos(self, model, path, iter, repos_list):
        """Recopila información de repositorios desde el modelo de datos"""
        # Extraer datos de la fila
        active = model[iter][0]
        repo_type = model[iter][1]
        uri = model[iter][2]
        distribution = model[iter][3]
        components = model[iter][4]
        comment = model[iter][5]
        
        # Buscar si este repositorio ya existe en el sistema
        # para mantener su archivo de origen y formato
        existing_repos = self.repo_manager.get_all_repos()
        found_repo = None
        
        for existing in existing_repos:
            if (existing['uri'] == uri and 
                existing['distribution'] == distribution and 
                existing['type'] == repo_type):
                found_repo = existing
                break
        
        # Si encontramos un repo existente, usar su información
        if found_repo:
            repo = {
                'disabled': not active,
                'type': repo_type,
                'uri': uri,
                'distribution': distribution,
                'components': components,
                'comment': comment,
                'file': found_repo['file'],
                'format': found_repo.get('format', 'legacy')
            }
        else:
            # Para repositorios nuevos, usar un archivo apropiado basado en su origen
            file_path = None
            format_type = 'legacy'  # Por defecto usar formato legacy
            
            # Determinar archivo adecuado basado en URI y distribución
            if "debian.org" in uri:
                # Para repos oficiales Debian usar formato deb822
                format_type = 'deb822'
                
                if "security.debian.org" in uri:
                    file_path = '/etc/apt/sources.list.d/debian-security.sources'
                elif distribution.endswith('-backports'):
                    file_path = '/etc/apt/sources.list.d/debian-backports.sources'
                else:
                    file_path = '/etc/apt/sources.list.d/debian.sources'
                    
            elif "google" in uri.lower() or "chrome" in uri.lower():
                file_path = '/etc/apt/sources.list.d/google-chrome.list'
            elif "microsoft" in uri.lower() or "vscode" in uri.lower() or "code" in uri.lower():
                file_path = '/etc/apt/sources.list.d/vscode.list'
            elif "docker" in uri.lower():
                file_path = '/etc/apt/sources.list.d/docker.list'
            elif "mozilla.org" in uri.lower():
                file_path = '/etc/apt/sources.list.d/mozilla.list'
            elif "obs" in uri.lower():
                file_path = '/etc/apt/sources.list.d/obs-studio.list'
            elif "liquorix" in uri.lower():
                file_path = '/etc/apt/sources.list.d/liquorix.list'
            else:
                # Para otros repos, crear un archivo basado en el hostname
                hostname = uri.split('//')[-1].split('/')[0]
                file_path = f'/etc/apt/sources.list.d/{hostname.replace(".", "-")}.list'
            
            repo = {
                'disabled': not active,
                'type': repo_type,
                'uri': uri,
                'distribution': distribution,
                'components': components,
                'comment': comment,
                'file': file_path,
                'format': format_type
            }
        
        # Añadir a la lista
        repos_list.append(repo)
        
        # Devolver False para continuar el recorrido
        return False

    def on_apply_changes_clicked(self, button):
        """Aplica los cambios a los repositorios"""
        # Mostrar spinner y deshabilitar el botón
        self.spinner.start()
        button.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("applying_changes", "Aplicando cambios a los repositorios..."), 0.1)
        
        try:
            # Recopilar todos los repositorios actuales
            current_repos = []
            self.repo_list.foreach(self._collect_repos, current_repos)
            
            # Actualizar progreso
            self._update_progress_bar(0.5, get_string("saving_changes", "Guardando cambios..."))
            
            # Guardar los cambios
            self.repo_manager.save_repos(current_repos)
            
            # Completar progreso
            self._update_progress_bar(1.0, get_string("changes_applied_success", "Cambios aplicados correctamente"))
            
            # Ocultar barra de progreso después de un tiempo
            GLib.timeout_add(1500, self._hide_progress_bar)
            
            # Mostrar mensaje de éxito
            self._show_info_dialog(get_string("changes_applied", "Cambios aplicados correctamente"))
            
        except Exception as e:
            log_error("Error al aplicar cambios", e)
            self._hide_progress_bar()
            # Mostrar error
            self._show_error_dialog(get_string("apply_error", "Error al aplicar cambios: {0}").format(str(e)))
        finally:
            # Detener spinner y restaurar sensibilidad
            self.spinner.stop()
            button.set_sensitive(True)
    
    def _do_update_repos(self, button):
        """Ejecuta apt update en segundo plano"""
        try:
            # Crear proceso y redirigir la salida para poder monitorear el progreso
            try:
                # Usar el método seguro del gestor de repositorios para ejecutar apt update
                # Necesitamos capturar la salida, así que creamos un proceso manualmente
                process = subprocess.Popen(
                    ["pkexec", "apt", "update"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    universal_newlines=True,
                    bufsize=1
                )
                
                # Variables para seguimiento del progreso
                total_repos = len(self.saved_repos)
                repos_updated = 0
                
                # Procesar la salida línea por línea
                for line in iter(process.stdout.readline, ''):
                    log_info(f"apt update: {line.strip()}")
                    
                    # Detectar progreso de actualización basado en la salida
                    if "Ign" in line or "Hit" in line or "Get" in line:
                        repos_updated += 1
                        fraction = min(0.9, repos_updated / max(total_repos, 1))
                        GLib.idle_add(self._update_progress_bar, fraction, 
                                    get_string("updating_repo_count", "Actualizando {0} de {1}").format(repos_updated, total_repos))
                
                # Esperar a que termine el proceso
                return_code = process.wait()
                
                # Verificar el resultado
                if return_code == 0:
                    # Éxito
                    GLib.idle_add(self._update_progress_bar, 1.0, get_string("update_complete", "Actualización completada"))
                    GLib.idle_add(lambda: self._show_info_dialog(get_string("update_success", "Repositorios actualizados correctamente")))
                else:
                    # Error
                    GLib.idle_add(self._hide_progress_bar)
                    GLib.idle_add(lambda: self._show_error_dialog(get_string("update_error", "Error al actualizar repositorios")))
                    
            except subprocess.CalledProcessError as e:
                GLib.idle_add(self._hide_progress_bar)
                GLib.idle_add(lambda: self._show_error_dialog(f"{get_string('update_error', 'Error al actualizar repositorios')}: {e.stderr}"))
            except PermissionError as e:
                GLib.idle_add(self._hide_progress_bar)
                GLib.idle_add(lambda: self._show_error_dialog(f"{get_string('permission_error', 'Error de permisos')}: {str(e)}"))
        except Exception as e:
            GLib.idle_add(self._hide_progress_bar)
            GLib.idle_add(lambda: self._show_error_dialog(f"{get_string('error', 'Error')}: {str(e)}"))
        
        GLib.idle_add(self.spinner.stop)
        GLib.idle_add(lambda: button.set_sensitive(True))
        
        # Ocultar barra de progreso después de completar
        GLib.timeout_add(2000, self._hide_progress_bar)
        
        # Recargar repositorios después de actualizar
        GLib.idle_add(self._load_repos_preserving_changes)
        
        return False  # Importante para GLib.idle_add
    
    def _load_repos_preserving_changes(self):
        """Carga los repositorios del sistema preservando los cambios no guardados"""
        # Mostrar spinner mientras carga
        self.spinner.start()
        self.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("reloading_repos", "Recargando repositorios..."), 0.0)
        
        # Usar GLib.idle_add para no bloquear la UI
        GLib.idle_add(self._do_load_repos_preserving_changes)
    
    def _do_load_repos_preserving_changes(self):
        """Realiza la carga de repositorios preservando los cambios no guardados"""
        try:
            # Cargar los repositorios del sistema
            sys_repos = self.repo_manager.get_all_repos()
            
            # Crear un mapa con los repositorios guardados previamente
            saved_repos_map = {}
            for repo in getattr(self, 'saved_repos', []):
                key = (repo['uri'], repo['distribution'])
                saved_repos_map[key] = repo
            
            # Limpiar la lista existente
            self.repo_list.clear()
            
            # Añadir primero los repositorios del sistema
            added_keys = set()
            for repo in sys_repos:
                key = (repo['uri'], repo['distribution'])
                added_keys.add(key)
                
                # Si este repo estaba en nuestra lista guardada, usar su estado
                if key in saved_repos_map:
                    saved = saved_repos_map[key]
                    self.repo_list.add_repo(
                        not saved['disabled'],  # Activo
                        saved['type'],          # Tipo
                        saved['uri'],           # URI
                        saved['distribution'],  # Distribución
                        saved['components'],    # Componentes
                        saved['comment']        # Comentario
                    )
                else:
                    # Usar el valor del sistema
                    self.repo_list.add_repo(
                        not repo['disabled'],  # Activo
                        repo['type'],          # Tipo
                        repo['uri'],           # URI
                        repo['distribution'],  # Distribución
                        repo['components'],    # Componentes
                        repo['comment']        # Comentario
                    )
            
            # Añadir repositorios que estaban en nuestra lista pero no en el sistema
            for key, repo in saved_repos_map.items():
                if key not in added_keys:
                    self.repo_list.add_repo(
                        not repo['disabled'],  # Activo
                        repo['type'],          # Tipo
                        repo['uri'],           # URI
                        repo['distribution'],  # Distribución
                        repo['components'],    # Componentes
                        repo['comment']        # Comentario
                    )
        except Exception as e:
            self._show_error_dialog(f"Error al cargar repositorios: {str(e)}")
        
        # Detener spinner y restaurar sensibilidad
        self.spinner.stop()
        self.set_sensitive(True)
        
        return False  # Importante para GLib.idle_add
    
    # Manejadores para repositorios predefinidos
    
    def on_chrome_repo_clicked(self, button):
        """Añade el repositorio de Google Chrome"""
        self._add_predefined_repo({
            'active': True,
            'type': 'deb',
            'uri': 'http://dl.google.com/linux/chrome/deb/',
            'distribution': 'stable',
            'components': 'main',
            'comment': get_string('chrome_comment', '# Google Chrome Repository')
        })
    
    def on_vscode_repo_clicked(self, button):
        """Añade el repositorio de VSCode"""
        # Detectar automáticamente la arquitectura del sistema
        try:
            arch = subprocess.check_output(["dpkg", "--print-architecture"], universal_newlines=True).strip()
        except:
            arch = "amd64"  # Valor por defecto si no se puede detectar

        # La distribución ahora usa $(lsb_release -cs) para adaptarse automáticamente
        self._add_predefined_repo({
            'active': True,
            'type': 'deb',
            'uri': f'https://packages.microsoft.com/repos/code',
            'distribution': 'stable',
            'components': 'main',
            'comment': get_string('vscode_comment', '# Visual Studio Code Repository')
        })
    
    def on_docker_repo_clicked(self, button):
        """Añade el repositorio de Docker"""
        self._add_predefined_repo({
            'active': True,
            'type': 'deb',
            'uri': 'https://download.docker.com/linux/debian',
            'distribution': '$(lsb_release -cs)',
            'components': 'stable',
            'comment': get_string('docker_comment', '# Docker Repository')
        })
    
    def on_obs_repo_clicked(self, button):
        """Añade el repositorio de OBS Studio"""
        self._add_predefined_repo({
            'active': True,
            'type': 'deb',
            'uri': 'http://ppa.launchpad.net/obsproject/obs-studio/ubuntu',
            'distribution': '$(lsb_release -cs)',
            'components': 'main',
            'comment': get_string('obs_comment', '# OBS Studio Repository')
        })
    
    def _add_predefined_repo(self, repo):
        """Añade un repositorio predefinido a la lista"""
        # Comprobar si ya existe el repositorio
        exists = False
        
        def check_exists(model, path, iter, data):
            if (model[iter][2] == data['uri'] and
                model[iter][3] == data['distribution']):
                data['exists'] = True
                return True
            return False
        
        check_data = {'uri': repo['uri'], 'distribution': repo['distribution'], 'exists': False}
        self.repo_list.foreach(check_exists, check_data)
        
        if not check_data['exists']:
            # Intentar instalar automáticamente la clave GPG antes de añadir el repositorio
            self._show_progress_bar(
                get_string("installing_key", "Instalando clave GPG para {0}...").format(repo['comment'].replace('# ', '')),
                0.2
            )
            
            success, key_or_message = ensure_key_for_repo(repo['uri'], self)
            
            if success:
                self._update_progress_bar(0.8, get_string("key_installed", "Clave GPG instalada correctamente"))
                # Mostrar mensaje de éxito de la clave
                log_info(f"Clave GPG instalada para {repo['uri']}: {key_or_message}")
            else:
                self._update_progress_bar(0.8, get_string("key_install_warning", "Advertencia: No se pudo instalar la clave GPG"))
                # Mostrar advertencia pero continuar
                log_warning(f"No se pudo instalar la clave para {repo['uri']}: {key_or_message}")
            
            # Añadir el repositorio a la lista
            self.repo_list.add_repo(
                repo['active'],
                repo['type'],
                repo['uri'],
                repo['distribution'],
                repo['components'],
                repo['comment']
            )
            
            # Ocultar barra de progreso
            GLib.timeout_add(1000, self._hide_progress_bar)
            
            self._show_info_dialog(get_string("repo_added", "Se ha añadido el repositorio: {0}").format(repo['comment'].replace('# ', '')))
        else:
            self._show_info_dialog(get_string("already_exists", "Este repositorio ya está en la lista"))
    
    def _show_error_dialog(self, message):
        """Muestra un diálogo de error"""
        ErrorHandler.show_error_dialog(
            get_string("error", "Error"),
            message,
            self
        )
    
    def _show_info_dialog(self, message):
        """Muestra un diálogo informativo"""
        ErrorHandler.show_info_dialog(
            get_string("success", "Éxito"),
            message,
            self
        )
    
    def on_language_changed(self, combo):
        """Maneja el cambio de idioma"""
        new_lang = combo.get_active_id()
        if new_lang != get_current_language():
            set_language(new_lang)
            # Actualizar strings de la UI
            self._update_interface_strings()
    
    def _update_interface_strings(self):
        """Actualiza todos los textos de la interfaz"""
        try:
            # Actualizar título de la ventana
            self.set_title(get_string('window_title', APP_NAME))

            # Actualizar etiquetas de notebook
            self.notebook.set_tab_label_text(self.notebook.get_nth_page(0), get_string('repositories', "Repositorios"))
            self.notebook.set_tab_label_text(self.notebook.get_nth_page(1), get_string('gpg_keys', "Claves GPG"))
            
            # Actualizar títulos y descripciones
            self.title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('repo_manager', 'Gestor de Repositorios Debian')}</span>")
            self.desc_label.set_text(get_string('repo_description', 'Administra los repositorios APT de tu sistema'))
            self.gpg_title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('gpg_key_manager', 'Gestor de Claves GPG')}</span>")
            self.gpg_desc_label.set_text(get_string('gpg_key_description', 'Administra las claves GPG para tus repositorios'))
            
            # Actualizar etiqueta para el selector de idioma
            language_label = self.get_descendant_with_name("language_label") 
            if language_label and isinstance(language_label, Gtk.Label):
                language_label.set_text(get_string("language", "Idioma") + ":")
            
            # Actualizar etiqueta de frame de repositorios predefinidos
            self.predef_frame.set_label(get_string('popular_repos', "Repositorios Predefinidos Populares"))
            
            # Actualizar botones
            self.update_button.set_label(get_string('update_repos', "Actualizar Repositorios"))
            self.update_button.set_tooltip_text(get_string('update_tooltip', "Actualizar índices de paquetes (apt update)"))
            
            # Actualizar el texto del botón de búsqueda rápida
            self.fast_repos_button.set_label(get_string('find_fastest_repos', "Buscar Repositorios Más Rápidos"))
            
            self.close_button.set_label(get_string('close', "Cerrar"))
            self.apply_button.set_label(get_string('apply', "Aplicar Cambios"))
            
            # Actualizar el RepoListWidget con las traducciones
            strings = {
                'add_repo_tooltip': get_string('add_repo_tooltip', "Añadir nuevo repositorio"),
                'edit_repo_tooltip': get_string('edit_repo_tooltip', "Editar repositorio seleccionado"),
                'remove_repo_tooltip': get_string('remove_repo_tooltip', "Eliminar repositorio seleccionado"),
                'active': get_string('active', "Activo"),
                'type': get_string('type', "Tipo"),
                'uri': get_string('uri', "URI"),
                'distribution': get_string('distribution', "Distribución"),
                'components': get_string('components', "Componentes"),
                'comment': get_string('comment', "Comentario"),
            }
            self.repo_list.update_ui_strings(strings)
            
            # Actualizar el GPGKeyListWidget con las traducciones
            gpg_strings = {
                'import_key_tooltip': get_string('import_key_tooltip', "Importar clave GPG"),
                'download_key_tooltip': get_string('download_key_tooltip', "Descargar clave GPG"),
                'view_key_tooltip': get_string('view_key_tooltip', "Ver detalles de clave"),
                'name': get_string('name', "Nombre"),
                'path': get_string('path', "Ruta"),
                'format': get_string('format', "Formato"),
                'description': get_string('description', "Descripción"),
            }
            self.gpg_key_list.update_ui_strings(gpg_strings)
            
            # Forzar redibujado
            self.queue_draw()

        except Exception as e:
            log_error(f"Error al actualizar la interfaz: {e}", e)
            # Silenciar errores de actualización de interfaz para evitar bloqueos
            pass
    
    def find_widget(self, name=None, widget_type=None, rebuild_cache=False):
        """
        Encuentra un widget por su nombre y/o tipo de manera eficiente usando caché.
        
        Args:
            name: Nombre del widget a buscar (opcional)
            widget_type: Tipo de widget (clase) a buscar (opcional)
            rebuild_cache: Si es True, reconstruye el caché de widgets
            
        Returns:
            El widget encontrado o None si no se encuentra
        
        Notas:
            - Al menos uno de name o widget_type debe ser proporcionado
            - En la primera llamada, se construye un caché completo de widgets
            - Búsquedas subsiguientes son muy rápidas usando el caché
            - Si la interfaz cambia, use rebuild_cache=True para actualizar
        """
        if name is None and widget_type is None:
            raise ValueError("Debe proporcionar al menos un criterio de búsqueda (nombre o tipo)")
        
        # Reconstruir el caché si se solicita o no existe
        if rebuild_cache or not self._widget_cache:
            self._rebuild_widget_cache()
        
        # Caso 1: Búsqueda por nombre (más eficiente)
        if name is not None and name in self._widget_cache:
            widget = self._widget_cache[name]
            
            # Si también se especifica un tipo, verificar que coincida
            if widget_type is None or isinstance(widget, widget_type):
                return widget
        
        # Caso 2: Búsqueda exclusiva por tipo
        if name is None and widget_type is not None:
            for widget in self._widget_cache.values():
                if isinstance(widget, widget_type):
                    return widget
        
        # Si llegamos aquí, no se encontró en el caché o hay discrepancia de tipo
        # Realizar búsqueda manual una vez más (por si el widget se agregó después)
        widget = self._find_widget_manually(self, name, widget_type)
        
        # Actualizar el caché si se encuentra el widget
        if widget and name:
            self._widget_cache[name] = widget
        
        return widget
    
    def _rebuild_widget_cache(self):
        """Reconstruye el caché completo de widgets por nombre"""
        self._widget_cache = {}
        
        def collect_widgets(container):
            # Guardar el widget actual si tiene un nombre no vacío
            widget_name = container.get_name()
            if widget_name and widget_name != "GtkWindow":  # Ignorar nombres genéricos
                self._widget_cache[widget_name] = container
            
            # Procesar hijos recursivamente para contenedores
            if isinstance(container, Gtk.Container):
                for child in container.get_children():
                    collect_widgets(child)
        
        # Iniciar la recolección desde la ventana principal
        collect_widgets(self)
    
    def _find_widget_manually(self, container, name=None, widget_type=None):
        """
        Busca manualmente un widget por nombre y/o tipo
        
        Args:
            container: Contenedor donde buscar
            name: Nombre del widget (opcional)
            widget_type: Tipo del widget (opcional)
            
        Returns:
            El widget encontrado o None
        """
        # Verificar si el widget actual coincide
        matches_name = (name is None) or (container.get_name() == name)
        matches_type = (widget_type is None) or isinstance(container, widget_type)
        
        if matches_name and matches_type:
            return container
        
        # Buscar en hijos si es un contenedor
        if isinstance(container, Gtk.Container):
            for child in container.get_children():
                result = self._find_widget_manually(child, name, widget_type)
                if result:
                    return result
        
        return None
    
    # Mantener el método original por compatibilidad (redirige al nuevo método)
    def get_descendant_with_name(self, widget_name):
        """
        OBSOLETO: Use find_widget() en su lugar.
        Busca recursivamente un widget por su nombre.
        """
        return self.find_widget(name=widget_name)
    
    # Mantener el otro método por compatibilidad (redirige al nuevo método)
    def get_descendant_at_name(self, widget_name, widget_type=None):
        """
        OBSOLETO: Use find_widget() en su lugar.
        Busca un widget por su nombre y opcionalmente por tipo.
        """
        return self.find_widget(name=widget_name, widget_type=widget_type)
    
    def on_close_clicked(self, button):
        """Cierra la aplicación"""
        if not self.on_delete_event(None, None):
            self.get_application().quit()
    
    def on_delete_event(self, widget, event):
        """Manejador del evento delete-event"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,  # Sin botones predeterminados
            text=get_string("close_confirm", "¿Estás seguro de que quieres cerrar la aplicación?")
        )
        
        # Añadir botones con texto traducido
        dialog.add_button(get_string("no", "No"), Gtk.ResponseType.NO)
        dialog.add_button(get_string("yes", "Yes"), Gtk.ResponseType.YES)
        
        # Establecer YES como botón por defecto
        dialog.set_default_response(Gtk.ResponseType.YES)
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            return False  # Procede con el cierre
        return True  # Cancela el cierre
    
    def destroy(self, *args, **kwargs):
        """Limpia callbacks antes de cerrar"""
        super().destroy(*args, **kwargs)
