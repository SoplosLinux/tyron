# Soplos Repo Selector

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)]()

Una herramienta gráfica para gestionar repositorios APT en sistemas basados en Debian.

*A graphical tool to manage APT repositories in Debian-based systems.*

## 📝 Descripción

Soplos Repo Selector facilita la gestión de repositorios APT en sistemas basados en Debian, permitiendo añadir, editar y eliminar fuentes de software de manera intuitiva. También incluye funcionalidades para encontrar los servidores de repositorio más rápidos según tu ubicación.

## ✨ Características

- Gestión completa de repositorios APT
- Búsqueda de servidores más rápidos según tu ubicación
- Soporte para claves GPG de repositorios
- Repositorios predefinidos populares
- Interfaz gráfica intuitiva
- Soporte para múltiples idiomas

## 📸 Capturas de pantalla

### Ventana principal de Soplos Repo Selector
![Ventana principal](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-repo-selector/screenshots/screenshot1.png)

### Búsqueda de repositorios rápidos
![Búsqueda de repositorios](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-repo-selector/screenshots/screenshot2.png)

## 🔧 Instalación

```bash
# Desde repositorios (recomendado)
sudo apt update
sudo apt install soplos-repo-selector

# Desde el código fuente
git clone https://github.com/SoplosLinux/soplos-repo-selector.git
cd soplos-repo-selector
pip install -r requirements.txt
python3 main.py
```

## 🌐 Idiomas soportados

- Español
- Inglés
- Francés
- Portugués
- Alemán
- Italiano
- Ruso
- Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos Linux](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)

## 📦 Versiones

### v1.0.0 (08/05/2025)
- Versión inicial de lanzamiento
- Gestión completa de repositorios APT
- Búsqueda de servidores más rápidos
- Soporte para 8 idiomas
