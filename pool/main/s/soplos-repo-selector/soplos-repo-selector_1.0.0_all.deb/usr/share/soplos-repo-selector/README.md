# Soplos Repo Selector

![Soplos Repo Selector](assets/icons/com.soplos.reposelector.png)

Gestor gráfico de repositorios APT para sistemas basados en Debian, desarrollado por el equipo de Soplos Linux.

## Características

- **Gestión completa de repositorios**: Añadir, editar, activar/desactivar y eliminar repositorios APT
- **Búsqueda de servidores más rápidos**: Encuentra los mirrors con mejor rendimiento según tu ubicación
- **Gestión de claves GPG**: Importa y administra claves GPG para tus repositorios
- **Repositorios predefinidos**: Añade rápidamente repositorios populares (Chrome, VSCode, Docker, OBS)
- **Soporte multilingüe**: Disponible en 8 idiomas (ES, EN, DE, FR, IT, PT, RU, RO)
- **Interfaz intuitiva**: Diseño sencillo y amigable basado en GTK3

## Requisitos

- Python 3.9 o superior
- PyGObject (python3-gi)
- Gtk 3.0
- python3-apt
- apt-transport-https
- gnupg
- curl

## Instalación

### Desde los paquetes deb

```bash
sudo apt install ./soplos-repo-selector_1.0.0_all.deb
```

### Instalación manual

```bash
git clone https://github.com/SoplosLinux/soplos-repo-selector.git
cd soplos-repo-selector
sudo pip3 install -e .
sudo cp debian/soplos-repo-selector /usr/local/bin/
sudo chmod +x /usr/local/bin/soplos-repo-selector
sudo cp assets/com.soplos.reposelector.desktop /usr/share/applications/
sudo cp assets/icons/com.soplos.reposelector.png /usr/share/icons/hicolor/256x256/apps/
```

## Uso

Inicia la aplicación desde el menú de aplicaciones o ejecutando:

```bash
soplos-repo-selector
```

## Licencia

Este software está licenciado bajo GNU GPL v3.

## Contribuir

Las contribuciones son bienvenidas. Por favor, envía tus pull requests a nuestro repositorio GitHub.

## Capturas de Pantalla

![Captura 1](assets/screenshots/screenshot1.png)
![Captura 2](assets/screenshots/screenshot2.png)
![Captura 3](assets/screenshots/screenshot3.png)
![Captura 4](assets/screenshots/screenshot4.png)
