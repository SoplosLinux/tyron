import os
import subprocess
import socket
import time
import threading
from urllib.parse import urlparse
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import GObject, GLib

# Lista de principales mirrors de Debian
DEFAULT_MIRRORS = [
    "http://deb.debian.org/debian",
    "http://ftp.us.debian.org/debian",
    "http://ftp.uk.debian.org/debian",
    "http://ftp.de.debian.org/debian",
    "http://ftp.fr.debian.org/debian",
    "http://ftp.es.debian.org/debian",
    "http://ftp.it.debian.org/debian",
    "http://ftp.br.debian.org/debian"
]

class RepoSpeedTester:
    """Clase para probar la velocidad de repositorios APT"""
    
    def __init__(self, mirrors=None):
        self.mirrors = mirrors or DEFAULT_MIRRORS
        
    def measure_ping(self, url):
        """Mide el tiempo de respuesta (ping) a un repositorio"""
        hostname = urlparse(url).netloc
        
        try:
            # Medir tiempo de conexión TCP
            start = time.time()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2.0)
            s.connect((hostname, 80))
            s.close()
            latency = time.time() - start
            return latency * 1000  # Convertir a ms
        except:
            return 99999  # Valor alto para errores
    
    def get_fastest_mirrors(self, limit=5):
        """Obtiene los mirrors más rápidos"""
        results = []
        
        for url in self.mirrors:
            ping = self.measure_ping(url)
            country = self.get_mirror_country(url)
            results.append({
                "url": url,
                "ping": ping,
                "country": country
            })
        
        # Ordenar por ping (menor primero)
        results.sort(key=lambda x: x["ping"])
        
        # Devolver los más rápidos
        return results[:limit]
    
    def get_mirror_country(self, url):
        """Obtiene el país asociado a un mirror basado en su URL"""
        hostname = urlparse(url).netloc
        
        # Mapeo de algunos dominios conocidos
        country_map = {
            "deb.debian.org": "Global CDN",
            "ftp.us.debian.org": "Estados Unidos",
            "ftp.uk.debian.org": "Reino Unido", 
            "ftp.de.debian.org": "Alemania",
            "ftp.fr.debian.org": "Francia",
            "ftp.au.debian.org": "Australia",
            "ftp.jp.debian.org": "Japón",
            "ftp.br.debian.org": "Brasil",
            "ftp.cl.debian.org": "Chile",
            "ftp.es.debian.org": "España",
            "ftp.it.debian.org": "Italia",
            "ftp.cn.debian.org": "China",
            "ftp.ru.debian.org": "Rusia",
            "ftp.ca.debian.org": "Canadá"
        }
        
        for domain, country in country_map.items():
            if domain in hostname:
                return country
        
        # Si no coincide con ninguno conocido
        if hostname.endswith(".debian.org"):
            # Extraer el código de país
            parts = hostname.split(".")
            if parts[0].startswith("ftp.") and len(parts[0]) > 4:
                country_code = parts[0][4:].upper()
                return f"Código: {country_code}"
        
        return "Desconocido"

def get_country_mirrors():
    """Obtiene una lista de mirrors organizados por país"""
    return {
        'Global': ['http://deb.debian.org/debian'],
        'Estados Unidos': ['http://ftp.us.debian.org/debian'],
        'Reino Unido': ['http://ftp.uk.debian.org/debian'],
        'Alemania': ['http://ftp.de.debian.org/debian'],
        'Francia': ['http://ftp.fr.debian.org/debian'],
        'Australia': ['http://ftp.au.debian.org/debian'],
        'Japón': ['http://ftp.jp.debian.org/debian'],
        'Brasil': ['http://ftp.br.debian.org/debian'],
        'Chile': ['http://ftp.cl.debian.org/debian'],
        'España': ['http://ftp.es.debian.org/debian'],
        'Italia': ['http://ftp.it.debian.org/debian'],
        'China': ['http://ftp.cn.debian.org/debian'],
        'Rusia': ['http://ftp.ru.debian.org/debian'],
        'Canadá': ['http://ftp.ca.debian.org/debian'],
    }
