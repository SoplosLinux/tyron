import os
import subprocess
import socket
import time
import threading
import concurrent.futures
from urllib.parse import urlparse
import requests
from pathlib import Path
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import GObject, GLib

# Importar ErrorHandler para estandarizar el manejo de errores
from src.utils.error_handler import ErrorHandler, log_error, log_warning, log_info

# Lista de principales mirrors de Debian
DEFAULT_MIRRORS = [
    "http://deb.debian.org/debian",
    "http://ftp.us.debian.org/debian",
    "http://ftp.uk.debian.org/debian",
    "http://ftp.de.debian.org/debian",
    "http://ftp.fr.debian.org/debian",
    "http://ftp.es.debian.org/debian",
    "http://ftp.it.debian.org/debian",
    "http://ftp.br.debian.org/debian"
]

class RepoSpeedTester:
    """Clase para probar la velocidad de repositorios APT"""
    
    def __init__(self, mirrors=None):
        self.mirrors = mirrors or DEFAULT_MIRRORS
        self.timeout = 5
        self.test_file_size = 512 * 1024  # 512KB para test rápido
        
    def measure_download_speed(self, url):
        """Mide velocidad real de descarga"""
        try:
            test_paths = [
                "dists/stable/Release",
                "dists/bookworm/Release", 
                "ls-lR.gz"
            ]
            
            for test_path in test_paths:
                test_url = f"{url.rstrip('/')}/{test_path}"
                
                try:
                    start_time = time.time()
                    response = requests.get(test_url, timeout=self.timeout, stream=True)
                    
                    if response.status_code == 200:
                        downloaded = 0
                        download_start = time.time()
                        
                        for chunk in response.iter_content(chunk_size=8192):
                            downloaded += len(chunk)
                            if downloaded > self.test_file_size:
                                break
                        
                        elapsed = time.time() - download_start
                        
                        if elapsed > 0:
                            speed_mbps = (downloaded / (1024 * 1024)) / elapsed
                        else:
                            speed_mbps = 0
                        
                        return {
                            'speed_mbps': speed_mbps,
                            'latency_ms': elapsed * 1000,
                            'status': 'success',
                            'downloaded_bytes': downloaded
                        }
                        
                except requests.exceptions.Timeout:
                    log_warning(f"Timeout al probar {test_url}")
                    continue
                except requests.exceptions.ConnectionError:
                    log_warning(f"Error de conexión al probar {test_url}")
                    continue
                except Exception as e:
                    log_error(f"Error al probar {test_url}", e)
                    continue
            
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'no_valid_files'}
                
        except requests.exceptions.Timeout:
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'timeout'}
        except requests.exceptions.ConnectionError:
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'connection_error'}
        except Exception as e:
            log_error(f"Error al medir velocidad para {url}", e)
            return {'speed_mbps': 0, 'latency_ms': 9999, 'status': 'error', 'error': str(e)}
    
    def test_mirrors_parallel(self, callback=None, max_workers=3):
        """ARREGLADO: Prueba mirrors en paralelo y devuelve TODOS los resultados"""
        all_results = []
        
        def test_single_mirror(mirror_url):
            country = self.get_mirror_country(mirror_url)
            speed_result = self.measure_download_speed(mirror_url)
            
            result = {
                'url': mirror_url,
                'country': country,
                **speed_result
            }
            
            # IMPORTANTE: Siempre añadir a la lista completa
            all_results.append(result)
            
            # Callback individual para actualización en tiempo real
            if callback:
                callback(result)
            
            return result
        
        # Ejecutar todas las pruebas
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(test_single_mirror, mirror) for mirror in self.mirrors]
            
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result()  # Solo para capturar excepciones
                except Exception as e:
                    log_error("Error en test de velocidad", e)
        
        # CRÍTICO: Ordenar por velocidad (mayor primero) y devolver TODOS
        successful_results = [r for r in all_results if r['status'] == 'success']
        failed_results = [r for r in all_results if r['status'] != 'success']
        
        successful_results.sort(key=lambda x: x['speed_mbps'], reverse=True)
        failed_results.sort(key=lambda x: x['latency_ms'])
        
        final_results = successful_results + failed_results
        
        return final_results
    
    def get_fastest_mirrors(self, limit=5):
        """Obtiene los mirrors más rápidos"""
        results = []
        
        for url in self.mirrors:
            try:
                ping = self.measure_ping(url)
                country = self.get_mirror_country(url)
                results.append({
                    "url": url,
                    "ping": ping,
                    "country": country
                })
            except Exception as e:
                log_error(f"Error al probar mirror {url}", e)
        
        # Ordenar por ping (menor primero)
        results.sort(key=lambda x: x["ping"])
        
        # Devolver los más rápidos
        return results[:limit]
    
    def measure_ping(self, url):
        """Mide el ping a un servidor"""
        hostname = urlparse(url).netloc
        try:
            start = time.time()
            socket.gethostbyname(hostname)
            return (time.time() - start) * 1000  # Convertir a ms
        except socket.gaierror:
            log_warning(f"No se pudo resolver el hostname {hostname}")
            return 9999  # Valor alto para indicar error
    
    def get_mirror_country(self, url):
        """Obtiene el país asociado a un mirror basado en su URL"""
        hostname = urlparse(url).netloc
        
        # Mapeo de algunos dominios conocidos
        country_map = {
            "deb.debian.org": "Global CDN",
            "ftp.us.debian.org": "Estados Unidos",
            "ftp.uk.debian.org": "Reino Unido", 
            "ftp.de.debian.org": "Alemania",
            "ftp.fr.debian.org": "Francia",
            "ftp.au.debian.org": "Australia",
            "ftp.jp.debian.org": "Japón",
            "ftp.br.debian.org": "Brasil",
            "ftp.cl.debian.org": "Chile",
            "ftp.es.debian.org": "España",
            "ftp.it.debian.org": "Italia",
            "ftp.cn.debian.org": "China",
            "ftp.ru.debian.org": "Rusia",
            "ftp.ca.debian.org": "Canadá"
        }
        
        for domain, country in country_map.items():
            if domain in hostname:
                return country
        
        # Si no coincide con ninguno conocido
        if hostname.endswith(".debian.org"):
            # Extraer el código de país
            parts = hostname.split(".")
            if parts[0].startswith("ftp.") and len(parts[0]) > 4:
                country_code = parts[0][4:].upper()
                return f"Código: {country_code}"
        
        return "Desconocido"

def get_country_mirrors():
    """Obtiene una lista de mirrors organizados por país"""
    return {
        'Global': ['http://deb.debian.org/debian'],
        'Estados Unidos': ['http://ftp.us.debian.org/debian'],
        'Reino Unido': ['http://ftp.uk.debian.org/debian'],
        'Alemania': ['http://ftp.de.debian.org/debian'],
        'Francia': ['http://ftp.fr.debian.org/debian'],
        'Australia': ['http://ftp.au.debian.org/debian'],
        'Japón': ['http://ftp.jp.debian.org/debian'],
        'Brasil': ['http://ftp.br.debian.org/debian'],
        'Chile': ['http://ftp.cl.debian.org/debian'],
        'España': ['http://ftp.es.debian.org/debian'],
        'Italia': ['http://ftp.it.debian.org/debian'],
        'China': ['http://ftp.cn.debian.org/debian'],
        'Rusia': ['http://ftp.ru.debian.org/debian'],
        'Canadá': ['http://ftp.ca.debian.org/debian'],
    }
