import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GObject
import os
import subprocess
from pathlib import Path
from src.i18n.strings import get_string

class GPGKeyListWidget(Gtk.Box):
    """Widget para mostrar y gestionar claves GPG"""
    
    __gsignals__ = {
        'key-selected': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        'key-imported': (GObject.SignalFlags.RUN_FIRST, None, (bool, str)),
    }
    
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        
        # Crear el modelo para la lista de claves
        # Columnas: Nombre, Ruta, Formato (GPG/ASCII), Descripción
        self.keys_store = Gtk.ListStore(str, str, str, str)
        
        # Lista de claves GPG
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled_window.set_shadow_type(Gtk.ShadowType.ETCHED_IN)
        self.pack_start(scrolled_window, True, True, 0)
        
        # Vista de árbol para claves
        self.keys_view = Gtk.TreeView(model=self.keys_store)
        
        # Columnas de texto
        self._add_text_column("Nombre", 0)
        self._add_text_column("Ruta", 1)
        self._add_text_column("Formato", 2)
        self._add_text_column("Descripción", 3)
        
        # Permitir selección
        self.selection = self.keys_view.get_selection()
        self.selection.set_mode(Gtk.SelectionMode.SINGLE)
        self.selection.connect("changed", self.on_key_selection_changed)
        
        scrolled_window.add(self.keys_view)
        
        # Panel de botones para claves GPG
        key_buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.pack_start(key_buttons, False, False, 0)
        
        # Botones para gestionar claves
        self.import_button = Gtk.Button.new_from_icon_name("document-open", Gtk.IconSize.BUTTON)
        self.import_button.set_tooltip_text("Importar clave GPG")
        self.import_button.connect("clicked", self.on_import_key_clicked)
        key_buttons.pack_start(self.import_button, False, False, 0)
        
        self.download_button = Gtk.Button.new_from_icon_name("network-server", Gtk.IconSize.BUTTON)
        self.download_button.set_tooltip_text("Descargar clave GPG")
        self.download_button.connect("clicked", self.on_download_key_clicked)
        key_buttons.pack_start(self.download_button, False, False, 0)
        
        self.view_button = Gtk.Button.new_from_icon_name("document-properties", Gtk.IconSize.BUTTON)
        self.view_button.set_tooltip_text("Ver detalles de clave")
        self.view_button.connect("clicked", self.on_view_key_clicked)
        self.view_button.set_sensitive(False)  # Inicialmente desactivado
        key_buttons.pack_start(self.view_button, False, False, 0)
        
        # Espaciador
        key_buttons.pack_start(Gtk.Box(), True, True, 0)
        
        # Directorio de claves estándar
        self.keyrings_dir = '/usr/share/keyrings'
        self.etc_keyrings_dir = '/etc/apt/keyrings'
        
        # Cargar las claves disponibles
        self.refresh_keys()
    
    def _add_text_column(self, title, index):
        """Añade una columna de texto a la vista de árbol"""
        renderer = Gtk.CellRendererText()
        renderer.set_property("ellipsize", True)  # Permite elipsis en texto largo
        renderer.set_property("xpad", 10)  # Añadir padding horizontal
        column = Gtk.TreeViewColumn(title, renderer, text=index)
        column.set_resizable(True)  # Asegurar que las columnas sean redimensionables
        column.set_expand(True)  # Permitir que la columna se expanda
        column.set_sort_column_id(index)
        
        # Establecer un ancho mínimo para la columna
        if index == 0:  # Nombre
            column.set_min_width(150)
        elif index == 1:  # Ruta
            column.set_min_width(200)
        elif index == 2:  # Formato
            column.set_min_width(100)
        elif index == 3:  # Descripción
            column.set_min_width(200)
        
        self.keys_view.append_column(column)
        return column

    def _get_key_description(self, key_path):
        """Intenta obtener una descripción de la clave GPG"""
        try:
            # Intentar obtener información con gpg
            result = subprocess.run(
                ["gpg", "--show-keys", "--with-colons", key_path],
                capture_output=True, 
                text=True,
                timeout=2
            )
            
            if result.returncode == 0:
                # Parsear la salida para buscar campos útiles
                for line in result.stdout.splitlines():
                    parts = line.split(':')
                    if len(parts) > 9:
                        if parts[0] == "uid":
                            # El campo 9 generalmente contiene nombre/email
                            return parts[9]
                        elif parts[0] == "pub" and len(parts) > 1:
                            # Al menos devolver el ID de la clave
                            return f"ID: {parts[4]}"
            
            # Si no se puede obtener información detallada
            return get_string("gpg_key", "Clave GPG")
        except:
            # En caso de error, solo devolver un valor genérico
            return get_string("gpg_key", "Clave GPG")
    
    def clear(self):
        """Limpia la lista de claves"""
        self.keys_store.clear()
    
    def refresh_keys(self):
        """Carga las claves GPG disponibles en el sistema"""
        self.clear()
        
        # Directorios de claves a revisar
        key_dirs = [self.keyrings_dir, self.etc_keyrings_dir]
        
        for dir_path in key_dirs:
            if os.path.exists(dir_path):
                for file in sorted(os.listdir(dir_path)):
                    if file.endswith(('.gpg', '.asc', '.pgp')):
                        key_path = os.path.join(dir_path, file)
                        
                        # Determinar el tipo/formato usando traducciones
                        if file.endswith('.asc'):
                            format_type = get_string("ascii_gpg", "ASCII")
                        else:
                            format_type = get_string("binary_gpg", "Binario GPG")
                        
                        # Intentar obtener descripción de la clave
                        description = self._get_key_description(key_path)
                        
                        self.keys_store.append([file, key_path, format_type, description])
    
    def get_selected_key(self):
        """Devuelve la clave seleccionada actualmente"""
        model, iter = self.selection.get_selected()
        if iter:
            return {
                'name': model[iter][0],
                'path': model[iter][1],
                'format': model[iter][2],
                'description': model[iter][3]
            }
        return None
    
    def on_key_selection_changed(self, selection):
        """Actualiza la sensibilidad de los botones según la selección"""
        model, iter = selection.get_selected()
        has_selection = iter is not None
        
        self.view_button.set_sensitive(has_selection)
        
        # Emitir señal con la ruta de la clave seleccionada
        if has_selection:
            self.emit('key-selected', model[iter][1])  # Emitir la ruta
    
    def on_import_key_clicked(self, button):
        """Abre un diálogo para importar una clave GPG"""
        parent = self.get_toplevel()
        
        # Crear un diálogo de selección de archivo
        dialog = Gtk.FileChooserDialog(
            title=get_string("select_gpg_key", "Seleccionar clave GPG"), 
            parent=parent,
            action=Gtk.FileChooserAction.OPEN
        )
        
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        # Añadir filtros para tipos de archivos GPG
        gpg_filter = Gtk.FileFilter()
        gpg_filter.set_name("Archivos de clave GPG")
        gpg_filter.add_pattern("*.gpg")
        gpg_filter.add_pattern("*.asc")
        gpg_filter.add_pattern("*.pgp")
        dialog.add_filter(gpg_filter)
        
        all_filter = Gtk.FileFilter()
        all_filter.set_name("Todos los archivos")
        all_filter.add_pattern("*")
        dialog.add_filter(all_filter)
        
        # Mostrar el diálogo
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            key_path = dialog.get_filename()
            
            # Cerrar el diálogo antes de mostrar otro
            dialog.destroy()
            
            # Consultar nombre para la clave (usar nombre del archivo por defecto)
            key_name = os.path.basename(key_path)
            
            # Diálogo para confirmar/editar el nombre
            name_dialog = Gtk.Dialog(
                title=get_string("key_name_dialog", "Nombre de la clave"), 
                parent=parent,
                flags=0
            )
            
            name_dialog.add_buttons(
                Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                Gtk.STOCK_OK, Gtk.ResponseType.OK
            )
            
            name_dialog.set_default_size(350, -1)
            
            content_area = name_dialog.get_content_area()
            content_area.set_margin_top(10)
            content_area.set_margin_bottom(10)
            content_area.set_margin_start(10)
            content_area.set_margin_end(10)
            content_area.set_spacing(6)
            
            # Etiqueta
            label = Gtk.Label(label=get_string("key_name_label", "Nombre para la clave importada:"))
            content_area.pack_start(label, False, False, 0)
            
            # Campo de entrada
            entry = Gtk.Entry()
            entry.set_text(key_name)
            entry.set_activates_default(True)
            content_area.pack_start(entry, False, False, 0)
            
            # El botón OK es el predeterminado
            name_dialog.set_default_response(Gtk.ResponseType.OK)
            
            content_area.show_all()
            
            name_response = name_dialog.run()
            
            if name_response == Gtk.ResponseType.OK:
                new_key_name = entry.get_text().strip()
                
                # Asegurar que el nombre termine en .gpg
                if not new_key_name.endswith(('.gpg', '.asc', '.pgp')):
                    new_key_name += '.gpg'
                
                # Crear directorio si no existe
                dst_dir = self.etc_keyrings_dir
                if not os.path.exists(dst_dir):
                    dst_dir = self.keyrings_dir
                
                os.makedirs(dst_dir, exist_ok=True)
                
                # Destino final
                dst_path = os.path.join(dst_dir, new_key_name)
                
                try:
                    # Copiar la clave con privilegios elevados
                    result = subprocess.run(
                        ["pkexec", "cp", key_path, dst_path], 
                        check=True,
                        capture_output=True
                    )
                    
                    # Establecer permisos correctos
                    subprocess.run(
                        ["pkexec", "chmod", "644", dst_path], 
                        check=True
                    )
                    
                    # Actualizar la lista de claves
                    self.refresh_keys()
                    
                    # Emitir señal de éxito
                    self.emit('key-imported', True, dst_path)
                    
                except subprocess.CalledProcessError as e:
                    # Emitir señal de fallo
                    self.emit('key-imported', False, str(e))
            
            name_dialog.destroy()
        else:
            dialog.destroy()
    
    def on_download_key_clicked(self, button):
        """Abre un diálogo para descargar una clave GPG"""
        parent = self.get_toplevel()
        
        dialog = Gtk.Dialog(
            title=get_string("download_gpg_key", "Descargar clave GPG"),
            parent=parent,
            flags=0
        )
        
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )
        
        dialog.set_default_size(400, -1)
        
        content_area = dialog.get_content_area()
        content_area.set_margin_top(10)
        content_area.set_margin_bottom(10)
        content_area.set_margin_start(10)
        content_area.set_margin_end(10)
        content_area.set_spacing(6)
        
        # Etiqueta
        label = Gtk.Label(label=get_string("gpg_url_label", "URL de la clave GPG:"))
        content_area.pack_start(label, False, False, 0)
        
        # Campo de entrada para URL
        url_entry = Gtk.Entry()
        url_entry.set_placeholder_text(get_string("gpg_url_placeholder", "https://ejemplo.com/key.gpg"))
        url_entry.set_activates_default(True)
        content_area.pack_start(url_entry, True, True, 0)
        
        # Etiqueta para nombre
        name_label = Gtk.Label(label=get_string("gpg_name_label", "Nombre para guardar la clave:"))
        content_area.pack_start(name_label, False, False, 10)
        
        # Campo de entrada para nombre
        name_entry = Gtk.Entry()
        name_entry.set_placeholder_text("nombre-clave.gpg")
        content_area.pack_start(name_entry, True, True, 0)
        
        # El botón OK es el predeterminado
        dialog.set_default_response(Gtk.ResponseType.OK)
        
        content_area.show_all()
        
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            url = url_entry.get_text().strip()
            key_name = name_entry.get_text().strip()
            
            # Validar URL
            if not url:
                error_dialog = Gtk.MessageDialog(
                    parent=parent,
                    flags=0,
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK,
                    text=get_string("invalid_url", "URL inválida")
                )
                error_dialog.format_secondary_text(get_string("enter_valid_url", "Por favor, introduce una URL válida."))
                error_dialog.run()
                error_dialog.destroy()
                dialog.destroy()
                return
            
            # Generar nombre si está vacío
            if not key_name:
                import hashlib
                key_name = hashlib.md5(url.encode()).hexdigest() + '.gpg'
            elif not key_name.endswith(('.gpg', '.asc', '.pgp')):
                key_name += '.gpg'
            
            # Crear directorio si no existe
            dst_dir = self.etc_keyrings_dir
            if not os.path.exists(dst_dir):
                dst_dir = self.keyrings_dir
                
            os.makedirs(dst_dir, exist_ok=True)
            
            # Destino final
            dst_path = os.path.join(dst_dir, key_name)
            
            try:
                # Descargar y guardar la clave con privilegios elevados
                command = f"curl -fsSL {url} | gpg --dearmor > {dst_path} && chmod 644 {dst_path}"
                result = subprocess.run(
                    ["pkexec", "bash", "-c", command], 
                    check=True,
                    capture_output=True
                )
                
                # Actualizar la lista de claves
                self.refresh_keys()
                
                # Emitir señal de éxito
                self.emit('key-imported', True, dst_path)
                
            except subprocess.CalledProcessError as e:
                # Emitir señal de fallo
                self.emit('key-imported', False, str(e))
        
        dialog.destroy()
    
    def on_view_key_clicked(self, button):
        """Muestra los detalles de la clave seleccionada"""
        key = self.get_selected_key()
        if not key:
            return
            
        parent = self.get_toplevel()
        
        # Crear un diálogo para mostrar los detalles
        dialog = Gtk.Dialog(
            title=get_string("gpg_key_details", "Detalles de {0}").format(key['name']),
            parent=parent,
            flags=0,
            buttons=(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
        )
        
        dialog.set_default_size(500, 400)
        
        content_area = dialog.get_content_area()
        content_area.set_margin_top(10)
        content_area.set_margin_bottom(10)
        content_area.set_margin_start(10)
        content_area.set_margin_end(10)
        content_area.set_spacing(6)
        
        # Mostrar información básica
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        content_area.pack_start(info_box, False, False, 0)
        
        # Añadir campos de información
        fields = [
            ("Nombre:", key['name']),
            ("Ruta:", key['path']),
            ("Formato:", key['format'])
        ]
        
        for label_text, value in fields:
            field_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            
            label = Gtk.Label(label=label_text)
            label.set_halign(Gtk.Align.START)
            label.set_width_chars(10)
            field_box.pack_start(label, False, False, 0)
            
            value_label = Gtk.Label(label=value)
            value_label.set_halign(Gtk.Align.START)
            value_label.set_selectable(True)
            field_box.pack_start(value_label, True, True, 0)
            
            info_box.pack_start(field_box, False, False, 0)
        
        # Añadir separador
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        content_area.pack_start(separator, False, False, 10)
        
        # Área de texto para mostrar la información detallada
        scrolled_win = Gtk.ScrolledWindow()
        scrolled_win.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        content_area.pack_start(scrolled_win, True, True, 0)
        
        text_view = Gtk.TextView()
        text_view.set_editable(False)
        text_view.set_wrap_mode(Gtk.WrapMode.WORD)
        text_buffer = text_view.get_buffer()
        scrolled_win.add(text_view)
        
        # Cargar la información detallada de la clave
        self._load_key_details(key['path'], text_buffer)
        
        content_area.show_all()
        
        dialog.run()
        dialog.destroy()
    
    def _load_key_details(self, key_path, text_buffer):
        """Carga los detalles de la clave GPG en el buffer de texto"""
        try:
            # Intentar obtener información con gpg
            result = subprocess.run(
                ["gpg", "--show-keys", key_path],
                capture_output=True, 
                text=True
            )
            
            if result.returncode == 0:
                text_buffer.set_text(result.stdout)
            else:
                # Si falla, intentar otra forma
                result = subprocess.run(
                    ["gpg", "--list-packets", key_path],
                    capture_output=True, 
                    text=True
                )
                
                if result.returncode == 0:
                    text_buffer.set_text(result.stdout)
                else:
                    text_buffer.set_text(f"No se pudo obtener información detallada de la clave.\nError: {result.stderr}")
        except Exception as e:
            text_buffer.set_text(f"Error al cargar los detalles de la clave: {str(e)}")
    
    def update_ui_strings(self, strings):
        """Actualiza los textos de la interfaz con las traducciones"""
        self.import_button.set_tooltip_text(strings.get('import_key_tooltip', "Importar clave GPG"))
        self.download_button.set_tooltip_text(strings.get('download_key_tooltip', "Descargar clave GPG"))
        self.view_button.set_tooltip_text(strings.get('view_key_tooltip', "Ver detalles de clave"))
        
        # Actualizar columnas de TreeView
        column_titles = ['name', 'path', 'format', 'description']
        translated_titles = [
            strings.get('name', "Nombre"),
            strings.get('path', "Ruta"),
            strings.get('format', "Formato"),
            strings.get('description', "Descripción")
        ]
        
        for i, title in enumerate(column_titles):
            if i < len(self.keys_view.get_columns()):
                column = self.keys_view.get_column(i)
                if column:
                    column.set_title(translated_titles[i])
