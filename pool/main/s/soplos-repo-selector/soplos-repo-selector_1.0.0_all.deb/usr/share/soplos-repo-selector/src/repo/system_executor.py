import os
import subprocess
import shlex
from typing import List, Dict, Optional, Any, Union
import shutil

from src.utils.error_handler import ErrorHandler, log_error, log_warning

class SystemCommandExecutor:
    """Ejecuta comandos del sistema de manera segura"""
    
    def __init__(self):
        # Lista de rutas seguras para operaciones con privilegios
        self.safe_paths = [
            '/etc/apt/sources.list',
            '/etc/apt/sources.list.d',
            '/usr/share/keyrings',
            '/etc/apt/keyrings',
            '/var/lib/apt/lists',
            '/var/cache/apt'
        ]
    
    def _is_safe_path(self, path: str) -> bool:
        """Verifica si una ruta es segura para operaciones con privilegios"""
        path = os.path.abspath(path)
        for safe_path in self.safe_paths:
            # Comprobar si es exactamente la ruta o está dentro de un directorio seguro
            if path == safe_path or path.startswith(safe_path + '/'):
                return True
        return False
    
    def _check_command_exists(self, command: str) -> bool:
        """Verifica si un comando existe en el sistema"""
        return shutil.which(command) is not None
    
    def run_as_root(self, command: Union[str, List[str]], 
                   shell: bool = False, 
                   validate_paths: bool = True) -> subprocess.CompletedProcess:
        """
        Ejecuta un comando como root de manera segura
        
        Args:
            command: Comando a ejecutar (string o lista)
            shell: Si True, ejecuta como shell command
            validate_paths: Si True, valida que las rutas sean seguras
            
        Returns:
            Objeto CompletedProcess con el resultado
            
        Raises:
            ValueError: Si el comando o las rutas no son seguras
            subprocess.CalledProcessError: Si el comando falla
        """
        # Validar que pkexec esté instalado
        if not self._check_command_exists('pkexec'):
            raise ValueError("pkexec no está instalado. Instale policykit-1.")
        
        # Validar rutas si es necesario
        if validate_paths and isinstance(command, list):
            for arg in command:
                if arg.startswith('/') and not self._is_safe_path(arg):
                    raise ValueError(f"Ruta no segura para operaciones con privilegios: {arg}")
        
        try:
            # Preparar el comando
            if shell:
                if isinstance(command, list):
                    cmd_str = ' '.join(command)
                else:
                    cmd_str = command
                
                # Preparar para ejecución con shell
                pkexec_cmd = ['pkexec', 'bash', '-c', cmd_str]
            else:
                if isinstance(command, str):
                    command = shlex.split(command)
                
                # Preparar para ejecución directa
                pkexec_cmd = ['pkexec'] + command
            
            # Ejecutar el comando
            result = subprocess.run(
                pkexec_cmd,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True
            )
            
            return result
            
        except subprocess.CalledProcessError as e:
            log_error(f"Error al ejecutar comando {command}: {e}", e)
            
            # Si el error es por permisos, proporcionar un mensaje más claro
            if e.returncode == 126 or e.returncode == 127:
                raise PermissionError("Acceso denegado. Se requieren privilegios de administrador.")
                
            raise
        except Exception as e:
            log_error(f"Error inesperado al ejecutar comando {command}: {e}", e)
            raise
    
    def run_apt_update(self) -> bool:
        """Ejecuta apt update para actualizar los índices de repositorios"""
        try:
            # Ejecutar apt update con privilegios
            self.run_as_root(['apt', 'update'])
            return True
        except Exception as e:
            log_error("Error al ejecutar apt update", e)
            return False
    
    def run_apt_install(self, packages: List[str]) -> bool:
        """Instala paquetes con apt"""
        if not packages:
            return True
            
        try:
            # Instalar sin pedir confirmación
            cmd = ['apt', 'install', '-y'] + packages
            self.run_as_root(cmd)
            return True
        except Exception as e:
            log_error(f"Error al instalar paquetes {packages}", e)
            return False
