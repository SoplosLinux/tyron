import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib

import os
import sys
import time
import atexit
import locale

from src.config.constants import APP_ID, APP_NAME, APP_VERSION
from src.gui.window import MainWindow
from src.i18n.strings import set_language, get_current_language, detect_system_language
from src.utils.error_handler import log_info, log_warning, log_error

class SoplosRepoSelector(Gtk.Application):
    """
    Clase principal de la aplicación Soplos Repo Selector.
    Coordina la ventana principal y gestiona la aplicación Gtk.
    """
    def __init__(self):
        super().__init__(application_id=APP_ID,
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        
        # Inicializar variables de la aplicación
        self.window = None
        
        # Configurar la aplicación
        self.setup_application()
        
    def setup_application(self):
        """Configura los parámetros globales de la aplicación"""
        # Establecer identificadores de aplicación globales
        GLib.set_prgname(APP_ID)
        GLib.set_application_name(APP_NAME)
        
        # Deshabilitar warnings de accesibilidad
        os.environ['NO_AT_BRIDGE'] = '1'
        
        # Configurar idioma basado en locale del sistema
        self.setup_language()
    
    def setup_language(self):
        """Configura el idioma basado en la configuración del sistema"""
        # Usar la función mejorada del módulo i18n para detectar el idioma del sistema
        system_lang = detect_system_language()
        
        # Establecer el idioma en el módulo de internacionalización
        set_language(system_lang)
        
        # Registrar para depuración
        log_info(f"Idioma configurado: {get_current_language()}")
    
    def do_startup(self):
        """Invocado durante el inicio de la aplicación, antes de abrir la primera ventana"""
        Gtk.Application.do_startup(self)
    
    def do_activate(self):
        """Gestiona la activación de la aplicación"""
        # Si ya hay una ventana, mostrarla
        if self.window:
            self.window.present()
            return
            
        # Crear la ventana principal
        self.window = MainWindow(application=self)
        
        # Conectar la señal de cierre
        self.window.connect('delete-event', self.on_window_delete_event)
        
        # Mostrar la ventana
        self.window.show_all()
    
    def on_window_delete_event(self, window, event):
        """Maneja el evento de cierre de la ventana principal"""
        from src.i18n.strings import get_string
        
        # Crear un diálogo personalizado en lugar de usar YES_NO predefinido
        dialog = Gtk.MessageDialog(
            transient_for=window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,  # Sin botones predeterminados
            text=get_string("close_confirm", "¿Estás seguro de que quieres cerrar la aplicación?")
        )
        
        # Añadir botones con texto traducido
        dialog.add_button(get_string("no", "No"), Gtk.ResponseType.NO)
        dialog.add_button(get_string("yes", "Yes"), Gtk.ResponseType.YES)
        
        # Establecer YES como botón por defecto
        dialog.set_default_response(Gtk.ResponseType.YES)
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            return False  # Proceder con el cierre
        return True  # Cancelar el cierre
    
    def clean_stale_cache_files(self, verbose=False):
        """
        Limpia archivos de caché Python antiguos y directorios __pycache__
        
        Args:
            verbose: Si es True, muestra mensajes de registro.
        """
        from src.i18n.strings import get_string
        
        log_info(get_string("checking_old_cache", "Verificando archivos de caché antiguos"))
        
        try:
            # Obtener la ruta base del programa
            base_dir = "/usr/local/bin/soplos-repo-selector"
            if not os.path.exists(base_dir):
                try:
                    # Alternativa: usar la ruta del script actual
                    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                except NameError:
                    base_dir = os.getcwd()
            
            # Tiempo actual para comparar
            current_time = time.time()
            # Tiempo máximo de antigüedad para eliminar (1 día)
            max_age = 24 * 60 * 60  # 1 día en segundos
            
            # Contadores para seguimiento
            pyc_count = 0
            pycache_count = 0
            
            # Buscar y eliminar archivos .pyc antiguos y directorios __pycache__
            for root, dirs, files in os.walk(base_dir):
                # No procesar directorios git o venv
                if '.git' in dirs:
                    dirs.remove('.git')
                if 'venv' in dirs:
                    dirs.remove('venv')
                    
                # No procesar directorios de site-packages
                if 'site-packages' in root:
                    continue
                
                # Revisar archivos .pyc individuales
                for file in files:
                    if file.endswith('.pyc') or file.endswith('.pyo'):
                        file_path = os.path.join(root, file)
                        try:
                            os.remove(file_path)
                            pyc_count += 1
                            if verbose:
                                log_info(f"Eliminado archivo de caché: {file_path}")
                        except (IOError, PermissionError) as e:
                            if verbose:
                                log_warning(f"No se pudo eliminar {file_path}: {e}")
                
                # Buscar y eliminar directorios __pycache__
                if '__pycache__' in dirs:
                    pycache_dir = os.path.join(root, '__pycache__')
                    try:
                        # Eliminar todos los archivos dentro
                        for cache_file in os.listdir(pycache_dir):
                            try:
                                cache_path = os.path.join(pycache_dir, cache_file)
                                os.remove(cache_path)
                            except:
                                pass
                        
                        # Intentar eliminar el directorio
                        os.rmdir(pycache_dir)
                        pycache_count += 1
                        if verbose:
                            log_info(f"Eliminado directorio __pycache__: {pycache_dir}")
                    except (IOError, OSError) as e:
                        if verbose:
                            log_warning(f"No se pudo eliminar directorio __pycache__ {pycache_dir}: {e}")
                    
                    # Importante: evitar que os.walk entre en este directorio
                    dirs.remove('__pycache__')
            
            # Registrar resumen
            if pyc_count > 0 or pycache_count > 0:
                log_info(f"Limpieza de caché: {pyc_count} archivos .pyc y {pycache_count} directorios __pycache__ eliminados")
            else:
                log_info("No se encontraron archivos de caché para eliminar")
                
        except Exception as e:
            log_error(f"Error durante la limpieza de archivos de caché: {e}")


def create_application():
    """Crea y devuelve la instancia de la aplicación"""
    app = SoplosRepoSelector()
    
    # Limpiar archivos antiguos solo al inicio
    app.clean_stale_cache_files(verbose=False)
    
    return app

def main():
    """Punto de entrada para la aplicación"""
    app = create_application()
    return app.run(None)

if __name__ == '__main__':
    main()
