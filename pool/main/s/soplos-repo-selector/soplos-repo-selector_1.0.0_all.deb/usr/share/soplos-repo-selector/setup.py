#!/usr/bin/env python3
"""
Script de instalación para Soplos Repo Selector
"""
from setuptools import setup, find_packages
from pathlib import Path

# Leer README.md para la descripción larga
readme = Path(__file__).parent / "README.md"
long_description = readme.read_text() if readme.exists() else ""

# Dependencias
install_requires = [
    'PyGObject',    # Para interfaz GTK
]

# Dependencias opcionales
extras_require = {
    'full': [
        'python-debian',  # Para archivos .sources
    ]
}

setup(
    name="soplos-repo-selector",
    version="1.0.0",
    description="Gestor de repositorios APT para Debian/Soplos Linux",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Equipo Soplos",
    author_email="info@soplos.org",
    url="https://github.com/soplos/repo-selector",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=install_requires,
    extras_require=extras_require,
    entry_points={
        'console_scripts': [
            'soplos-repo-selector=src.gui.app:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: End Users/Desktop',
        'Topic :: System :: Systems Administration',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Operating System :: POSIX :: Linux',
        'Environment :: X11 Applications :: GTK',
    ],
    python_requires='>=3.7',
)
