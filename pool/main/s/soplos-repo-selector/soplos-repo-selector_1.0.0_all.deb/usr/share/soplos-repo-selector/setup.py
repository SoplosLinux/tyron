#!/usr/bin/env python3
"""
Script de instalación para Soplos Repo Selector
"""
from setuptools import setup, find_packages
import os
import shutil
from pathlib import Path

# Limpiar archivos __pycache__ antes de la instalación
def clean_pycache():
    """Elimina archivos __pycache__ y .pyc antes de la instalación"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    for root, dirs, files in os.walk(base_dir):
        if '__pycache__' in dirs:
            try:
                shutil.rmtree(os.path.join(root, '__pycache__'))
                print(f"Limpiando: {os.path.join(root, '__pycache__')}")
            except:
                pass
        
        for file in files:
            if file.endswith('.pyc'):
                try:
                    os.remove(os.path.join(root, file))
                    print(f"Eliminando: {os.path.join(root, file)}")
                except:
                    pass

# Limpiar antes de instalar
clean_pycache()

# Función para leer requisitos
def read_requirements():
    with open('requirements.txt', 'r') as req:
        return [line.strip() for line in req if line.strip() and not line.startswith('#')]

# Leer README.md para la descripción larga
readme = Path(__file__).parent / "README.md"
long_description = readme.read_text() if readme.exists() else ""

setup(
    name="soplos-repo-selector",
    version="1.0.0",
    description="Gestor gráfico de repositorios APT para sistemas basados en Debian",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Equipo Soplos Linux",
    author_email="soporte@soploslinux.com",
    url="https://soploslinux.com",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=read_requirements(),
    python_requires=">=3.9",
    entry_points={
        "console_scripts": [
            "soplos-repo-selector=src.gui.app:main",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: X11 Applications :: GTK",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: System :: Software Distribution",
    ],
    data_files=[
        ('share/applications', ['assets/com.soplos.reposelector.desktop']),
        ('share/icons/hicolor/256x256/apps', ['assets/icons/com.soplos.reposelector.png']),
        ('share/metainfo', ['debian/com.soplos.reposelector.metainfo.xml']),
    ],
)
