#!/usr/bin/env python3
"""
Punto de entrada principal para Soplos Repo Selector
"""

import sys
import os
import signal
import locale
import shutil

# Configurar el entorno antes de importar GTK
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['NO_AT_BRIDGE'] = '1'

# Añadir el directorio raíz al PYTHONPATH
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def setup_environment():
    """Configura el entorno de ejecución"""
    try:
        # Configurar locale
        locale.setlocale(locale.LC_ALL, '')
    except locale.Error:
        # Si falla, usar locale por defecto
        pass
    
    # Configurar codificación UTF-8
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8')
        

def handle_signal(signum, frame):
    """Maneja señales del sistema para cierre limpio"""
    print(f"\nRecibida señal {signum}, cerrando aplicación...")
    sys.exit(0)

def clean_all_pycache(base_dir):
    """Elimina todos los directorios __pycache__ y archivos .pyc"""
    for root, dirs, files in os.walk(base_dir, topdown=False):
        for file in files:
            if file.endswith('.pyc') or file.endswith('.pyo'):
                try:
                    if os.access(os.path.join(root, file), os.W_OK):
                        os.remove(os.path.join(root, file))
                        print(f"Eliminado: {os.path.join(root, file)}")
                except Exception:
                    pass
        
        # Eliminar directorios __pycache__ solo si tenemos permiso
        if '__pycache__' in dirs:
            pycache_path = os.path.join(root, '__pycache__')
            try:
                if os.access(pycache_path, os.W_OK):
                    shutil.rmtree(pycache_path)
                    print(f"Eliminado: {pycache_path}")
            except Exception:
                pass

def main():
    """Función principal que inicia la aplicación"""
    # Asegurarse de no crear archivos .pyc
    sys.dont_write_bytecode = True
    
    # Configurar el entorno
    setup_environment()
    
    # Registrar manejadores de señales
    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)
    
    # Limpiar archivos de caché
    app_dir = os.path.dirname(os.path.abspath(__file__))
    clean_all_pycache(app_dir)
    
    try:
        # Importar la aplicación principal
        from src.gui.app import create_application
        
        # Crear y ejecutar la aplicación
        app = create_application()
        return app.run(sys.argv)
    except ImportError as e:
        print(f"Error al importar módulos necesarios: {e}")
        return 1
    except Exception as e:
        print(f"Error al iniciar la aplicación: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
