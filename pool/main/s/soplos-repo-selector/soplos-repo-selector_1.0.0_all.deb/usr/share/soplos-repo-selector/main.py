#!/usr/bin/env python3
"""
Soplos Repo Selector - Gestor de repositorios APT para distribuciones Debian
"""

import os
import sys
import logging
import time
import argparse
import locale
from pathlib import Path

# Evitar la creación de archivos .pyc y directorios __pycache__
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

# Asegurar que el directorio raíz esté en el PYTHONPATH
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Inicializar locale para internacionalización
try:
    locale.setlocale(locale.LC_ALL, '')
except locale.Error:
    # Fallback si no se puede configurar el locale del sistema
    try:
        locale.setlocale(locale.LC_ALL, 'C.UTF-8')
    except locale.Error:
        locale.setlocale(locale.LC_ALL, 'C')

# Configurar logging antes que todo
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   stream=sys.stdout)
logger = logging.getLogger('soplos-repo-selector')

def parse_arguments():
    """Parsea argumentos de línea de comandos"""
    parser = argparse.ArgumentParser(description='Soplos Repo Selector - Gestor de repositorios APT')
    parser.add_argument('-d', '--debug', action='store_true', help='Activa el modo de depuración')
    parser.add_argument('-l', '--lang', help='Establece el idioma (ej: es, en, fr)')
    parser.add_argument('--clean-cache', action='store_true', help='Limpia archivos de caché antiguos')
    return parser.parse_args()

def run():
    """Función principal para iniciar la aplicación"""
    # Iniciar la aplicación directamente sin verificar dependencias
    return main()

def main():
    """Función principal de la aplicación"""
    # Configurar la ruta base para importaciones
    base_dir = os.path.dirname(os.path.abspath(__file__))
    if base_dir not in sys.path:
        sys.path.insert(0, base_dir)
    
    # Parsear argumentos
    args = parse_arguments()
    
    # Configurar nivel de logging para modo depuración
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Importaciones ahora que tenemos las rutas configuradas
    from src.gui.app import create_application
    from src.i18n.strings import set_language, enable_debug
    
    # Activar modo de depuración en i18n si es necesario
    if args.debug:
        enable_debug(True)
    
    # Si se especificó un idioma por línea de comandos
    if args.lang:
        logging.info(f"Forzando idioma: {args.lang}")
        set_language(args.lang)
    else:
        # Aseguramos que sea español en lugar de inglés
        set_language("es")
    
    # Crear y ejecutar la aplicación
    app = create_application()
    return app.run(sys.argv)

if __name__ == "__main__":
    sys.exit(run())
