"""
Módulo para gestión de traducciones
"""
import os
import locale
import importlib
import importlib.util
import logging
import sys
from typing import Dict

# Mapeo de idiomas disponibles para facilitar la internacionalización
LANGUAGE_NAMES = {
    "en": "English",          # Inglés
    "es": "Español",          # Español
    "de": "Deutsch",          # Alemán
    "fr": "Français",         # Francés
    "it": "Italiano",         # Italiano
    "pt": "Português",        # Portugués 
    "ru": "Русский",          # Ruso
    "ro": "Română"            # Rumano
}

# El idioma actual (se establece en set_language)
_current_lang = "es"  # Usar español por defecto

# El diccionario de strings del idioma actual
_current_strings = {}

# Variables de control y depuración
_debug_mode = True
_translation_override = None

def enable_debug(enable=True):
    """Activar/desactivar modo de depuración"""
    global _debug_mode
    _debug_mode = enable

def set_language(lang_code: str) -> bool:
    """
    Establece el idioma para la aplicación
    
    Args:
        lang_code: Código de idioma (e.g., 'es', 'en')
        
    Returns:
        True si el idioma se estableció correctamente
    """
    global _current_lang, _current_strings, _translation_override
    
    # Si se proporciona un código específico en los argumentos de línea de comando, usarlo
    if _translation_override is not None:
        lang_code = _translation_override
    
    # Si se pasa None o cadena vacía, detectar el idioma del sistema
    if not lang_code:
        lang_code = detect_system_language()
        if _debug_mode:
            print(f"DEBUG: Idioma detectado del sistema: {lang_code}")
    
    # Si no se pudo detectar el idioma, usar español como fallback
    if not lang_code:
        lang_code = "es"  # Por defecto SIEMPRE español
        if _debug_mode:
            print(f"DEBUG: No se pudo detectar el idioma, usando español por defecto")
    
    # Verificar si es un idioma soportado, sino usar español
    available_langs = get_available_languages()
    if lang_code not in available_langs and lang_code != "es":
        # Si no es un idioma soportado y no es español, usar español
        if _debug_mode:
            print(f"DEBUG: Idioma {lang_code} no soportado, usando español")
        lang_code = "es"
    
    # Intentar cargar el módulo de traducción específico
    try:
        # Ruta absoluta al archivo de traducción
        translations_dir = os.path.join(os.path.dirname(__file__), "translations")
        lang_file_path = os.path.join(translations_dir, f"{lang_code}.py")
        
        if _debug_mode:
            print(f"DEBUG: Buscando archivo de traducción: {lang_file_path}")
        
        if os.path.exists(lang_file_path):
            if _debug_mode:
                print(f"DEBUG: Archivo de traducción encontrado: {lang_file_path}")
            
            # Construir el nombre del módulo para importación
            module_name = f"src.i18n.translations.{lang_code}"
            
            try:
                # Importar desde el path
                spec = importlib.util.spec_from_file_location(module_name, lang_file_path)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = module
                    spec.loader.exec_module(module)
                    if _debug_mode:
                        print(f"DEBUG: Módulo cargado correctamente desde: {lang_file_path}")
                else:
                    raise ImportError(f"No se pudo crear spec para el módulo {module_name}")
            except Exception as e:
                print(f"ERROR: Error al importar módulo {module_name}: {e}")
                # Si fallamos con un idioma específico que no es español, intentar inglés
                if lang_code != "es":
                    print("ERROR: Fallando a español")
                    return set_language("es")
                # Si fallamos con español, intentar inglés
                elif lang_code != "en":
                    print("ERROR: Fallando a inglés")
                    return set_language("en")
                else:
                    # Si ni español ni inglés funcionan, usar diccionario vacío
                    _current_strings = {}
                    return False
            
            # Buscar diccionarios por nombres comunes
            dict_names = {
                "es": ["SPANISH", "Spanish", "spanish", "ES", "Es"],
                "en": ["ENGLISH", "English", "english", "EN", "En"],
                "de": ["GERMAN", "German", "german", "DE", "De"],
                "fr": ["FRENCH", "French", "french", "FR", "Fr"],
                "it": ["ITALIAN", "Italian", "italian", "IT", "It"],
                "pt": ["PORTUGUESE", "Portuguese", "portuguese", "PT", "Pt"],
                "ru": ["RUSSIAN", "Russian", "russian", "RU", "Ru"],
                "ro": ["ROMANIAN", "Romanian", "romanian", "RO", "Ro"]
            }
            
            found_dict = None
            
            # Buscar diccionario específico para este idioma
            specific_names = dict_names.get(lang_code, [lang_code.upper(), lang_code.capitalize(), lang_code])
            for dict_name in specific_names:
                if hasattr(module, dict_name):
                    found_dict = getattr(module, dict_name)
                    if _debug_mode:
                        print(f"DEBUG: Encontrado diccionario {dict_name} en {lang_file_path}")
                    break
            
            # Si no encontramos el diccionario específico, buscar uno genérico
            if found_dict is None:
                generic_names = ["strings", "translations", "TRANSLATIONS", "Translations", "STRINGS", "Strings"]
                for dict_name in generic_names:
                    if hasattr(module, dict_name):
                        found_dict = getattr(module, dict_name)
                        if _debug_mode:
                            print(f"DEBUG: Encontrado diccionario genérico {dict_name} en {lang_file_path}")
                        break
            
            # Si encontramos algún diccionario, usarlo
            if found_dict is not None:
                _current_strings = found_dict
                _current_lang = lang_code
                logging.info(f"Idioma establecido: {lang_code} con {len(_current_strings)} traducciones")
                return True
            else:
                print(f"ERROR: No se encontró diccionario de strings para {lang_code}")
                
                # Si fallamos con un idioma que no es español, intentar español
                if lang_code != "es":
                    return set_language("es")
                # Si fallamos con español, intentar inglés
                elif lang_code != "en":
                    return set_language("en")
                else:
                    # Si ni español ni inglés funcionan, usar diccionario vacío
                    _current_strings = {}
                    return False
                    
        else:
            if _debug_mode:
                print(f"ERROR: No se encontró archivo de traducción: {lang_file_path}")
            
            # Si el archivo no existe y no es español, intentar español
            if lang_code != "es":
                return set_language("es")
            # Si fallamos con español, intentar inglés
            elif lang_code != "en":
                return set_language("en")
            else:
                # Si ni español ni inglés funcionan, usar diccionario vacío
                _current_strings = {}
                return False
                
    except Exception as e:
        print(f"ERROR: Error general al cargar el idioma {lang_code}: {e}")
        # En caso de error con el idioma específico, intentar con español
        if lang_code != "es":
            return set_language("es")
        # En caso de error con español, intentar con inglés
        elif lang_code != "en":
            return set_language("en")
        else:
            # Si ni español ni inglés funcionan, usar diccionario vacío
            _current_strings = {}
            return False

def get_string(key: str, default: str = None) -> str:
    """
    Obtiene una cadena traducida según el idioma actual
    
    Args:
        key: Clave de la cadena a buscar
        default: Valor predeterminado si no se encuentra la cadena
        
    Returns:
        La cadena traducida o el valor predeterminado
    """
    # Si no hay strings cargados o la clave no existe, devolver el default
    if not _current_strings or key not in _current_strings:
        return default if default is not None else key
    
    return _current_strings[key]

def get_available_languages() -> Dict[str, str]:
    """
    Obtiene un diccionario con los idiomas disponibles
    
    Returns:
        Diccionario con los códigos de idioma como claves y los nombres como valores
    """
    # Utilizar el mapeo de idiomas predefinido para nombres consistentes
    available_langs = {}
    
    # Buscar archivos de traducción en el directorio
    translations_dir = os.path.join(os.path.dirname(__file__), "translations")
    if os.path.exists(translations_dir):
        for filename in os.listdir(translations_dir):
            if filename.endswith(".py") and not filename.startswith("__"):
                lang_code = os.path.splitext(filename)[0]
                # Usar el nombre predefinido si existe, o generar uno a partir del código
                if lang_code in LANGUAGE_NAMES:
                    available_langs[lang_code] = LANGUAGE_NAMES[lang_code]
                else:
                    # Generar un nombre basado en el código (capitalizado)
                    available_langs[lang_code] = lang_code.capitalize()
    
    # Asegurarse de que al menos español esté disponible
    if "es" not in available_langs:
        available_langs["es"] = LANGUAGE_NAMES["es"]
    
    # Asegurarse de que al menos inglés esté disponible
    if "en" not in available_langs:
        available_langs["en"] = LANGUAGE_NAMES["en"]
    
    return available_langs

def get_current_language() -> str:
    """
    Obtiene el código del idioma actual
    
    Returns:
        Código del idioma actual (e.g., 'es', 'en')
    """
    return _current_lang

def detect_system_language() -> str:
    """
    Detecta el idioma del sistema de manera más robusta
    
    Returns:
        Código del idioma detectado o 'es' como fallback
    """
    if _debug_mode:
        print("DEBUG: Intentando detectar el idioma del sistema...")
    
    try:
        # Verificar variables de entorno en orden de prioridad
        lang = None
        
        # LANGUAGE contiene códigos con prioridades (es:en:fr)
        if 'LANGUAGE' in os.environ:
            langs = os.environ['LANGUAGE'].split(':')
            if langs and langs[0]:
                parts = langs[0].split('_')[0].split('.')[0].lower()
                if parts:
                    lang = parts
                    if _debug_mode:
                        print(f"DEBUG: Idioma detectado desde LANGUAGE: {lang}")
                    
        # LC_ALL tiene prioridad sobre LANG
        if not lang and 'LC_ALL' in os.environ:
            lc_all = os.environ['LC_ALL']
            if lc_all:
                parts = lc_all.split('_')[0].split('.')[0].lower()
                if parts:
                    lang = parts
                    if _debug_mode:
                        print(f"DEBUG: Idioma detectado desde LC_ALL: {lang}")
        
        # LC_MESSAGES específico para mensajes y UI
        if not lang and 'LC_MESSAGES' in os.environ:
            lc_msg = os.environ['LC_MESSAGES']
            if lc_msg:
                parts = lc_msg.split('_')[0].split('.')[0].lower()
                if parts:
                    lang = parts
                    if _debug_mode:
                        print(f"DEBUG: Idioma detectado desde LC_MESSAGES: {lang}")
        
        # LANG como última opción de variables de entorno
        if not lang and 'LANG' in os.environ:
            lng = os.environ['LANG']
            if lng:
                parts = lng.split('_')[0].split('.')[0].lower()
                if parts:
                    lang = parts
                    if _debug_mode:
                        print(f"DEBUG: Idioma detectado desde LANG: {lang}")
        
        # Si no encontramos nada en variables, intentar con locale
        if not lang:
            try:
                # getdefaultlocale() está obsoleta pero puede funcionar en algunos sistemas
                system_locale = locale.getdefaultlocale()[0]
                if system_locale:
                    lang = system_locale.split('_')[0].lower()
                    if _debug_mode:
                        print(f"DEBUG: Idioma detectado desde getdefaultlocale: {lang}")
            except:
                pass
        
        # Si aún no tenemos idioma, intentar con getlocale()
        if not lang:
            try:
                system_locale, encoding = locale.getlocale()
                if system_locale:
                    lang = system_locale.split('_')[0].lower()
                    if _debug_mode:
                        print(f"DEBUG: Idioma detectado desde getlocale: {lang}")
            except:
                pass
        
        # Si encontramos un idioma y está en nuestros idiomas disponibles, usarlo
        available_langs = get_available_languages()
        if lang and lang in available_langs:
            if _debug_mode:
                print(f"DEBUG: Idioma del sistema es: {lang}")
            return lang
            
        # Si el idioma encontrado es español pero no está en la lista (por alguna razón)
        if lang and lang == 'es':
            if _debug_mode:
                print(f"DEBUG: Idioma es español pero no está en la lista, agregándolo")
            return 'es'
            
    except Exception as e:
        if _debug_mode:
            print(f"DEBUG: Error al detectar idioma: {e}")
    
    # Si no se detectó ningún idioma o hubo algún error, usar español
    if _debug_mode:
        print(f"DEBUG: No se detectó un idioma válido, usando español por defecto")
    return 'es'

# Parsear argumentos de línea de comando para soportar forzar idioma
def check_language_override():
    """Verifica si hay una anulación de idioma en los argumentos de línea de comando"""
    global _translation_override
    
    import sys
    for i, arg in enumerate(sys.argv):
        if arg in ['-l', '--lang', '--language'] and i + 1 < len(sys.argv):
            _translation_override = sys.argv[i + 1]
            if _debug_mode:
                print(f"DEBUG: Idioma anulado por argumento de línea de comando: {_translation_override}")
            break
        elif arg.startswith('--lang=') or arg.startswith('--language='):
            _translation_override = arg.split('=', 1)[1]
            if _debug_mode:
                print(f"DEBUG: Idioma anulado por argumento de línea de comando: {_translation_override}")
            break

# Revisar argumentos de línea de comando
check_language_override()

# Inicializar con el idioma detectado (o español por defecto)
set_language(detect_system_language())
