"""
Módulo para gestión de traducciones
"""
import os
import sys
import locale
import importlib.util
from typing import Dict

# Diccionario de idiomas soportados
_LANGUAGES = {
    "es": "Español",
    "en": "English",
    "fr": "Français",
    "pt": "Português",
    "de": "Deutsch",
    "it": "Italiano",
    "ru": "Русский",
    "ro": "Română"
}

# El idioma actual (se establece en set_language)
_current_lang = "es"  # Usar español por defecto

# El diccionario de strings del idioma actual
_current_strings = {}

# Variables de control y depuración
_debug_mode = True
_translation_override = None

def enable_debug(enable=True):
    """Activa o desactiva el modo de depuración"""
    global _debug_mode
    _debug_mode = enable

def set_language(lang_code: str) -> bool:
    """
    Establece el idioma activo y carga las traducciones
    
    Args:
        lang_code: Código de idioma (ej: 'es', 'en', 'fr')
        
    Returns:
        True si se cargó correctamente, False en caso contrario
    """
    global _current_lang, _current_strings
    
    # Determinar el directorio de traducciones
    current_dir = os.path.dirname(os.path.abspath(__file__))
    translations_dir = os.path.join(current_dir, 'translations')
    
    # Construir el path del archivo de traducción
    translation_file = os.path.join(translations_dir, f'{lang_code}.py')
    
    # Verificar que el archivo existe
    if not os.path.exists(translation_file):
        if _debug_mode:
            print(f"DEBUG: Archivo de traducción no encontrado: {translation_file}")
        return False
    
    try:
        # Eliminar o comentar prints de debug relacionados con la carga de traducciones
        # print(f"DEBUG: Archivo de traducción encontrado: {translation_file}")
        
        # Cargar el módulo de traducción dinámicamente
        spec = importlib.util.spec_from_file_location(f"translation_{lang_code}", translation_file)
        if spec is None or spec.loader is None:
            if _debug_mode:
                print(f"DEBUG: No se pudo crear spec para {translation_file}")
            return False
            
        translation_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(translation_module)
        
        # print(f"DEBUG: Módulo cargado correctamente desde: {translation_file}")
        
        # Buscar el diccionario de traducciones en el módulo
        # Los diccionarios están nombrados como SPANISH, ENGLISH, etc.
        lang_dict_names = {
            'es': 'SPANISH',
            'en': 'ENGLISH', 
            'de': 'GERMAN',
            'fr': 'FRENCH',
            'it': 'ITALIAN',
            'pt': 'PORTUGUESE',
            'ru': 'RUSSIAN',
            'ro': 'ROMANIAN'
        }
        
        dict_name = lang_dict_names.get(lang_code)
        if dict_name and hasattr(translation_module, dict_name):
            _current_strings = getattr(translation_module, dict_name)
            _current_lang = lang_code

            # Eliminar cualquier print DEBUG aquí
            # if _debug_mode:
            #     print(f"DEBUG: Encontrado diccionario {dict_name} en {translation_file}")

            return True
        else:
            if _debug_mode:
                print(f"DEBUG: No se encontró diccionario {dict_name} en {translation_file}")
                print(f"DEBUG: Atributos disponibles: {dir(translation_module)}")
            return False
    except Exception as e:
        if _debug_mode:
            print(f"DEBUG: Error cargando traducción para {lang_code}: {e}")
        return False

def get_string(key: str, default: str = None) -> str:
    """
    Obtiene una cadena traducida
    
    Args:
        key: Clave de la cadena a traducir
        default: Valor por defecto si no se encuentra la traducción
        
    Returns:
        Cadena traducida o valor por defecto
    """
    global _current_strings
    
    # Si hay override, usarlo
    if _translation_override and key in _translation_override:
        return _translation_override[key]
    
    # Buscar en las traducciones cargadas
    if key in _current_strings:
        return _current_strings[key]
    
    # Si no se encuentra, devolver default o la clave
    if default is not None:
        return default
    
    # Como último recurso, devolver la clave formateada
    return key.replace('_', ' ').title()

def get_available_languages() -> Dict[str, str]:
    """
    Obtiene la lista de idiomas disponibles
    
    Returns:
        Diccionario con código de idioma -> nombre del idioma
    """
    return _LANGUAGES.copy()

def get_current_language() -> str:
    """
    Obtiene el código del idioma actual
    
    Returns:
        Código de idioma actual
    """
    return _current_lang

def detect_system_language() -> str:
    """
    Detecta el idioma del sistema
    
    Returns:
        Código de idioma detectado o 'es' por defecto
    """
    try:
        # Intentar obtener desde variables de entorno
        for env_var in ['LANG', 'LANGUAGE', 'LC_ALL', 'LC_MESSAGES']:
            lang_val = os.environ.get(env_var)
            if lang_val:
                # Extraer código de idioma (primeros 2 caracteres)
                lang_code = lang_val[:2].lower()
                if lang_code in _LANGUAGES:
                    return lang_code
        
        # Intentar usando locale
        try:
            system_locale = locale.getdefaultlocale()[0]
            if system_locale:
                lang_code = system_locale[:2].lower()
                if lang_code in _LANGUAGES:
                    return lang_code
        except:
            pass
        
        # Por defecto, español
        return 'es'
        
    except Exception:
        return 'es'

# Parsear argumentos de línea de comando para soportar forzar idioma
def check_language_override():
    """Verifica si hay override de idioma en argumentos de línea de comandos"""
    global _translation_override
    
    for arg in sys.argv:
        if arg.startswith('--lang='):
            lang_code = arg.split('=')[1]
            if lang_code in _LANGUAGES:
                set_language(lang_code)
                break

# Revisar argumentos de línea de comando
check_language_override()

# Inicializar con el idioma detectado (o español por defecto)
set_language(detect_system_language())

def check_missing_translation_keys():
    """
    Verifica claves faltantes en los archivos de traducción respecto al español.
    Imprime las claves que faltan en cada idioma.
    """
    import os

    base_dir = os.path.dirname(os.path.abspath(__file__))
    translations_dir = os.path.join(base_dir, 'translations')
    base_lang = 'es'
    base_file = os.path.join(translations_dir, f'{base_lang}.py')

    # Cargar el diccionario base (español)
    import importlib.util
    spec = importlib.util.spec_from_file_location("base_translation", base_file)
    base_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base_module)
    base_dict = getattr(base_module, 'SPANISH')

    # Recorrer otros idiomas
    for fname in os.listdir(translations_dir):
        if not fname.endswith('.py') or fname == f'{base_lang}.py' or fname == '__init__.py':
            continue
        lang_code = fname[:-3]
        spec = importlib.util.spec_from_file_location(f"translation_{lang_code}", os.path.join(translations_dir, fname))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        # Buscar el nombre del diccionario
        dict_name = None
        for k in mod.__dict__:
            if k.isupper() and isinstance(mod.__dict__[k], dict):
                dict_name = k
                break
        if not dict_name:
            print(f"[{lang_code}] No se encontró diccionario de traducción.")
            continue
        lang_dict = getattr(mod, dict_name)
        missing = [k for k in base_dict if k not in lang_dict]
        extra = [k for k in lang_dict if k not in base_dict]
        if missing:
            print(f"[{lang_code}] Faltan {len(missing)} claves: {missing}")
        if extra:
            print(f"[{lang_code}] Claves extra no usadas: {extra}")
        if not missing and not extra:
            print(f"[{lang_code}] OK - Todas las claves coinciden.")
