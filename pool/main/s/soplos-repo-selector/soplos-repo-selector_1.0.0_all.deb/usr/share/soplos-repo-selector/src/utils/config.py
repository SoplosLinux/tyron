"""
Gestión de configuración para Soplos Repo Selector
"""
import os
import configparser
from pathlib import Path

class Config:
    """Gestiona la configuración de la aplicación"""
    
    def __init__(self):
        """Inicializa la configuración con valores predeterminados"""
        # Directorios de la aplicación
        self.home_dir = Path.home()
        self.config_dir = self.home_dir / ".config" / "soplos-repo-selector"
        self.cache_dir = self.home_dir / ".cache" / "soplos-repo-selector"
        self.data_dir = self.home_dir / ".local" / "share" / "soplos-repo-selector"
        
        # Asegurarse de que los directorios existan
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Archivo de configuración
        self.config_file = self.config_dir / "config.ini"
        self.config = configparser.ConfigParser()
        
        # Cargar configuración existente si existe
        if self.config_file.exists():
            self.config.read(self.config_file)
    
    def get(self, section, key, default=None):
        """Obtiene un valor de configuración"""
        if section not in self.config:
            return default
        
        if key not in self.config[section]:
            return default
            
        # Determinar el tipo basado en el valor predeterminado
        if isinstance(default, bool):
            return self.config[section].getboolean(key, default)
        elif isinstance(default, int):
            return self.config[section].getint(key, default)
        elif isinstance(default, float):
            return self.config[section].getfloat(key, default)
        else:
            return self.config[section].get(key, default)
    
    def set(self, section, key, value):
        """Establece un valor de configuración"""
        if section not in self.config:
            self.config[section] = {}
        
        self.config[section][key] = str(value)
        
        # Guardar inmediatamente los cambios
        with open(self.config_file, 'w') as f:
            self.config.write(f)
    
    def save(self):
        """Guarda la configuración en el archivo"""
        with open(self.config_file, 'w') as f:
            self.config.write(f)
        
    @property
    def use_modern_format(self) -> bool:
        """Si usar formato DEB822 moderno"""
        return self.get('repositories', 'use_modern_format', True)
    
    @use_modern_format.setter
    def use_modern_format(self, value: bool):
        self.set('repositories', 'use_modern_format', value)
    
    @property
    def debug_mode(self) -> bool:
        """Si el modo de depuración está activo"""
        return self.get('advanced', 'debug_mode', False)
    
    @debug_mode.setter
    def debug_mode(self, value: bool):
        self.set('advanced', 'debug_mode', value)
    
    # Rutas de archivos
    def get_cache_file(self, filename: str) -> Path:
        """Obtiene ruta de archivo de caché"""
        return self.cache_dir / filename
    
    def get_data_file(self, filename: str) -> Path:
        """Obtiene ruta de archivo de datos"""
        return self.data_dir / filename
