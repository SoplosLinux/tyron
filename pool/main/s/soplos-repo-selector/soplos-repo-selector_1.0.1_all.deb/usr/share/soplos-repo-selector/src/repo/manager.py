from pathlib import Path
import subprocess
from typing import List, Dict, Optional, Any, Tuple
from urllib.parse import urlparse
import os
from src.repo.gpg_manager import GPGManager

from src.utils.error_handler import ErrorHandler, log_error, log_warning
from src.repo.system_executor import SystemCommandExecutor
from src.repo.repo_file_manager import RepoFileManager

# Importar deb822 con manejo de errores avanzado
try:
    from debian import deb822
    HAVE_DEBIAN_MODULE = True
except ImportError:
    HAVE_DEBIAN_MODULE = False
    # Proporcionar una implementación mínima para permitir funcionamiento básico
    class MinimalDeb822:
        class Deb822:
            def __init__(self, *args, **kwargs):
                self.data = {}
            
            def __getitem__(self, key):
                return self.data.get(key, '')
            
            def __setitem__(self, key, value):
                self.data[key] = value
    
    # Usar la implementación mínima
    deb822 = MinimalDeb822()
    
    log_warning("El módulo 'python-debian' no está instalado.")
    log_warning("La funcionalidad para leer/escribir archivos .sources estará limitada.")
    log_warning("Instale el paquete con: sudo apt-get install python3-debian")

class RepoManager:
    """Gestor de repositorios APT de Debian"""
    
    def __init__(self):
        # Inicializar componentes especializados
        self.file_manager = RepoFileManager()
        self.system_executor = SystemCommandExecutor()
        
        # Inicializar el gestor de claves GPG moderno
        self.gpg_manager = GPGManager()
        
        # Cachear la lista de repos para evitar múltiples lecturas
        self._cached_repos = None
        
        # Verificar si tenemos soporte completo para archivos .sources
        self.has_deb822_support = HAVE_DEBIAN_MODULE
        
        # Comprobar si hay sources.list activo
        self.has_main_sources = self.file_manager.has_main_sources
        
        # Determinar si debemos utilizar formato moderno (DEB822)
        self.use_modern_format = self.has_deb822_support and self.file_manager.prefer_deb822
    
    def get_available_gpg_keys(self):
        """Devuelve las claves GPG disponibles"""
        return self.gpg_manager.get_available_keys()
    
    def get_key_path_for_repo(self, repo_uri):
        """Obtiene la ruta de la clave GPG para un repositorio dado"""
        return self.gpg_manager.get_key_path_for_repo(repo_uri)
    
    def run_as_root(self, command, shell=False, validate_paths=True):
        """Ejecuta un comando como root de manera segura"""
        return self.system_executor.run_as_root(command, shell, validate_paths)
    
    def get_all_repos(self, use_cache=True):
        """Obtiene todos los repositorios del sistema"""
        if self._cached_repos is not None and use_cache:
            return self._cached_repos
        
        repos = self.file_manager.parse_all_sources_files()
        
        # Cachear resultado para futuras llamadas
        self._cached_repos = repos
        return repos
    
    def save_repos(self, repos):
        """Guarda los cambios en los repositorios"""
        # Filtrar para eliminar los repositorios desactivados que el usuario quiere eliminar
        repos_to_save = []
        main_sources_repos = []
        
        for repo in repos:
            # Si el repositorio viene del archivo sources.list principal y éste existe, tratarlo separadamente
            if repo.get('file') == self.file_manager.main_sources and self.has_main_sources:
                main_sources_repos.append(repo)
            else:
                # Si viene de otro archivo o no existe sources.list, incluir en repos normales
                repos_to_save.append(repo)
        
        # Agrupar los repositorios por archivo
        repos_by_file = {}
        for repo in repos_to_save:
            # Determinar el formato apropiado para nuevos repositorios
            file_path = repo.get('file')
            
            # Si no está definido archivo o si preferimos usar formato moderno, reasignar a .sources
            if not file_path or (self.use_modern_format and not file_path.endswith('.sources')):
                # Nombres de archivos basados en el tipo de repo
                if "security.debian.org" in repo['uri']:
                    file_path = f"{self.file_manager.sources_dir}/debian-security.sources"
                elif "debian.org" in repo['uri']:
                    if "backports" in repo['distribution']:
                        file_path = f"{self.file_manager.sources_dir}/debian-backports.sources"
                    else:
                        file_path = f"{self.file_manager.sources_dir}/debian.sources"
                else:
                    # Para otros repositorios, usar el nombre basado en el hostname
                    hostname = repo['uri'].split('//')[-1].split('/')[0].replace(".", "-")
                    file_path = f"{self.file_manager.sources_dir}/{hostname}.sources"
            
            # Guardar el repositorio en su grupo de archivo
            if file_path not in repos_by_file:
                repos_by_file[file_path] = []
            repos_by_file[file_path].append(repo)
        
        # Actualizar cada archivo
        for file_path, file_repos in repos_by_file.items():
            if file_path.endswith('.sources'):
                self.file_manager.update_deb822_sources(file_path, file_repos)
            else:
                self.file_manager.update_legacy_sources(file_path, file_repos)
        
        # Manejar especialmente los repositorios del sources.list principal
        if self.has_main_sources and main_sources_repos:
            self.file_manager.update_main_sources(main_sources_repos)
        elif not self.has_main_sources and main_sources_repos:
            # Si no existe el sources.list pero hay repos para él, redirigirlos a debian.sources
            debian_sources = f"{self.file_manager.sources_dir}/debian.sources"
            debian_sources_list = repos_by_file.get(debian_sources, [])
            debian_sources_list.extend(main_sources_repos)
            self.file_manager.update_deb822_sources(debian_sources, debian_sources_list)
        
        # Invalidar caché
        self._cached_repos = None
    
    def import_gpg_key(self, key_path, key_name=None):
        """Importa una clave GPG al sistema"""
        return self.gpg_manager.import_key(key_path, key_name)
    
    def add_repo_key(self, key_url, key_name=None):
        """
        Añade una clave GPG para un repositorio
        
        Args:
            key_url: URL o archivo de la clave
            key_name: Nombre para la clave (opcional)
            
        Returns:
            tuple: (éxito, mensaje)
        """
        # Determinar si es una URL o un archivo local
        if key_url.startswith(('http://', 'https://')):
            return self.gpg_manager.download_key(key_url, key_name)
        elif os.path.exists(key_url):
            return self.gpg_manager.import_key_from_file(key_url, key_name)
        else:
            return False, f"URL o archivo no válido: {key_url}"
    
    def update_repos(self):
        """Actualiza los índices de los repositorios (apt update)"""
        return self.system_executor.run_apt_update()
