# Este archivo ha sido eliminado. Toda la lógica de claves GPG está en src/repo/gpg_manager.py.
