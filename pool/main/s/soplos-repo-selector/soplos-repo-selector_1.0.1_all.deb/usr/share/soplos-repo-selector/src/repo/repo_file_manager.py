import os
from pathlib import Path
from typing import List, Dict, Any, Optional
import shutil
import time

from src.utils.error_handler import ErrorHandler, log_error, log_warning

# Importar deb822 si está disponible
try:
    from debian import deb822
    HAVE_DEBIAN_MODULE = True
except ImportError:
    HAVE_DEBIAN_MODULE = False

class RepoFileManager:
    """Gestiona los archivos de repositorios APT"""
    
    def __init__(self):
        # Ubicación de los archivos de repositorios
        self.sources_dir = '/etc/apt/sources.list.d'
        self.main_sources = '/etc/apt/sources.list'
        
        # Lista de directorios y archivos seguros para modificar
        self.safe_paths = [
            '/etc/apt/sources.list',
            '/etc/apt/sources.list.d'
        ]
        
        # Verificar si sources.list existe o es solo una copia de seguridad
        self.has_main_sources = os.path.isfile(self.main_sources) and not self.main_sources.endswith(('~', '.bak'))
        
        # Flag para indicar si debemos usar preferentemente formato DEB822
        self.prefer_deb822 = True
    
    def is_safe_path(self, path):
        """Verifica si una ruta es segura para modificar"""
        path = str(path)
        for safe_path in self.safe_paths:
            # Comprobar si es exactamente la ruta o está dentro de un directorio seguro
            if path == safe_path or path.startswith(safe_path + '/'):
                return True
        return False
    
    def parse_all_sources_files(self) -> List[Dict[str, Any]]:
        """Parsea todos los archivos de repositorios encontrados en el sistema"""
        repos = []
        
        # Primero, procesar el archivo sources.list principal si existe
        if self.has_main_sources and os.path.exists(self.main_sources):
            try:
                repos.extend(self.parse_legacy_sources(self.main_sources))
            except Exception as e:
                log_error(f"Error al analizar {self.main_sources}", e)
        
        # Luego, procesar todos los archivos en sources.list.d
        if os.path.exists(self.sources_dir):
            for file_name in os.listdir(self.sources_dir):
                file_path = os.path.join(self.sources_dir, file_name)
                if not os.path.isfile(file_path) or file_name.endswith(('.bak', '~')):
                    continue
                
                try:
                    if file_name.endswith('.sources'):
                        if HAVE_DEBIAN_MODULE:
                            repos.extend(self.parse_deb822_sources(file_path))
                    else:
                        repos.extend(self.parse_legacy_sources(file_path))
                except Exception as e:
                    log_error(f"Error al analizar {file_path}", e)
        
        return repos
    
    def parse_legacy_sources(self, file_path: str) -> List[Dict[str, Any]]:
        """Parsea un archivo de repositorios en formato legacy (sources.list)"""
        repos = []
        current_comment = ''
        
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    
                    # Manejar líneas vacías
                    if not line:
                        continue
                    
                    # Manejar comentarios
                    if line.startswith('#'):
                        current_comment = line
                        continue
                    
                    # Ignorar otras líneas que no parecen definiciones de repo
                    parts = line.split()
                    if len(parts) < 4:
                        continue
                    
                    # Verificar si el repo está deshabilitado (comienza con #)
                    disabled = False
                    if line.lstrip().startswith('#'):
                        disabled = True
                        # Quitar el # inicial para procesar el resto de la línea
                        parts = line.lstrip()[1:].strip().split()
                    
                    # Obtener tipo, URI, distribución y componentes
                    repo_type = parts[0]  # deb o deb-src
                    uri = parts[1]
                    distribution = parts[2]
                    components = ' '.join(parts[3:])
                    
                    repo = {
                        'disabled': disabled,
                        'type': repo_type,
                        'uri': uri,
                        'distribution': distribution,
                        'components': components,
                        'comment': current_comment,
                        'file': file_path,
                        'format': 'legacy'
                    }
                    
                    repos.append(repo)
                    current_comment = ''  # Resetear el comentario para la siguiente entrada
        except Exception as e:
            log_error(f"Error al parsear archivo legacy {file_path}", e)
        
        return repos
    
    def parse_deb822_sources(self, file_path: str) -> List[Dict[str, Any]]:
        """Parsea un archivo de repositorios en formato deb822 (.sources)"""
        if not HAVE_DEBIAN_MODULE:
            log_warning(f"No se puede parsear {file_path} - módulo debian no disponible")
            return []
        
        repos = []
        
        try:
            with open(file_path, 'r') as f:
                for paragraph in deb822.Deb822.iter_paragraphs(f):
                    # Los archivos .sources tienen un formato diferente
                    repo_types = paragraph.get('Types', 'deb').split()
                    uri = paragraph.get('URIs', paragraph.get('URI', ''))
                    suites = paragraph.get('Suites', paragraph.get('Suite', ''))
                    components = paragraph.get('Components', '')
                    comment = paragraph.get('X-Comment', '')
                    
                    # Procesar cada tipo (deb, deb-src)
                    for repo_type in repo_types:
                        # Procesar cada suite/distribución
                        for distribution in suites.split():
                            repo = {
                                'disabled': 'Enabled' in paragraph and paragraph['Enabled'] == 'no',
                                'type': repo_type,
                                'uri': uri,
                                'distribution': distribution,
                                'components': components,
                                'comment': comment,
                                'file': file_path,
                                'format': 'deb822'
                            }
                            repos.append(repo)
        except Exception as e:
            log_error(f"Error al parsear archivo deb822 {file_path}", e)
        
        return repos
    
    def update_main_sources(self, repos):
        """Actualiza el archivo sources.list principal, respetando las eliminaciones"""
        # Si no existe el archivo main_sources, usar un archivo .sources en su lugar
        if not self.has_main_sources:
            # Redirigir a archivo .sources en sources.list.d
            debian_sources_path = os.path.join(self.sources_dir, "debian.sources")
            if repos:
                self.update_deb822_sources(debian_sources_path, repos)
            return
            
        # Solo actualizar main_sources si realmente existe
        if not repos:
            # Si no hay repositorios para guardar, reemplazar con un comentario
            temp_file = f"{self.main_sources}.new"
            try:
                with open(temp_file, 'w') as f:
                    f.write("# Este archivo fue editado por Soplos Repo Selector\n")
                    f.write("# Se han eliminado todos los repositorios\n")
                    
                # Mover el archivo temporal al lugar correcto con permisos elevados
                from src.repo.system_executor import SystemCommandExecutor
                executor = SystemCommandExecutor()
                executor.run_as_root(['mv', temp_file, self.main_sources])
                executor.run_as_root(['chmod', '644', self.main_sources])
            except Exception as e:
                # Limpiar archivo temporal si hay error
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
                log_error(f"Error al actualizar sources.list: {e}", e)
                raise
            return
            
        # Actualizar normalmente si hay repositorios
        self.update_legacy_sources(self.main_sources, repos)

    def update_legacy_sources(self, file_path: str, repos: List[Dict[str, Any]]):
        """Actualiza un archivo de repositorios en formato legacy"""
        if not self.is_safe_path(file_path):
            raise ValueError(f"Ruta no segura: {file_path}")
        
        # Si no hay repos para guardar y no es el sources.list principal, no crear el archivo
        if not repos and file_path != self.main_sources:
            # Si existe el archivo, eliminarlo
            if os.path.exists(file_path):
                from src.repo.system_executor import SystemCommandExecutor
                executor = SystemCommandExecutor()
                try:
                    executor.run_as_root(['rm', file_path])
                    return
                except Exception as e:
                    log_error(f"Error al eliminar archivo vacío {file_path}: {e}", e)
        
        # Crear directorio si no existe
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Crear archivo temporal
        temp_file = f"{file_path}.new"
        
        try:
            with open(temp_file, 'w') as f:
                # Añadir encabezado
                f.write("# Este archivo fue generado por Soplos Repo Selector\n")
                f.write(f"# Última actualización: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                for repo in repos:
                    # Sólo escribir repositorios no desactivados
                    if not repo.get('disabled', False):
                        # Escribir comentario si existe
                        if repo.get('comment'):
                            f.write(f"{repo['comment']}\n")
                        
                        # Construir línea del repositorio
                        line = f"{repo['type']} {repo['uri']} {repo['distribution']} {repo['components']}"
                        f.write(f"{line}\n")
                        
                        # Añadir una línea vacía para separar entradas
                        f.write("\n")
            
            # Mover el archivo temporal al lugar correcto con permisos elevados
            from src.repo.system_executor import SystemCommandExecutor
            executor = SystemCommandExecutor()
            executor.run_as_root(['mv', temp_file, file_path])
            executor.run_as_root(['chmod', '644', file_path])
            
        except Exception as e:
            # Limpiar archivo temporal si hay error
            if os.path.exists(temp_file):
                os.unlink(temp_file)
            log_error(f"Error al actualizar archivo legacy {file_path}", e)
            raise

    def update_deb822_sources(self, file_path: str, repos: List[Dict[str, Any]]):
        """Actualiza un archivo de repositorios en formato deb822"""
        if not self.is_safe_path(file_path):
            raise ValueError(f"Ruta no segura: {file_path}")
        
        # Si no hay repos para guardar, no crear el archivo
        if not repos:
            # Si existe el archivo, eliminarlo
            if os.path.exists(file_path):
                from src.repo.system_executor import SystemCommandExecutor
                executor = SystemCommandExecutor()
                try:
                    executor.run_as_root(['rm', file_path])
                    return
                except Exception as e:
                    log_error(f"Error al eliminar archivo vacío {file_path}: {e}", e)
            return
        
        if not HAVE_DEBIAN_MODULE:
            log_warning(f"No se puede actualizar {file_path} - módulo debian no disponible")
            return
        
        # Crear directorio si no existe
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Crear archivo temporal
        temp_file = f"{file_path}.new"
        
        try:
            # Agrupar repos activos por URI, Componentes y Comentario
            grouped_repos = {}
            for repo in repos:
                # Sólo incluir repos activos
                if not repo.get('disabled', False):
                    key = (repo['uri'], repo['components'], repo.get('comment', ''))
                    if key not in grouped_repos:
                        grouped_repos[key] = {'types': set(), 'suites': set()}
                    
                    grouped_repos[key]['types'].add(repo['type'])
                    grouped_repos[key]['suites'].add(repo['distribution'])
            
            # Escribir archivo en formato deb822
            with open(temp_file, 'w') as f:
                # Añadir encabezado
                f.write("# Este archivo fue generado por Soplos Repo Selector\n")
                f.write(f"# Última actualización: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                for (uri, components, comment), data in grouped_repos.items():
                    # Crear un nuevo párrafo deb822
                    para = deb822.Deb822()
                    
                    # Establecer campos comunes
                    para['Types'] = ' '.join(sorted(data['types']))
                    para['URIs'] = uri
                    para['Suites'] = ' '.join(sorted(data['suites']))
                    para['Components'] = components
                    
                    # Añadir firmado por defecto para repositorios Debian
                    if "debian.org" in uri:
                        para['Signed-By'] = "/usr/share/keyrings/debian-archive-keyring.gpg"
                    
                    if comment:
                        if not comment.startswith('#'):
                            comment = '# ' + comment
                        para['X-Comment'] = comment.replace('# ', '')
                    
                    # Escribir párrafo
                    f.write(str(para))
                    f.write("\n\n")  # Separación entre párrafos
            
            # Mover el archivo temporal al lugar correcto con permisos elevados
            from src.repo.system_executor import SystemCommandExecutor
            executor = SystemCommandExecutor()
            executor.run_as_root(['mv', temp_file, file_path])
            executor.run_as_root(['chmod', '644', file_path])
            
        except Exception as e:
            # Limpiar archivo temporal si hay error
            if os.path.exists(temp_file):
                os.unlink(temp_file)
            log_error(f"Error al actualizar archivo deb822 {file_path}", e)
            raise
