import os

# Rutas
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
LOGO_PATH = os.path.join(ASSETS_DIR, "icons/soplos-logo.png")

# Valores predeterminados
DEFAULT_TEMP_DIR = "/home/live-build"
DEFAULT_ISO_DIR = "/home/iso"
DEFAULT_ISO_NAME = "soplos-linux-1.0-tyron.iso"

# Exclusiones e inclusiones predeterminadas
DEFAULT_EXCLUSIONS = """--exclude=/proc/*
--exclude=/sys/*
--exclude=/dev/*
--exclude=/tmp/*
--exclude=/run/*
--exclude=/mnt/*
--exclude=/media/*
--exclude=/lost+found/*
--exclude=/home/*/.cache/*
--exclude=/home/*/.local/share/Trash/*
--exclude=/home/*/.mozilla/*
--exclude=/var/log/*
--exclude=/var/cache/*
--exclude=/var/tmp/*
--exclude=/usr/share/doc/*
--exclude=/usr/src/*
--exclude=/usr/include/*
--exclude=/root/.cache/*
--exclude=/etc/fstab
--exclude=/etc/hostname
--exclude=/etc/resolv.conf
--exclude=/home/live-build
--exclude=/home/iso
--exclude=/.distro"""

DEFAULT_INCLUSIONS = """--include=/home/liveuser/**
--include=/boot/**
--include=/boot/efi/**
--include=/boot/grub/**"""

# Plantilla para grub.cfg
GRUB_CONFIG_TEMPLATE = '''set default=0
set timeout=10

menuentry "Soplos Linux Live" {
    linux /boot/vmlinuz boot=live quiet splash
    initrd /boot/initrd.img
}
'''

# Valores de progreso para cada paso
PROGRESS_VALUES = {
    "create_dir": 0.1667,  # 1/6
    "rsync": 0.3334,      # 2/6
    "squashfs": 0.5001,   # 3/6
    "clean_temp": 0.6668, # 4/6
    "create_iso": 0.8335, # 5/6
    "remove_squashfs": 1.0 # 6/6
}