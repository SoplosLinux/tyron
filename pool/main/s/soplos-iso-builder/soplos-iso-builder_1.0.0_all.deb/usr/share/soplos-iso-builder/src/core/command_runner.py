import subprocess
import os
import signal
import threading
from gi.repository import GLib

class CommandRunner:
    def __init__(self, output_callback, progress_callback=None):
        self.output_callback = output_callback
        self.progress_callback = progress_callback
        self.current_process = None
        self.process_group = None
        self.is_cancelled = False
        self.window = None  # Referencia a la ventana principal

    def parse_progress(self, line):
        """Parsea el progreso de rsync y mksquashfs"""
        try:
            line = line.strip()
            
            # Para rsync (formato: "   <número>%    <velocidad>  <tiempo>")
            if "%" in line:
                # Buscar el porcentaje en el formato típico de rsync
                try:
                    # Dividir por espacios y buscar el token con %
                    tokens = line.split()
                    for token in tokens:
                        if "%" in token:
                            value = float(token.strip("%"))
                            if 0 <= value <= 100:
                                return value / 100
                except ValueError:
                    pass

                # Para mksquashfs (formato: "Compressing ... with xz")
                if "Compressing" in line:
                    try:
                        parts = line.split()
                        for i, part in enumerate(parts):
                            if "%" in part:
                                value = float(part.strip("%"))
                                if 0 <= value <= 100:
                                    return value / 100
                    except ValueError:
                        pass

            # Para xorriso/grub-mkrescue
            if "done" in line.lower():
                return 1.0
            elif "writing" in line.lower():
                return 0.5

            return None

        except Exception as e:
            print(f"Error parsing progress: {e}")
            return None

    def run_command(self, command, on_complete=None):
        """Ejecuta un comando y maneja su salida"""
        self.is_cancelled = False
        last_progress = 0.0
        
        def _run_command(cmd):
            try:
                self.current_process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    universal_newlines=True,
                    preexec_fn=os.setsid,
                    bufsize=1
                )
                
                while self.current_process and not self.is_cancelled:
                    output = self.current_process.stdout.readline()
                    if output == '' and self.current_process.poll() is not None:
                        break
                    if output:
                        # Procesar la salida para actualizar el progreso
                        if self.progress_callback:
                            progress = self.parse_progress(output)
                            if progress is not None:
                                GLib.idle_add(lambda p=progress: self.progress_callback(p))
                        
                        # Mostrar la salida
                        GLib.idle_add(lambda o=output: self.output_callback(o))

                if self.is_cancelled:
                    self.current_process = None
                    if on_complete:
                        GLib.idle_add(lambda: on_complete(False))
                    return

                # Asegurar que llegamos al 100% al completar
                if self.progress_callback:
                    GLib.idle_add(lambda: self.progress_callback(1.0))
                
                return_code = self.current_process.wait()
                if on_complete:
                    GLib.idle_add(lambda: on_complete(return_code == 0))
            
            except Exception as e:
                print(f"Error in command execution: {e}")
                if on_complete:
                    GLib.idle_add(lambda: on_complete(False))
            finally:
                self.current_process = None

        thread = threading.Thread(target=_run_command, args=(command,))
        thread.daemon = True
        thread.start()

    def cancel_current_process(self):
        """Cancela el proceso actual si existe"""
        if self.current_process:
            try:
                self.is_cancelled = True
                # Obtener el grupo de proceso
                pgid = os.getpgid(self.current_process.pid)
                # Enviar SIGTERM al grupo completo
                os.killpg(pgid, signal.SIGTERM)
                
                # Esperar un momento
                try:
                    self.current_process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    # Si no responde, usar SIGKILL
                    os.killpg(pgid, signal.SIGKILL)
                
                # Asegurarse de que el proceso principal también se mata
                self.current_process.kill()
                self.current_process = None
                return True
            except Exception as e:
                print(f"Error canceling process: {e}")
                return False
        return False