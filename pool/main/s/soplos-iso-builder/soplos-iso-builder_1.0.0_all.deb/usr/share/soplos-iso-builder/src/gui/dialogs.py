import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf
import os

class MessageDialog:
    def __init__(self, parent_window, logo_path=None):
        self.parent = parent_window
        self.logo_path = logo_path
        # Obtener la función de traducción del padre
        self._ = parent_window._

    def show_message(self, title, message):
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=self._(title)  # Traducir título
        )
        dialog.format_secondary_text(self._(message))  # Traducir mensaje
        
        if self.logo_path and os.path.exists(self.logo_path):
            try:
                content_area = dialog.get_content_area()
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    self.logo_path, width=64, height=64, preserve_aspect_ratio=True)
                image = Gtk.Image.new_from_pixbuf(pixbuf)
                content_area.pack_start(image, False, False, 10)
                content_area.reorder_child(image, 0)
                content_area.show_all()
            except Exception as e:
                print(f"Error al cargar el logo en el diálogo: {e}")
        
        dialog.run()
        dialog.destroy()

class ConfirmDialog(MessageDialog):
    def confirm(self, title, message):
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=self._(title)
        )
        dialog.format_secondary_text(self._(message))
        
        # Añadir atajos a los botones Sí/No con underscores
        yes_button = dialog.get_widget_for_response(Gtk.ResponseType.YES)
        no_button = dialog.get_widget_for_response(Gtk.ResponseType.NO)
        yes_button.set_label("_" + self._('yes'))
        no_button.set_label("_" + self._('no'))
        yes_button.set_use_underline(True)
        no_button.set_use_underline(True)
        
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.YES