import os
import multiprocessing

def get_cpu_count():
    """Retorna el número de cores disponibles en el sistema"""
    try:
        return multiprocessing.cpu_count()
    except:
        return 1  # Valor por defecto si no se puede detectar
