import gi
import os
import sys
import warnings
import shutil
warnings.filterwarnings('ignore', category=Warning)
os.environ['NO_AT_BRIDGE'] = '1'

# Definir BASE_DIR al inicio
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

import locale
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GdkPixbuf, GLib, Gdk
from src.config.strings import get_translation, get_system_language
from src.gui.main_window import LiveISOCreator

DEBUG = False  # Cambiar a True para ver mensajes de depuración

# Definir las constantes de identificación
# Usar exactamente el mismo ID que se especifica en .desktop y metainfo
APP_ID = "com.soplos.isobuilder"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

def clean_pycache():
    """Cleans project's __pycache__ files"""
    try:
        project_root = os.path.dirname(os.path.abspath(__file__))
        found = False
        for root, dirs, files in os.walk(project_root):
            if '__pycache__' in dirs:
                pycache_path = os.path.join(root, '__pycache__')
                try:
                    shutil.rmtree(pycache_path)
                    if DEBUG:
                        print(f"Cleaning cache: {pycache_path}")
                    found = True
                except Exception as e:
                    print(f"Error cleaning {pycache_path}: {e}")
        if DEBUG and not found:
            print("No cache files found to clean")
    except Exception as e:
        print(f"Error searching caches: {e}")

def setup_locale():
    """Configura la localización del sistema"""
    try:
        locale.setlocale(locale.LC_ALL, '')
    except locale.Error:
        try:
            locale.setlocale(locale.LC_ALL, 'C.UTF-8')
        except locale.Error:
            print("Warning: No se pudo configurar el idioma del sistema")

def main():
    try:
        # Limpiar caché al inicio
        clean_pycache()
        
        # Configurar localización
        setup_locale()
        
        # Establecer identificadores de aplicación globales
        GLib.set_prgname(APP_ID)
        GLib.set_application_name(APP_ID)  # Usar APP_ID en lugar de "Soplos ISO Builder"
        
        # Establecer icono predeterminado para todas las ventanas
        Gtk.Window.set_default_icon_name(APP_ID)
        
        # Configuración para asegurar que GDK use el WMCLASS correcto
        if hasattr(Gdk, 'set_program_class'):
            Gdk.set_program_class(WMCLASS)
        
        # Obtener idioma del sistema
        current_lang = get_system_language()
        if DEBUG:
            print(f"Idioma detectado: {current_lang}")
        
        # Crear aplicación GTK con ID específico
        app = Gtk.Application(
            application_id=APP_ID,
            flags=Gio.ApplicationFlags.FLAGS_NONE
        )

        def on_activate(app):
            window = LiveISOCreator(current_lang)
            window.set_application(app)
            
            # Establecer explícitamente el WM_CLASS para asegurar identificación correcta en el dock
            # Usar exactamente el mismo valor que el .desktop espera
            window.set_wmclass(WMCLASS, WMCLASS)
            
            # Establecer el icono para taskbar/dock/menú
            try:
                icon_theme = Gtk.IconTheme.get_default()
                try:
                    # Intentar cargar el icono por nombre - debe coincidir con .desktop
                    icon = icon_theme.load_icon(APP_ID, 128, 0)
                    window.set_icon(icon)
                except:
                    # Fallar a la ruta del archivo
                    icon_path = os.path.join(BASE_DIR, "assets/icons/com.soplos.isobuilder.png")
                    if os.path.exists(icon_path):
                        icon = GdkPixbuf.Pixbuf.new_from_file(icon_path)
                        window.set_icon(icon)
                    else:
                        # Intentar con el icono de logo antiguo como fallback
                        legacy_icon = os.path.join(BASE_DIR, "assets/icons/soplos-logo.png")
                        if os.path.exists(legacy_icon):
                            icon = GdkPixbuf.Pixbuf.new_from_file(legacy_icon)
                            window.set_icon(icon)
            except Exception as e:
                print(f"Error al cargar el icono: {e}")
                
            # Forzar actualización de propiedades de ventana antes de mostrar
            window.realize()
            
            # Conectar señal destroy
            window.connect("destroy", lambda w: app.quit())
            window.show_all()

        app.connect('activate', on_activate)
        return app.run(sys.argv)

    except Exception as e:
        print(f"Error al iniciar la aplicación: {e}")
        sys.exit(1)

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nPrograma interrumpido por el usuario")
        clean_pycache()
        sys.exit(0)