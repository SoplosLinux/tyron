# Soplos ISO Builder

## 🎯 Descripción
Constructor gráfico de ISOs personalizadas para Soplos Linux.

## ✨ Características
- 🖥️ Interfaz gráfica intuitiva
- 🚀 Proceso automatizado o manual
- 🔧 Personalización avanzada
- 📦 Gestión de paquetes
- 🔄 Compresión optimizada
- 🌍 Soporte 8 idiomas

## 🛠️ Requisitos
- Python 3.6+
- GTK 3.0
- squashfs-tools
- xorriso
- grub2

## 📥 Instalación

### Desde Fuente
```bash
git clone https://github.com/SoplosLinux/soplos-iso-builder.git
cd soplos-iso-builder
sudo pip3 install .
```

### Desde Paquete DEB
```bash
wget https://github.com/SoplosLinux/soplos-iso-builder/releases/latest/download/soplos-iso-builder.deb
sudo dpkg -i soplos-iso-builder.deb
sudo apt-get install -f
```

## ⚡ Proceso ISO
1. Crear directorio temporal
2. Copiar archivos del sistema
3. Crear sistema squashfs
4. Limpiar temporales
5. Generar ISO
6. Eliminar squashfs

## ⌨️ Atajos
- `Ctrl+R`: Proceso automático
- `Ctrl+Q`: Salir
- `Esc`: Cancelar operación
- `Alt+A`: Auto
- `Alt+L`: Limpiar cachés
- `Alt+S`: Configurar estructura

## 🌍 Idiomas
- 🇪🇸 ES  - 🇬🇧 EN
- 🇫🇷 FR  - 🇩🇪 DE
- 🇮🇹 IT  - 🇵🇹 PT
- 🇷🇴 RO  - 🇷🇺 RU

## 📞 Contacto
- **Web**: https://soploslinux.com/
- **GitHub**: https://github.com/SoplosLinux
- **Email**: info@soploslinux.com

## 📄 Licencia
GPL-3.0 © 2024 Soplos Team