# Soplos ISO Builder

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)]()

Una herramienta gráfica potente y fácil de usar para crear ISOs personalizadas de Soplos Linux.

*A powerful and easy-to-use graphical tool for creating customized Soplos Linux ISOs.*

## 📝 Descripción

Soplos ISO Builder permite crear imágenes ISO personalizadas de Soplos Linux mediante un proceso dividido en 6 pasos, con una interfaz gráfica intuitiva que facilita todo el proceso de creación.

## ✨ Características

- 🖥️ Interfaz gráfica moderna e intuitiva
- 🚀 Proceso automatizado o paso a paso 
- 🌍 8 idiomas soportados
- 🔧 Personalización avanzada:
  - Configuración de núcleos para compresión
  - Exclusiones e inclusiones personalizables
  - Gestión de cachés
- 🔑 Integración con PolicyKit
- 🔄 Detección automática de dependencias

## 🛠️ Funcionalidad del Programa

El proceso de creación de ISOs se divide en estos 6 pasos:

1. **Crear directorio temporal**: Configura un espacio de trabajo para almacenar los archivos necesarios.
2. **Copiar archivos del sistema**: Usa `rsync` para copiar los archivos del sistema con exclusiones e inclusiones configurables.
3. **Crear sistema de archivos squashfs**: Comprime los archivos en un sistema de archivos squashfs optimizado.
4. **Limpiar directorio temporal**: Elimina los archivos temporales para liberar espacio.
5. **Generar la ISO**: Usa `grub-mkrescue` para crear la imagen ISO final.
6. **Eliminar squashfs**: Limpia los archivos squashfs temporales.

## 📸 Capturas de pantalla

### Ventana principal de Soplos ISO Builder
![Ventana principal](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-iso-builder/screenshots/screenshot1.png)

### Proceso de creación de ISO
![Proceso de creación](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-iso-builder/screenshots/screenshot2.png)

## 🔧 Instalación

### Desde Fuente

```bash
# Clonar el repositorio
git clone https://github.com/SoplosLinux/soplos-iso-builder.git

# Entrar al directorio
cd soplos-iso-builder

# Instalar
sudo pip3 install .
```

### Desde Paquete DEB

```bash
# Descargar e instalar
wget https://github.com/SoplosLinux/soplos-iso-builder/releases/latest/download/soplos-iso-builder.deb
sudo dpkg -i soplos-iso-builder.deb
sudo apt-get install -f
```

## 💻 Requisitos

- Sistema operativo Linux basado en Debian/Ubuntu (compatible con otras distribuciones)
- Python 3.6 o superior
- GTK 3.0
- Dependencias del sistema (instalación automática disponible):
  - squashfs-tools
  - grub-common
  - mtools
  - python3-gi

## ⌨️ Atajos de Teclado

- `Ctrl + R` - Iniciar proceso automático
- `Ctrl + Q` - Salir
- `Esc` - Cancelar operación
- `Alt + A` - Auto
- `Alt + L` - Limpiar cachés
- `Alt + N` - Cancelar
- `Alt + C` - Cerrar
- `Alt + E` - Examinar
- `Alt + G` - Guardar configuración
- `Alt + S` - Configurar estructura ISO

## 🌐 Idiomas soportados

- 🇪🇸 Español
- 🇬🇧 Inglés
- 🇫🇷 Francés
- 🇩🇪 Alemán
- 🇵🇹 Portugués
- 🇮🇹 Italiano
- 🇷🇺 Ruso
- 🇷🇴 Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos Linux](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)
- [Correo](mailto:info@soploslinux.com)

## 📦 Versiones

### v1.0.0 (08/05/2025)
- Versión inicial de lanzamiento