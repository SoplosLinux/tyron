import os
import logging
import subprocess
import threading
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import GLib
from pathlib import Path
from ..config.constants import (
    DEFAULT_TEMP_DIR,
    DEFAULT_ISO_DIR,
    DEFAULT_ISO_NAME,
    DEFAULT_EXCLUSIONS,
    DEFAULT_INCLUSIONS
)

class ISOBuilder:
    def __init__(self, command_runner):
        # Configuración del logging
        log_dir = os.path.expanduser('~/.local/share/soplos-iso-builder')
        os.makedirs(log_dir, exist_ok=True)
        
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(message)s',
            filename=os.path.join(log_dir, 'iso_builder.log')
        )
        self.logger = logging.getLogger(__name__)
        
        # Rutas por defecto
        self.live_build_path = DEFAULT_TEMP_DIR
        self.iso_path = DEFAULT_ISO_DIR
        self.command_runner = command_runner
        self.squashfs_path = None  # Se establecerá cuando se configuren las rutas
        self.iso_name = DEFAULT_ISO_NAME
        self.volume_name = "soplos-linux-live"  # Valor por defecto del volumen

    def set_paths(self, live_build_path, iso_path):
        """Configurar rutas desde la GUI"""
        self.live_build_path = os.path.abspath(live_build_path)
        self.iso_path = os.path.abspath(iso_path)
        self.squashfs_path = os.path.join(self.iso_path, "live/filesystem.squashfs")
        self.logger.info(f"Rutas configuradas: live={self.live_build_path}, iso={self.iso_path}")

    def check_iso_structure(self):
        """Verifica si existe la estructura ISO básica"""
        required_dirs = [
            os.path.join(self.iso_path, "live"),
            os.path.join(self.iso_path, "boot"),
            os.path.join(self.iso_path, "boot/grub")
        ]
        
        # Verificar solo directorios necesarios
        for path in required_dirs:
            if not os.path.exists(path):
                self.logger.error(f"Falta directorio: {path}")
                return False
            if not os.access(path, os.R_OK):
                self.logger.error(f"Sin permisos de lectura: {path}")
                return False

        # Si existe grub.cfg, verificar permisos pero no contenido
        grub_cfg = os.path.join(self.iso_path, "boot/grub/grub.cfg")
        if os.path.exists(grub_cfg):
            if not os.access(grub_cfg, os.R_OK):
                self.logger.error(f"Sin permisos de lectura: {grub_cfg}")
                return False
        
        return True

    def get_squashfs_path(self):
        """Obtener ruta del sistema de archivos squashfs"""
        return os.path.join(self.iso_path, "live/filesystem.squashfs")

    def get_iso_path(self):
        """Obtener ruta completa del archivo ISO"""
        return os.path.join(self.iso_path, self.iso_name)

    # MODO AUTOMÁTICO: pkexec solo primer paso, resto sudo
    def build_iso(self, volume_name="soplos-linux-live", on_complete=None, custom_exclusions=None, custom_inclusions=None):
        try:
            # Verificar estructura ISO y proceso en curso
            if not self.check_iso_structure():
                self.logger.error("Estructura ISO no encontrada")
                if on_complete:
                    GLib.idle_add(lambda: on_complete(False))
                return False

            if self.command_runner.current_process:
                self.logger.error("Hay una operación en curso")
                if on_complete:
                    GLib.idle_add(lambda: on_complete(False))
                return False

            # Verificar si el directorio temporal ya existe
            if os.path.exists(self.live_build_path):
                self.logger.warning(f"El directorio {self.live_build_path} ya existe. Se limpiará antes de continuar.")
                try:
                    subprocess.run(['pkexec', 'rm', '-rf', self.live_build_path], check=True)
                except subprocess.CalledProcessError as e:
                    self.logger.error(f"Error al limpiar directorio existente: {e}")
                    if on_complete:
                        GLib.idle_add(lambda: on_complete(False))
                    return False

            self.logger.info("Iniciando proceso automático...")

            # En lugar de subprocess.run, usamos command_runner para cada paso
            def run_steps():
                try:
                    # 1. Crear directorio inicial (pkexec)
                    self.logger.info("Creando directorio inicial...")
                    def step1_complete(success):
                        if not success:
                            GLib.idle_add(lambda: on_complete(False))
                            return
                        # 2. Continuar con rsync (usando pkexec en lugar de sudo)
                        self.logger.info("Iniciando rsync...")
                        rsync_command = ["pkexec", "rsync", "-av", "/", self.live_build_path]
                        
                        # Procesar exclusiones
                        if custom_exclusions and custom_exclusions.strip():
                            for exclusion in custom_exclusions.split('\n'):
                                exclusion = exclusion.strip()
                                if exclusion and not exclusion.startswith('#'):
                                    rsync_command.append(exclusion)
                        else:
                            for exclusion in DEFAULT_EXCLUSIONS.split('\n'):
                                exclusion = exclusion.strip()
                                if exclusion and not exclusion.startswith('#'):
                                    rsync_command.append(exclusion)
                        
                        # Procesar inclusiones
                        if custom_inclusions and custom_inclusions.strip():
                            for inclusion in custom_inclusions.split('\n'):
                                inclusion = inclusion.strip()
                                if inclusion and not inclusion.startswith('#'):
                                    rsync_command.append(inclusion)
                        else:
                            for inclusion in DEFAULT_INCLUSIONS.split('\n'):
                                inclusion = inclusion.strip()
                                if inclusion and not inclusion.startswith('#'):
                                    rsync_command.append(inclusion)
                        
                        # Agregar exclusiones dinámicas
                        rsync_command.extend([
                            f'--exclude={self.live_build_path}',
                            f'--exclude={self.iso_path}'
                        ])
                        
                        self.logger.info(f"Comando rsync: {' '.join(rsync_command)}")
                        self.command_runner.run_command(rsync_command, step2_complete)

                    def step2_complete(success):
                        if not success or self.command_runner.is_cancelled:
                            GLib.idle_add(lambda: on_complete(False))
                            return
                        # Eliminar la llamada a setup_live_user y pasar directo a crear squashfs
                        self.logger.info("Creando squashfs...")
                        squashfs_path = self.get_squashfs_path()
                        self.command_runner.run_command([
                            "pkexec", "mksquashfs",
                            self.live_build_path,
                            squashfs_path,
                            "-comp", "xz",
                            "-Xbcj", "x86",
                            "-b", "1M",
                            "-no-recovery",
                            "-noappend"
                        ], step3_complete)

                    def step3_complete(success):
                        if not success or self.command_runner.is_cancelled:
                            GLib.idle_add(lambda: on_complete(False))
                            return
                        # 4. Limpiar directorio temporal (usando pkexec)
                        self.logger.info("Limpiando directorio temporal...")
                        self.command_runner.run_command(
                            ["pkexec", "rm", "-rf", self.live_build_path],
                            step4_complete
                        )

                    def step4_complete(success):
                        if not success:
                            GLib.idle_add(lambda: on_complete(False))
                            return
                        # 5. Crear ISO (usando pkexec)
                        self.logger.info("Creando ISO...")
                        self.command_runner.run_command([
                            "pkexec", "grub-mkrescue",
                            "-V", volume_name,
                            "-o", self.get_iso_path(),
                            self.iso_path
                        ], step5_complete)

                    def step5_complete(success):
                        if not success:
                            GLib.idle_add(lambda: on_complete(False))
                            return
                        # 6. Limpiar squashfs (usando pkexec)
                        self.logger.info("Limpiando squashfs...")
                        squashfs_path = self.get_squashfs_path()
                        self.command_runner.run_command(
                            ["pkexec", "rm", "-R", squashfs_path],
                            final_complete
                        )

                    def final_complete(success):
                        if success:
                            self.logger.info("Proceso completado exitosamente")
                        else:
                            self.logger.error("Error en el paso final")
                        GLib.idle_add(lambda: on_complete(success))

                    # Iniciar el primer paso
                    self.command_runner.run_command(
                        ['pkexec', 'mkdir', '-p', self.live_build_path],
                        step1_complete
                    )

                except Exception as e:
                    self.logger.error(f"Error inesperado: {str(e)}")
                    GLib.idle_add(lambda: on_complete(False))

            # Ejecutar en un hilo separado
            thread = threading.Thread(target=run_steps)
            thread.daemon = True
            thread.start()
            return True

        except Exception as e:
            self.logger.error(f"Error al iniciar el proceso: {str(e)}")
            if on_complete:
                GLib.idle_add(lambda: on_complete(False))
            return False

    # MODO MANUAL: Todos los pasos usan pkexec
    def create_directory(self, on_complete):
        """Paso 1 manual: Crear directorio temporal"""
        if os.path.exists(self.live_build_path):
            self.logger.info(f"El directorio {self.live_build_path} ya existe")
            if on_complete:
                GLib.idle_add(lambda: on_complete(True))
            return True
        
        self.command_runner.run_command(
            ['pkexec', 'mkdir', '-p', self.live_build_path], 
            on_complete
        )

    def rsync_files(self, on_complete, custom_exclusions=None, custom_inclusions=None):
        """Paso 2: Copiar archivos del sistema con rsync"""
        command = [
            'pkexec',
            'rsync',
            '-aHAXv',
            '--progress',
            '--stats'
        ]
        
        # Procesar exclusiones
        if custom_exclusions and custom_exclusions.strip():
            for exclusion in custom_exclusions.split('\n'):
                exclusion = exclusion.strip()
                if exclusion:
                    if not exclusion.startswith('--exclude='):
                        exclusion = f'--exclude={exclusion}'
                    command.append(exclusion)
        else:
            for exclusion in DEFAULT_EXCLUSIONS.split('\n'):
                exclusion = exclusion.strip()
                if exclusion:
                    command.append(exclusion)
        
        # Procesar inclusiones
        if custom_inclusions and custom_inclusions.strip():
            for inclusion in custom_inclusions.split('\n'):
                inclusion = inclusion.strip()
                if inclusion:
                    if not inclusion.startswith('--include='):
                        inclusion = f'--include={inclusion}'
                    command.append(inclusion)
        else:
            for inclusion in DEFAULT_INCLUSIONS.split('\n'):
                inclusion = inclusion.strip()
                if inclusion:
                    command.append(inclusion)
        
        # Agregar exclusiones dinámicas
        command.extend([
            f'--exclude={self.live_build_path}',
            f'--exclude={self.iso_path}'
        ])
        
        # Agregar origen y destino
        command.append('/')
        command.append(self.live_build_path)
        
        # Mostrar el comando que se va a ejecutar
        self.logger.info(f"Ejecutando rsync con comando: {' '.join(command)}")
        self.command_runner.run_command(command, on_complete)

    def create_squashfs(self, on_complete):
        """Paso 3 manual: Squashfs"""
        squashfs_path = self.get_squashfs_path()
        # Obtener número de cores seleccionado (o usar 1 si no está disponible)
        try:
            n_cores = int(self.command_runner.window.cores_combo.get_active_text() or "1")
        except:
            n_cores = 1

        command = [
            'pkexec', 'mksquashfs',
            self.live_build_path,
            squashfs_path,
            '-comp', 'xz',
            '-Xbcj', 'x86',
            '-processors', str(n_cores),  # Usar el número de cores seleccionado
            '-b', '1M',
            '-no-recovery',
            '-noappend',
            '-info'
        ]
        self.command_runner.run_command(command, on_complete)

    def clean_temp_dir(self, on_complete):
        """Paso 4 manual: Limpiar directorio temporal"""
        self.command_runner.run_command(
            ['pkexec', 'rm', '-rf', self.live_build_path],
            on_complete
        )

    def create_iso(self, on_complete):
        """Paso 5: Crear ISO usando grub-mkrescue"""
        # Verificar dependencias necesarias
        deps_command = [
            "pkexec", "bash", "-c",
            "command -v grub-mkrescue >/dev/null 2>&1 || apt-get install -y grub-common;"
            "command -v mtools >/dev/null 2>&1 || apt-get install -y mtools"
        ]
        
        def run_grub_mkrescue(success):
            if not success:
                if on_complete:
                    GLib.idle_add(lambda: on_complete(False))
                return
                
            # Usar grub-mkrescue directamente
            self.command_runner.run_command([
                "pkexec", "grub-mkrescue",
                "-o", self.get_iso_path(),
                "-v",  # Salida detallada
                "-V", self.volume_name,
                self.iso_path
            ], on_complete)
        
        # Verificar/instalar dependencias y luego ejecutar grub-mkrescue
        self.command_runner.run_command(deps_command, run_grub_mkrescue)

    def remove_squashfs(self, on_complete):
        """Paso 6 manual: Eliminar squashfs"""
        squashfs_path = self.get_squashfs_path()
        self.command_runner.run_command(
            ['pkexec', 'rm', '-R', squashfs_path],
            on_complete
        )

    def clean_caches(self, on_complete=None):
        """Limpia cachés y archivos temporales"""
        try:
            self.logger.info("Iniciando limpieza de cachés...")
            
            cleanup_paths = [
                # Directorios temporales
                self.live_build_path,
                "/tmp/soplos-iso-*",
                
                # Cachés del sistema
                "/var/cache/apt/archives/*.deb",
                "/var/cache/apt/*.bin",
                "/var/lib/apt/lists/*",
                
                # Cachés de usuario
                "/home/*/.cache/*",
                "/home/*/.local/share/Trash/*",
                "/root/.cache/*",
                
                # Logs
                "/var/log/*.log*",
                "/var/log/*/*.log*",
                
                # Squashfs temporal si existe
                self.get_squashfs_path() if self.squashfs_path else None
            ]
            
            # Filtrar None y convertir a string
            cleanup_paths = [str(p) for p in cleanup_paths if p]
            
            def cleanup_complete(success):
                if success:
                    self.logger.info("Limpieza completada exitosamente")
                else:
                    self.logger.error("Error durante la limpieza")
                if on_complete:
                    GLib.idle_add(lambda: on_complete(success))
            
            # Ejecutar limpieza con pkexec
            cleanup_command = ["pkexec", "rm", "-rf"] + cleanup_paths
            self.command_runner.run_command(cleanup_command, cleanup_complete)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error al iniciar limpieza: {str(e)}")
            if on_complete:
                GLib.idle_add(lambda: on_complete(False))
            return False

    def clean_project_cache(self):
        """Limpia los __pycache__ del proyecto"""
        try:
            self.logger.info("Limpiando cachés del proyecto...")
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            
            # Encontrar y eliminar todos los __pycache__
            for root, dirs, files in os.walk(project_root):
                if '__pycache__' in dirs:
                    pycache_path = os.path.join(root, '__pycache__')
                    try:
                        import shutil
                        shutil.rmtree(pycache_path)
                        self.logger.info(f"Eliminado: {pycache_path}")
                    except Exception as e:
                        self.logger.error(f"Error al eliminar {pycache_path}: {e}")
            
            self.logger.info("Limpieza de cachés del proyecto completada")
            return True
        
        except Exception as e:
            self.logger.error(f"Error al limpiar cachés del proyecto: {e}")
            return False