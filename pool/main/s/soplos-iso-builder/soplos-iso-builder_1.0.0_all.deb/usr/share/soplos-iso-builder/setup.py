from setuptools import setup, find_packages

setup(
    name="soplos-iso-builder",
    version="1.1.0",
    author="Tyron Software",
    author_email="info@tyronsoftware.com",
    description="Herramienta gráfica para crear ISOs personalizadas de Soplos Linux",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'pygobject>=3.0.0',
        'setuptools>=42.0.0',
    ],
    package_data={
        'assets': ['*.png', '*.desktop'],
        'src/config': ['*.py'],
    },
    entry_points={
        'gui_scripts': [
            'soplos-iso-builder=main:main',
        ],
    },
    data_files=[
        ('share/applications', ['assets/com.soplos.isobuilder.desktop']),
        ('share/icons/hicolor/128x128/apps', ['assets/icons/com.soplos.isobuilder.png']),
        ('share/metainfo', ['debian/com.soplos.isobuilder.metainfo.xml']),
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: POSIX :: Linux",
        "Environment :: X11 Applications :: GTK",
        "Natural Language :: Spanish",
        "Natural Language :: English",
        "Natural Language :: French",
        "Natural Language :: German",
        "Natural Language :: Portuguese",
        "Natural Language :: Italian",
        "Natural Language :: Romanian",
        "Natural Language :: Russian",
    ],
    python_requires='>=3.6',
)