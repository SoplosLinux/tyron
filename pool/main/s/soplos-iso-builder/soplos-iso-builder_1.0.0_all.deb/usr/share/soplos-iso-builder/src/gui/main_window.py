import os
import signal
import threading
import subprocess
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GdkPixbuf, Gdk, Pango
from ..core.iso_builder import ISOBuilder
from ..core.command_runner import CommandRunner
from ..core.system_info import get_cpu_count
from ..config.constants import (
    DEFAULT_TEMP_DIR, 
    DEFAULT_ISO_DIR, 
    DEFAULT_ISO_NAME,
    DEFAULT_EXCLUSIONS,
    DEFAULT_INCLUSIONS,
    PROGRESS_VALUES,
    GRUB_CONFIG_TEMPLATE
)
from .dialogs import ConfirmDialog
from ..config.strings import get_translation, get_available_languages, get_language_name

class StepsGrid(Gtk.Grid):
    def __init__(self, window):
        super().__init__()
        self.set_column_spacing(10)
        self.set_row_spacing(10)
        self.set_column_homogeneous(True)
        self._ = window._  # Compartir función de traducción
        
        # Diccionario para almacenar los botones
        self.buttons = {}
        
        # Configuración de los pasos con atajos
        steps = [
            ("create_dir", "_1. " + self._('create_dir_button'), 0, 0),
            ("rsync", "_2. " + self._('copy_files'), 1, 0),
            ("squashfs", "_3. " + self._('create_squashfs'), 2, 0),
            ("clean_temp", "_4. " + self._('clean_temp'), 0, 1),
            ("create_iso", "_5. " + self._('create_iso'), 1, 1),
            ("remove_squashfs", "_6. " + self._('clean_squashfs'), 2, 1)
        ]
        
        # Crear los botones con use_underline
        for name, label, col, row in steps:
            button = Gtk.Button(label=label, use_underline=True)
            button.set_sensitive(False)  # Inicialmente desactivados
            self.buttons[name] = button
            self.attach(button, col, row, 1, 1)

class LiveISOCreator(Gtk.ApplicationWindow):  # Cambiar a ApplicationWindow
    def __init__(self, lang='en'):
        self.lang = lang
        self._ = lambda key: get_translation(key, self.lang)
        
        # Inicialización como ApplicationWindow
        Gtk.ApplicationWindow.__init__(self, title=self._('window_title'))
        
        self.set_border_width(10)
        self.set_default_size(800, 600)
        
        # Inicialización de componentes
        self.logo_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                    "assets/icons/soplos-logo.png")
        self.command_runner = CommandRunner(
            self.append_output, 
            self.update_real_progress
        )
        self.command_runner.window = self  # Añadir referencia a la ventana
        self.iso_builder = ISOBuilder(self.command_runner)
        
        # Estado de los pasos
        self.step_completed = {
            "create_dir": False,
            "rsync": False,
            "squashfs": False,
            "clean_temp": False,
            "create_iso": False,
            "remove_squashfs": False
        }
        
        # Crear interfaz
        self.create_widgets()

    def create_widgets(self):
        """Crea todos los widgets de la interfaz"""
        # Contenedor principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Añadir selector de idioma en la parte superior
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        lang_box.set_halign(Gtk.Align.END)
        lang_box.set_margin_end(10)
        
        self.lang_combo = Gtk.ComboBoxText()
        for lang in get_available_languages():
            self.lang_combo.append(lang, get_language_name(lang))
        self.lang_combo.set_active_id(self.lang)
        self.lang_combo.connect('changed', self.on_language_changed)
        lang_box.pack_start(self.lang_combo, False, False, 0)
        main_box.pack_start(lang_box, False, False, 5)
        
        # Logo en la cabecera
        try:
            logo_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            logo_box.set_halign(Gtk.Align.CENTER)
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                self.logo_path, 
                width=120, 
                height=120, 
                preserve_aspect_ratio=True
            )
            logo_image = Gtk.Image.new_from_pixbuf(pixbuf)
            logo_box.pack_start(logo_image, False, False, 10)
            main_box.pack_start(logo_box, False, False, 10)
            
            # Establecer el icono de la ventana
            self.set_icon_from_file(self.logo_path)
        except Exception as e:
            print(f"Error al cargar el logo: {e}")
        
        # Notebook para las pestañas
        self.notebook = Gtk.Notebook()
        main_box.pack_start(self.notebook, True, True, 0)
        
        # Crear las páginas
        self.main_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.config_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        
        # Crear pestañas y agregarlas al notebook con sus traducciones
        self._create_main_tab()
        self._create_config_tab()
        
        self.notebook.append_page(self.main_page, Gtk.Label(self._('main_tab')))
        self.notebook.append_page(self.config_page, Gtk.Label(self._('config_tab')))

        # Agregar atajos de teclado globales
        accel = Gtk.AccelGroup()
        self.add_accel_group(accel)
        
        # Ctrl+Q para salir
        key, mod = Gtk.accelerator_parse("<Control>Q")
        accel.connect(key, mod, Gtk.AccelFlags.VISIBLE, 
                     lambda *x: self.close_application(None))
        
        # Ctrl+R para ejecutar todo
        key, mod = Gtk.accelerator_parse("<Control>R")
        accel.connect(key, mod, Gtk.AccelFlags.VISIBLE,
                     lambda *x: self.btn_auto.emit("clicked"))
        
        # Esc para cancelar
        key, mod = Gtk.accelerator_parse("Escape")
        accel.connect(key, mod, Gtk.AccelFlags.VISIBLE,
                     lambda *x: self.btn_cancel.emit("clicked"))

    def _create_main_tab(self):
        """Crea la pestaña principal"""
        self.main_page.set_border_width(10)
        
        # Grid para los botones de pasos
        self.steps_grid = StepsGrid(self)
        self.main_page.pack_start(self.steps_grid, False, False, 0)
        
        # Área de salida
        output_frame = Gtk.Frame(label=self._('output'))
        self.main_page.pack_start(output_frame, True, True, 0)
        
        scroll = Gtk.ScrolledWindow()
        output_frame.add(scroll)
        
        self.output_text = Gtk.TextView()
        self.output_text.set_editable(False)
        self.output_text.override_font(Pango.FontDescription.from_string("Monospace 10"))
        self.output_text.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.95, 0.95, 0.95, 1))
        self.output_text.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0, 0, 0, 1))
        scroll.add(self.output_text)
        
        # Barra de progreso debajo del área de salida
        self.progress = Gtk.ProgressBar()
        self.progress.set_show_text(True)
        self.main_page.pack_start(self.progress, False, False, 0)
        
        # Botones de control con mnemonics
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        button_box.set_halign(Gtk.Align.CENTER)
        self.main_page.pack_start(button_box, False, False, 10)
        
        self.btn_auto = Gtk.Button(label="_" + self._('auto'), use_underline=True)
        self.btn_auto.get_style_context().add_class("suggested-action")
        self.btn_auto.connect("clicked", self.run_all_steps)
        
        self.btn_clean = Gtk.Button(label="_" + self._('clean_caches'), use_underline=True)
        self.btn_clean.connect("clicked", self.clean_caches)
        
        self.btn_cancel = Gtk.Button(label="_" + self._('cancel'), use_underline=True)
        self.btn_cancel.get_style_context().add_class("destructive-action")
        self.btn_cancel.connect("clicked", self.cancel_operation)
        self.btn_cancel.set_sensitive(False)
        
        self.btn_close = Gtk.Button(label="_" + self._('close'), use_underline=True)
        self.btn_close.connect("clicked", self.close_application)
        
        button_box.pack_start(self.btn_auto, False, False, 10)
        button_box.pack_start(self.btn_clean, False, False, 10)
        button_box.pack_start(self.btn_cancel, False, False, 10)
        button_box.pack_start(self.btn_close, False, False, 10)
        
        # Después de crear los botones en StepsGrid
        self.update_buttons()
    
    def _create_config_tab(self):
        """Crea la pestaña de configuración"""
        self.config_page.set_border_width(10)

        # Grid para las rutas
        paths_grid = Gtk.Grid()
        paths_grid.set_column_spacing(10)
        paths_grid.set_row_spacing(10)
        self.config_page.pack_start(paths_grid, False, False, 0)

        # Campos de configuración
        fields = [
            (self._('temp_dir'), "temp_dir", DEFAULT_TEMP_DIR),
            (self._('iso_dir'), "iso_dir", DEFAULT_ISO_DIR),
            (self._('iso_name'), "iso_name", DEFAULT_ISO_NAME)
        ]
        
        for i, (label_text, entry_name, default_value) in enumerate(fields):
            # Label con ID único
            label = Gtk.Label(label=label_text)
            label.set_name(f"config_label_{entry_name}")
            label.set_halign(Gtk.Align.START)
            paths_grid.attach(label, 0, i, 1, 1)
            
            # Entry con ID único
            entry = Gtk.Entry(text=default_value)
            entry.set_name(f"config_entry_{entry_name}")
            setattr(self, f"{entry_name}_entry", entry)
            paths_grid.attach(entry, 1, i, 1, 1)
            
            # Botón examinar con mnemonic
            browse_button = Gtk.Button(label="_" + self._('browse'), use_underline=True)
            browse_button.set_name(f"config_browse_{entry_name}")
            browse_button.connect("clicked", self.on_browse_clicked, entry_name)
            paths_grid.attach(browse_button, 2, i, 1, 1)

        # Selector de cores con ID
        cores_label = Gtk.Label(label=self._('cores'))
        cores_label.set_name("config_label_cores")
        cores_label.set_halign(Gtk.Align.START)
        paths_grid.attach(cores_label, 0, 3, 1, 1)

        self.cores_combo = Gtk.ComboBoxText()
        max_cores = get_cpu_count()
        for i in range(1, max_cores + 1):
            self.cores_combo.append_text(str(i))
        default_cores = max(1, max_cores // 2)
        self.cores_combo.set_active(default_cores - 1)
        paths_grid.attach(self.cores_combo, 1, 3, 1, 1)

        # Campo de volumen con ID
        volume_label = Gtk.Label(label=self._('volume_name'))
        volume_label.set_name("config_label_volume")
        volume_label.set_halign(Gtk.Align.START)
        paths_grid.attach(volume_label, 0, 4, 1, 1)
        
        self.volume_entry = Gtk.Entry(text="SOPLOS-LINUX")
        paths_grid.attach(self.volume_entry, 1, 4, 1, 1)

        # Sección de exclusiones e inclusiones
        filters_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.config_page.pack_start(filters_box, True, True, 0)
        
        self._create_text_section(filters_box, self._('exclusions'), "exclusions", DEFAULT_EXCLUSIONS, 150)
        self._create_text_section(filters_box, self._('inclusions'), "inclusions", DEFAULT_INCLUSIONS, 150)

        # Botones con IDs
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        button_box.set_halign(Gtk.Align.END)
        self.config_page.pack_end(button_box, False, False, 10)
        
        self.iso_structure_button = Gtk.Button(label="_" + self._('create_iso_structure'), use_underline=True)
        self.iso_structure_button.set_name("config_button_structure")
        self.iso_structure_button.get_style_context().add_class("suggested-action")
        self.iso_structure_button.connect("clicked", self.setup_iso_structure)
        button_box.pack_start(self.iso_structure_button, False, False, 10)
        
        self.btn_save_config = Gtk.Button(label="_" + self._('save_config'), use_underline=True)
        self.btn_save_config.set_name("config_button_save")
        self.btn_save_config.get_style_context().add_class("suggested-action")
        self.btn_save_config.connect("clicked", self.save_config)
        button_box.pack_start(self.btn_save_config, False, False, 10)

    def on_browse_clicked(self, button, entry_name):
        """Maneja el clic en los botones de examinar"""
        if entry_name == "iso_name":
            # Diálogo especial para nombre de ISO
            dialog = Gtk.FileChooserDialog(
                title=self._('save_iso_as'),
                parent=self,
                action=Gtk.FileChooserAction.SAVE,
                buttons=(
                    Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                    Gtk.STOCK_SAVE, Gtk.ResponseType.OK
                )
            )
            
            # Añadir filtro para archivos .iso
            filter_iso = Gtk.FileFilter()
            filter_iso.set_name(self._('iso_files'))
            filter_iso.add_pattern("*.iso")
            dialog.add_filter(filter_iso)
            
            # Establecer nombre actual si existe
            current_name = self.iso_name_entry.get_text()
            if not current_name.endswith('.iso'):
                current_name += '.iso'
            dialog.set_current_name(current_name)
            
            # Establecer carpeta actual
            current_iso_dir = self.iso_dir_entry.get_text()
            if os.path.exists(current_iso_dir):
                dialog.set_current_folder(current_iso_dir)
            
            response = dialog.run()
            if response == Gtk.ResponseType.OK:
                file_path = dialog.get_filename()
                # Extraer solo el nombre del archivo
                iso_name = os.path.basename(file_path)
                self.iso_name_entry.set_text(iso_name)
            
            dialog.destroy()
        else:
            # Código existente para selección de directorios
            dialog = Gtk.FileChooserDialog(
                title=self._('select_folder'),
                parent=self,
                action=Gtk.FileChooserAction.SELECT_FOLDER,
                buttons=(
                    self._('create_folder'), Gtk.ResponseType.APPLY,
                    Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                    Gtk.STOCK_OPEN, Gtk.ResponseType.OK
                )
            )
            
            # Establecer el directorio actual como punto de inicio
            current_path = getattr(self, f"{entry_name}_entry").get_text()
            if os.path.exists(current_path):
                dialog.set_current_folder(current_path)
            
            while True:
                response = dialog.run()
                if response == Gtk.ResponseType.OK:
                    folder_path = dialog.get_filename()
                    getattr(self, f"{entry_name}_entry").set_text(folder_path)
                    break
                elif response == Gtk.ResponseType.APPLY:
                    # Diálogo para crear nuevo directorio
                    create_dialog = Gtk.Dialog(
                        self._('create_folder'),
                        self,
                        0,
                        (
                            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                            Gtk.STOCK_OK, Gtk.ResponseType.OK
                        )
                    )
                    box = create_dialog.get_content_area()
                    label = Gtk.Label(label=self._('folder_name'))
                    box.add(label)
                    entry = Gtk.Entry()
                    box.add(entry)
                    box.show_all()
                    create_response = create_dialog.run()
                    dir_name = entry.get_text()
                    create_dialog.destroy()
                    if create_response == Gtk.ResponseType.OK and dir_name:
                        parent_dir = dialog.get_current_folder()
                        new_dir = os.path.join(parent_dir, dir_name)
                        try:
                            command = ['pkexec', 'mkdir', '-p', new_dir]
                            subprocess.run(command, check=True)
                            dialog.set_current_folder(new_dir)
                        except subprocess.CalledProcessError:
                            self.show_error(self._('error_create_dir'))
                        continue
                    
                else:
                    # Cancelar o cerrar diálogo
                    dialog.destroy()
                    return
    
    def _create_text_section(self, container, title, name, default_text, height):
        """Crea una sección de texto con scroll"""
        frame = Gtk.Frame(label=title)
        frame.set_name(f"frame_{name}")  # Añadir ID al frame
        container.pack_start(frame, True, True, 10)
        
        scroll = Gtk.ScrolledWindow()
        scroll.set_min_content_height(height)
        frame.add(scroll)
        
        text_view = Gtk.TextView()
        text_view.set_wrap_mode(Gtk.WrapMode.NONE)
        text_view.override_font(Pango.FontDescription.from_string("Monospace 10"))
        text_view.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.95, 0.95, 0.95, 1))
        text_view.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0, 0, 0, 1))
        
        buffer = text_view.get_buffer()
        buffer.set_text(default_text)
        
        scroll.add(text_view)
        setattr(self, f"{name}_text", text_view)
    
    def _handle_step_completion(self, step_name, success):
        """Maneja la finalización de un paso"""
        if success:
            self.step_completed[step_name] = True
            self.update_buttons()
            self.update_progress()

    def update_progress(self):
        """Actualiza el progreso basado en los pasos completados"""
        progress = 0
        for step, completed in self.step_completed.items():
            if completed and step in PROGRESS_VALUES:
                progress = PROGRESS_VALUES[step]
        
        self.progress.set_fraction(progress)
        self.progress.set_text(f"{int(progress * 100)}%")
    
    def update_buttons(self):
        """Actualiza el estado de los botones según el progreso"""
        if not hasattr(self, 'steps_grid'):
            return

        # Primer botón siempre activo
        self.steps_grid.buttons["create_dir"].set_sensitive(True)

        # Resto de botones dependen del paso anterior
        self.steps_grid.buttons["rsync"].set_sensitive(self.step_completed["create_dir"])
        self.steps_grid.buttons["squashfs"].set_sensitive(self.step_completed["rsync"])
        self.steps_grid.buttons["clean_temp"].set_sensitive(self.step_completed["squashfs"])
        self.steps_grid.buttons["create_iso"].set_sensitive(self.step_completed["clean_temp"])
        self.steps_grid.buttons["remove_squashfs"].set_sensitive(self.step_completed["create_iso"])
    
    def append_output(self, text):
        """Añade texto al área de salida"""
        buffer = self.output_text.get_buffer()
        buffer.insert(buffer.get_end_iter(), text)
        self.output_text.scroll_to_iter(buffer.get_end_iter(), 0.0, False, 0.0, 0.0)
    
    def show_message(self, title, message):
        """Muestra un diálogo de mensaje"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def show_error(self, message):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text="Error"
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def close_application(self, widget):
        """Cierra la aplicación con confirmación"""
        dialog = ConfirmDialog(self, self.logo_path)
        if dialog.confirm(self._('exit_app'), self._('confirm_exit')):
            try:
                # Limpiar caché antes de salir
                from main import clean_pycache
                clean_pycache()
            except Exception as e:
                print(f"Error limpiando caché: {e}")
            self.get_application().quit()
    
    def cancel_operation(self, widget):
        """Cancela la operación en curso con confirmación"""
        dialog = ConfirmDialog(self, self.logo_path)
        if dialog.confirm(self._('cancel_op'), self._('confirm_cancel')):
            self.command_runner.cancel_current_process()
            self.append_output(f"\n❌ {self._('operation_cancelled')}\n")
            self.btn_cancel.set_sensitive(False)
            self.btn_auto.set_sensitive(True)
            # Resetear el estado
            for key in self.step_completed:
                self.step_completed[key] = False
            self.update_buttons()
            self.progress.set_fraction(0.0)
            self.update_progress_text()

    # Métodos para los pasos individuales
    def create_directory(self, widget):
        """Paso 1: Crear directorio temporal"""
        def on_complete(success):
            if success:
                self._handle_step_completion("create_dir", True)
            else:
                self.show_error("Error al crear el directorio temporal")
                self.btn_cancel.set_sensitive(False)
                self.btn_auto.set_sensitive(True)
        
        self.progress.set_fraction(0.0)  # Reiniciar progreso
        self.btn_cancel.set_sensitive(True)
        self.iso_builder.create_directory(on_complete)

    def rsync_files(self, widget):
        """Paso 2: Copiar archivos del sistema con rsync"""
        def on_complete(success):
            if success:
                self._handle_step_completion("rsync", True)
                self.progress.set_fraction(1.0)  # Asegurar 100% al completar
            else:
                self.show_error("Error al copiar archivos del sistema")
                self.btn_cancel.set_sensitive(False)
                self.btn_auto.set_sensitive(True)

        self.progress.set_fraction(0.0)  # Reiniciar progreso
        # Obtener exclusiones e inclusiones personalizadas
        exclusions_buffer = self.exclusions_text.get_buffer()
        inclusions_buffer = self.inclusions_text.get_buffer()
        
        custom_exclusions = exclusions_buffer.get_text(
            exclusions_buffer.get_start_iter(),
            exclusions_buffer.get_end_iter(),
            True
        )
        
        custom_inclusions = inclusions_buffer.get_text(
            inclusions_buffer.get_start_iter(),
            inclusions_buffer.get_end_iter(),
            True
        )
        
        self.btn_cancel.set_sensitive(True)
        self.btn_auto.set_sensitive(False)
        self.iso_builder.rsync_files(
            on_complete, 
            custom_exclusions=custom_exclusions,
            custom_inclusions=custom_inclusions
        )

    def create_squashfs(self, widget):
        """Paso 3: Crear archivo squashfs"""
        def on_complete(success):
            if success:
                self._handle_step_completion("squashfs", True)
            else:
                self.show_error("Error al crear squashfs")

        self.iso_builder.create_squashfs(on_complete)

    def clean_temp_dir(self, widget):
        """Paso 4: Eliminar directorio temporal"""
        def on_complete(success):
            if success:
                self._handle_step_completion("clean_temp", True)
            else:
                self.show_error("Error al limpiar directorio temporal")

        self.iso_builder.clean_temp_dir(on_complete)

    def create_iso(self, widget):
        """Paso 5: Crear imagen ISO"""
        def on_complete(success):
            if success:
                self._handle_step_completion("create_iso", True)
            else:
                self.show_error("Error al crear ISO")

        self.iso_builder.create_iso(on_complete)

    def remove_squashfs(self, widget):
        """Paso 6: Eliminar archivo squashfs"""
        def on_complete(success):
            if success:
                self._handle_step_completion("remove_squashfs", True)
                self.show_message("Proceso completado", 
                                f"La imagen ISO ha sido creada con éxito en:\n{self.iso_builder.iso_dir}/{self.iso_builder.iso_name}")
            else:
                self.show_error("Error al eliminar squashfs")

        self.iso_builder.remove_squashfs(on_complete)
    
    def run_all_steps(self, widget):
        """Ejecuta todos los pasos secuencialmente"""
        if not self.iso_builder.check_iso_structure():
            dialog = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text=self._('structure_not_found')
            )
            dialog.format_secondary_text(self._('structure_not_found_msg'))
            
            response = dialog.run()
            dialog.destroy()
            
            if response == Gtk.ResponseType.YES:
                self.setup_iso_structure(None)
                return
            else:
                self.show_error(self._('structure_error'))
                return

        # Configurar botones al inicio
        self.btn_auto.set_sensitive(False)
        self.btn_cancel.set_sensitive(True)

        # Reiniciar estado
        for key in self.step_completed:
            self.step_completed[key] = False
        self.update_buttons()
        self.progress.set_fraction(0.0)
        self.update_progress_text()
        self.append_output(f"\n🚀 {self._('starting_auto_process')}\n")

        # Obtener exclusiones e inclusiones personalizadas
        exclusions_buffer = self.exclusions_text.get_buffer()
        inclusions_buffer = self.inclusions_text.get_buffer()
        
        custom_exclusions = exclusions_buffer.get_text(
            exclusions_buffer.get_start_iter(),
            exclusions_buffer.get_end_iter(),
            True
        )
        
        custom_inclusions = inclusions_buffer.get_text(
            inclusions_buffer.get_start_iter(),
            inclusions_buffer.get_end_iter(),
            True
        )
        
        def on_complete(success):
            if not success and not self.command_runner.is_cancelled:
                self.show_error("Error en el proceso automático")
            
            # Restaurar botones independientemente del resultado
            self.btn_auto.set_sensitive(True)
            self.btn_cancel.set_sensitive(False)
            
            # Si fue exitoso, mostrar mensaje final
            if success:
                self.progress.set_fraction(1.0) 
                self.progress.set_text("100%")
                self.show_message(
                    "Proceso completado", 
                    f"La imagen ISO ha sido creada con éxito en:\n{self.iso_builder.get_iso_path()}"
                )

        # Verificar si ya hay una operación en curso
        if self.command_runner.current_process:
            self.show_error("Ya hay una operación en curso")
            return
        
        # Obtener el nombre del volumen configurado
        volume_name = self.volume_entry.get_text()
        self.iso_builder.build_iso(
            volume_name=volume_name, 
            on_complete=on_complete,
            custom_exclusions=custom_exclusions,
            custom_inclusions=custom_inclusions
        )

    def save_config(self, widget):
        """Guardar la configuración actual"""
        try:
            # Obtener rutas y nombres
            temp_dir = self.temp_dir_entry.get_text()
            iso_dir = self.iso_dir_entry.get_text()
            iso_name = self.iso_name_entry.get_text()
            
            # Actualizar rutas en iso_builder
            self.iso_builder.set_paths(temp_dir, iso_dir)
            self.iso_builder.iso_name = iso_name
            
            self.show_message(
                "Configuración guardada",
                "La configuración se ha actualizado correctamente."
            )
        except Exception as e:
            self.show_error(f"Error al guardar la configuración: {str(e)}")

    def update_progress_text(self):
        """Actualiza el texto de la barra de progreso"""
        fraction = self.progress.get_fraction()
        percentage = int(fraction * 100)
        self.progress.set_text(f"{percentage}%")

    def setup_iso_structure(self, widget):
        """Paso previo: Configurar estructura de ISO y archivos de arranque"""
        iso_dir = self.iso_dir_entry.get_text()
        grub_cfg = os.path.join(iso_dir, "boot/grub/grub.cfg")
        
        # Construir los comandos base
        commands = [
            f'mkdir -p {iso_dir}/live',
            f'mkdir -p {iso_dir}/boot/grub'
        ]
        
        # Copiar kernel y initrd solo si no existen
        if not os.path.exists(os.path.join(iso_dir, "boot/vmlinuz")):
            commands.append(f'cp $(ls -v /boot/vmlinuz* | tail -n 1) {iso_dir}/boot/vmlinuz')
        
        if not os.path.exists(os.path.join(iso_dir, "boot/initrd.img")):
            commands.append(f'cp $(ls -v /boot/initrd.img* | tail -n 1) {iso_dir}/boot/initrd.img')
        
        # Crear grub.cfg solo si no existe
        if not os.path.exists(grub_cfg):
            commands.append(f'echo "{GRUB_CONFIG_TEMPLATE}" > {grub_cfg}')
        
        command = ['pkexec', 'bash', '-c', ' && '.join(commands)]
        
        def on_complete(success):
            if success:
                self.show_message(
                    "Estructura ISO verificada",
                    "La estructura de directorios para la ISO está lista."
                )
            else:
                self.show_error("Error al verificar/crear la estructura ISO")
        
        self.command_runner.run_command(command, on_complete)

    def clean_caches(self, widget):
        """Manejador para el botón de limpieza"""
        def on_complete(success):
            if success:
                self.show_message(
                    "Limpieza Completada",
                    "Se han limpiado todas las cachés y archivos temporales"
                )
            else:
                self.show_error("Error durante la limpieza")
            self.btn_clean.set_sensitive(True)
        
        self.btn_clean.set_sensitive(False)
        self.iso_builder.clean_caches(on_complete)

    def update_real_progress(self, progress):
        """Actualiza el progreso real basado en la salida del comando"""
        if progress is not None:
            progress_value = max(0, min(1, progress))  # Asegurar que el progreso está entre 0 y 1
            def update():
                self.progress.set_fraction(progress_value)
                self.progress.set_text(f"{int(progress_value * 100)}%")
                return False
            GLib.idle_add(update)

    def on_language_changed(self, combo):
        """Maneja el cambio de idioma"""
        new_lang = combo.get_active_id()
        if new_lang != self.lang:
            self.lang = new_lang
            self._ = lambda key: get_translation(key, self.lang)
            self.update_interface_language()

    def update_interface_language(self):
        """Actualiza todos los textos de la interfaz al nuevo idioma"""
        # Actualizar título de la ventana
        self.set_title(self._('window_title'))
        
        # Actualizar etiquetas de pestañas
        self.notebook.set_tab_label_text(self.main_page, self._('main_tab'))
        self.notebook.set_tab_label_text(self.config_page, self._('config_tab'))
        
        # Actualizar botones
        self.btn_auto.set_label("_" + self._('auto'))
        self.btn_clean.set_label("_" + self._('clean_caches'))
        self.btn_cancel.set_label("_" + self._('cancel'))
        self.btn_close.set_label("_" + self._('close'))
        
        # Actualizar botones de pasos con atajos
        steps = [
            ("create_dir", "_1. " + self._('create_dir_button')),
            ("rsync", "_2. " + self._('copy_files')),
            ("squashfs", "_3. " + self._('create_squashfs')),
            ("clean_temp", "_4. " + self._('clean_temp')),
            ("create_iso", "_5. " + self._('build_iso')),
            ("remove_squashfs", "_6. " + self._('clean_squashfs'))
        ]
        
        for name, label in steps:
            if name in self.steps_grid.buttons:
                self.steps_grid.buttons[name].set_label(label)
        
        # Actualizar etiquetas de configuración
        self.update_config_labels()
        
        # Actualizar historial de salida
        self.output_text.get_buffer().set_text("")  # Limpiar historial

    def update_config_labels(self):
        """Actualiza las etiquetas en la pestaña de configuración"""
        grid = self.config_page.get_children()[0]
        
        # Actualizar usando los IDs únicos
        for child in grid.get_children():
            if child is None:
                continue
                
            name = child.get_name()
            if name is None:
                continue

            if isinstance(child, Gtk.Label):
                if name == "config_label_temp_dir":
                    child.set_text(self._('temp_dir'))
                elif name == "config_label_iso_dir":
                    child.set_text(self._('iso_dir'))
                elif name == "config_label_iso_name":
                    child.set_text(self._('iso_name'))
                elif name == "config_label_cores":
                    child.set_text(self._('cores'))
                elif name == "config_label_volume":
                    child.set_text(self._('volume_name'))
            elif isinstance(child, Gtk.Button):
                if name.startswith("config_browse_"):
                    child.set_label("_" + self._('browse'))

        # Actualizar botones principales usando referencias directas
        if hasattr(self, 'iso_structure_button'):
            self.iso_structure_button.set_label("_" + self._('create_iso_structure'))
        if hasattr(self, 'btn_save_config'):
            self.btn_save_config.set_label("_" + self._('save_config'))

        # Actualizar frames de exclusión/inclusión
        for child in self.config_page.get_children():
            if isinstance(child, Gtk.Box):
                for frame in child.get_children():
                    if isinstance(frame, Gtk.Frame):
                        name = frame.get_name()
                        if name == "frame_exclusions":
                            frame.set_label(self._('exclusions'))
                        elif name == "frame_inclusions":
                            frame.set_label(self._('inclusions'))