#!/usr/bin/env python3
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk
import os
import sys

class DebugWindow(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="WM_CLASS Debug")
        self.set_default_size(400, 300)
        
        # Datos del entorno
        env_wmclass = os.environ.get("WMCLASS", "No establecido")
        startup_id = os.environ.get("GDK_STARTUP_NOTIFICATION_ID", "No establecido")
        
        # Crear interfaz
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(box)
        
        # Etiquetas para información del sistema
        env_label = Gtk.Label(label=f"WMCLASS (env): {env_wmclass}")
        startup_label = Gtk.Label(label=f"GDK_STARTUP_NOTIFICATION_ID: {startup_id}")
        
        # Botón para mostrar información de la ventana actual
        check_button = Gtk.Button(label="Verificar WM_CLASS de esta ventana")
        check_button.connect("clicked", self.check_wmclass)
        
        # Área de texto para resultados
        self.result_text = Gtk.TextView()
        self.result_text.set_editable(False)
        scroll = Gtk.ScrolledWindow()
        scroll.set_hexpand(True)
        scroll.set_vexpand(True)
        scroll.add(self.result_text)
        
        # Agregar widgets al box
        box.pack_start(env_label, False, False, 0)
        box.pack_start(startup_label, False, False, 0)
        box.pack_start(check_button, False, False, 0)
        box.pack_start(scroll, True, True, 0)
        
        # Conectar señales
        self.connect("destroy", Gtk.main_quit)
        
    def check_wmclass(self, button):
        # Forzar que la ventana se realice completamente
        self.realize()
        
        # Obtener información de WM_CLASS usando xprop
        try:
            import subprocess
            window_id = self.get_window().get_xid()
            result = subprocess.run(
                ["xprop", "-id", str(window_id)], 
                capture_output=True, 
                text=True
            )
            
            # Actualizar el área de texto con los resultados
            buffer = self.result_text.get_buffer()
            buffer.set_text(result.stdout)
            
        except Exception as e:
            buffer = self.result_text.get_buffer()
            buffer.set_text(f"Error: {str(e)}")

if __name__ == "__main__":
    # Establecer WM_CLASS explícitamente para pruebas
    wmclass = sys.argv[1] if len(sys.argv) > 1 else "com.soplos.isobuilder"
    print(f"Configurando WM_CLASS como: {wmclass}")
    window = DebugWindow()
    window.set_wmclass(wmclass, wmclass)
    window.show_all()
    Gtk.main()
