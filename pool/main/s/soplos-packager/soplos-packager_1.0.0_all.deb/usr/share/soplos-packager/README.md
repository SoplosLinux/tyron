# Soplos Packager

## 🎯 Descripción
Herramienta gráfica para crear y gestionar paquetes Debian (.deb) de forma sencilla.

## ✨ Características
- 📦 Creación visual de paquetes .deb
- 🔍 Detección automática de dependencias
- 🖼️ Integración de iconos y .desktop
- 👁️ Vista previa del paquete
- 🌍 Soporte multiidioma
- ✅ Validación en tiempo real

## 🛠️ Requisitos
- Python 3.8+
- GTK 3.0
- dpkg-dev
- policykit-1

## 📥 Instalación
```bash
# Dependencias
sudo apt install python3-gi python3-xlib gir1.2-gtk-3.0 dpkg-dev policykit-1 python3-dev libgtk-3-0

# Instalación
sudo pip3 install .
```

## 🔧 Funcionalidades
- Creación de paquetes
- Edición de metadatos
- Gestión de dependencias
- Scripts de pre/post instalación
- Validación de paquetes
- Firma digital

## ⚡ Dependencias Python
- PyGObject >= 3.0.0
- python-gi >= 3.0
- python-xlib >= 0.20
- setuptools >= 40.0

## 🌍 Idiomas
- 🇪🇸 ES  - 🇬🇧 EN
- 🇫🇷 FR  - 🇩🇪 DE
- 🇮🇹 IT  - 🇵🇹 PT
- 🇷🇴 RO  - 🇷🇺 RU

## 📞 Contacto
- **Web**: https://soploslinux.com/
- **GitHub**: https://github.com/SoplosLinux
- **Email**: info@soploslinux.com

## 📄 Licencia
GPL-3.0 © 2024 Soplos Team