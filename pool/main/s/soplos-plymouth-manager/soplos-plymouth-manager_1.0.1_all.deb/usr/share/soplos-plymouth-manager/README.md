# Soplos Plymouth Manager

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)]()

Un gestor de temas Plymouth simple e intuitivo que te permite previsualizar, instalar y aplicar temas de arranque fácilmente.

*A simple and intuitive Plymouth theme manager that allows you to preview, install and apply boot splash themes easily.*

## 📝 Descripción

Soplos Plymouth Manager es un gestor de temas de arranque Plymouth para Soplos Linux que permite previsualizar, instalar y aplicar temas de arranque de forma sencilla e intuitiva.

## ✨ Características

- Previsualización de temas Plymouth
- Instalación sencilla de nuevos temas
- Aplicación inmediata de temas
- Configuración avanzada
- Interfaz gráfica intuitiva
- Soporte para múltiples idiomas

## 📸 Capturas de pantalla

### Lista de temas disponibles
![Lista de temas disponibles](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-plymouth-manager/screenshots/screenshot1.png)

### Previsualización del tema
![Previsualización del tema](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-plymouth-manager/screenshots/screenshot2.png)

### Configuración avanzada
![Configuración avanzada](https://raw.githubusercontent.com/SoplosLinux/tyron/refs/heads/main/media/soplos-plymouth-manager/screenshots/screenshot3.png)

## 🔧 Instalación

```bash
# Instrucciones de instalación pendientes
```

## 🌐 Idiomas soportados

- Español
- Inglés
- Francés
- Portugués
- Alemán
- Italiano
- Ruso
- Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)

## 📦 Versiones

### v1.0.0 (08/05/2025)
- Versión inicial
