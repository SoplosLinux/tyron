# Soplos Plymouth Manager

## 📝 Descripción
Aplicación gráfica para gestionar y personalizar los temas de Plymouth en sistemas Linux de manera sencilla e intuitiva.

## ✨ Características
- 🎨 Gestión visual de temas Plymouth
- 📥 Instalación de nuevos temas
- 👁️ Previsualización en tiempo real
- 🔄 Cambio de tema activo
- ⚙️ Configuración avanzada
- 🔒 Validación de temas

## 🛠️ Requisitos
- Sistema Linux
- Plymouth instalado
- Permisos de administrador
- Python 3.6+
- GTK 3.0

## 📥 Instalación
```bash
sudo apt install soplos-plymouth-manager
```

## 🔧 Funcionalidades
- Gestión de temas Plymouth
- Previsualización de animaciones
- Configuración de resolución
- Backup de temas
- Importación/exportación

## 📞 Contacto
- **Web**: https://soploslinux.com/
- **GitHub**: https://github.com/SoplosLinux
- **Email**: info@soploslinux.com

## 📄 Licencia
GPL-3.0 © 2024 Soplos Team
